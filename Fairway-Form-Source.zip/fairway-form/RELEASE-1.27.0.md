# Final Form - Disc Golf 1.27.0

Coaching now explains what is visible, why it matters, what to try or keep, and
how to check the next set. The default view shows a real practice comparison
with setup, steps and an outcome check, plus a relevant article/tutorial link
and summary. Detailed and spoken guidance follow the same topic and task.
Positive patterns receive maintenance advice; unknown/uncertain evidence does
not become an invented fault. Estimated reviews no longer send every selected
coaching topic to release-only instruction.

Eight new practical tasks include flight-window scoring, baseline/one-step
comparisons, connected-turn work and controlled grip comparisons. Their counts
are app starting tasks, not validated training doses. Forehand and putting
remain separate from backhand instructions.

Technique library now offers Practical lessons, Research & sources and Disc
flight references. It has 100 lessons, 77 distinct research resources from 81
stable source records, and all 1,092 dated built-in disc references. Every
registered source is searchable even without a lesson. Overviews explain the
subject and actual access basis. External pages/videos need internet; source
summaries remain offline. See COACHING-CLARITY-1.27.0.md for research and limits.

## Verification

711 JavaScript tests passed; zero failures/skips/cancellations. Changed syntax,
13 serialized browser checked-step expressions and 93 offline-shell paths passed
static checks. The local browser run was BLOCKED by socket permissions. No
local browser/model, signed APK or physical-phone verification is claimed.
Mandatory GitHub browser/model, Android compile and APK checks remain enabled.
This update does not change event detection, model weights or video decoding,
and does not establish measured coaching effectiveness.

## Update

Replace repository-root Fairway-Form-Source.zip in the same private repository
and commit. Keep the existing workflow and signing credentials. Once Actions
passes, download Fairway-Form-APK, extract and install the APK over the existing
app without uninstalling. No workflow edit is needed. Version 1.27.0; fallback
Android versionCode 48, with CI supplying its increasing code.

Open a review and check that the default plan includes its explanation, named
practice task and a relevant source. Try Browse → Research & sources and search
for a subject or publisher; use Disc flight references for a model/brand.
Opening a lesson from coaching should take you directly to the right section.
Package/origin, schema 5, signing, approved intro and saved data IDs are preserved.
