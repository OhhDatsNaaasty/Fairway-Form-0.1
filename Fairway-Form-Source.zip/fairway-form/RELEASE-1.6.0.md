# Fairway Form 1.6.0 — measure a throw with GPS

Caddy now has a visible Measure throw card above the player and hole controls. It uses two endpoint captures, not a walked route, a video distance estimate or the difference between two basket distances.

## Using it

1. Open an active hole in Caddy. At the throwing spot, tap **Start · measure throw**. Android asks for precise foreground location when needed. Choose Precise and While using the app. Weather's existing approximate permission alone is insufficient.
2. Stand still until the start is captured. Then throw, walk to the disc's **first landing point**, and tap **Stop · at landing**. Hold the phone still while that reading settles. A roll or skip to the resting place is not carry.
3. Read the GPS distance and reported uncertainty. Feet is the measurement card's default; its independent meters option changes only the display. The feedback value converts to the current caddy units automatically.
4. Tap **Save throw**. This saves a distance draft with the active hole/throw and fills Actual throw carry in **What happened?** It does not advance the lie. If you have not made a caddy plan, enter the basket distance/line and choose a disc to open that feedback panel; the measurement will still be there.
5. Complete the actual disc, release, result and remaining-distance feedback, then tap **Record throw … & plan next lie**. The GPS distance and uncertainty attach to that physical bag copy. The next throw starts with a clean measurement.

Cancel discards an unsaved capture or result. Start over begins a new capture at the throwing spot. Changing holes or recording a throw clears unsaved endpoint coordinates. Leaving Caddy, backgrounding or native pause stops an active location watch; a captured start remains in memory so you can retry Stop at the landing point. Closing/restarting the app loses an unsaved start; a successful Save throw retains the distance draft without saving coordinates. Cancel after Save does not undo the saved feedback draft; it resets the measuring card.

## Accuracy and learning

Phone GPS cannot reliably meet a 1–2 foot target. Trees, reflected signals, receiver quality and the location provider all matter. Both endpoint accuracies are shown; their sum is a conservative indicator for the two-point distance, not a guaranteed bound or a certified confidence interval. Very short throws may be indistinguishable from GPS error. Use a tape or a rangefinder with a suitable stated accuracy for more precise manual measurements.

The app requests fresh high-accuracy readings and allows time to settle. It retains the best recent stationary fix and its original reported accuracy. It does not divide the error by the number of readings or pretend averaging removes GPS bias. Coarse/stale/moving/very uncertain readings are rejected or timed out. The distance uses WGS84 ellipsoidal geodesy and is horizontal straight-line carry, not a three-dimensional flight arc.

GPS logs have their own averages and farthest estimates in disc history, distinct from measured and estimated entries. Only GPS throws whose combined reported uncertainty is at most 10 meters AND 10% of carry are eligible for range learning, alongside comparable clear measured throws. Three eligible comparable throws are still required, and existing hand, style, angle, conditions and execution exclusions apply. These are app quality rules, not a certification of GPS accuracy. GPS provenance and uncertainty survive backup/restore. Editing the distance manually removes the GPS claim; it becomes estimated unless you deliberately select a measured source.

## Updating on your Android phone

Replace the repository-root **Fairway-Form-Source.zip** in the SAME GitHub repository and commit it. Keep the exact filename, existing workflow, APP_SIGNING_PASSWORD and .fairway-signing.enc. After Actions succeeds, download/extract Fairway-Form-APK and install Fairway-Form.apk over the current app. Check Version 1.6.0 in App & settings. No workflow change is required.

Package com.fairwayform.app, the appassets origin, database version 4 and the existing signing identity remain. Local versionCode is 18; GitHub continues to supply its increasing code. The Kotlin BOM dependency fix remains. ACCESS_FINE_LOCATION is added, requested with coarse permission for Android's precise-location upgrade flow. No background-location permission, continuous tracking service, map API or new native dependency is added. Precise location is optional; manual distance, coaching and caddy planning still work without it.

## Verification and outdoor checks

307 automated tests pass, including 21 measurement/geodesy/permission/history tests and eight new caddy integration tests. Static JS/import/control/cache/XML/shell/version checks pass. The CI browser smoke script now exercises real Start/Stop controls against a simulated geolocation provider, save/record/history and backup provenance; it never requests an actual test-runner location.

Full browser/model smoke and signed APK compilation remain for GitHub Actions. Local Chromium cannot launch under the workspace's socket restrictions, and there is no configured Android SDK/Gradle installation here. This download is editable source, not a compiled APK. Live GPS has not been field-validated on your phone.

On the phone, check a known tape/rangefinder baseline in open sky and under trees, allow/deny/approximate-only permission, the upgrade from weather's coarse permission, Cancel during each capture, screen lock during capture/walking, feet/meters conversion, Save before/after a plan, app restart after Save, next-throw reset, and GPS history/correction/backup. Compare uncertainty as well as the displayed distance. Do not infer foot-level accuracy from a whole-foot display.

Research and implementation details: GPS-RESEARCH-1.6.0.md.
