# Fairway Form 1.9.1 — repair the course build check

The failed GitHub step was the browser smoke check, before Android compilation. Its earlier bag-removal checks deliberately removed all physical bag copies. The newly added course scenario then saved a hole layout and requested a recommendation without adding any discs to the bag. Caddy returned no candidates, as required for bag-only recommendations, and the test timed out with “Course tee did not receive a plan.”

The course scenario now seeds its own explicitly named QA TeeBird bag copy in the temporary browser profile before loading the course. It requires the resulting plan to select that exact copy, exercises feedback and next-hole progression, and removes its copy afterward. The prior empty-bag/removal checks remain. No test data is added to the shipped application.

A new regression reproduces selecting a 750-foot saved course tee with an empty bag, verifies that no disc is invented, adds the scenario's bag copy, and verifies recommendation, saved throw, unchanged tee distance, and progression to the next course hole. Browser timeouts now include Caddy status, course status, readiness and bag count so a future failure has actionable context.

The 850-mold catalog, 28 brands, My Courses, simplified Caddy layout, existing user bags, histories and player profiles are retained. Database schema remains 5, package remains com.fairwayform.app, and the existing signing identity/workflow are retained. The local Android versionCode default is 22; CI still supplies its run number.

## Install the corrected build

1. Replace the repository-root Fairway-Form-Source.zip in the same GitHub repository and commit it. Keep that exact filename.
2. Keep the existing APK workflow, .fairway-signing.enc and APP_SIGNING_PASSWORD.
3. Once Actions succeeds, download/extract Fairway-Form-APK and install Fairway-Form.apk over the current app. Do not uninstall or clear app data.
4. App & settings should show Version 1.9.1.

## Validation

375 automated checks pass locally, including the new empty-bag-to-course-recommendation regression. JavaScript syntax/imports, embedded browser expressions, HTML controls, offline shell, Android XML and shell scripts, package identity, database version and release versions are checked separately. Full Chromium/model smoke checks and signed Android compilation still require GitHub Actions; no APK was compiled in this workspace.
