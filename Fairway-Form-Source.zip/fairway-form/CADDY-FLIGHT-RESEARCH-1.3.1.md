# Flight roles, chart references and personal distances — 1.3.1

Research checked 2026-10-21. This release uses manufacturer descriptions, published ratings, chart references and original planning rules. It does not turn those sources into a validated aerodynamic simulator. Chart artwork is linked rather than copied into the app. There is no trained disc-flight AI or automatic measurement of throw distance.

## Manufacturer findings used in the app

Innova's [flight-rating guide](https://www.innovadiscs.com/home/disc-golf-faq/flight-ratings-system/) explains speed, glide, turn, fade, power requirements and plastic differences. It cautions that brands rate differently and that the numbers are not exact trajectories. [Its wind guide](https://www.innovadiscs.com/tips/tips-for-playing-disc-golf-in-the-wind/) informs the headwind, tailwind, crosswind, gust and conservative-placement advice. The app does not convert wind into an exact distance bonus or penalty.

[Axiom's rating guide](https://axiomdiscs.com/flight-rating-system/) distinguishes speed requirements from an individual's distance. Its model pages and MVP's model pages supply power-dependent descriptions and flight-chart sections. The [Wave](https://mvpdiscsports.com/discs/wave/) and [Photon](https://mvpdiscsports.com/discs/photon/) illustrate why a driver's turn can differ with power and headwind. Published player-bag distances on those pages vary substantially; they are examples of particular players, not universal ranges transferred to this user.

[Discraft's Buzzz page](https://www.team.discraft.com/discs/buzzz) describes a controlled, line-holding midrange, while the [Nuke](https://www.team.discraft.com/discs/nuke) has a distance-driver role. The [manufacturer lineup chart](https://www.discraft.com/disc-golf-flight-charts-poster.flightchart) is also linked. Neither category is a universal maximum-distance limit.

[Discmania's chart](https://www.discmania.net/pages/flight-chart) distinguishes putters, approaches, midranges, fairway/control drivers and distance drivers. Model variants and older versions may differ. Its lineup information supports role separation, not a promise of carry.

[Prodigy's naming/plastic guide](https://prodigydisc.com/pages/flight-plastic-info) explains the PA/A/M/F/H/D families and stability ordering within a family. Its [PA-3](https://www.prodigydisc.com/products/prodigy-pa-3-300-firm-plastic), [M3](https://www.prodigydisc.com/products/prodigy-m3-350g-plastic) and [D6](https://prodigydisc.com/products/prodigy-d6-air-spectrum-plastic) pages provide mold-specific descriptions and chart sections. Old descriptions and updated ratings can differ; the catalog retains its dated reference ratings.

[Dynamic Discs Escape](https://www.dynamicdiscs.com/products/lucid-escape) supports the control-driver/glide role. [Latitude 64 Diamond](https://latitude64.com/products/opto-diamond) and [River](https://latitude64.com/collections/river) support developing-player and glide/control distinctions. The old River manufacturer URL redirects to its current collection; the direct product URL and a guessed global chart URL were unavailable during this research, so a specific nonexistent chart is not claimed.

[Westside Bear](https://westsidediscs.com/products/vip-bear) describes controllable fairway flight with power-dependent stability. [Trash Panda's starter lineup](https://trashpandadiscgolf.com/products/100-recycled-disc-golf-set) distinguishes Inner Core, Dune and Ozone roles and ratings. These pages provide role/flight guidance; they do not supply a universal distance table.

## Coverage and provenance

The bundled catalog now has 302 molds, including the researched MVP Photon. All 302 have an app role, broad estimated window, original qualitative flight sketch and an existing manufacturer/source link. Those do not imply a verified factory trajectory for every mold.

There are 21 additional original manufacturer-informed role summaries across all ten requested brands. Mold-specific manufacturer chart sections were verified for 42 catalog molds; two additional curated references point to Discmania's lineup chart. Another 40 molds can link to an explicitly labeled exact-four-number, same-type chart analogue. Manufacturer lineup charts or a flight/plastic guide provide additional references. Overall 183 molds have one of these chart/comparison/guide references; 119 retain their model/source link and clearly labeled app interpretation without an identified suitable chart reference.

The 30 newly verified Axiom/MVP chart-page URLs are enumerated in dist/lib/disc-flight-data.js under VERIFIED_MOLD_CHARTS. The curated references are in FLIGHT_REFERENCES. A manufacturer chart section or downloadable chart was verified; graphs were not digitized into measured coordinates, distances or launch-speed calibration. Source pages can change after the checked date.

An analogue must match speed, glide, turn, fade and catalog type. Same-brand candidates are preferred. It is labeled as a comparison, and its distance is never transferred. No different-number chart is silently substituted. The small inline curve is an original schematic of turn/fade direction, with no feet/meters axis, predicted landing point or obstacle-clearance claim. Hand and forehand/backhand mirror its orientation.

## App distance policy — explicitly an estimate

The following base windows are application assumptions for initial comparison, not manufacturer specifications, measured population averages, minimum throws or maximum possible distances:

| Role | Base planning window (feet) |
| --- | --- |
| Touch/catch style, speed up to 1.5 | 25–150 |
| Putt/approach | 50–225 |
| Other approach/utility, speed up to 4.5 | 75–250 |
| Midrange, speed up to 5.5 | 125–300 |
| Fairway, speed up to 8.5 | 175–350 |
| Control driver, speed up to 10.5 | 225–400 |
| Distance driver | 250–450 |

Role selection uses type and speed. For an uncalibrated mold, the endpoints receive a small heuristic glide/fade adjustment, clamped between 0.82 and 1.12, then round to 25-foot steps. When an entered general distance for this hand/style exists, an explicitly disclosed profile scaling uses that distance divided by 325, clamped to 0.35–1.5. The reference 325 and all coefficients are planning choices, not aerodynamic constants or claims about the user's arm speed. Differences in turn are handled in shape/line advice rather than being converted directly into feet.

A measured or entered disc-specific distance remains separate from this estimate. Three comparable clear-flight measured throws can establish a conditional average. Otherwise three calm, level, normal-effort clear-flight measurements can supply a baseline average. An entered comfortable distance is the next reference. Only when those are absent does a labeled role window help the comparison. A maximum never becomes routine carry. Estimated distances are stored and summarized separately; they do not become measured range.

There is no fixed putter tee-distance cutoff. The 1.3.0 cutoff was removed following the user's clarification. A reliable 300-foot putter can be a tee option, and the generic putter window above is never a hard eligibility limit. Measured and entered disc-specific distances take precedence over that window.

When no explicit landing point is entered and the basket exceeds 1.3 times the best available controlled reference, the caddy uses a staged comparison around 90% of that reference. A controlled speed limit narrows the pool used to establish this reference when suitable options exist. On straight, open targets beyond 400 feet, short-game roles receive a ranking penalty only when a controlled driving disc offers greater reference carry. A putter with demonstrated greater carry remains competitive. Driving roles receive a staged bonus only when their carry is at least 90% of the best controlled reference. All these coefficients are application assumptions, not aerodynamic constants.

The top three scored bag copies normally form the shortlist. If all three are putters, a midrange or driver can replace the third choice if it is within 10 ranking points of the leader, within any selected comfortable speed limit, and its reference covers the comparison target within the existing 8% reach margin after slope/headwind adjustments. The strongest choice remains first. This avoids filling the list with putter copies while forcing neither an unreachable alternative nor a high-speed disc beyond the player's comfort. Putting recommendations still use putting putters and comfort, separately from driving carry.

A putter-only bag remains usable for a reachable placement shot on a long hole; the app explains the absent driving option. The user must choose a real clear landing area. No rule establishes a safe path, predicts a final basket distance or counts the strokes needed. Basket distance stays separate from the comparison distance.


## Learning and persistence

Every recorded caddy throw already has a stable ID in the local caddyHoles IndexedDB store. This release adds optional actual carry, measured/estimated source and clear-flight status to that canonical record. The actual bag-copy ID, disc snapshot, hand/type, effort, line, slope, wind category/mph/gusts, wet status, available weather, outcome, actual remaining basket distance and notes remain attached. There is no duplicate statistics database to drift away from the hole log. Statistics are rebuilt from those durable records when needed.

All measured logs can contribute to the displayed historical measured average and farthest milestone; estimates get their own average/farthest summary. The recommendation reference excludes tree hits and early impacts. It separates bag copies, hands, throw types, effort, slope, wind strength/direction and wet conditions. Calm wind has no meaningful direction. If both weather temperatures are present, a conditional comparison also requires them within 8°C. That tolerance and the 20-most-recent qualifying sample limit are app choices. These logs cannot isolate wind from release angle, spin or execution; the UI presents them as local experience rather than causal science. Headwind/slope carry margins are not applied again when a matching-condition measured average already includes those conditions.

A distance to the basket before and after a shot is not measured carry: bends, lateral movement, roll and the target geometry can make subtraction misleading. Missing carry stays null, never zero. Putting travel does not become putting comfort or a driving reference.

Users can correct or clear a logged measurement from its bag history. The canonical hole entry is updated and statistics are recomputed. Reentering Caddy loads the corrected record rather than saving a stale copy over it. Pending draft saves are flushed before an editable bag view opens.

Bag backup schema 2 includes the bag, custom catalog and sanitized throw-history records. Existing schema-1 bag backups remain accepted. History is validated before the atomic bag/catalog/hole transaction, IDs are deduplicated, and current matching entries take priority over an older backup. New restored histories are archived as finished holes; merging additional history into a current hole also archives it to avoid an incorrect next-lie assumption. Original on-device photos/drafts are preserved for an existing matching hole. The backup excludes sign-image bytes, demographic profiles and location coordinates. It retains the selected throw conditions and sanitized weather metadata.

## Validation limits

216 automated tests pass, including 29 pure flight/history tests and the real-module UI integration cases. The GitHub browser smoke check was extended to save actual carry, show its bag statistics, correct it, and restore history without duplication. Static syntax, imports, controls, offline-cache entries, Android XML, versions and preserved package/database wiring are checked locally.

The local workspace cannot open its browser server (EPERM), and it lacks Gradle/Android SDK. Full browser, native compilation and phone verification must run through the existing GitHub workflow and the phone. No claim of successful Android compilation or actual manufacturer-calibrated distance prediction is made for this source update.
