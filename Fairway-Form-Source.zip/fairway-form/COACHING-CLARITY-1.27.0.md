# Descriptive coaching and a searchable research library — 1.27.0

The default coaching view was replacing fuller explanations with short stock
phrases, placing practice/source material in closed details, and linking every
estimated review to release help regardless of its selected topic. That made
a valid observation hard to understand or act on. This update changes the
presentation, practice selection and research access; it does not change the
throw-event detector, pose model or decoding pipeline.

## One explanation across the review

For thirteen supported coaching topics, guidance now provides:

- What the report actually observed, retaining contextual event times when useful.
- Why that movement matters, with camera/interpretation limits where needed.
- A concrete action, or maintenance advice for a reported positive pattern.
- What to compare in the next set to decide whether the cue helped.

Default, detailed and spoken coaching use the same evidence and topic guidance.
The unused one-line summary tables have been removed. An observation remains an
experiment rather than an invented fault. Unknown checks do not acquire personal
corrections. The release-check path remains for uncertain sequences, while a
supported automatic sequence can receive the observational coaching introduced
in 1.26.0. Existing praise/fault anchoring rules are unchanged.

The default view includes one selected focus, a named practice comparison,
replay buttons, one relevant external article/tutorial with an overview, and
internal lesson links. It does not send an estimated posture/coil/footwork
review to release-only instruction. Each deeper body check also has a named
external reference. A source explains an action; its existence does not prove
that this user has a fault or validate a numerical threshold.

Examples of practical tasks include baseline versus one-step support, contact
and release comparisons, a scored flight window, body-turn/target comparisons,
forehand setup comparisons and testing one grip adjustment. Eight new tasks join
the existing choices. Tasks specify setup, steps, a result check, what to record
and when to progress or simplify. Counts are starting tasks designed by the app,
not validated training doses. Individual shot types keep their own guidance.

## Sources and summaries

New research used the following primary/publisher material:

- [Ultiworld fieldwork planning](https://discgolf.ultiworld.com/2021/06/15/tuesday-tips-disc-golf-field-work-how-to-structure-practice-pt-2/):
  purpose, identifying strengths/weaknesses, journaling and manageable sessions.
- [Innova fieldwork guide](https://www.innovadiscs.com/innova-news/how-field-work-can-make-you-a-better-disc-golfer/):
  gap, distance-control and shot-shaping practice. App tasks are adaptations.
- [Overthrow extension lesson](https://www.overthrowdiscgolf.academy/lessons/extension-out-of-the-pocket):
  public transcript reviewed; it informs arm-opening context, not a rigid elbow.
- [UDisc / Overthrow backhand tutorial outline](https://udisc.com/blog/post/5-great-videos-how-to-throw-backhand-in-disc-golf):
  the written box-drill sequence and distinction between a demonstration pose
  and the non-throwing arm in a full throw. Video playback was not verified.
- [Discmania realistic putting practice](https://www.discmania.net/blogs/discover/be-a-better-disc-golf-putter-practice-in-reality),
  [Innova / Dave Dunipace putting transcript](https://www.innovadiscs.com/disc-golf-pro-tips/make-more-putts/),
  [Dynamic Discs putting strategy](https://blog.dynamicdiscs.com/2017/11/quick-tip-putting-strategy.html),
  and [Ultiworld slope putting](https://discgolf.ultiworld.com/2017/07/18/tuesday-tips-using-straddle-stance-uphill-downhill-putts/):
  searchable backfills for previously documented putting research. No quoted
  training percentage becomes a personal prediction. Old rule numbering is
  disclosed, with the current PDGA putting-rule source retained.
- [PDGA course design](https://www.pdga.com/course-development/design-elements),
  [PDGA par guidance](https://www.pdga.com/documents/par-guidelines), and
  [UDisc hyzer terminology](https://udisc.com/blog/post/meaning-origin-of-the-word-hyzer-in-disc-golf):
  clear overviews for course/layout and shot-language research.
- [Jyväskylä lead-leg thesis record](https://www.finna.fi/Record/jyx.123456789_102903?lng=en-gb):
  abstract/record only, not a full-thesis review. Lab force measurements do not
  validate phone force, joint-load or safety claims.
- [Innova rating definitions](https://www.innovadiscs.com/home/disc-golf-faq/flight-ratings-system/),
  [Discraft BuzzzSaw history](https://www.team.discraft.com/post/evolution-of-discraft-s-buzzzsaw), and
  [GPS accuracy FAQ](https://www.gps.gov/gps-accuracy):
  subject-specific reference entries for previously documented disc-version,
  flight-rating and measurement research. A manufacturer story is not measured
  performance; general GPS limits are not a particular phone calibration.

The audit is research/coaching-library-review-1.27.0.json. Twelve source records
and eight lessons were added. Head/non-throwing-arm headlines were clarified,
and the latter's explanation now matches its written tutorial reference.
No full videos, transcripts or third-party screenshots are bundled. No model
training, coaching-outcome trial or new real-video detection accuracy is claimed.

## Finding research in the app

Technique library has three Browse choices:

1. Practical lessons: 100 lessons with subject titles, summaries, expanded notes
   and practice ideas. Existing lesson IDs and coaching navigation are preserved.
2. Research & sources: every registered source is searchable even without a
   linked lesson. Duplicate URLs are combined for browsing: 81 stable source
   records represent 77 distinct resources. Access labels distinguish articles,
   outlines, transcripts, abstracts and model documentation.
3. Disc flight references: all 1,092 built-in catalog records expose their dated
   source type, ratings, existing role notes and available related chart links.
   This reuses catalog evidence; it is not a fresh review of 1,092 websites.

Search, topic and publisher filters apply to the selected view. Source/reference
cards render in groups of 30, with Show more. Opening a coaching lesson switches
back to lessons and clears incompatible filters. Source overviews work offline;
external articles/videos still need internet. New AGENTS.md guidance requires
future disc-golf research used by the app to be registered with an accurate
subject overview and access provenance.

## Validation

711 JavaScript tests passed, zero failures/skips/cancellations. Eleven new tests
cover shared default/detailed/spoken guidance, maintenance versus correction,
unknown evidence, source-topic matching, practical comparisons, forehand/putting
separation, searchable unlinked sources, duplicate URLs, catalog reference
coverage and escaped markup/provenance. Two existing presentation assertions were
updated for the expanded shared action and spoken practice text.

Changed JavaScript passed syntax checks. Thirteen embedded browser checked-step
expressions were expanded and parsed; all 93 offline-shell paths exist. A named,
bounded GitHub browser step checks visible coaching and source/reference browsing.
Existing real decoder/model, event-sequence and Android/APK gates remain enabled.

Fresh local browser run 365055a2-4295-4c5b-b552-1addee54406b on
2026-11-01T07:24:35Z returned BLOCKED by localhost socket EPERM in about 0.2 s.
No local browser/model, Android compile/signing, phone rendering or measured
coaching effectiveness pass is claimed. GitHub and device checks remain needed.

Android package, origin, schema 5, signing identity, intro and existing bag,
course and session IDs are unchanged. Saved report data is not silently rewritten.
