# Fairway Form 1.14.2 — Chrome test-startup fix

The course packaging check passed in the latest screenshot. The build then stopped before opening the app because the browser test waited 20 seconds for Chrome's debugger announcement. This happened before Gradle compilation and is separate from course-data availability.

## Fix

The browser check now connects over Chrome's supported debugging pipe instead of waiting for a specific stderr line, discovering a random debugging port and fetching a target list. It verifies an actual Browser.getVersion response, creates a test page and attaches a real DevTools session before running the existing app/model checks. A partial handshake cannot count as success.

Startup has one bounded retry with a fresh temporary profile. Each attempt has a shared 45-second startup budget. Detected browser paths are deduplicated; a different installed binary can be tried when available. Failed processes are stopped and temporary profiles cleaned up. If Chrome cannot start, captured stderr/stdout, command timeout and exit details are included in the failure instead of the previous generic message. Signing passwords/tokens/key paths continue to be excluded from Chrome's child environment.

The real browser, model, saved-data, Caddy, course-availability and interface checks remain required. This patch does not skip them or turn an untested app into a successful build. All 1.14.0 analysis improvements and the 1.14.1 course-outage fix are included.

## Update from your Android phone

Replace the private repository-root **Fairway-Form-Source.zip** with this download and commit the replacement, keeping the exact filename and the existing workflow/signing setup. Re-running the old commit will still use the old Chrome launcher. No workflow replacement is needed.

After Actions succeeds, download/extract **Fairway-Form-APK** and install **Fairway-Form.apk** over your current app. Do not uninstall or clear data. Settings should show **Version 1.14.2**. Package com.fairwayform.app, WebView origin and database schema 5 remain compatible. Local versionCode fallback is 31; CI supplies its run number.

## Verification and limit

492 automated JavaScript tests pass. Ten new launcher/transport regressions cover a successful handshake without any debugger log line, session routing, UTF-8/chunk framing, fresh-profile retry and cleanup, bounded timeouts, early crashes, missing pipes, malformed protocol data, force-stop cleanup, runtime-error scoping and credential filtering. These use isolated protocol/process doubles; they do not pretend to be a completed Chrome/model run.

Static JavaScript/import/control/offline-shell, XML, shell/version and serialized browser-expression checks pass. An actual local Chromium probe failed with this workspace's OS restriction in crashpad (setsockopt: Operation not permitted); the new launcher captured that diagnostic promptly. Full Chrome/model verification and signed APK compilation still need GitHub Actions. No local APK or successful real Chrome run is claimed, and the screenshot alone does not establish why Chrome stalled on that particular runner.
