// Original synthetic image fixtures, not the supplied photographs or map tiles.
export function treeImage(kind='sign'){
 const width=360,height=420,data=new Uint8ClampedArray(width*height*4),trees=kind==='sign'?[{x:83,y:92,r:11,type:'round'},{x:145,y:125,r:22,type:'round'},{x:230,y:96,r:17,type:'pine'},{x:7,y:270,r:14,type:'round'},{x:270,y:290,r:12,type:'round'}]:[{x:112,y:96,r:15},{x:235,y:122,r:23},{x:110,y:210,r:21},{x:247,y:234,r:16},{x:126,y:310,r:13},{x:244,y:345,r:20}];
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){const n=(x*17+y*31)%9,i=(y*width+x)*4;data.set(kind==='sign'?[90,202,51,255]:[66+n,82+n,58+n,255],i)}
 for(const t of trees)for(let y=Math.max(0,t.y-t.r-1);y<Math.min(height,t.y+t.r+2);y++)for(let x=Math.max(0,t.x-t.r-1);x<Math.min(width,t.x+t.r+2);x++){
  const dx=x-t.x,dy=y-t.y,a=Math.atan2(dy,dx),r=t.type==='pine'?t.r*(.69+.31*Math.cos(a*10)):t.r,d=Math.hypot(dx,dy);if(d>r)continue;
  const light=kind==='satellite'?Math.max(0,1-d/t.r)*55+(x*7+y*13)%7:0,c=t.type==='pine'?[25,105,50]:kind==='sign'?[53,146,76]:[34+light*.5,69+light,46+light*.35];data.set([...c,255],(y*width+x)*4);
 }
 return {width,height,data,expected:trees};
}
