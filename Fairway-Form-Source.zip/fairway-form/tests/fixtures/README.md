# Video decoder regression fixtures

Original synthetic moving test patterns, not people or app content. These files are served only by the browser test runner and are excluded from the APK assets. They test near-tail decoding and release-window revisits at 24, 30 and 60 fps.

Generate each with FFmpeg (substitute RATE):

    ffmpeg -f lavfi -i testsrc2=size=640x360:rate=RATE -t 3.76 -c:v libx264 -pix_fmt yuv420p -movflags +faststart decoder-RATE.mp4

The browser loads the complete fixture as a local Blob, matching Gallery input. QA pose tokens exercise orchestration only; they are never model evidence or user coaching.
