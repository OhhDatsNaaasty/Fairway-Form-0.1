// Synthetic movement fixtures, not human-labeled video or accuracy training.
export function walkupSequence({steps=3,fps=30,hand='right',direction='right',tempo=1,hiddenFinishHip=false,plantShift=0}={}){
 const plant=1.4+(steps-3)*.35,release=plant+.3,duration=release+1.8,point=(x,y)=>({x,y,visibility:1});
 const lerp=(t,a,b,x,y)=>t<=a?x:t>=b?y:x+(y-x)*(t-a)/(b-a);
 const frames=Array.from({length:Math.ceil(duration*fps)+1},(_,i)=>{
  const u=i/fps,t=u*tempo,c=lerp(u,0,plant,.26,.55),p=Array.from({length:33},()=>point(c,.5));
  p[0]=point(c,.16);p[11]=point(c-.025,.3);p[12]=point(c+.025,.3);p[23]=point(c-.02,.63);p[24]=point(c+.02,.63);
  let lx,ly=.95;
  if(u<plant-.55){const cycle=u%.65;lx=.17+.09*Math.floor(u/.65)+.09*Math.min(1,cycle/.35);if(cycle<.35)ly-=.07*Math.sin(Math.PI*cycle/.35)}
  else{const a=plant-.55+plantShift,b=plant+plantShift;lx=lerp(u,a,b,.47,.72);if(u>a&&u<b)ly-=.07*Math.sin(Math.PI*(u-a)/(b-a))}
  const rx=lerp(u,plant-.95,plant-.55,.38,.57);
  p[27]=point(rx,.95);p[28]=point(lx,ly);p[29]=point(rx-.01,.96);p[31]=point(rx+.025,.96);p[30]=point(lx-.01,ly+.01);p[32]=point(lx+.025,ly+.01);
  p[25]=point(rx,.78);p[26]=point(lx,.78);p[13]=point(c-.07,.43);p[15]=point(c-.1,.52);p[14]=point(c+.07,.41);
  let wx=u<plant-.8?.02: u<plant-.03?lerp(u,plant-.8,plant-.03,.02,-.21):u<release?lerp(u,plant-.03,release,-.21,.24):lerp(u,release,release+1.0,.24,-.10);
  p[16]=point(c+.025+wx,lerp(u,release,release+1,.44,.62));
  const world=Array.from({length:33},()=>({x:0,y:0,z:0}));
  const shoulder=u<plant-.03?lerp(u,plant-.8,plant-.03,10,65):lerp(u,plant-.03,release+1,65,-40),hip=u<plant?lerp(u,plant-.8,plant,5,24):lerp(u,plant,release+1,24,-50);
  for(const [a,b,degrees]of [[11,12,shoulder],[23,24,hip]]){const r=degrees*Math.PI/180;world[a]={x:-.14*Math.cos(r),z:-.14*Math.sin(r)};world[b]={x:.14*Math.cos(r),z:.14*Math.sin(r)}}
  if(hiddenFinishHip&&u>release)for(const k of [11,23])p[k].visibility=.1;
  if(hand==='left')for(const [a,b]of [[11,12],[13,14],[15,16],[23,24],[25,26],[27,28],[29,30],[31,32]]){[p[a],p[b]]=[p[b],p[a]];[world[a],world[b]]=[world[b],world[a]]}
  if(direction==='left'){for(const q of p)q.x=1-q.x;for(const q of world)q.x=-q.x}
  return {t,p,world};
 });return {frames,plant:(plant+plantShift)*tempo,release:release*tempo,backswing:(plant-.03)*tempo,options:{hand,type:'backhand',view:'side',cameraStable:true,stance:'walkup',aspect:1,direction}};
}
