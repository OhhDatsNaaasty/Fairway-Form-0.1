export const ATTACK_BEND_NOTES='The fairway and basket are heavily wooded. There is a slight Left bend about 250 ft down the fairway and water is behind about 20 ft behind the basket';
export const ATTACK_BEND_DRY_NOTES='The fairway and basket are heavily wooded. There is a slight Left bend about 250 ft down the fairway.';
// Hypothetical longer-disc references; these are not the user's bag distances.
export const ATTACK_BEND_BAG=[{id:'qa-attack-putter',discId:'discmania-p1x',distance:150},{id:'qa-attack-mid',discId:'discraft-buzzz',distance:260},{id:'qa-attack-fairway',discId:'innova-teebird',distance:330}];
