export const EVERYDAY_WOODED_NOTE='There are trees everywhere and the basket is through the trees just to the right.';
