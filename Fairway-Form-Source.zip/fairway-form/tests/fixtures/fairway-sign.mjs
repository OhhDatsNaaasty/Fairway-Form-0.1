// Original schematic reproduction of the failure's structure, not the user's
// actual photo: skewed green panel, pale ribbon, black dashes, darker tree spots.
export function fairwaySign({dashed=true,solid=false,border=true,noise=false}={}){
 const width=300,height=480,data=new Uint8ClampedArray(width*height*4);
 const pixel=(x,y,c)=>{x=Math.round(x);y=Math.round(y);if(x>=0&&y>=0&&x<width&&y<height)data.set([...c,255],(y*width+x)*4)};
 for(let y=0;y<height;y++)for(let x=0;x<width;x++)pixel(x,y,noise?[75+(x*31+y*17)%30,95+(x*13+y*19)%30,45+(x*11+y*23)%20]:[89,104,65]);
 const poly=(points,c)=>{for(let y=Math.floor(Math.min(...points.map(p=>p[1])));y<=Math.max(...points.map(p=>p[1]));y++){const hits=[];for(let i=0;i<points.length;i++){const a=points[i],b=points[(i+1)%points.length];if((a[1]>y)!==(b[1]>y))hits.push(a[0]+(y-a[1])*(b[0]-a[0])/(b[1]-a[1]))}hits.sort((a,b)=>a-b);for(let i=0;i<hits.length;i+=2)for(let x=Math.ceil(hits[i]);x<=hits[i+1];x++)pixel(x,y,c)}};
 const line=(a,b,c,size=1,dash=false)=>{const steps=Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1]));for(let k=0;k<=steps;k++){if(dash&&Math.floor(k/6)%2)continue;for(let dy=-size;dy<=size;dy++)for(let dx=-size;dx<=size;dx++)pixel(a[0]+(b[0]-a[0])*k/steps+dx,a[1]+(b[1]-a[1])*k/steps+dy,c)}};
 const circle=(x,y,r,c)=>{for(let yy=-r;yy<=r;yy++)for(let xx=-r;xx<=r;xx++)if(xx*xx+yy*yy<=r*r)pixel(x+xx,y+yy,c)};
 poly([[55,100],[275,110],[260,405],[35,390]],[238,236,210]);const panel=[[125,155],[267,161],[253,385],[97,374]];poly(panel,[91,202,51]);if(border)for(let i=0;i<panel.length;i++)line(panel[i],panel[(i+1)%4],[35,75,40]);
 const route=[[171,345],[181,280],[190,220],[201,184]];for(let i=1;i<route.length;i++)line(route[i-1],route[i],[202,223,190],8);circle(201,184,9,[202,223,190]);
 if(dashed||solid)for(let i=1;i<route.length;i++)line(route[i-1],route[i],[74,76,77],0,dashed&&!solid);
 poly([[167,342],[175,343],[173,353],[165,352]],[125,138,137]);circle(201,184,3,[92,96,102]);
 const trees=[[223,175],[229,203],[151,245],[212,243],[235,265],[224,286],[142,297],[205,326],[238,355]];for(const [x,y]of trees){circle(x,y,9,[53,146,76]);circle(x-2,y-2,5,[72,163,83])}
 return {width,height,data,expected:{tee:{x:171/width,y:345/height},basket:{x:201/width,y:184/height},trees:trees.map(([x,y])=>({x:x/width,y:y/height}))}};
}
