import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createForwardSampler} from '../dist/lib/video-forward.js';
import {createVideoSeeker} from '../dist/lib/video-player.js';
import {analyzeVideo} from '../dist/lib/video-analysis.js';

class Playback extends EventTarget{
 constructor(){super();this.time=0;this.duration=.76;this.videoWidth=640;this.videoHeight=360;this.readyState=2;this.seeking=false;this.paused=true;this.ended=false;this.muted=false;this.playbackRate=1.5;this.loop=true;this.callbacks=new Map();this.id=0;this.seeks=[];this.stall=false;this.stopAt=Infinity;this.stride=1/30}
 get currentTime(){return this.time}
 set currentTime(t){this.seeks.push(t);this.seeking=true;this.ended=false;queueMicrotask(()=>{this.time=Math.floor((t+1e-7)*30)/30;this.seeking=false;this.present();this.dispatchEvent(new Event('seeked'))})}
 requestVideoFrameCallback(fn){this.callbacks.set(++this.id,fn);return this.id}
 cancelVideoFrameCallback(id){this.callbacks.delete(id)}
 present(){const callbacks=[...this.callbacks.values()];this.callbacks.clear();for(const fn of callbacks)fn(0,{mediaTime:this.time})}
 pause(){this.paused=true;clearTimeout(this.timer)}
 play(){this.paused=false;if(this.rejectPlay)return Promise.reject(Error('QA playback denied'));if(!this.stall){const tick=()=>{if(this.paused)return;const t=this.time+this.stride;if(t>=this.duration||t>this.stopAt){this.ended=true;this.dispatchEvent(new Event('ended'));return}this.time=t;this.present();if(!this.paused)this.timer=setTimeout(tick,1)};this.timer=setTimeout(tick,1)};return Promise.resolve()}
}
function setup(overrides={}){
 const video=new Playback(),controller=new AbortController(),canvas={width:0,height:0,pixels:null,getContext(){return {drawImage:source=>{this.pixels=source.currentTime}}}},seek=createVideoSeeker(video,{timeout:100,pollInterval:2});
 const make=()=>createForwardSampler({video,seek,signal:controller.signal,makeCanvas:()=>canvas,timeout:500});
 const config={video,seek,signal:controller.signal,createSampler:make,fps:30,handDetail:false,detectBody:async source=>{assert.equal(video.paused,true);assert.equal(source,canvas);return {p:{at:source.pixels},multi:false}},...overrides};return {video,canvas,controller,make,config};
}
test('forward decode freezes real frames and eliminates per-frame keyframe seeks',async()=>{
 const s=setup(),r=await analyzeVideo(s.config);assert.equal(r.sampleInfo.decodeMode,'forward-playback');assert.equal(r.frames.length,23);assert.equal(s.video.seeks.length,1);assert.ok(r.frames.every(f=>Math.abs(f.p.at-f.t)<1e-7));assert.ok(r.frames.slice(1).every(f=>f.decodedTime));assert.ok(r.frames.every(f=>!('source' in f)));assert.equal(s.video.callbacks.size,0);assert.equal(s.video.muted,false);assert.equal(s.video.playbackRate,1.5);assert.equal(s.video.loop,true);assert.equal(s.canvas.width,0);
});
test('release hand detail makes one rewind then advances forward, preserving body coverage',async()=>{
 const s=setup({handDetail:true,findRelease:()=>.5,prepareHands:async()=>{},detectHand:async(source,p)=>{assert.equal(source.pixels,p.at);return {at:source.pixels}}}),r=await analyzeVideo(s.config);
 assert.equal(r.sampleInfo.bodyComplete,true);assert.equal(r.sampleInfo.detailIncomplete,false);assert.equal(s.video.seeks.length,2);assert.ok(s.video.seeks[1]<.5);assert.ok(r.frames.filter(f=>f.hand).length>=10);assert.ok(r.frames.filter(f=>f.hand).every(f=>f.hand.at===f.t));
});
test('60 requested samples cannot relabel duplicated 30fps pixels as new frames',async()=>{
 const s=setup({fps:60}),r=await analyzeVideo(s.config);assert.equal(r.frames.length,23);assert.equal(new Set(r.frames.map(f=>f.t)).size,23);assert.equal(r.sampleInfo.bodyComplete,true);assert.equal(r.sampleInfo.reachedEnd,true);
});
test('missing final sub-frame ends normally without repeatedly seeking the clip tail',async()=>{
 const s=setup(),reader=s.make();await reader.sample(0);const frame=await reader.sample(.72);assert.ok(frame.t>=.718);assert.equal(await reader.sample(.759),null);reader.close();assert.equal(s.video.seeks.length,1);assert.equal(s.video.callbacks.size,0);
});
test('a stalled playback has a bounded error and cleans callbacks, abort listeners and flags',async()=>{
 const s=setup(),reader=s.make();await reader.sample(0);s.video.stall=true;await assert.rejects(reader.sample(.1),/stopped producing new frames/);reader.close();assert.equal(s.video.callbacks.size,0);assert.equal(s.video.paused,true);assert.equal(s.video.muted,false);
});
test('cancellation interrupts a stalled forward frame and retains collected evidence',async()=>{
 const s=setup();let frames=[];s.config.onFrames=f=>{frames=f};s.config.onProgress=({done})=>{if(done===3){s.video.stall=true;setTimeout(()=>s.controller.abort(),2)}};await assert.rejects(analyzeVideo(s.config),{name:'AbortError'});assert.equal(frames.length,3);assert.equal(s.video.callbacks.size,0);assert.equal(s.video.muted,false);
});
test('an early decoder end cannot be mislabeled as complete body coverage',async()=>{
 const s=setup();s.video.stopAt=.2;const info={};s.config.sampleInfo=info;await assert.rejects(analyzeVideo(s.config),/ended before/);assert.equal(info.bodyComplete,false);assert.equal(s.video.muted,false);assert.equal(s.video.callbacks.size,0);
});
test('optional hand playback failure keeps a completed body review',async()=>{
 const s=setup({handDetail:true,findRelease:()=>.5,prepareHands:async()=>{s.video.rejectPlay=true},detectHand:async()=>null}),r=await analyzeVideo(s.config);assert.equal(r.sampleInfo.bodyComplete,true);assert.equal(r.sampleInfo.detailIncomplete,true);assert.match(r.sampleInfo.handWarning,/playback could not start/);assert.equal(r.frames.length,23);assert.equal(s.video.muted,false);
});
test('browsers without compositor frame callbacks keep the seek compatibility path',()=>{
 assert.equal(createForwardSampler({video:{play(){}},makeCanvas:()=>{throw Error('must not allocate')}}),null);
});
test('sparse source frames retain their actual decoded times rather than generated timing',async()=>{
 const s=setup();s.video.stride=.1;const r=await analyzeVideo(s.config);assert.equal(r.frames.length,8);assert.ok(r.frames.slice(1).every((f,i)=>Math.abs(f.t-r.frames[i].t-.1)<1e-7));assert.ok(r.frames.every(f=>f.p.at===f.t));
});
