import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
// Exercise the real PhoneCompass class's source selection and listener lifecycle.
// Android service stubs do not validate physical sensors or orientation math.
const stubs={
 'android/hardware/Sensor.java':`package android.hardware;public class Sensor {public static final int TYPE_ACCELEROMETER=1,TYPE_MAGNETIC_FIELD=2,TYPE_ROTATION_VECTOR=11,TYPE_GEOMAGNETIC_ROTATION_VECTOR=20;private final int type;public Sensor(int t){type=t;}public int getType(){return type;}}`,
 'android/hardware/SensorEvent.java':`package android.hardware;public class SensorEvent {public Sensor sensor;public float[] values;public int accuracy;public long timestamp;public SensorEvent(Sensor s,float[] v,int a){sensor=s;values=v;accuracy=a;timestamp=System.nanoTime();}}`,
 'android/hardware/SensorEventListener.java':`package android.hardware;public interface SensorEventListener {void onSensorChanged(SensorEvent e);void onAccuracyChanged(Sensor s,int accuracy);}`,
 'android/hardware/SensorManager.java':`package android.hardware;import java.util.*;public class SensorManager {public static final int SENSOR_STATUS_UNRELIABLE=0,SENSOR_DELAY_UI=2,AXIS_X=1,AXIS_Y=2,AXIS_MINUS_X=129,AXIS_MINUS_Y=130;public static final float GRAVITY_EARTH=9.80665f;public Set<Integer> available=new HashSet<>(Set.of(1,2,11,20)),failed=new HashSet<>(),active=new HashSet<>();public int unregisters;public Sensor getDefaultSensor(int type){return available.contains(type)?new Sensor(type):null;}public boolean registerListener(SensorEventListener l,Sensor s,int delay){if(failed.contains(s.getType()))return false;active.add(s.getType());return true;}public void unregisterListener(SensorEventListener l){unregisters++;active.clear();}private static void identity(float[] m){Arrays.fill(m,0);m[0]=m[4]=m[8]=1;}public static void getRotationMatrixFromVector(float[] m,float[] v){identity(m);}public static boolean getRotationMatrix(float[] m,float[] i,float[] g,float[] f){identity(m);return true;}public static boolean remapCoordinateSystem(float[] m,int x,int y,float[] out){System.arraycopy(m,0,out,0,m.length);return true;}public static void getOrientation(float[] m,float[] out){Arrays.fill(out,0);}}`,
 'android/hardware/GeomagneticField.java':`package android.hardware;public class GeomagneticField {public GeomagneticField(float a,float b,float c,long t){}public float getDeclination(){return 0;}}`,
 'android/os/Looper.java':`package android.os;public class Looper {public static Looper getMainLooper(){return new Looper();}}`,
 'android/os/Handler.java':`package android.os;import java.util.*;public class Handler {public static Set<Runnable> pending=new HashSet<>();public Handler(Looper l){}public void postDelayed(Runnable r,long t){pending.add(r);}public void removeCallbacks(Runnable r){pending.remove(r);}}`,
 'android/os/SystemClock.java':`package android.os;public class SystemClock {public static long elapsedRealtimeNanos(){return System.nanoTime();}public static long elapsedRealtime(){return System.nanoTime()/1000000;}}`,
 'android/view/Surface.java':`package android.view;public class Surface {public static final int ROTATION_90=1,ROTATION_180=2,ROTATION_270=3;}`,
 'android/view/WindowManager.java':`package android.view;public class WindowManager {public Display getDefaultDisplay(){return new Display();}public static class Display {public int getRotation(){return 0;}}}`,
 'android/app/Activity.java':`package android.app;import android.hardware.SensorManager;import android.view.WindowManager;public class Activity {public final SensorManager sensors=new SensorManager();public <T>T getSystemService(Class<T> c){return c.cast(sensors);}public WindowManager getWindowManager(){return new WindowManager();}}`,
 'org/json/JSONObject.java':`package org.json;import java.util.*;public class JSONObject {public static final Object NULL=new Object();private final Map<String,Object> values=new HashMap<>();public JSONObject put(String k,Object v){values.put(k,v);return this;}public Object get(String k){return values.get(k);}public boolean has(String k){return values.containsKey(k);}}`,
 'com/fairwayform/app/PhoneCompassLifecycleTest.java':`package com.fairwayform.app;import android.app.Activity;import android.hardware.*;import android.os.Handler;import java.util.*;import org.json.JSONObject;public class PhoneCompassLifecycleTest {
 static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);}static JSONObject last(List<JSONObject> r){return r.get(r.size()-1);}static SensorEvent event(int type){return new SensorEvent(new Sensor(type),type==1?new float[]{0,0,9.80665f}:type==2?new float[]{0,45,0}:new float[]{0,0,0,1,.1f},3);}
 public static void main(String[] args){
 Activity a=new Activity();List<JSONObject> rows=new ArrayList<>();PhoneCompass c=new PhoneCompass(a,rows::add);c.start("one",40,-90);check(last(rows).get("sensor").equals("rotation-vector"),"first source");check(Handler.pending.size()==1,"one deadline");c.onSensorChanged(event(11));check(last(rows).has("heading"),"heading from active source");int count=rows.size();c.retry("wrong");check(rows.size()==count,"old request ignored");c.retry("one");check(last(rows).get("sensor").equals("geomagnetic-vector"),"second source");count=rows.size();c.onSensorChanged(event(11));check(rows.size()==count,"old source event ignored");c.retry("one");check(last(rows).get("sensor").equals("magnetic-field"),"raw fallback");check(a.sensors.active.equals(Set.of(1,2)),"both raw listeners active");c.onSensorChanged(event(1));c.onSensorChanged(event(2));check(last(rows).has("heading"),"paired raw inputs emit");c.retry("one");check(last(rows).has("error"),"exhaustion ends capture");check(a.sensors.active.isEmpty()&&Handler.pending.isEmpty(),"exhaustion unregisters and clears deadline");
 for(int mode=0;mode<3;mode++){a=new Activity();if(mode>0)a.sensors.failed.add(11);if(mode>1)a.sensors.failed.add(20);rows=new ArrayList<>();c=new PhoneCompass(a,rows::add);c.start("startup",40,-90);check(last(rows).get("sensor").equals(mode==0?"rotation-vector":mode==1?"geomagnetic-vector":"magnetic-field"),"failed registration falls through");c.stop();check(a.sensors.active.isEmpty()&&Handler.pending.isEmpty(),"cancel cleanup");}
 a=new Activity();a.sensors.available.clear();rows=new ArrayList<>();c=new PhoneCompass(a,rows::add);c.start("absent",40,-90);check(last(rows).has("error")&&a.sensors.active.isEmpty(),"missing sensors reported");
 a=new Activity();a.sensors.available.remove(11);a.sensors.available.remove(20);a.sensors.failed.add(2);rows=new ArrayList<>();c=new PhoneCompass(a,rows::add);c.start("partial",40,-90);check(last(rows).has("error")&&a.sensors.active.isEmpty(),"partial registration cleaned up");
 a=new Activity();rows=new ArrayList<>();c=new PhoneCompass(a,rows::add);c.start("paused",40,-90);c.pause();count=rows.size();c.onSensorChanged(event(11));check(rows.size()==count&&last(rows).has("error")&&Handler.pending.isEmpty(),"pause stops later readings");
 a=new Activity();rows=new ArrayList<>();c=new PhoneCompass(a,rows::add);c.start("invalid",Double.NaN,-90);check(last(rows).has("error")&&a.sensors.active.isEmpty(),"invalid correction location rejected");
 System.out.println("Native compass lifecycle: 8 scenarios passed (Android service stubs; no device test).");
 }} `
};
test('native compass changes source, handles registration failures, rejects old callbacks and cleans up',async()=>{
 const tmp=await fs.mkdtemp(path.join(os.tmpdir(),'final-form-compass-'));
 try{
  for(const [relative,source]of Object.entries(stubs)){const p=path.join(tmp,relative);await fs.mkdir(path.dirname(p),{recursive:true});await fs.writeFile(p,source)}
  const actual=path.resolve('android/app/src/main/java/com/fairwayform/app/PhoneCompass.java');
  const found=spawnSync('javac',['-version'],{encoding:'utf8',timeout:5000});
  const javaFound=spawnSync('java',['-version'],{encoding:'utf8',timeout:5000});
  const runner=javaFound.status===0?'java':'/usr/lib/jvm/java-21-openjdk-amd64/bin/java';
  const compiler=found.status===0?'javac':runner,compilerArgs=found.status===0?[]:['com.sun.tools.javac.Main'];
  const build=spawnSync(compiler,[...compilerArgs,'-d',path.join(tmp,'classes'),...Object.keys(stubs).map(p=>path.join(tmp,p)),actual],{encoding:'utf8',timeout:20000});assert.equal(build.status,0,build.error?.message??build.stderr);
  const run=spawnSync(runner,['-cp',path.join(tmp,'classes'),'com.fairwayform.app.PhoneCompassLifecycleTest'],{encoding:'utf8',timeout:10000});assert.equal(run.status,0,run.error?.message??run.stderr);assert.match(run.stdout,/8 scenarios passed/);
 }finally{await fs.rm(tmp,{recursive:true,force:true})}
});
