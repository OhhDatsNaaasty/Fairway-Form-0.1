import {test} from 'node:test';import assert from 'node:assert/strict';
import {findArmLoading,findPlantContact} from '../dist/lib/phase-evidence.js';
const point=(x,y)=>({x,y,visibility:1}),ix={s:12,e:14,w:16,ankle:28,heel:30,toe:32};
function arms(angles){return angles.map((degrees,i)=>{const p=Array.from({length:33},()=>point(.5,.5));p[11]=point(.45,.3);p[12]=point(.4,.3);p[23]=point(.45,.6);p[24]=point(.4,.6);p[14]=point(.6,.3);p[16]=point(.6-.2*Math.cos(degrees*Math.PI/180),.3+.2*Math.sin(degrees*Math.PI/180));return {t:.6+i*.05,p}})}
function legs(raised=false){return Array.from({length:37},(_,i)=>{const t=i*.05,p=arms([90])[0].p,x=Math.min(.2+i*.025,.7),y=raised?(t<.5?.96:t<.9?.96-(t-.5)*.65:.7):.96;p[28]=point(x,y-.02);p[30]=point(x-.02,y);p[32]=point(x+.03,y);return {t,p}})}
test('arm loading needs subsequent opening and prefers the end of a bent-arm plateau',()=>{
 const frames=arms([110,85,80,82,86,100,130,150,160]),chosen=findArmLoading(frames,1,ix,{aspect:1});assert.equal(chosen.t,.75);
 assert.equal(findArmLoading(arms(Array(9).fill(80)),1,ix,{aspect:1}),null);
 assert.equal(findArmLoading(arms([160,150,140,130,120,110,100,90,80]),1,ix,{aspect:1}),null);
});
test('backhand arm loading cannot be borrowed from forehand or before the marked backswing',()=>{
 const frames=arms([110,85,80,82,86,100,130,150,160]);assert.equal(findArmLoading(frames,1,ix,{type:'forehand',aspect:1}),null);
 const chosen=findArmLoading(frames,1,ix,{aspect:1,reachback:.82});assert.ok(chosen&&chosen.t>=.82);
});
test('occluded arms and too few later frames cannot establish the bend-then-opening sequence',()=>{
 const frames=arms([80,85,100,140,160]);frames.forEach(f=>f.p[16].visibility=.1);assert.equal(findArmLoading(frames,1,ix,{aspect:1}),null);
 assert.equal(findArmLoading(arms([80,160]),.65,ix,{aspect:1}),null);
});
test('lead-foot settling near the visible low foot level gives a contact candidate, not force measurement',()=>{
 const frames=legs(),chosen=findPlantContact(frames,1.6,ix,{aspect:1});assert.ok(chosen);assert.ok(chosen.t>=1&&chosen.t<1.6);assert.ok(frames.includes(chosen));
});
test('a foot pausing high in the air cannot become plant just because the ankle stops',()=>assert.equal(findPlantContact(legs(true),1.6,ix,{aspect:1}),null));
test('missing both contact landmarks, standstill and moving camera cannot receive automatic foot-contact suggestions',()=>{
 const frames=legs();for(const options of [{stance:'standstill'},{cameraStable:false}])assert.equal(findPlantContact(frames,1.6,ix,{aspect:1,...options}),null);
 frames.forEach(f=>{f.p[30].visibility=.1;f.p[32].visibility=.1});assert.equal(findPlantContact(frames,1.6,ix,{aspect:1}),null);
});
