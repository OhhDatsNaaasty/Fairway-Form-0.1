import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createFrameReview} from '../dist/lib/frame-review.js';
const gate=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve}};
test('rapid scrubbing cannot display stale pixels or approve a marker while a requested frame is pending',async()=>{
 const requests=[],shown=[];
 const source={times:[0,1,2],sample(t,{signal}){const wait=gate();requests.push({t,signal,...wait});return wait.promise},close(){},step:t=>t};
 const review=createFrameReview(source,{onFrame:frame=>shown.push(frame.t)});
 const first=review.seek(1);assert.equal(review.canMark,false);assert.equal(review.time,0);
 const second=review.seek(2);assert.equal(requests[0].signal.aborted,true);requests[1].resolve({t:2,source:{}});await second;assert.equal(review.canMark,true);assert.equal(review.time,2);
 requests[0].resolve({t:1,source:{}});await first;assert.deepEqual(shown,[2]);assert.equal(review.time,2);review.close();
});
test('failed scrubbing keeps the last displayed timestamp and never records the requested time',async()=>{
 const review=createFrameReview({times:[.033,1],sample:async t=>{if(t>1)throw Error('disk unavailable');return {t,source:{}}},close(){},step:t=>t});
 await review.seek(.033);await assert.rejects(review.seek(2.28),/disk unavailable/);assert.equal(review.time,.033);assert.equal(review.canMark,true);review.close();
});
test('native image playback ends normally and markers remain blocked during playback',async()=>{
 let clock=0;const shown=[],states=[];
 const review=createFrameReview({times:[0,.1,.2],sample:async t=>({t,source:{}}),close(){},step:(t,d)=>d>0?.2:0},{now:()=>clock,delay:async()=>{clock+=100},onFrame:f=>shown.push(f.t),onState:s=>states.push(s)});
 await review.play();assert.deepEqual(shown,[0,.1,.2]);assert.equal(review.playing,false);assert.equal(review.canMark,true);assert.ok(states.filter(s=>s.playing).every(s=>!s.canMark));review.close();
});
test('a superseded playback cannot cancel a new scrub or move its saved time',async()=>{
 const waits=[],shown=[];
 const review=createFrameReview({times:[0,1,2],sample:t=>{const wait=gate();waits.push({...wait,t});return wait.promise},close(){},step:t=>t},{onFrame:f=>shown.push(f.t)});
 const playing=review.play(),seeking=review.seek(2);waits[0].resolve({t:0});await playing;assert.equal(review.canMark,false);waits[1].resolve({t:2});await seeking;assert.deepEqual(shown,[2]);assert.equal(review.time,2);review.close();
});
test('scrubbing during an end-of-clip playback restart cannot unexpectedly start playback again',async()=>{
 let held=null;
 const source={times:[0,1,2],sample:async t=>{if(t===0){held=gate();return held.promise}return {t}},close(){},step:t=>t};
 const review=createFrameReview(source);await review.seek(2);const restart=review.play();await review.seek(1);held.resolve({t:0});await restart;assert.equal(review.time,1);assert.equal(review.playing,false);assert.equal(review.canMark,true);review.close();
});
test('analysis presentation advances native transport time and pixels without replaying or seeking',()=>{
 const shown=[],source={times:[0,1,2],sample(){throw Error('must reuse the measured image')},close(){}};
 const review=createFrameReview(source,{onFrame:frame=>shown.push(frame)});const frame={t:1,source:{pixels:'frame-1'},observation:{t:1,p:'pose-1'}};review.present(frame);assert.equal(review.time,1);assert.equal(shown[0],frame);assert.equal(review.canMark,true);assert.equal(review.playing,false);review.close();
});
