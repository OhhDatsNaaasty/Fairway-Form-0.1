import {test} from 'node:test';
import assert from 'node:assert/strict';
import {analyzeVideo} from '../dist/lib/video-analysis.js';
import {createVideoSeeker} from '../dist/lib/video-player.js';
import {review} from '../dist/lib/analysis.js';

// A paused 30 fps decoder that rounds time, emits exactly one compositor
// callback per seek (before the promise resolves), and can fail on rewind.
class Decoder extends EventTarget {
 constructor(){super();this.duration=3.76;this.readyState=2;this.seeking=false;this.time=0;this.callbacks=new Map();this.next=0;this.requests=[];this.beforeSeek=()=>{}}
 get currentTime(){return this.time}
 set currentTime(t){
  this.beforeSeek(t);this.requests.push(t);this.seeking=true;
  queueMicrotask(()=>{this.time=Math.floor((t+1e-7)*30)/30;this.seeking=false;const callbacks=[...this.callbacks.values()];this.callbacks.clear();for(const callback of callbacks)callback(1,{mediaTime:this.time});this.dispatchEvent(new Event('seeked'))});
 }
 requestVideoFrameCallback(fn){this.callbacks.set(++this.next,fn);return this.next}
 cancelVideoFrameCallback(id){this.callbacks.delete(id)}
}
function setup(overrides={}){
 const video=new Decoder(),sampleInfo={},bodyTimes=[],handTimes=[],updates=[];
 const config={video,sampleInfo,seek:createVideoSeeker(video,{timeout:100,pollInterval:2}),fps:30,handDetail:true,
  detectBody:async source=>{bodyTimes.push(source.currentTime);return {p:{at:source.currentTime},world:null,multi:false}},
  detectHand:async(source,p)=>{assert.equal(p.at,source.currentTime);handTimes.push(source.currentTime);return {at:source.currentTime}},
  prepareHands:async()=>{},findRelease:()=>3.52,onFrames:frames=>updates.push(frames),...overrides};
 return {video,sampleInfo,bodyTimes,handTimes,updates,config};
}

test('3.76s clip completes body and release detail with rounded 30fps frames',async()=>{
 const {config,video,handTimes}=setup();const result=await analyzeVideo(config);
 assert.equal(result.frames.length,113);assert.equal(result.sampleInfo.bodyComplete,true);assert.equal(result.sampleInfo.incomplete,false);
 assert.ok(handTimes.length>=10);assert.equal(new Set(handTimes).size,handTimes.length);
 assert.ok(result.frames.every(f=>f.t<3.76));assert.ok(result.frames.every(f=>f.t===0||f.decodedTime));
 assert.ok(result.frames.filter(f=>f.hand).every(f=>f.hand.at===f.t));
 const requests=video.requests,rewind=requests.findIndex((t,i)=>i&&t<requests[i-1]);
 assert.ok(rewind>0);assert.equal(requests.filter((t,i)=>i&&t<requests[i-1]).length,1);
 const bodyRequests=requests.slice(0,rewind);
 assert.ok(requests.slice(rewind).every(t=>bodyRequests.includes(t)),'detail must only revisit first-pass times');
 assert.equal(video.callbacks.size,0);
});
test('60 requested samples/s cannot manufacture more than 30 decoded frames/s',async()=>{
 const {config,bodyTimes,handTimes}=setup({fps:60});const result=await analyzeVideo(config);
 assert.equal(result.frames.length,113);assert.equal(bodyTimes.length,113+handTimes.length);
 assert.equal(new Set(handTimes).size,handTimes.length);assert.ok(handTimes.length<20);
});
test('turning hand detail off eliminates the backward pass entirely',async()=>{
 const {config,video,handTimes}=setup({handDetail:false,prepareHands:()=>{throw Error('must not load')},findRelease:()=>{throw Error('must not refine')}});
 const result=await analyzeVideo(config);assert.equal(result.sampleInfo.bodyComplete,true);assert.equal(handTimes.length,0);
 assert.ok(video.requests.every((t,i)=>!i||t>=video.requests[i-1]));
});
test('a decoder error near 3.58s in the optional pass preserves the completed body review',async()=>{
 const state=setup();let detail=false;
 state.config.onProgress=({phase})=>{if(phase==='hands')detail=true};
 state.video.beforeSeek=t=>{if(detail&&t>3.56)throw Error('The frame at 3.58s could not be decoded in time.')};
 const result=await analyzeVideo(state.config),info=result.sampleInfo;
 assert.equal(result.frames.length,113);assert.equal(info.bodyComplete,true);assert.equal(info.incomplete,false);assert.equal(info.cancelled,false);
 assert.equal(info.detailIncomplete,true);assert.match(info.handWarning,/3.58s/);
 assert.equal(review(result.frames,{sampleInfo:info}).quality.incomplete,false);
 assert.equal(state.video.callbacks.size,0);
});
test('hand model and hand inference failures each leave all body samples available',async()=>{
 for(const broken of ['prepareHands','detectHand']){
  const state=setup({[broken]:async()=>{throw Error('Hand model unavailable')}});
  const result=await analyzeVideo(state.config);
  assert.equal(result.frames.length,113);assert.equal(result.sampleInfo.bodyComplete,true);
  assert.equal(result.sampleInfo.detailIncomplete,true);assert.equal(result.sampleInfo.incomplete,false);
 }
});
test('cancelling hand detail keeps body coverage complete and discloses the cancellation',async()=>{
 const controller=new AbortController(),state=setup({signal:controller.signal});
 state.config.onProgress=({phase,done})=>{if(phase==='hands'&&done===1)controller.abort()};
 const result=await analyzeVideo(state.config);
 assert.equal(result.frames.length,113);assert.equal(result.sampleInfo.bodyComplete,true);
 assert.equal(result.sampleInfo.detailCancelled,true);assert.equal(result.sampleInfo.cancelled,false);
 assert.match(result.sampleInfo.handWarning,/cancelled/);assert.equal(state.video.callbacks.size,0);
});
test('cancelling the body pass remains a real interruption with collected evidence',async()=>{
 const controller=new AbortController(),state=setup({signal:controller.signal});
 state.config.onProgress=({phase,done})=>{if(phase==='body'&&done===5)controller.abort()};
 await assert.rejects(analyzeVideo(state.config),{name:'AbortError'});
 assert.equal(state.updates.at(-1).length,5);assert.equal(state.sampleInfo.bodyComplete,false);
 assert.equal(state.handTimes.length,0);assert.equal(state.video.callbacks.size,0);
});
test('a true failure during body review still rejects and retains only collected frames',async()=>{
 const state=setup();state.video.beforeSeek=t=>{if(t>.3)throw Error('Broken source frame')};
 await assert.rejects(analyzeVideo(state.config),/Broken source frame/);
 assert.equal(state.sampleInfo.bodyComplete,false);assert.equal(state.updates.at(-1).length,10);
 assert.equal(state.handTimes.length,0);assert.equal(state.video.callbacks.size,0);
});
test('no-person footage cannot acquire hand points or personal form findings',async()=>{
 const state=setup({detectBody:async()=>({p:null,world:null,multi:false}),findRelease:frames=>review(frames).release,prepareHands:()=>{throw Error('must not load')}});
 const result=await analyzeVideo(state.config);
 assert.equal(result.sampleInfo.bodyComplete,true);assert.equal(result.sampleInfo.refined,0);
 assert.equal(review(result.frames).findings.length,0);assert.equal(state.handTimes.length,0);
});
test('an unavailable release or all hidden poses does not trigger a second pass',async()=>{
 for(const overrides of [{findRelease:()=>null},{detectBody:async()=>({p:null})}]){
  const state=setup({...overrides,prepareHands:()=>{throw Error('must not load')}});
  const result=await analyzeVideo(state.config);
  assert.equal(result.sampleInfo.detailIncomplete,false);assert.equal(state.handTimes.length,0);
 }
});
test('a genuinely stuck optional seek has a bounded deadline and cannot discard body coverage',async()=>{
 const state=setup();let detail=false;
 state.config.onProgress=({phase})=>{if(phase==='hands')detail=true};
 const seek=createVideoSeeker(state.video,{timeout:100,pollInterval:2});
 state.config.seek=async(t,settings)=>{
  if(detail){assert.equal(settings.timeout,3000);Object.defineProperty(state.video,'currentTime',{get(){return this.time},set(){this.seeking=true}})}
  return seek(t,{...settings,timeout:detail?20:100});
 };
 const result=await analyzeVideo(state.config);
 assert.equal(result.sampleInfo.bodyComplete,true);assert.equal(result.sampleInfo.detailIncomplete,true);
 assert.match(result.sampleInfo.handWarning,/could not be decoded/);assert.equal(result.frames.length,113);
 assert.equal(state.video.callbacks.size,0);
});
test('cancellation after the final body sample cannot relabel full coverage as partial',async()=>{
 for(const handDetail of [true,false]){
  const controller=new AbortController(),state=setup({signal:controller.signal,handDetail});
  state.config.onProgress=({phase,done,total})=>{if(phase==='body'&&done===total)controller.abort()};
  const result=await analyzeVideo(state.config);
  assert.equal(result.sampleInfo.bodyComplete,true);assert.equal(result.frames.length,113);
  assert.equal(result.sampleInfo.incomplete,false);assert.equal(result.sampleInfo.cancelled,false);
  assert.equal(result.sampleInfo.detailCancelled,handDetail);
 }
});
