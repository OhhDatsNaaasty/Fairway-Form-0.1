import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {catalogMatches,bagCounts,bagCountLabel,CATALOG_VERSIONS} from '../dist/lib/disc-catalog.js';
import {DISCS} from '../dist/lib/discs.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../dist');
const html=await fs.readFile(path.join(root,'index.html'),'utf8');
class Element extends EventTarget{
 constructor(){super();this.value='';this.textContent='';this._html='';this.dataset={};this.hidden=false;this.disabled=false;this.buttons=[]}
 set innerHTML(value){this._html=value;this.buttons=[...value.matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button>/g)].map(m=>{const e=new Element();for(const a of m[1].matchAll(/data-([a-z-]+)="([^"]*)"/g))e.dataset[a[1].replace(/-([a-z])/g,(_,v)=>v.toUpperCase())]=a[2];e.textContent=m[2];return e})}
 get innerHTML(){return this._html}
 querySelectorAll(selector){const match=selector.match(/^\[data-([a-z-]+)\]$/);return match?this.buttons.filter(b=>Object.hasOwn(b.dataset,match[1].replace(/-([a-z])/g,(_,v)=>v.toUpperCase()))):[]}
 close(){this.open=false}showModal(){this.open=true}
}
async function fixture(copies=[]){
 const elements=new Map([...html.matchAll(/\bid="([\w-]+)"/g)].map(m=>[m[1],new Element()])),el=id=>{assert.ok(elements.has(id),'Unknown control '+id);return elements.get(id)};
 el('discMaxSpeed').value='15';let bag=structuredClone(copies),fail=false,writes=0;
 const storage={listBag:async()=>structuredClone(bag),listCatalog:async()=>[],listCaddyHoles:async()=>[],storeCatalog:async()=>{},correctThrowMeasurement:async()=>{},restoreBag:async items=>{bag=structuredClone(items)},storeBagItem:async item=>{writes++;if(fail)throw Error('QA write failure');bag=[...bag.filter(b=>b.id!==item.id),structuredClone(item)]},deleteBagItem:async id=>{bag=bag.filter(b=>b.id!==id)}};
 const context=vm.createContext({document:{getElementById:el},crypto:globalThis.crypto,Blob,URL,structuredClone,console,fetch:async()=>({ok:false})});
 const code=new Map();for(const name of await fs.readdir(path.join(root,'lib')))if(name.endsWith('.js')){const file=path.join(root,'lib',name);code.set(file,await fs.readFile(file,'utf8'))}
 const modules=new Map();function module(file){if(modules.has(file))return modules.get(file);const m=file===path.join(root,'lib/storage.js')?new vm.SyntheticModule(Object.keys(storage),function(){for(const [k,v]of Object.entries(storage))this.setExport(k,v)},{context,identifier:file}):new vm.SourceTextModule(code.get(file),{context,identifier:file});modules.set(file,m);return m}
 const entry=module(path.join(root,'lib/discs-ui.js'));await entry.link((specifier,parent)=>module(path.resolve(path.dirname(parent.identifier),specifier)));await entry.evaluate();const messages=[];entry.namespace.setupDiscs({notify:m=>messages.push(m),download(){}});await entry.namespace.renderDiscs();
 return {el,messages,bag:()=>bag,fail:()=>{fail=true},writes:()=>writes,render:entry.namespace.renderDiscs,add:(id,version)=>el('discCatalog').querySelectorAll('[data-add]').find(b=>b.dataset.add===id&&(b.dataset.version??'')===(version??''))};
}
const buzzz=DISCS.find(d=>d.id==='discraft-buzzz');
test('BuzzzSaw names resolve to the existing Buzzz mold without duplicating its identity',()=>{for(const name of ['buzzzsaw','Discraft buzzsaw','buzz saw','Fuzed Buzzz','Discraft Buzzz Saw'])assert.equal(catalogMatches(buzzz,name),true,name);assert.equal(DISCS.filter(d=>catalogMatches(d,'buzzsaw')).length,1);assert.equal(CATALOG_VERSIONS[buzzz.id][0].plastic,'Fuzed Z · BuzzzSaw');assert.equal(catalogMatches(buzzz,'zone'),false)});
test('ownership counts physical copies without confusing molds',()=>{const count=bagCounts([{id:'a',discId:'discraft-buzzz'},{id:'b',discId:'discraft-buzzz'},{id:'c',discId:'axiom-crave'}]);assert.equal(count.get('discraft-buzzz'),2);assert.equal(bagCountLabel(count.get('discraft-buzzz')),'2 in your bag');assert.equal(bagCountLabel(0),'')});
test('catalog add updates visible ownership immediately and preserves active search/brand',async()=>{const f=await fixture();f.el('discSearch').value='crave';f.el('discBrand').value='Axiom';f.el('discSearch').dispatchEvent(new Event('input'));await f.add('axiom-crave').onclick();assert.match(f.el('discCatalog').innerHTML,/1 in your bag/);assert.match(f.add('axiom-crave').textContent,/Add another/);assert.equal(f.el('discSearch').value,'crave');assert.equal(f.el('discBrand').value,'Axiom');await f.add('axiom-crave').onclick();assert.match(f.el('discCatalog').innerHTML,/2 in your bag/);assert.equal(new Set(f.bag().map(b=>b.id)).size,2)});
test('removing a bag copy updates catalog counts before returning to search',async()=>{const f=await fixture([{id:'a',discId:'axiom-crave'},{id:'b',discId:'axiom-crave'}]);f.el('showBag').onclick();await f.el('myBag').querySelectorAll('[data-remove]')[0].onclick();assert.match(f.el('discCatalog').innerHTML,/1 in your bag/);await f.el('myBag').querySelectorAll('[data-remove]')[0].onclick();f.el('showCatalog').onclick();assert.doesNotMatch(f.el('discCatalog').innerHTML,/in your bag/);assert.match(f.add('axiom-crave').textContent,/Add to bag/)});
test('BuzzzSaw quick add records a separate physical copy with Fuzed plastic and canonical mold',async()=>{const f=await fixture([{id:'old-buzzz',discId:'discraft-buzzz',plastic:'ESP'}]);f.el('discSearch').value='buzzsaw';f.el('discSearch').dispatchEvent(new Event('input'));assert.equal(f.el('discCatalog').querySelectorAll('[data-add]').length,2);await f.add('discraft-buzzz','buzzzsaw').onclick();const copy=f.bag().find(b=>b.id!=='old-buzzz');assert.equal(copy.discId,'discraft-buzzz');assert.equal(copy.plastic,'Fuzed Z · BuzzzSaw');assert.match(f.el('discCatalog').innerHTML,/2 in your bag/)});
test('an add cannot double-submit while pending and a failed save cannot invent ownership',async()=>{const f=await fixture();const button=f.add('axiom-crave');const first=button.onclick();await button.onclick();await first;assert.equal(f.writes(),1);f.fail();const retry=f.add('axiom-crave');await retry.onclick();assert.equal(retry.disabled,false);assert.match(f.el('discCatalog').innerHTML,/1 in your bag/);assert.equal(f.bag().length,1);assert.match(f.messages.at(-1),/Could not add disc/)});
test('ownership refresh preserves catalog pagination and restored copies have counts',async()=>{const f=await fixture();f.el('moreMolds').onclick();await f.add('axiom-crave').onclick();assert.equal((f.el('discCatalog').innerHTML.match(/data-catalog-id=/g)??[]).length,120);const backup={bag:[...f.bag(),{id:'restore-copy',discId:'axiom-crave'}]};await f.el('bagFile').onchange({target:{files:[{size:500,text:async()=>JSON.stringify(backup)}],value:'backup.json'}});f.el('showCatalog').onclick();assert.match(f.el('discCatalog').innerHTML,/2 in your bag/)});
