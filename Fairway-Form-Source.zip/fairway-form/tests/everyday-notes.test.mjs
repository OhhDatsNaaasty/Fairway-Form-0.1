import {EVERYDAY_WOODED_NOTE} from './fixtures/everyday-notes.mjs';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parseLayoutNotes} from '../dist/lib/caddy-layout.js';
import {planShot} from '../dist/lib/caddy.js';
import {DISCS} from '../dist/lib/discs.js';
import {buildHoleScene,holeSceneSVG} from '../dist/lib/hole-scene.js';
import {landingScene,suggestLanding} from '../dist/lib/landing-zone.js';

const userNote=EVERYDAY_WOODED_NOTE;
const bag=[{id:'mid',discId:'discraft-buzzz',distance:250,alternateDistance:160},{id:'driver',discId:'innova-destroyer',distance:310,alternateDistance:180}];
const raw={distanceFt:240,fairway:'straight',type:'auto',hand:'right',hazard:'none'};
const plan=(notes,extra={})=>planShot({...raw,layoutNotes:notes,...extra},bag,DISCS,[],{profile:{skill:'intermediate'}});
for(const [note,side] of [
 [userNote,'right'],
 ['Trees everywhere, basket through the trees just to the left.','left'],
 ['There are lots of trees. The basket is just off to the right through them.','right'],
 ['The hole is heavily wooded. The pin is slightly left through those trees.','left'],
 ['Dense woods. Basket to the right.','right'],
 ['A lot of trees and the basket is between the trees on the left.','left'],
 ['Trees all around. Pin tucked to the right through the woods.','right'],
 ['The basket is behind the trees, just to the left.','left']
])test('wooded destination language: '+note,()=>{
 const p=parseLayoutNotes(note);assert.equal(p.wooded,true);assert.equal(p.throughTrees,true);assert.equal(p.basketSide,side);assert.equal(p.cornerFt,null);assert.equal(p.fairway,null);assert.deepEqual(p.warnings,[]);
 const s=buildHoleScene({distance:240,line:'Straight',note});assert.equal(s.targetSide,side);assert.equal(s.throughTrees,true);assert.equal(s.unplaced.length,0);
 const dx=s.points.at(-1)[0]-s.points[0][0];assert.ok(side==='right'?dx>0:dx<0);
});
for(const [note,direction] of [
 ['A left bend.','left'],['A right-hand bend.','right'],
 ['The fairway bends to the left.','left'],['The hole hooks right.','right'],
 ['The fairway goes a little to the left.','slight-left'],['The hole heads gently right.','slight-right'],
 ['The route sweeps left.','left'],['The hole doglegs to your right.','right'],
 ['Go straight for 200 ft then slightly left.','slight-left']
])test('ordinary route language: '+note,()=>{
 const p=parseLayoutNotes(note);assert.equal(p.fairway,direction);assert.deepEqual(p.warnings,[]);
 const a=plan(note),b=plan(p.cornerFt!=null?'Corner at '+p.cornerFt+' ft.':'',{fairway:direction});assert.equal(a.shot.fairway,direction);assert.deepEqual(a.candidates.map(c=>[c.optionKey,c.targetFt]),b.candidates.map(c=>[c.optionKey,c.targetFt]));
});
for(const note of ['The hole goes left, then heads right.','Fairway bends left, then heads right.','The hole goes left, then bends right.','A left bend. Then a right bend.'])test('ordered route: '+note,()=>{
 const p=parseLayoutNotes(note);assert.equal(p.fairway,'left-right');assert.ok(!p.warnings.some(w=>w.includes('more than one fairway')));
});
test('unordered opposing directions still produce an actionable conflict',()=>{
 const p=parseLayoutNotes('The fairway goes left. The fairway goes right.');assert.equal(p.fairway,null);assert.match(p.warnings.join(' '),/more than one fairway/);
});
for(const note of ["There aren't any trees everywhere.",'The hole is not heavily wooded.','There are no trees.','Not surrounded by trees.'])test('negated woodland: '+note,()=>{
 const p=parseLayoutNotes(note),s=buildHoleScene({distance:240,line:'Straight',note});assert.equal(p.wooded,false);assert.equal(p.throughTrees,false);assert.equal(s.wooded,false);assert.equal(s.features.length,0);
});
test('right behind and right through do not become rightward basket positions',()=>{
 for(const note of ['Basket is right behind those trees.','Basket is right through the trees.']){const p=parseLayoutNotes(note);assert.equal(p.basketSide,null);assert.equal(p.throughTrees,true);assert.equal(p.fairway,null);}
});
test('basket, water and wind directions keep their own subjects',()=>{
 const p=parseLayoutNotes('Basket on the right and water on the left. Wind goes right.');assert.equal(p.basketSide,'right');assert.deepEqual(p.hazards,['left']);assert.equal(p.fairway,null);
 const q=parseLayoutNotes('Water on the right of the basket.');assert.equal(q.basketSide,null);
});
test('a clear fairway through wooded surroundings retains edge trees without a false tight route',()=>{
 const note='Trees everywhere but the fairway is clear.';const p=parseLayoutNotes(note),s=buildHoleScene({distance:240,line:'Straight',note});assert.equal(p.wooded,false);assert.equal(p.throughTrees,false);assert.equal(p.woodedEdges,true);assert.equal(s.wooded,true);assert.equal(s.throughTrees,false);
});
test('an explicitly narrow route remains narrow even when its center is clear',()=>{
 const p=parseLayoutNotes('Trees everywhere. Mostly clear inside the fairway, but a narrow gap.');assert.equal(p.wooded,true);assert.equal(p.throughTrees,true);
});
test('a rightward wooded basket uses a controlled gap line rather than an invented dogleg',()=>{
 const p=plan(userNote);assert.equal(p.layout.fairway,null);assert.equal(p.shot.fairway,'straight');assert.equal(p.shot.wooded,true);assert.match(p.strategy,/clear gap.*right/);assert.equal(p.candidates[0].disc.id,'discraft-buzzz');assert.equal(p.candidates[0].lineFit.kind,'straight');assert.equal(p.candidates[0].releaseAngle,'flat');assert.ok(p.candidates[0].reasons.some(r=>/visible gap.*right/.test(r)));assert.equal(p.layout.cornerFt,null);
});
test('a woodland destination can supply a missing line without inventing an elbow distance',()=>{
 const p=plan(userNote,{fairway:''});assert.equal(p.shot.fairway,'straight');assert.ok(p.candidates.length);assert.equal(p.layout.cornerFt,null);
});
test('hole and landing pictures agree about the rightward destination and interior trees',()=>{
 const p=plan(userNote),home=buildHoleScene({distance:240,line:'Straight',note:userNote}),landing=landingScene(p);assert.deepEqual(home.points,landing.points);assert.equal(home.throughTrees,landing.throughTrees);
 const [a,b,c]=home.points;assert.ok(Math.abs((b[0]-a[0])*(c[1]-a[1])-(c[0]-a[0])*(b[1]-a[1]))<1e-8);assert.match(holeSceneSVG(home,{labels:true}),/Basket right · through trees/);
 assert.match(suggestLanding(p,p.candidates[0]).description,/visible gap.*right/);
});
test('slight and far basket offsets change the picture without inventing flight curves',()=>{
 const a=buildHoleScene({distance:240,line:'Straight',note:'Basket just to the right.'}),b=buildHoleScene({distance:240,line:'Straight',note:'Basket far to the right.'});assert.ok(b.points.at(-1)[0]-b.points[0][0]>a.points.at(-1)[0]-a.points[0][0]);
});
test('later lies do not inherit the old tee-relative basket direction',()=>{
 const p=plan(userNote,{lie:'fairway',distanceFt:90,layoutNotesCurrent:false});assert.equal(p.layout.basketSide,null);assert.equal(p.layout.basketDirectionOnly,false);assert.equal(landingScene(p,{throws:[{input:raw}],courseLayout:raw}).targetSide,undefined);
});
test('language interpretation preserves original notes and cannot create measured throw data',()=>{
 const input={...raw,layoutNotes:userNote},before=JSON.stringify({input,bag}),p=planShot(input,bag,DISCS);suggestLanding(p,p.candidates[0]);assert.equal(JSON.stringify({input,bag}),before);assert.equal(p.shot.distanceFt,240);assert.equal(p.shot.layoutNotes,userNote);assert.equal(p.layout.bearing,undefined);assert.equal(p.layout.throwDistanceFt,undefined);
});

test('a notes-only basket direction also supplies the home picture before recommending',()=>{
 const s=buildHoleScene({distance:240,line:'',note:userNote});assert.equal(s.targetSide,'right');assert.ok(s.points);assert.equal(s.throughTrees,true);
});
