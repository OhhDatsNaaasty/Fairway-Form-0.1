import {test} from 'node:test';import assert from 'node:assert/strict';
import {terrainSky} from '../dist/lib/terrain-sky.js';
import {terrainCamera,normalizeTerrainTilt} from '../dist/lib/terrain-camera.js';
import {buildHoleScene,holeSceneSVG,scenePoint} from '../dist/lib/hole-scene.js';
import {terrainProjection} from '../dist/lib/hole-terrain.js';
import {pickHolePoint} from '../dist/lib/hole-navigation.js';
import {filterResources} from '../dist/lib/research-index.js';
const date=h=>Date.UTC(2026,10,17,h),w=(h,cloudCover=0)=>({fetchedAt:date(h),cloudCover,weatherCode:cloudCover>=80?3:0,isDay:h>=6&&h<18,sunEvents:[{sunriseAt:date(6),sunsetAt:date(18)}]});
const scene=buildHoleScene({distance:475,line:'Slight dogleg right',note:'Trees along both sides. Basket on a small hill 8 ft high.'});
test('clock fallback gives day, sunrise, sunset and night without acquiring location or weather',()=>{
 for(const [h,phase]of [[5.5,'sunrise'],[12,'day'],[18,'sunset'],[22,'night']]){const sky=terrainSky({now:date(12),localHour:h});assert.equal(sky.phase,phase);assert.equal(sky.source,'local-clock');assert.equal(sky.condition,'clear')}
});
test('available sun times override the clock approximation and lower the illustrated sun near sunset',()=>{
 const sunset=date(16),weather={...w(15),sunEvents:[{sunriseAt:date(7),sunsetAt:sunset}]},day=terrainSky({now:date(12),localHour:12,weather:{...weather,fetchedAt:date(12)}}),late=terrainSky({now:sunset-15*60000,localHour:15.75,weather:{...weather,fetchedAt:sunset-15*60000}});assert.equal(late.phase,'sunset');assert.equal(late.source,'weather-sun-times');assert.ok(late.sunY>day.sunY);
});
test('the moon and stars appear at night while the sun is hidden',()=>{
 const night=terrainSky({now:date(22),weather:w(22)}),day=terrainSky({now:date(12),weather:w(12)});assert.equal(night.sunOpacity,0);assert.ok(night.moonOpacity>0&&night.starOpacity>0);assert.equal(day.moonOpacity,0);assert.equal(day.starOpacity,0);
});
test('cloudy and rainy weather soften the sky and obscure the celestial lights',()=>{
 const cloudy=terrainSky({now:date(12),weather:w(12,95)}),rain=terrainSky({now:date(12),weather:{...w(12,95),rainMm:2,weatherCode:61}}),night=terrainSky({now:date(22),weather:w(22,100)});assert.equal(cloudy.condition,'cloudy');assert.equal(rain.condition,'rain');assert.ok(cloudy.cloudOpacity>.7);assert.equal(cloudy.sunOpacity,0);assert.equal(night.starOpacity,0);
});
test('stale conditions are ignored while bounded same-day sun timings can still guide time of day',()=>{
 const weather={...w(12,100),fetchedAt:date(10)},sky=terrainSky({now:date(12),weather});assert.equal(sky.condition,'clear');assert.equal(sky.cloudOpacity,0);assert.equal(sky.source,'weather-sun-times');const old=terrainSky({now:date(12),localHour:12,weather:{...weather,fetchedAt:date(12)-40*3600000}});assert.equal(old.source,'local-clock');
});
test('invalid sun events and future weather cannot invent a live sky source',()=>{
 assert.equal(terrainSky({now:date(12),weather:{...w(12),fetchedAt:date(13)}}).source,'local-clock');assert.equal(terrainSky({now:date(12),weather:{...w(12),sunEvents:[{sunriseAt:NaN,sunsetAt:date(18)}]}}).source,'local-clock');
});
test('all sky art is clipped above the ground horizon and disappears from the overhead ground view',()=>{
 for(const tilt of [10,14,30,60,90]){const sky=terrainSky({now:date(22),weather:w(22)}),svg=holeSceneSVG(scene,{sky,tilt}),height=Math.max(0,Math.min(560,terrainCamera(scene,0,tilt).horizon)),clip=svg.match(/data-orbit-key="sky-clip"[^>]*height="([^"]*)"/);assert.ok(clip);assert.equal(Number(clip[1]),height);assert.match(svg,/data-sky="night"[^>]*clip-path="url\(#terrain-sky-clip\)"/);assert.match(svg,/data-orbit-key="ground-plane"/);assert.match(svg,/gradientUnits="userSpaceOnUse"/);assert.equal(Number(svg.match(/data-orbit-key="sky-gradient"[^>]*y2="([^"]*)"/)[1]),Math.max(1,height));if(tilt===90)assert.equal(height,0)}
});
test('overhead projection is finite and hill picking still intersects the exact rendered ground',()=>{
 for(const angle of [0,90,180,270]){const p=scenePoint(scene,250),screen=terrainProjection(scene,{},angle,null,90).project(p),hit=pickHolePoint(scene,screen,angle,90);assert.ok([screen.x,screen.y,screen.depth].every(Number.isFinite));assert.ok(hit&&Math.hypot(hit.x-p.x,hit.y-p.y)<.01)}assert.equal(normalizeTerrainTilt(-100),10);assert.equal(normalizeTerrainTilt(1000),90);assert.equal(normalizeTerrainTilt(NaN),14);
});
test('the sky reference can be found in the research library',()=>{assert.ok(filterResources({query:'sunrise sunset'}).some(s=>s.id==='scienceSkyWeather'))});
