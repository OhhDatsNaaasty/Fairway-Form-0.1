import {test} from 'node:test';
import assert from 'node:assert/strict';
import {relativeWind,parseWeather,fetchWeather,weatherIsFresh} from '../dist/lib/caddy-weather.js';
const now=Date.parse('2026-10-21T12:00:00Z');
const payload=()=>({current_units:{wind_speed_10m:'mp/h',wind_gusts_10m:'mp/h',temperature_2m:'°C',precipitation:'mm'},current:{time:'2026-10-21T12:00',wind_speed_10m:10,wind_gusts_10m:18,wind_direction_10m:90,temperature_2m:20,precipitation:0}});
test('meteorological wind-from direction is converted relative to a northbound throw',()=>{
 assert.equal(relativeWind(0,0,10).direction,'head');assert.equal(relativeWind(180,0,10).direction,'tail');
 assert.equal(relativeWind(90,0,10).direction,'right-left');assert.equal(relativeWind(270,0,10).direction,'left-right');
});
test('the same wind changes its relative direction when the next throw faces another way',()=>{
 assert.equal(relativeWind(90,90,10).direction,'head');assert.equal(relativeWind(90,270,10).direction,'tail');
 assert.equal(relativeWind(90,180,10).direction,'left-right');
});
test('diagonal winds retain both head/tail and crosswind components',()=>{
 const wind=relativeWind(45,0,10);assert.ok(wind.headMph>7&&wind.crossMph<-7);assert.match(wind.label,/headwind/);assert.match(wind.label,/right → left/);
});
test('missing and invalid bearings cannot silently become north',()=>{
 for(const bearing of ['',null,undefined,NaN,999,-1])assert.throws(()=>relativeWind(90,bearing,10));
});
test('weather parsing rejects wrong units, stale timestamps and unusable wind',()=>{
 const p=payload();assert.equal(parseWeather(p,now).windMph,10);
 assert.throws(()=>parseWeather({...p,current_units:{wind_speed_10m:'km/h',wind_gusts_10m:'km/h'}},now),/units/);
 assert.throws(()=>parseWeather({...p,current:{...p.current,time:'2026-10-20T12:00'}},now),/out of date/);
 assert.throws(()=>parseWeather({...p,current:{...p.current,wind_speed_10m:null}},now),/Usable wind/);
});
test('a weather request rounds location and requests explicit mph; it returns no coordinates',async()=>{
 let request;const result=await fetchWeather(40.123456,-75.987654,{now,fetcher:async url=>{request=new URL(url);return {ok:true,json:async()=>payload()}}});
 assert.equal(request.searchParams.get('latitude'),'40.12');assert.equal(request.searchParams.get('longitude'),'-75.99');assert.equal(request.searchParams.get('wind_speed_unit'),'mph');
 assert.ok(!('latitude' in result)&&!('longitude'in result));assert.equal(result.model,true);assert.equal(result.provider,'Open-Meteo');
});
test('weather failure leaves the manual path available and does not fabricate values',async()=>{
 await assert.rejects(fetchWeather(40,-75,{fetcher:async()=>({ok:false})}),/Manual wind controls/);
 await assert.rejects(fetchWeather(NaN,0),/valid one-time location/);
});
test('a cached model can only be applied while fresh',()=>{
 const w=parseWeather(payload(),now);assert.equal(weatherIsFresh(w,now+29*60*1000),true);assert.equal(weatherIsFresh(w,now+31*60*1000),false);assert.equal(weatherIsFresh(null,now),false);
});
test('unexpected temperature or rain units are not silently converted into misleading context',()=>{
 const p=payload();p.current_units.temperature_2m='°F';p.current_units.precipitation='inch';
 const result=parseWeather(p,now);assert.equal(result.tempC,null);assert.equal(result.rainMm,null);
});
