import {test} from 'node:test';
import assert from 'node:assert/strict';
import {sameMold,httpsUrl,imageCandidates,productLinks,shopifyImages,imageKind} from '../scripts/lib/disc-photos.mjs';
import {readPhotoIndex} from '../dist/lib/disc-photos.js';
const page='https://www.discmania.net/collections/fd';
test('photo matching separates similar molds and handles the PA-3 naming convention',()=>{
 assert.ok(sameMold('C-Line FD','FD'));assert.ok(sameMold('Prodigy PA3 300 Plastic','PA-3'));
 for(const [title,model]of [['C-Line FD1','FD'],['Halo Roc+','Roc'],['Buzzz OS','Buzzz'],['Buzzz SS','Buzzz'],['EMAC Truth','Truth'],['Grand Saint Pro','Saint'],['D1 Max','D1'],['Premier MD3','MD3']])assert.equal(sameMold(title,model),false,title);
});
test('image discovery reads matching Product data and excludes a related product',()=>{
 const html='<script type="application/ld+json">'+JSON.stringify({'@graph':[{'@type':'Product',name:'C-Line FD1',image:'https://cdn.shopify.com/fd1.png'},{'@type':'Product',name:'C-Line FD',image:'https://cdn.shopify.com/fd.png'}]})+'</script>';
 assert.deepEqual(imageCandidates(html,page,'FD').map(v=>v.url),['https://cdn.shopify.com/fd.png']);
});
test('product photos are preferred over logos and flight charts, with HTTPS URLs only',()=>{
 const html='<img alt="FD flight chart" src="https://cdn.shopify.com/fd-flight-chart.png"><img alt="C-Line FD" src="//cdn.shopify.com/fd.png"><img alt="C-Line FD" src="javascript:alert(1)"><img alt="C-Line FD" src="https://cdn.shopify.com/logo-fd.png">';
 assert.deepEqual(imageCandidates(html,page,'FD').map(v=>v.url),['https://cdn.shopify.com/fd.png']);
 assert.equal(httpsUrl('',page),null);assert.equal(httpsUrl('http://example.com/x',page),null);assert.equal(httpsUrl('https://name:secret@example.com/x',page),null);
});
test('an unrelated Wix template image is rejected even when its caption uses the requested mold',()=>{
 const html='<img alt="Force" src="https://static.wixstatic.com/media/hash/apx.png">';assert.equal(imageCandidates(html,'https://www.team.discraft.com/discs/force','Force').length,0);
});
test('catalog links stay on the manufacturer site and keep FD separate from FD1',()=>{
 const html='<a href="/collections/fd1">FD1 – Fairway Driver</a><a href="/collections/fd">FD – Fairway Driver – 7 | 6 | 0 | 1</a><a href="https://example.com/products/fd">FD</a>';
 assert.deepEqual(productLinks(html,page,'FD'),['https://www.discmania.net/collections/fd']);
});
test('Shopify collection discovery rejects a different mold and accepts a matching product',()=>{
 const result=shopifyImages({products:[{title:'C-Line FD1',handle:'fd1',images:[{src:'https://cdn.shopify.com/fd1.png'}]},{title:'S-Line FD',handle:'s-line-fd',images:[{src:'https://cdn.shopify.com/fd.png'}]}]},page,'FD');assert.equal(result.length,1);assert.equal(result[0].page,'https://www.discmania.net/products/s-line-fd');
});
test('HTML error pages cannot masquerade as a bundled photo',()=>{
 assert.equal(imageKind(Buffer.from('<html>'+'.'.repeat(400)+'</html>'),'image/png'),null);
 const png=Buffer.alloc(300);Buffer.from([137,80,78,71,13,10,26,10]).copy(png);assert.equal(imageKind(png,'image/png'),'png');assert.equal(imageKind(png,'image/jpeg'),null);
});
test('the app accepts only local photos tied to a known mold and safe source link',()=>{
 const catalog=[{id:'discmania-fd'}],image={src:'./disc-photos/discmania-fd.png',sourcePage:'https://www.discmania.net/collections/fd',credit:'Discmania'};
 assert.equal(readPhotoIndex({images:{'discmania-fd':image}},catalog).size,1);
 for(const src of ['https://example.com/fd.png','./disc-photos/other.png','./disc-photos/../app.js'])assert.equal(readPhotoIndex({images:{'discmania-fd':{...image,src}}},catalog).size,0);
 assert.equal(readPhotoIndex({images:{'unknown-model':image}},catalog).size,0);assert.equal(readPhotoIndex({images:{'discmania-fd':{...image,sourcePage:'javascript:alert(1)'}}},catalog).size,0);
});
