import {test} from 'node:test';
import assert from 'node:assert/strict';
import {explainFinding,makeCoachPlan,reviewIntro,videoEvidence,practiceChoices} from '../dist/lib/coaching-language.js';
const finding=(id,kind='observe')=>({id,kind,title:id,t:.5,evidence:'Projected angle is 167° at 430 ms and 0.45 torso lengths.',meaning:'Technical interpretation',sourceIds:[]});
const report=findings=>({findings,release:.7,estimated:false,usable:20,options:{type:'backhand',view:'side'},quality:{}});
test('the practice focus follows an actual review prompt and leaves measurements out of narration',()=>{
 const r=report([finding('head','attention'),finding('arm','positive'),finding('brace','attention')]);const plan=makeCoachPlan(r);
 assert.deepEqual(plan.focus,['brace']);assert.deepEqual(plan.positive,['arm']);
 assert.match(plan.text,/Slow the approach/);assert.ok(plan.drills.length>=2);assert.ok(plan.selectedDrill);assert.match(plan.text,/settled stance/);assert.doesNotMatch(plan.text,/167|430|torso lengths|Projected/);
});
test('an observation is not turned into an invented fault or praise',()=>{
 const plan=makeCoachPlan(report([finding('arm'),finding('feet')]));
 assert.equal(plan.focus.length,0);assert.equal(plan.positive.length,0);assert.match(plan.text,/isn’t a specific change I can back up/);
});
test('missing landmarks lead to filming guidance rather than a guessed technique correction',()=>{
 const unknown=explainFinding(finding('brace','unknown'),report([]));
 assert.match(unknown.observation,/cannot judge/);assert.match(unknown.cue,/both feet visible/);assert.doesNotMatch(unknown.cue,/Slow the approach|lock/);
});
test('a standstill does not receive a made-up landing instruction',()=>{
 const copy=explainFinding(finding('timing','unknown'),{options:{stance:'standstill'}});
 assert.match(copy.observation,/does not assume a new foot landing/);assert.doesNotMatch(copy.cue,/step, then swing/i);
});
test('forehands and specialty throws do not inherit backhand timing drills',()=>{
 for(const type of ['forehand','putt','roller','overhand']){
  const copy=explainFinding(finding('timing'),{options:{type}});
  assert.doesNotMatch(copy.drill,/backhand|step, then swing/i);
 }
});
test('every supported body check has actionable copy without a measurement dump',()=>{
 for(const id of ['release','head','posture','reachback','arm','upper-arm','coil','timing','feet','brace','wrist','off-arm','finish']){
  for(const kind of ['attention','observe','positive','unknown']){
   const copy=explainFinding(finding(id,kind),report([]));
   assert.ok(copy.title&&copy.observation&&copy.cue&&copy.drill,id);assert.doesNotMatch(copy.observation,/167|430|0\.45/);
  }
 }
});
test('a partial review is disclosed before any spoken coaching',()=>{
 const r=report([finding('posture','attention')]);r.quality.incomplete=true;
 assert.match(makeCoachPlan(r).text,/^This review is incomplete/);
});
test('uncertain release and insufficient footage keep honest next steps',()=>{
 const r=report([finding('head','attention')]);r.estimated=true;assert.match(makeCoachPlan(r).text,/check the suggested release/);
 assert.match(reviewIntro({usable:0,findings:[]}),/Not enough clear video/);
 assert.match(reviewIntro({usable:20,release:null,findings:[]}),/Mark the moment/);
 assert.equal(makeCoachPlan(null).focus.length,0);
});

test('the main plan links event order to this report’s marked video times',()=>{
 const r=report([finding('timing','attention')]);r.phases=[{id:'plant',t:.45,origin:'marked'},{id:'release',t:.7,origin:'marked'}];
 const plan=makeCoachPlan(r);
 assert.match(plan.text,/0.45s/);assert.match(plan.text,/0.70s/);assert.match(plan.text,/0.25s later/);
 assert.deepEqual(plan.moments.map(m=>m.t),[.45,.7]);assert.deepEqual(plan.focus,['timing']);
});
test('estimated events stay labeled as suggestions and do not establish an ideal interval',()=>{
 const r=report([finding('reachback')]);r.phases=[{id:'reachback',t:.2,origin:'estimated'},{id:'plant',t:.45,origin:'estimated'}];
 const evidence=videoEvidence(r.findings[0],r);
 assert.match(evidence.summary,/Suggested backswing/);assert.match(evidence.summary,/0.25s before/);
 assert.ok(evidence.moments.every(m=>m.origin==='estimated'));assert.doesNotMatch(evidence.summary,/too early|too late|perfect/);
});
test('observed movement supports a labeled practice experiment without inventing a fault',()=>{
 const r=report([finding('reachback'),finding('feet','unknown')]);const plan=makeCoachPlan(r);
 assert.deepEqual(plan.focus,[]);assert.deepEqual(plan.explore,['reachback']);assert.ok(plan.drills.length>=2);
 assert.match(plan.text,/optional practice experiment/);assert.doesNotMatch(plan.text,/Move the camera|Film side-on|front-foot landing is not clear/);
});
test('users can change visible focus and drill without changing measured findings',()=>{
 const r=report([finding('reachback'),finding('brace','attention')]),before=JSON.stringify(r);
 const plan=makeCoachPlan(r,{focusId:'reachback',drillId:'walk-past'});
 assert.equal(plan.selectedFocus,'reachback');assert.equal(plan.selectedDrill,'walk-past');assert.deepEqual(plan.focus,[]);
 assert.match(plan.text,/moving past the disc/);assert.equal(JSON.stringify(r),before);
 const other=makeCoachPlan(r,{focusId:'brace',drillId:'walk-past'});assert.notEqual(other.selectedDrill,'walk-past');
});
test('unknown body parts cannot become a selectable personal practice finding',()=>{
 const r=report([finding('wrist','unknown'),finding('posture')]);
 assert.ok(!practiceChoices(r).some(c=>c.id==='wrist'));
 assert.notEqual(makeCoachPlan(r,{focusId:'wrist'}).selectedFocus,'wrist');
 assert.deepEqual(videoEvidence(r.findings[0],r),{summary:'',moments:[]});
});
test('an explicitly selected X-step lesson stays general and has no claimed video evidence',()=>{
 const plan=makeCoachPlan(report([finding('feet')]),{focusId:'xstep'});
 assert.equal(plan.selectedFocus,'xstep');assert.deepEqual(plan.focus,[]);assert.deepEqual(plan.moments,[]);
 assert.match(plan.text,/general X-step lesson/);assert.match(plan.text,/not a detected form fault/);
});
test('standstills, forehands and specialty throws cannot inherit the X-step program',()=>{
 for(const options of [{type:'backhand',stance:'standstill'},{type:'forehand'},{type:'putt'},{type:'overhand'},{type:'roller'}]){
  const r=report([finding('feet'),finding('brace'),finding('timing')]);r.options=options;
  assert.ok(!practiceChoices(r).some(c=>c.id==='xstep'));
  const plan=makeCoachPlan(r,{focusId:'xstep'});assert.notEqual(plan.selectedFocus,'xstep');
  if(options.type!=='backhand')assert.ok(plan.drills.every(d=>!d.types.includes('backhand')||d.types.includes(options.type)));
  if(options.stance==='standstill')assert.ok(plan.drills.every(d=>!d.stances||d.stances.includes('standstill')));
 }
});
test('a disabled fixed-camera setting is explained as that setting, not hidden feet',()=>{
 const copy=explainFinding(finding('brace','unknown'),{options:{cameraStable:false}});
 assert.match(copy.observation,/Camera stays fixed is switched off/);assert.match(copy.cue,/If the phone really stayed fixed/);
 assert.doesNotMatch(copy.observation,/hidden|missing part/);
});
test('old reports without event provenance are not labeled as marked releases',()=>{
 const evidence=videoEvidence(finding('arm'),{release:.7});
 assert.ok(evidence.moments.every(m=>m.origin!=='marked'));assert.doesNotMatch(evidence.summary,/Marked/);
});
