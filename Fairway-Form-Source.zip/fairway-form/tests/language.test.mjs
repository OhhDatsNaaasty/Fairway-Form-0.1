import {test} from 'node:test';
import assert from 'node:assert/strict';
import {explainFinding,makeCoachPlan,reviewIntro} from '../dist/lib/coaching-language.js';
const finding=(id,kind='observe')=>({id,kind,title:id,t:.5,evidence:'Projected angle is 167° at 430 ms and 0.45 torso lengths.',meaning:'Technical interpretation',sourceIds:[]});
const report=findings=>({findings,release:.7,estimated:false,usable:20,options:{type:'backhand',view:'side'},quality:{}});
test('the practice focus follows an actual review prompt and leaves measurements out of narration',()=>{
 const r=report([finding('head','attention'),finding('arm','positive'),finding('brace','attention')]);const plan=makeCoachPlan(r);
 assert.deepEqual(plan.focus,['brace']);assert.deepEqual(plan.positive,['arm']);
 assert.match(plan.text,/Slow the approach/);assert.match(plan.text,/three gentle one-step throws/);assert.doesNotMatch(plan.text,/167|430|torso lengths|Projected/);
});
test('an observation is not turned into an invented fault or praise',()=>{
 const plan=makeCoachPlan(report([finding('arm'),finding('feet')]));
 assert.equal(plan.focus.length,0);assert.equal(plan.positive.length,0);assert.match(plan.text,/isn’t a specific change I can back up/);
});
test('missing landmarks lead to filming guidance rather than a guessed technique correction',()=>{
 const unknown=explainFinding(finding('brace','unknown'),report([]));
 assert.match(unknown.observation,/cannot judge/);assert.match(unknown.cue,/both feet visible/);assert.doesNotMatch(unknown.cue,/Slow the approach|lock/);
});
test('a standstill does not receive a made-up landing instruction',()=>{
 const copy=explainFinding(finding('timing','unknown'),{options:{stance:'standstill'}});
 assert.match(copy.observation,/does not assume a new foot landing/);assert.doesNotMatch(copy.cue,/step, then swing/i);
});
test('forehands and specialty throws do not inherit backhand timing drills',()=>{
 for(const type of ['forehand','putt','roller','overhand']){
  const copy=explainFinding(finding('timing'),{options:{type}});
  assert.doesNotMatch(copy.drill,/backhand|step, then swing/i);
 }
});
test('every supported body check has actionable copy without a measurement dump',()=>{
 for(const id of ['release','head','posture','reachback','arm','upper-arm','coil','timing','feet','brace','wrist','off-arm','finish']){
  for(const kind of ['attention','observe','positive','unknown']){
   const copy=explainFinding(finding(id,kind),report([]));
   assert.ok(copy.title&&copy.observation&&copy.cue&&copy.drill,id);assert.doesNotMatch(copy.observation,/167|430|0\.45/);
  }
 }
});
test('a partial review is disclosed before any spoken coaching',()=>{
 const r=report([finding('posture','attention')]);r.quality.incomplete=true;
 assert.match(makeCoachPlan(r).text,/^This review is incomplete/);
});
test('uncertain release and insufficient footage keep honest next steps',()=>{
 const r=report([finding('head','attention')]);r.estimated=true;assert.match(makeCoachPlan(r).text,/check the suggested release/);
 assert.match(reviewIntro({usable:0,findings:[]}),/Not enough clear video/);
 assert.match(reviewIntro({usable:20,release:null,findings:[]}),/Mark the moment/);
 assert.equal(makeCoachPlan(null).focus.length,0);
});
