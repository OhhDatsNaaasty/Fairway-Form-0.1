import {test} from 'node:test';
import assert from 'node:assert/strict';
import {reviewFeedback} from '../dist/lib/field-ui.js';

const report={total:90,usable:75,release:1.5,quality:{}};
test('loading a clip alone never announces analysis success',()=>{
 assert.equal(reviewFeedback({blob:new Blob([])}),null);
});
test('a rerun does not present the old report as a completed new analysis',()=>{
 const feedback=reviewFeedback({reviewOutcome:'analyzing',report});
 assert.equal(feedback.kind,'working');assert.ok(!feedback.canOpen);
});
test('a complete review offers coaching independently of the selected tab',()=>{
 const feedback=reviewFeedback({reviewOutcome:'complete',report});
 assert.equal(feedback.title,'Analysis complete');assert.equal(feedback.canOpen,true);
});
test('completed sampling with missing throw moments explains the detection limit',()=>{
 const feedback=reviewFeedback({reviewOutcome:'complete',report:{...report,release:null}});
 assert.equal(feedback.kind,'complete');assert.match(feedback.message,/could not be identified/);assert.ok(feedback.canOpen);
});
test('an unavailable optional hand pass preserves completed body coaching',()=>{
 const feedback=reviewFeedback({reviewOutcome:'complete',report,sampleInfo:{detailIncomplete:true}});
 assert.equal(feedback.kind,'complete');assert.match(feedback.message,/body review is ready/);assert.match(feedback.message,/hand close-up did not finish/);
});
test('interrupted and saved partial reports cannot claim full completion',()=>{
 for(const reviewOutcome of ['partial','saved']){
  const feedback=reviewFeedback({reviewOutcome,report:{...report,quality:{incomplete:true}}});
  assert.equal(feedback.kind,'partial');assert.equal(feedback.title,'Partial review ready');assert.ok(feedback.canOpen);
 }
});
test('cancelled analysis distinguishes a retained report from no result',()=>{
 const kept=reviewFeedback({reviewOutcome:'cancelled',report});
 assert.equal(kept.title,'Analysis cancelled');assert.ok(kept.canOpen);
 const empty=reviewFeedback({reviewOutcome:'cancelled'});
 assert.equal(empty.kind,'error');assert.ok(!empty.canOpen);assert.match(empty.message,/No review/);
});
test('failed analysis exposes its error instead of enabling empty coaching',()=>{
 const feedback=reviewFeedback({reviewOutcome:'error',reviewError:'The video decoder stopped.'});
 assert.equal(feedback.title,'Analysis could not finish');assert.equal(feedback.message,'The video decoder stopped.');assert.ok(!feedback.canOpen);
});
test('no-person footage finishes with recording guidance rather than a form success claim',()=>{
 const feedback=reviewFeedback({reviewOutcome:'complete',report:{...report,usable:0}});
 assert.equal(feedback.kind,'limited');assert.match(feedback.title,/limited visibility/);assert.ok(feedback.canOpen);
});
test('saved reviews and disc-only traces have distinct ready messages',()=>{
 assert.equal(reviewFeedback({reviewOutcome:'saved',report}).title,'Saved review ready');
 const trace=reviewFeedback({report:{total:0}});assert.equal(trace.title,'Disc trail ready');assert.match(trace.message,/Analyze your throw/);
});
