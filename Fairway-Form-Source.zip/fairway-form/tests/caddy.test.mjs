import {test} from 'node:test';
import assert from 'node:assert/strict';
import {planShot,fadeSide,loggedRange,makeHole,recordThrow,feedbackFor,toFeet,fromFeet,normalizeShot,windLevel} from '../dist/lib/caddy.js';
const mold=(id,speed,glide,turn,fade,type='Fairway')=>({id,brand:'Test',model:id,speed,glide,turn,fade,type});
const catalog=[mold('neutral',7,5,-1,1),mold('stable',7,4,0,3),mold('turn',7,5,-3,1),mold('mid',5,4,0,1,'Midrange'),mold('putt',2,3,0,1,'Putter'),mold('fast',12,5,-1,3,'Distance')];
const bag=catalog.map(d=>({id:'bag-'+d.id,discId:d.id,distance:d.id==='fast'?330:d.id==='putt'?170:d.id==='mid'?230:280,distanceThrow:'backhand',condition:'Stock'}));
const input={distanceFt:230,fairway:'straight',hand:'right',type:'backhand',elevation:'level',windStrength:'calm',windDirection:'calm'};
const names=plan=>plan.candidates.map(c=>c.discId);

test('recommendations only contain copies actually in the saved bag',()=>{
 const plan=planShot(input,bag.filter(b=>b.discId==='mid'),catalog);
 assert.deepEqual(names(plan),['mid']);assert.ok(plan.candidates.every(c=>c.bagId==='bag-mid'));
 assert.equal(planShot(input,[],catalog).candidates.length,0);
});
test('unknown bag models are skipped rather than replaced with catalog suggestions',()=>{
 const result=planShot(input,[{id:'gone',discId:'not-in-catalog'}],catalog);
 assert.equal(result.candidates.length,0);assert.match(result.warnings[0],/catalog/);
});
test('straight wooded lines favor a reachable controlled disc over a fast driver',()=>{
 const plan=planShot({...input,distanceFt:190,fairway:'woods'},bag,catalog);
 assert.equal(plan.candidates[0].discId,'mid');assert.ok(plan.notes.some(n=>n.includes('clean gap')));
});
test('hand and forehand/backhand reverse the natural late-fade side',()=>{
 assert.equal(fadeSide('right','backhand'),'left');assert.equal(fadeSide('left','backhand'),'right');
 assert.equal(fadeSide('right','forehand'),'right');assert.equal(fadeSide('left','forehand'),'left');
});
test('a bending line changes the shortlist and explains a turnover tradeoff',()=>{
 const left=planShot({...input,distanceFt:250,fairway:'left'},bag,catalog);
 const right=planShot({...input,distanceFt:250,fairway:'right'},bag,catalog);
 assert.equal(left.candidates[0].discId,'stable');assert.equal(right.candidates[0].discId,'turn');
 assert.ok(right.candidates[0].cautions.some(c=>c.includes('opposes')));
});
test('a strong headwind changes the ranking and discloses the stability reasoning',()=>{
 const plan=planShot({...input,distanceFt:250,windDirection:'head',windStrength:'strong'},bag,catalog);
 assert.equal(plan.candidates[0].discId,'stable');assert.ok(plan.notes.some(n=>n.includes('relative')));
 assert.ok(plan.notes.some(n=>n.includes('Strong wind')));
});
test('tailwind guidance does not insist on the fastest mold',()=>{
 const plan=planShot({...input,windDirection:'tail',windStrength:'medium'},bag,catalog);
 assert.notEqual(plan.candidates[0].discId,'fast');assert.ok(plan.notes.some(n=>n.includes('slower')));
});
test('crosswind guidance preserves bank-angle uncertainty instead of claiming a fixed curve',()=>{
 const plan=planShot({...input,windDirection:'left-right',windStrength:'medium'},bag,catalog);
 assert.ok(plan.notes.some(n=>n.includes('which side of the flight plate')));
 assert.ok(plan.notes.some(n=>n.includes('no fixed aim correction')));
});
test('numeric wind and gusts override the qualitative category, with contradictory calm reset',()=>{
 const s=normalizeShot({...input,windMph:12,gustMph:25});assert.equal(windLevel(s),'strong');assert.equal(s.windDirection,'unknown');
 assert.equal(windLevel(normalizeShot({...input,windStrength:'strong',windMph:0,gustMph:0})),'calm');
});
test('uncalibrated discs keep measured range empty and show a separately labeled estimated window',()=>{
 const plan=planShot({...input,type:'forehand'},bag,catalog);
 assert.ok(plan.candidates.every(c=>c.rangeFt===null));assert.ok(plan.warnings.some(w=>w.includes('this throw style')));
 assert.ok(plan.candidates.every(c=>c.estimatedRange.lowFt>0&&c.cautions.some(w=>w.includes('Estimated planning window'))));
});
test('a separately logged other-throw distance is used only for that throw',()=>{
 const item={...bag[0],alternateDistance:180};assert.equal(loggedRange(item,'forehand'),180);assert.equal(loggedRange(item,'backhand'),280);
 assert.equal(loggedRange({...item,distanceThrow:'forehand'},'forehand'),280);
 assert.equal(loggedRange({...item,distanceThrow:'forehand'},'backhand'),180);
});
test('putting never uses a putter’s full throwing distance as make range',()=>{
 const plan=planShot({...input,type:'putt',distanceFt:40},bag,catalog);
 assert.ok(plan.candidates.every(c=>c.disc.type==='Putter'));assert.equal(plan.candidates[0].rangeFt,null);
 assert.ok(plan.candidates[0].cautions.some(c=>c.includes('Throwing distance is not used')));
});
test('putting chooses only bag putters and respects putting favorites',()=>{
 const others=[...catalog,mold('second',3,3,0,2,'Putter')],items=[...bag,{id:'fav',discId:'second',puttingPreferred:true,puttingRange:25}];
 const plan=planShot({...input,type:'putt',distanceFt:20},items,others);
 assert.equal(plan.candidates[0].bagId,'fav');assert.equal(plan.candidates[0].rangeFt,25);
 assert.ok(plan.candidates.every(c=>c.disc.speed<=3.5));
});
test('without a putting disc the caddy cannot quietly recommend a driver',()=>{
 const plan=planShot({...input,type:'putt',distanceFt:20},bag.filter(b=>b.discId==='fast'),catalog);
 assert.equal(plan.candidates.length,0);assert.match(plan.warnings[0],/No putter/);
});
test('a dangerous longer putt gets a risk-based layup, with explicit run override',()=>{
 const shot={...input,type:'putt',distanceFt:45,comfortablePuttFt:20,hazard:'long'};
 assert.match(planShot(shot,bag,catalog).strategy,/lay-up/);
 const run=planShot({...shot,puttIntent:'run'},bag,catalog);assert.doesNotMatch(run.strategy,/lay-up/);assert.ok(run.warnings.some(w=>w.includes('chose to run')));
});
test('uphill/downhill and wet inputs produce contextual advice without exact flight claims',()=>{
 for(const elevation of ['uphill','downhill']){const plan=planShot({...input,elevation,wet:true},bag,catalog);assert.ok(plan.notes.some(n=>n.startsWith(elevation==='uphill'?'Uphill':'Downhill')));assert.ok(plan.notes.some(n=>n.startsWith('Wet')))}
});
test('a user-selected corner distance changes the planning target without changing basket distance',()=>{
 const shot={...input,distanceFt:450,landingFt:150,fairway:'left'},plan=planShot(shot,bag,catalog);
 assert.equal(plan.shot.distanceFt,450);assert.equal(plan.shot.landingFt,150);assert.match(plan.strategy,/landing point/);
 assert.notEqual(plan.candidates[0].discId,'fast');
});
test('meters convert to canonical feet and reference reasons use the selected unit',()=>{
 assert.ok(Math.abs(toFeet(100,'m')-328.0839895)<1e-6);assert.ok(Math.abs(fromFeet(328.0839895,'m')-100)<1e-6);
 const plan=planShot({...input,unit:'m'},bag,catalog);assert.ok(plan.candidates[0].reasons.some(r=>/m logged/.test(r)));
});
test('invalid distances, lines and landing points cannot produce a recommendation',()=>{
 for(const shot of [{...input,distanceFt:''},{...input,distanceFt:-1},{...input,distanceFt:Infinity},{...input,fairway:''},{...input,landingFt:9999},{...input,windMph:-3}])assert.throws(()=>planShot(shot,bag,catalog));
});
test('a throw advances from tee to a fresh lie using actual remaining distance',()=>{
 const hole=makeHole('Hole 1'),plan=planShot({...input,windDirection:'head',windStrength:'medium'},bag,catalog);hole.draft={...hole.draft,...input,windDirection:'head',windStrength:'medium'};
 const next=recordThrow(hole,{plan,usedBagId:'bag-mid',outcome:'short',remainingFt:70});
 assert.equal(hole.throws.length,0);assert.equal(next.throws.length,1);assert.equal(next.throws[0].number,1);assert.equal(next.draft.distanceFt,70);
 assert.equal(next.draft.fairway,'');assert.equal(next.draft.windDirection,'unknown');assert.equal(next.draft.bearing,'');
});
test('unknown remaining distance cannot reuse the previous tee distance',()=>{
 const next=recordThrow(makeHole(),{plan:planShot(input,bag,catalog),usedBagId:'bag-mid',outcome:'hit-tree',remainingFt:''});
 assert.equal(next.draft.distanceFt,'');assert.equal(next.throws[0].remainingFt,null);
});
test('subsequent throws are numbered and a made putt completes the hole',()=>{
 let hole=recordThrow(makeHole(),{plan:planShot(input,bag,catalog),usedBagId:'bag-mid',outcome:'planned',remainingFt:20});
 hole=recordThrow(hole,{plan:planShot({...input,distanceFt:20,type:'putt'},bag,catalog),usedBagId:'bag-putt',outcome:'made',remainingFt:''});
 assert.equal(hole.throws[1].number,2);assert.equal(hole.status,'finished');assert.equal(hole.draft.distanceFt,0);
 assert.throws(()=>recordThrow(hole,{plan:planShot(input,bag,catalog)}),/new hole/);
});
test('a tee ace can finish a hole without pretending it was a putt',()=>{
 const hole=recordThrow(makeHole(),{plan:planShot(input,bag,catalog),usedBagId:'bag-mid',outcome:'made'});
 assert.equal(hole.status,'finished');assert.equal(hole.throws[0].input.type,'backhand');
});
test('actual disc snapshots survive even if that copy is later removed from the bag',()=>{
 const hole=recordThrow(makeHole(),{plan:planShot(input,bag,catalog),usedBagId:'other-copy',outcome:'planned',remainingFt:50,usedDisc:{name:'My personal disc',plastic:'Test blend'}});
 assert.equal(hole.throws[0].usedDisc.name,'My personal disc');assert.equal(hole.throws[0].usedDisc.plastic,'Test blend');
});
test('one miss does not rewrite ratings or become a causal diagnosis',()=>{
 const before=JSON.stringify({bag,catalog});planShot(input,bag,catalog,[{usedBagId:'bag-neutral',outcome:'turned-over',input}]);
 assert.equal(JSON.stringify({bag,catalog}),before);assert.match(feedbackFor('hit-tree',input),/does not establish/);
 assert.match(feedbackFor('short',input),/can involve/);
});
test('only repeated comparable outcomes produce a history caution',()=>{
 const recent=Array.from({length:3},(_,i)=>({usedBagId:'bag-neutral',outcome:'turned-over',input:normalizeShot(input),recordedAt:i}));
 const one=planShot(input,bag.filter(b=>b.discId==='neutral'),catalog,recent.slice(0,1));assert.ok(!one.candidates[0].cautions.some(c=>c.includes('comparable')));
 const many=planShot(input,bag.filter(b=>b.discId==='neutral'),catalog,recent);assert.ok(many.candidates[0].cautions.some(c=>c.includes('3 of 3')));
 const different=recent.map(h=>({...h,input:{...h.input,type:'forehand'}}));assert.ok(!planShot(input,bag.filter(b=>b.discId==='neutral'),catalog,different).candidates[0].cautions.some(c=>c.includes('comparable')));
});
test('a conservative putting preference favors a layup outside the logged range even in calm conditions',()=>{
 const plan=planShot({...input,type:'putt',distanceFt:45,comfortablePuttFt:20,risk:'safe'},bag,catalog);
 assert.match(plan.strategy,/lay-up/);
});
test('known lighter copies get a wind caution without inventing a new flight rating',()=>{
 const copies=[{...bag[1],id:'light',weight:150},{...bag[1],id:'heavy',weight:175}];
 const plan=planShot({...input,windDirection:'head',windStrength:'strong'},copies,catalog);
 assert.equal(plan.candidates[0].bagId,'heavy');assert.ok(plan.candidates.find(c=>c.bagId==='light').cautions.some(c=>c.includes('lighter copy')));
 assert.ok(plan.candidates.every(c=>c.disc.turn===0&&c.disc.fade===3));
});
test('a wooded dogleg can keep both the bend and the tight-fairway condition',()=>{
 const plan=planShot({...input,fairway:'left',wooded:true},bag,catalog);
 assert.equal(plan.shot.fairway,'left');assert.equal(plan.shot.wooded,true);
 assert.ok(plan.notes.some(n=>n.startsWith('Heavy trees')));assert.ok(plan.notes.some(n=>n.includes('bends left')));
});
test('an explicit putting landing point is a layup rather than a claimed basket run',()=>{
 const plan=planShot({...input,type:'putt',distanceFt:50,landingFt:40,comfortablePuttFt:60},bag,catalog);
 assert.match(plan.strategy,/lay-up/);assert.equal(plan.shot.distanceFt,50);assert.equal(plan.shot.landingFt,40);
});
