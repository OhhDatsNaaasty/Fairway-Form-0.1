import {test} from 'node:test';import assert from 'node:assert/strict';
import {selectThrowBurst} from '../dist/lib/throw-events.js';
const p=(x,y)=>({x,y,visibility:1});
const frames=Array.from({length:91},(_,i)=>{const points=Array.from({length:33},()=>p(.5,.5));points[11]=p(.4,.3);points[12]=p(.5,.3);points[23]=p(.4,.6);points[24]=p(.5,.6);points[16]=p(.2+i*.005,.4);return {t:i/30,p:points}});
const indexes={w:16,s:12},speeds=values=>values.map(([i,value])=>({t:frames[i].t,value,frame:frames[i]}));
test('a single fast sample cannot identify a release',()=>assert.equal(selectThrowBurst(speeds([[15,8]]),frames,indexes).peak,null));
test('marked reachback and plant select the subsequent sustained swing instead of faster unrelated motion',()=>{
 const speed=speeds([[10,8],[11,9],[12,8],[40,4],[41,5],[42,4]]);
 const result=selectThrowBurst(speed,frames,indexes,{markers:{reachback:1.1,plant:1.2},direction:'right'});assert.equal(result.peak.t,41/30);assert.equal(result.ambiguous,false);
});
test('competing strong swing sequences require a marker instead of silently picking one',()=>{
 const result=selectThrowBurst(speeds([[10,8],[11,9],[12,8],[40,8],[41,8.5],[42,8]]),frames,indexes);assert.equal(result.peak,null);assert.equal(result.ambiguous,true);assert.equal(result.candidates.length,2);
});
test('a backward reachback cannot become release when throw direction is known',()=>{
 const speed=speeds([[10,8],[11,9],[12,8]]);const backwards=frames.map(f=>({...f,p:f.p.map(point=>({...point,x:1-point.x}))}));
 assert.equal(selectThrowBurst(speed.map(s=>({...s,frame:backwards.find(f=>f.t===s.t)})),backwards,indexes,{direction:'right'}).peak,null);
});
