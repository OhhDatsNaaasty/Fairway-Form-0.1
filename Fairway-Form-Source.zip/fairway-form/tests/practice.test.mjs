import {test} from 'node:test';
import assert from 'node:assert/strict';
import {PRACTICE_DRILLS,drillsFor} from '../dist/lib/practice-library.js';
import {KNOWLEDGE,SOURCES,sourcesFor} from '../dist/lib/knowledge.js';

test('practice exercises have distinct IDs, actionable steps, outcome checks and resolvable lessons',()=>{
 assert.equal(new Set(PRACTICE_DRILLS.map(d=>d.id)).size,PRACTICE_DRILLS.length);
 assert.equal(new Set(PRACTICE_DRILLS.map(d=>d.name)).size,PRACTICE_DRILLS.length);
 for(const d of PRACTICE_DRILLS){
  assert.ok(d.steps.length>=2&&d.check&&d.name);assert.ok(d.topics.length&&d.types.length&&d.lessons.length);
  for(const lesson of d.lessons)assert.ok(KNOWLEDGE.some(k=>k.id===lesson),`${d.id}: ${lesson}`);
  assert.ok(sourcesFor(d.lessons).length>0,d.id);
 }
});
test('multiple exercises are available for backhand arm, backswing, support and approach practice',()=>{
 for(const topic of ['arm','reachback','brace','xstep'])assert.ok(drillsFor(topic,{options:{type:'backhand',stance:'walkup'}}).length>=2,topic);
 assert.equal(drillsFor('xstep',{options:{type:'forehand'}}).length,0);
 assert.equal(drillsFor('xstep',{options:{stance:'standstill'}}).length,0);
});
test('new X-step lessons resolve to coach-authored and manufacturer references',()=>{
 const ids=['x-step-sequence','x-step-compact','approach-tempo','x-step-review'];
 for(const id of ids)assert.ok(KNOWLEDGE.some(k=>k.id===id));
 const refs=sourcesFor(ids);assert.ok(refs.some(s=>s.publisher==='Innova'));assert.ok(refs.some(s=>s.publisher==='Dynamic Discs / Danny Lindahl'));
 assert.match(KNOWLEDGE.find(k=>k.id==='x-step-review').detail,/does not yet detect the complete crossover/);
});
test('video tutorial links disclose their actual review basis and valid chapter timestamps',()=>{
 const videos=Object.values(SOURCES).filter(s=>s.chapters?.length);
 assert.ok(videos.length>0);
 for(const source of videos){
  const url=new URL(source.url);assert.equal(url.protocol,'https:');assert.equal(url.hostname,'www.youtube.com');assert.ok(url.searchParams.get('v'));
  assert.ok(source.outlineUrl.startsWith('https://udisc.com/'));assert.match(source.reviewNote,/outline/);
  for(const c of source.chapters)assert.ok(Number.isInteger(c.seconds)&&c.seconds>=0&&c.label);
 }
});
