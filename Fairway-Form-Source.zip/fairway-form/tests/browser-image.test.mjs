import {test} from 'node:test';import assert from 'node:assert/strict';
import {decodeCheckedImage} from '../scripts/lib/browser-image.mjs';
test('offscreen lazy image is requested eagerly before waiting for decode',async()=>{
 let scrolled=false;
 const image={loading:'lazy',naturalWidth:0,naturalHeight:0,scrollIntoView(){scrolled=true},decode(){if(this.loading!=='eager')return new Promise(()=>{});this.naturalWidth=64;this.naturalHeight=32;return Promise.resolve()}};
 assert.deepEqual(await decodeCheckedImage(image,{label:'Study source'}),{width:64,height:32});assert.equal(scrolled,true);assert.equal(image.loading,'eager');
});
test('an unresolved image decode fails promptly with its step label',async()=>{
 const image={decode:()=>new Promise(()=>{})},start=Date.now();await assert.rejects(decodeCheckedImage(image,{label:'Study source',timeoutMs:20}),/Study source: image decoding exceeded 20ms/);assert.ok(Date.now()-start<2000);
});
test('decode failures retain their cause and an empty image cannot pass',async()=>{
 await assert.rejects(decodeCheckedImage({decode:async()=>{throw Error('invalid pixels')}},{label:'QA frame'}),/QA frame: invalid pixels/);
 await assert.rejects(decodeCheckedImage({decode:async()=>{},naturalWidth:0,naturalHeight:32},{label:'QA frame'}),/QA frame: decoded image has no usable dimensions/);
 await assert.rejects(decodeCheckedImage(null,{label:'QA frame'}),/QA frame: image element is missing/);
});
test('the helper serialized into the browser works without imported Node bindings',async()=>{
 const run=Function('image','return ('+decodeCheckedImage.toString()+')(image,{label:"Serialized image",timeoutMs:50})');
 assert.deepEqual(await run({naturalWidth:100,naturalHeight:60,decode:()=>Promise.resolve()}),{width:100,height:60});
});
