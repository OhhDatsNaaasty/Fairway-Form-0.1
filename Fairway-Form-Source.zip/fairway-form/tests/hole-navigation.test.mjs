import {terrainView,terrainViewBox,terrainViewPoint,pinchTerrainView} from '../dist/lib/terrain-viewport.js';
import {landingPickGesture} from '../scripts/lib/caddy-smoke.mjs';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {positionalLanguage,remainingDistance} from '../dist/lib/notes-language.js';
import {parseLayoutNotes} from '../dist/lib/caddy-layout.js';
import {parseSignText} from '../dist/lib/caddy-sign.js';
import {confirmedSignSetup} from '../dist/lib/sign-setup.js';
import {buildHoleScene,scenePoint,featurePoint,holeSceneSVG,createTerrainFrameRenderer} from '../dist/lib/hole-scene.js';
import {sceneForRound} from '../dist/lib/layout-art.js';
import {terrainProjection} from '../dist/lib/hole-terrain.js';
import {markLie,validLie,normalizeLie,routeDetails,lieScene,lieDraft,pickHolePoint} from '../dist/lib/hole-navigation.js';
import {makeHole,planShot,recordThrow} from '../dist/lib/caddy.js';
import {landingScene,suggestLanding,landingSketch} from '../dist/lib/landing-zone.js';
import {DISCS} from '../dist/lib/discs.js';
import {USER_BEND_NOTES} from './fixtures/bend-notes.mjs';
import {fairwaySign} from './fixtures/fairway-sign.mjs';
import {analyzeSignDiagram} from '../dist/lib/sign-diagram.js';
import {confirmedSignDiagram,buildSignScene} from '../dist/lib/sign-scene.js';
const notes='Fairway bends left at 250 ft. Water 20 ft right behind the basket. Basket on a hill 8 ft high.';
const draft={distanceFt:475,fairway:'left',elevation:'level',hazard:'none',type:'backhand',hand:'right',risk:'attack',layoutNotes:notes};
const bag=[{id:'driver',discId:'innova-teebird',distance:330},{id:'putter',discId:'discmania-p1x',distance:150}];
const round=()=>({...makeHole(),draft:{...makeHole().draft,...draft},setupMetadata:{notes,number:1,par:3}});
const plan=h=>planShot({...h.draft,lie:h.throws.length?'fairway':'tee',layoutNotesCurrent:!h.throws.length},bag,DISCS,[],{hole:h,profile:{skill:'intermediate'}});
const close=(a,b,t=.01)=>assert.ok(Math.abs(a-b)<t,`${a} differs from ${b}`);
for(const phrase of ['right behind','right in front of','right above','right below'])test('intensifier '+phrase+' does not become a lateral obstacle',()=>{
 const input='Water 20 ft '+phrase+' the basket',s=buildHoleScene({distance:300,line:'Straight',note:input});assert.equal(s.features.find(f=>f.kind==='water').side,'center');assert.ok(!parseLayoutNotes(input).hazards.includes('right'));
});
test('literal directions and route verbs remain directional',()=>{
 for(const input of ['Water to the right behind the basket','Tree 20 ft left of basket','Fairway turns right after 350 ft']){assert.equal(positionalLanguage(input),input)}assert.equal(parseLayoutNotes(USER_BEND_NOTES).fairway,'slight-right');assert.equal(parseLayoutNotes(USER_BEND_NOTES).cornerFt,350);
});
test('distance left is remaining distance without moving the basket left',()=>{
 for(const input of ['There is 150 feet left to the basket','150 ft remaining to the basket','Distance to basket is 150 ft']){assert.equal(remainingDistance(input),150);assert.equal(parseLayoutNotes(input).basketSide,null)}assert.equal(remainingDistance('Tree 20 feet left of the basket'),null);assert.equal(remainingDistance('100 ft left to basket. 150 ft remaining to basket.'),null);close(remainingDistance('20 m left to the basket'),20/.3048);
});
test('current remaining-distance notes supply the planner input while stale tee notes cannot',()=>{
 const p=planShot({...draft,distanceFt:300,layoutNotes:'There is 150 feet left to the basket'},bag,DISCS);assert.equal(p.shot.distanceFt,150);assert.equal(p.layout.basketSide,null);
 const old=planShot({...draft,distanceFt:80,lie:'fairway',layoutNotesCurrent:false,layoutNotes:'There is 150 ft left to basket'},bag,DISCS);assert.equal(old.shot.distanceFt,80);
});
test('confirmed sign distinguishes total hole length from bend, elevation and hazard quantities',()=>{
 const p=parseSignText('Sample Park\nHole 1\nPar 3\n475 ft\nFairway bends left after 250 ft.\nBasket on a hill 8 ft high.\nWater 20 ft right behind the basket.');assert.deepEqual(p.distances.map(d=>d.feet),[475]);assert.equal(p.fairway,'left');assert.equal(p.elevation,'uphill');assert.equal(p.hazard,'long');const setup=confirmedSignSetup(p,null,{draft:{fairway:'straight',hazard:'none',elevation:'level'}});assert.equal(setup.draft.distanceFt,475);assert.equal(setup.draft.elevation,'uphill');assert.equal(setup.draft.hazard,'long');assert.match(setup.draft.layoutNotes,/250 ft/);assert.match(setup.draft.layoutNotes,/8 ft/);const scene=buildHoleScene({distance:475,line:'Dogleg left',note:setup.draft.layoutNotes});assert.equal(scene.bendDistanceFt,250);assert.equal(scene.features.find(f=>f.kind==='water').side,'center');assert.equal(scene.terrain.events[0].heightFt,8);const mixed=parseSignText('Hole 2\nPar 4\n475 ft\nDogleg left after 350 ft.\nBasket is downhill 125 ft after the left bend.');assert.deepEqual(mixed.distances.map(d=>d.feet),[475]);
});
test('sign quantities stay scoped to the selected hole and retain tee choices',()=>{
 const p=parseSignText('Course Park\nHole 1\nPar 3\nBlue 300 ft\nRed 240 ft\nHole 2\nPar 4\n600 ft\nWater left of basket',{selectedHole:1});assert.deepEqual(p.distances.map(d=>d.feet),[300,240]);assert.ok(!p.layoutNotes.some(n=>n.includes('Water')));assert.throws(()=>confirmedSignSetup(p,null),/Choose the active/);
});
test('straight sign traces do not acquire a bend from endpoint noise',()=>{
 const f=fairwaySign(),a=analyzeSignDiagram(f),d=confirmedSignDiagram({...a,visual:{trees:a.trees,corridorHalfWidth:a.corridorHalfWidth},pointsSource:'automatic',imageAspect:f.width/f.height}),s={...buildSignScene(d,255),distanceFt:255};assert.equal(routeDetails(s).fairway,'straight');assert.equal(routeDetails(s).cornerFt,null);const p=planShot({...draft,distanceFt:255,fairway:'straight',layoutNotes:''},bag,DISCS,[],{signLayout:d});assert.equal(p.shot.fairway,'straight');assert.equal(p.layout.cornerFt,null);assert.equal(p.layout.signTrees.length,9);
});
test('confirmed sign route informs Caddy direction and bend distance without reshaping its artwork',()=>{
 const d={version:1,aspect:1,confirmed:true,routeSource:'manual',route:[{x:.6,y:.9},{x:.6,y:.5},{x:.2,y:.2}],trees:[]},h={...round(),draft:{...draft,distanceFt:475,layoutNotes:''},setupMetadata:{notes:''},layoutArt:{signDiagram:d}};const p=planShot({...h.draft,fairway:'straight'},bag,DISCS,[],{hole:h,signLayout:d}),s=landingScene(p,h);assert.equal(p.shot.fairway,'left');assert.ok(p.layout.cornerFt>180&&p.layout.cornerFt<260);assert.equal(p.layout.geometrySource,'sign');assert.deepEqual(s.points,sceneForRound(h).points);assert.deepEqual(s.pointDistancesFt,sceneForRound(h).pointDistancesFt);
});
for(const name of ['flat','hill'])test('3D picking intersects the '+name+' ground at every orbit quadrant',()=>{
 const s=buildHoleScene({distance:475,line:'Dogleg left',note:name==='hill'?notes:''}),points=[scenePoint(s,100),scenePoint(s,300),{x:140,y:155}];for(const angle of [0,45,90,180,270,359])for(const p of points){const q=terrainProjection(s,{},angle).project(p),hit=pickHolePoint(s,q,angle);assert.ok(hit);close(hit.x,p.x);close(hit.y,p.y)}assert.equal(pickHolePoint(s,{x:350,y:30}),null);assert.equal(pickHolePoint(s,{x:1,y:550}),null);
});
test('invalid markers and positions from a different layout are rejected',()=>{
 const s=sceneForRound(round()),p=markLie(s,scenePoint(s,200));assert.ok(validLie(s,p));assert.equal(validLie({...s,distanceFt:300},p),null);assert.throws(()=>normalizeLie({...p,x:Infinity}));assert.throws(()=>normalizeLie({...p,layoutKey:'<script>'}));assert.throws(()=>markLie(buildHoleScene(),{x:150,y:200}));
});
test('a lie beyond the bend has a straight remaining route and retains long water and hill context',()=>{
 const s=sceneForRound(round()),lie=markLie(s,scenePoint(s,300)),local=lieScene(s,lie),next=lieDraft(s,lie);close(local.distanceFt,175);assert.equal(next.fairway,'straight');assert.equal(next.elevation,'uphill');assert.equal(next.hazard,'long');assert.equal(local.lieFacts.cornerFt,null);assert.equal(local.worldScene.distanceFt,475);assert.equal(local.features.find(f=>f.kind==='water').side,'center');
});
test('a lie before the bend gets the distance from that lie to the corner',()=>{
 const s=sceneForRound(round()),lie=markLie(s,scenePoint(s,100)),next=lieScene(s,lie);close(next.distanceFt,375);close(next.bendDistanceFt,150);assert.equal(next.lieFacts.fairway,'left');
});
test('off-fairway landings retain their lateral position and include the entry to the route',()=>{
 const s=sceneForRound(round()),p=scenePoint(s,120),lie=markLie(s,{x:p.x+p.rightX*18,y:p.y+p.rightY*18}),local=lieScene(s,lie);assert.deepEqual(local.points[0],[lie.x,lie.y]);assert.ok(local.distanceFt>355);assert.ok(local.points.length>=4);assert.deepEqual(local.points.at(-1),s.points.at(-1));
});
test('logging a marked landing creates an approximate next lie without creating measured carry',()=>{
 const h=round(),s=sceneForRound(h),lie=markLie(s,scenePoint(s,300)),p=plan(h),next=recordThrow(h,{plan:p,usedBagId:'driver',outcome:'unknown',remainingFt:'',landingPosition:lie});close(next.draft.distanceFt,175);assert.equal(next.draft.fairway,'straight');assert.equal(next.draft.layoutNotesCurrent,false);assert.equal(next.draft.distanceSource,'sketch');assert.equal(next.throws[0].remainingSource,'sketch');assert.equal(next.throws[0].throwDistanceFt,null);assert.equal(next.throws[0].distanceMethod,null);assert.deepEqual(next.currentLie,lie);assert.ok(sceneForRound(next).currentLie);assert.equal(next.pendingLanding,null);const follow=plan(next);assert.equal(follow.shot.distanceFt,175);assert.equal(follow.shot.fairway,'straight');assert.equal(follow.layout.geometrySource,'marked-lie');assert.ok(follow.layout.hazards.includes('long'));
});
test('entered remaining distance overrides a sketch estimate and scales target placement only',()=>{
 const h=round(),s=sceneForRound(h),lie=markLie(s,scenePoint(s,300)),next=recordThrow(h,{plan:plan(h),usedBagId:'driver',outcome:'unknown',remainingFt:140,landingPosition:lie}),p=plan(next),local=landingScene(p,next);assert.equal(next.throws[0].remainingSource,'entered');assert.equal(p.shot.distanceFt,140);assert.equal(local.distanceFt,140);assert.equal(local.pointDistancesFt.at(-1),140);assert.deepEqual(local.worldScene.points,s.points);assert.deepEqual(next.currentLie,lie);
});
test('a later throw without a new position clears the old lie instead of reusing it',()=>{
 const h=round(),s=sceneForRound(h),lie=markLie(s,scenePoint(s,300)),first=recordThrow(h,{plan:plan(h),usedBagId:'driver',outcome:'unknown',remainingFt:'',landingPosition:lie}),next=recordThrow(first,{plan:plan(first),usedBagId:'putter',outcome:'unknown',remainingFt:60});assert.equal(next.currentLie,null);assert.equal(next.draft.fairway,'');assert.equal(next.throws[1].landingPosition,null);
});
test('stale landing confirmations cannot be saved against a changed drawing',()=>{
 const h=round(),lie=markLie(sceneForRound(h),scenePoint(sceneForRound(h),200));h.draft.distanceFt=400;assert.throws(()=>recordThrow(h,{plan:plan(h),usedBagId:'driver',outcome:'unknown',remainingFt:'',landingPosition:lie}),/layout changed/);
});
test('made result still finishes the hole without pretending a sketch marker measured carry',()=>{
 const h=round(),next=recordThrow(h,{plan:plan(h),usedBagId:'driver',outcome:'made',remainingFt:''});assert.equal(next.status,'finished');assert.equal(next.throws[0].remainingSource,'holed-out');assert.equal(next.currentLie,null);assert.equal(next.throws[0].throwDistanceFt,null);
});
test('full-hole render and next landing share the current lie, obstacles and terrain',()=>{
 const h=round(),s=sceneForRound(h),lie=markLie(s,scenePoint(s,300)),next=recordThrow(h,{plan:plan(h),usedBagId:'driver',outcome:'unknown',remainingFt:'',landingPosition:lie}),p=plan(next),zone=suggestLanding(p,p.candidates[0],next),before=JSON.stringify({next,p,zone});for(const angle of [0,90,180,270]){const svg=holeSceneSVG(zone.scene,{target:zone,angle,labels:true});assert.match(svg,/data-current-lie=/);assert.match(svg,/data-landing-target=/);assert.match(svg,/data-elevation-ft="8"/);assert.ok(!svg.includes('NaN'));assert.equal((svg.match(/data-current-lie=/g)??[]).length,1)}assert.equal(JSON.stringify({next,p,zone}),before);assert.deepEqual(zone.scene.worldScene.points,s.points);
});
test('position survives a normal saved-round JSON round trip and never appears on the next hole',()=>{
 const h=round(),s=sceneForRound(h),lie=markLie(s,scenePoint(s,300)),next=recordThrow(h,{plan:plan(h),usedBagId:'driver',outcome:'unknown',remainingFt:'',landingPosition:lie}),saved=JSON.parse(JSON.stringify(next));assert.deepEqual(sceneForRound(saved).currentLie,lie);assert.equal(sceneForRound(round()).currentLie,null);assert.deepEqual(lieDraft(sceneForRound(saved),saved.currentLie).fairway,'straight');
});

// This is the same coordinate helper serialized into the mandatory browser
// gate. Verify its final (not initial) pointer position against real terrain.
for(const width of [272,342,432])test('vertical browser gesture ends at the known route point with '+width+'px ground',()=>{
 const scene=sceneForRound(round()),projected=terrainProjection(scene,{},0).project(scenePoint(scene,300)),bounds={left:24,top:110,width,height:width*560/700},gesture=landingPickGesture(projected,bounds);
 assert.equal(gesture.endY-gesture.y,14);
 const point=pickHolePoint(scene,{x:(gesture.x-bounds.left)/bounds.width*700,y:(gesture.endY-bounds.top)/bounds.height*560},0),draft=lieDraft(scene,markLie(scene,point));
 close(draft.distanceFt,175);assert.equal(draft.fairway,'straight');assert.equal(draft.elevation,'uphill');assert.equal(draft.hazard,'long');
});
test('browser landing preparation rejects invalid or zero-sized render bounds',()=>{
 for(const width of [0,NaN,Infinity,-1])assert.throws(()=>landingPickGesture({x:300,y:260},{left:24,top:100,width,height:200}),/Invalid rendered/);
});

for(const angle of [0,45,90,180,270])test('pinched ground picks preserve the same landing on sloped terrain at '+angle+' degrees',()=>{
 const scene=sceneForRound(round()),point=scenePoint(scene,300),projected=terrainProjection(scene,{},angle).project(point);
 for(const zoom of [1,1.7,3,4]){
  const view=terrainView({zoom,cx:projected.x,cy:projected.y}),box=terrainViewBox(view),normalized={x:(projected.x-box.x)/box.width,y:(projected.y-box.y)/box.height},screen=terrainViewPoint(view,normalized),hit=pickHolePoint(scene,screen,angle);
  close(hit.x,point.x);close(hit.y,point.y);close(lieDraft(scene,markLie(scene,hit)).distanceFt,175);
 }
});
test('pinch zoom keeps its ground anchor under the fingers while two-finger panning moves only the viewport',()=>{
 const original=terrainView({zoom:2}),from={x:.4,y:.4},to={x:.45,y:.5},anchor=terrainViewPoint(original,from),next=pinchTerrainView(original,from,to,1.5);assert.equal(next.zoom,3);const after=terrainViewPoint(next,to);close(after.x,anchor.x);close(after.y,anchor.y);assert.deepEqual(original,{zoom:2,cx:350,cy:280});
 const out=pinchTerrainView(next,to,to,.001);assert.deepEqual(out,{zoom:1,cx:350,cy:280});const bounded=terrainView({zoom:100,cx:-1000,cy:10000}),box=terrainViewBox(bounded);assert.equal(bounded.zoom,4);assert.ok(box.x>=0&&box.y>=0&&box.x+box.width<=700&&box.y+box.height<=560);
});

for(const tilt of [10,25,50,75,90])test('tilted hill picking remains accurate through every orbit at '+tilt+' degrees',()=>{
 const scene=sceneForRound(round()),point=scenePoint(scene,300);
 for(const angle of [0,45,90,180,270]){const projected=terrainProjection(scene,{},angle,null,tilt).project(point),view=terrainView({zoom:3,cx:projected.x,cy:projected.y}),box=terrainViewBox(view),screen=terrainViewPoint(view,{x:(projected.x-box.x)/box.width,y:(projected.y-box.y)/box.height}),hit=pickHolePoint(scene,screen,angle,tilt);assert.ok(hit);close(hit.x,point.x);close(hit.y,point.y);close(lieDraft(scene,markLie(scene,hit)).distanceFt,175)}
});
