import {test} from 'node:test';import assert from 'node:assert/strict';
import {evaluateEventIntervals} from '../scripts/lib/form-benchmark.mjs';
test('benchmark respects a release interval rather than requiring a fabricated exact instant',()=>{
 const result=evaluateEventIntervals({release:1.016,plant:.7},{release:{status:'visible',earliest:1,latest:1.033},plant:{status:'visible',earliest:.8,latest:.82}});
 assert.equal(result.hits,1);assert.equal(result.coverage,1);assert.ok(Math.abs(result.meanIntervalErrorSec-.05)<1e-9);
});
test('benchmark separates a miss from a suggestion made without visible evidence',()=>{
 const result=evaluateEventIntervals({pocket:1,release:null},{release:{status:'visible',earliest:1.1,latest:1.12},pocket:{status:'unobservable'},crossover:{status:'not-applicable'}});
 assert.equal(result.coverage,0);assert.equal(result.meanIntervalErrorSec,null);assert.equal(result.unsupportedSuggestions,1);assert.equal(result.results.find(r=>r.event==='release').status,'missed');
});
test('unlabeled predictions cannot inflate benchmark accuracy and absent labels yield no accuracy metric',()=>{
 const result=evaluateEventIntervals({release:1},{});assert.equal(result.coverage,null);assert.equal(result.meanIntervalErrorSec,null);assert.deepEqual(result.unlabeledPredictions,['release']);
});
test('invalid annotations and nonfinite predictions are rejected',()=>{
 assert.throws(()=>evaluateEventIntervals({release:NaN},{release:{status:'visible',earliest:1,latest:2}}));
 assert.throws(()=>evaluateEventIntervals({},{release:{status:'visible',earliest:2,latest:1}}));
 assert.throws(()=>evaluateEventIntervals({},{release:{status:'guessed'}}));
});
