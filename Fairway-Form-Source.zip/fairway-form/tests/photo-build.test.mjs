import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const root=fileURLToPath(new URL('../',import.meta.url));
test('photo build bundles matched bytes and credits while keeping unavailable photos explicit',async()=>{
 const temp=await fs.mkdtemp(path.join(os.tmpdir(),'fairway-photo-build-'));
 try{
  await fs.mkdir(path.join(temp,'scripts/lib'),{recursive:true});await fs.mkdir(path.join(temp,'dist/lib'),{recursive:true});
  await fs.writeFile(path.join(temp,'package.json'),'{"type":"module"}');
  await fs.copyFile(path.join(root,'scripts/fetch-disc-photos.mjs'),path.join(temp,'scripts/fetch-disc-photos.mjs'));
  await fs.copyFile(path.join(root,'scripts/lib/disc-photos.mjs'),path.join(temp,'scripts/lib/disc-photos.mjs'));
  // An app icon is only a transport fixture in this temporary directory.
  // It is never used as a product image in the source or APK.
  await fs.copyFile(path.join(root,'dist/icon-192.png'),path.join(temp,'image-fixture.png'));
  const discs=[
   {id:'qa-valid',brand:'MVP',model:'QA Valid',sourceUrl:'https://mvpdiscsports.com/discs/qa-valid/',photoUrl:'https://mvpdiscsports.com/qa-valid.png'},
   {id:'qa-missing',brand:'MVP',model:'QA Missing',sourceUrl:'https://mvpdiscsports.com/discs/qa-missing/'},
   {id:'qa-discovered',brand:'MVP',model:'QA Discovered',sourceUrl:'https://mvpdiscsports.com/discs/qa-discovered/'}
  ];
  await fs.writeFile(path.join(temp,'dist/lib/discs.js'),'export const DISCS='+JSON.stringify(discs));
  const preload=`import fs from 'node:fs/promises';const image=await fs.readFile(new URL('./image-fixture.png',import.meta.url));globalThis.fetch=async address=>{const url=String(address);if(url.endsWith('/qa-valid.png')||url.endsWith('/qa-discovered.png'))return new Response(image,{headers:{'Content-Type':'image/png'}});if(url.endsWith('/discs/qa-discovered/'))return new Response('<script type="application/ld+json">'+JSON.stringify({'@type':'Product',name:'QA Discovered',image:'https://mvpdiscsports.com/qa-discovered.png'})+'</script>',{headers:{'Content-Type':'text/html'}});return new Response('Unavailable',{status:403})};`;
  await fs.writeFile(path.join(temp,'preload.mjs'),preload);
  const result=spawnSync(process.execPath,['--import',path.join(temp,'preload.mjs'),path.join(temp,'scripts/fetch-disc-photos.mjs')],{encoding:'utf8',timeout:10000});
  assert.equal(result.status,0,result.stderr);const index=JSON.parse(await fs.readFile(path.join(temp,'dist/disc-photos/index.json'),'utf8'));
  assert.equal(index.total,3);assert.equal(index.available,2);assert.deepEqual(index.unavailable,['qa-missing']);
  assert.equal(index.images['qa-discovered'].sourcePage,'https://mvpdiscsports.com/discs/qa-discovered/');
  assert.deepEqual(await fs.readFile(path.join(temp,'dist/disc-photos/qa-valid.png')),await fs.readFile(path.join(temp,'image-fixture.png')));
  assert.equal(index.byBrand.MVP.photos,2);
 }finally{await fs.rm(temp,{recursive:true,force:true})}
});
