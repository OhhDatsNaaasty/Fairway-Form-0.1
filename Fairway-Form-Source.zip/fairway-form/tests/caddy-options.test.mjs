import {test} from 'node:test';
import assert from 'node:assert/strict';
import {planShot,makeHole,recordThrow} from '../dist/lib/caddy.js';
import {recommendPower} from '../dist/lib/caddy-power.js';
import {normalizePlayer} from '../dist/lib/player-profile.js';
import {actualInput,normalizeActualShot} from '../dist/lib/shot-shape.js';
import {discStats,validateHistory,historyBackup} from '../dist/lib/disc-history.js';
import {normalizeShot} from '../dist/lib/caddy.js';
const disc={id:'stable',brand:'Test',model:'Stable',type:'Fairway',speed:7,glide:5,turn:0,fade:2};
const item={id:'copy-one',discId:'stable',distance:300,alternateDistance:260};
const shot={distanceFt:220,fairway:'straight',hand:'right',type:'auto'};
const plan=(raw={},profile={},history=[],d=disc,b=item)=>planShot({...shot,...raw},[b],[d],history,{profile});

test('automatic styles mirror for both throwing hands and either bend',()=>{
 for(const [hand,fairway,type] of [['right','left','backhand'],['right','right','forehand'],['left','left','forehand'],['left','right','backhand']]){
  const c=plan({hand,fairway}).candidates[0];assert.equal(c.throwType,type);assert.equal(c.release.fadeSide,fairway);assert.equal(c.release.path,'holding-hyzer');
 }
 assert.equal(makeHole().draft.type,'auto');
});
test('a preferred forehand is a familiarity preference and never locks out backhand',()=>{
 assert.equal(plan({fairway:'left'},{preferredThrow:'forehand'}).candidates[0].throwType,'backhand');
 assert.equal(plan({fairway:'right'},{preferredThrow:'backhand'}).candidates[0].throwType,'forehand');
});
test('all lower skill levels exclude advanced flights even with aggressive risk and wind',()=>{
 const under={...disc,turn:-3,fade:3};
 for(const skill of ['unknown','beginner','intermediate','amateur'])for(const fairway of ['straight','left','right','woods']){
  const p=plan({fairway,risk:'attack',windDirection:'head',windStrength:'strong'},{skill},[],under);
  assert.ok(p.candidates.length);assert.ok(p.candidates.every(c=>['flat','holding-hyzer','early-finish'].includes(c.release.path)));assert.ok(p.candidates.every(c=>c.releaseAngle!=='anhyzer'));
 }
});
test('Advanced and Pro can use hyzer-flips and anhyzer releases when appropriate',()=>{
 for(const skill of ['advanced','pro']){
  assert.equal(normalizePlayer({skill}).skill,skill);
  assert.equal(plan({releaseAngle:'hyzer'},{skill},[],{...disc,turn:-3}).candidates[0].release.path,'hyzer-flip');
  assert.equal(plan({releaseAngle:'anhyzer'},{skill}).candidates[0].releaseAngle,'anhyzer');
 }
});
test('advanced release history cannot bypass a lower skill setting',()=>{
 const rows=Array.from({length:3},(_,i)=>({id:'log-'+i,usedBagId:item.id,input:{...normalizeShot(shot),type:'backhand'},actualShot:{hand:'right',type:'backhand',releaseAngle:'hyzer',effort:'stock'},feedback:{flight:'flipped-flat',quality:'great',execution:'clean'},outcome:'planned',throwDistanceFt:300,distanceMethod:'measured',clearFlight:true,recordedAt:Date.now()-i}));
 const c=plan({type:'backhand'},{skill:'beginner'},rows).candidates[0];assert.equal(c.releaseAngle,'flat');assert.notEqual(c.release.path,'hyzer-flip');
 assert.equal(plan({type:'backhand'},{skill:'pro'},rows).candidates[0].release.path,'hyzer-flip');
});
test('unverified alternate styles are labeled and have their own estimated reference',()=>{
 const p=planShot(shot,[{...item,alternateDistance:null}],[disc],[],{profile:{averageBackhandFt:300,averageForehandFt:120}});
 assert.equal(p.candidates[0].throwType,'backhand');
 const c=planShot({...shot,type:'forehand'},[{...item,alternateDistance:null}],[disc],[],{profile:{averageForehandFt:120}}).candidates[0];
 assert.equal(c.rangeFt,null);assert.ok(c.estimatedRange.highFt<200);assert.match(c.power.basis,/unverified/);
});
test('power responds to this disc’s personal range and the actual landing target',()=>{
 const easy=plan({distanceFt:100,type:'backhand'}).candidates[0],stock=plan({distanceFt:240,type:'backhand'}).candidates[0],firm=plan({distanceFt:300,type:'backhand'}).candidates[0];
 assert.equal(easy.power.effort,'easy');assert.deepEqual(easy.power.band,[40,60]);assert.equal(stock.power.effort,'stock');assert.equal(firm.power.effort,'firm');
 assert.equal(plan({distanceFt:600,landingFt:120,type:'backhand'}).candidates[0].power.targetFt,120);
 assert.match(stock.power.basis,/saved distance/);assert.match(stock.power.basis,/not measured speed/);
});
test('a long staged hole does not prescribe power against the full basket distance',()=>{
 const p=plan({distanceFt:750,type:'backhand'}),c=p.candidates[0];assert.equal(p.staged,true);assert.equal(c.power.targetFt,p.comparisonTargetFt);assert.ok(c.power.targetFt<400);assert.ok(c.power.band[1]<=90);
});
test('wind and elevation influence planning demand without claiming measured power',()=>{
 const a=plan({distanceFt:240,type:'backhand'}).candidates[0].power;
 const b=plan({distanceFt:240,type:'backhand',elevation:'uphill',windDirection:'head',windStrength:'strong'}).candidates[0].power;
 assert.ok(b.targetFt>a.targetFt);assert.match(b.basis,/starting|feel/);assert.ok(!b.label.includes('100%'));
});
test('putting has a pace cue and no driver-power percentage',()=>{
 const putter={...disc,type:'Putter',speed:2};const p=plan({type:'putt',distanceFt:20,hazard:'none'},{},[],putter,{...item,puttingRange:30});
 assert.match(p.candidates[0].power.label,/putting pace/);assert.equal(p.candidates[0].power.band,undefined);
 assert.match(recommendPower({putting:true,layup:true}).label,/lay-up/);
});
test('suggested power stays distinct from actual effort and survives history backup',()=>{
 const p=plan(),h=recordThrow(makeHole(),{plan:p,usedBagId:item.id,outcome:'short',remainingFt:80,actualShot:{hand:'right',type:p.candidates[0].throwType,releaseAngle:'flat',effort:'easy'},throwDistanceFt:150});
 const t=h.throws[0];assert.equal(t.plannedShot.effort,p.candidates[0].power.effort);assert.equal(t.recommendations[0].power.label,p.candidates[0].power.label);assert.equal(actualInput(t).effort,'easy');
 const restored=validateHistory(historyBackup([h]),normalizeShot)[0].throws[0];assert.equal(restored.actualShot.effort,'easy');assert.equal(restored.plannedShot.effort,t.plannedShot.effort);
});
test('unknown or easy actual effort does not become a normal-power distance reference',()=>{
 const p=plan(),rows=['a','b','c'].map(id=>({...recordThrow(makeHole(),{plan:p,usedBagId:item.id,outcome:'planned',remainingFt:20,throwDistanceFt:200,actualShot:{hand:'right',type:'backhand',releaseAngle:'flat',effort:'unknown'}}).throws[0],id}));
 assert.equal(discStats(rows,item.id,{hand:'right',type:'backhand'}).baseline.rangeCount,0);
 assert.equal(discStats(rows.map(t=>({...t,actualShot:{...t.actualShot,effort:'stock'}})),item.id,{hand:'right',type:'backhand'}).baseline.rangeCount,3);
 assert.throws(()=>normalizeActualShot({effort:'maximum'},rows[0].plannedShot),/effort/);
});
