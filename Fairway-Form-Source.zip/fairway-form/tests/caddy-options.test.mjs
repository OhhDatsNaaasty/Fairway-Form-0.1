import {test} from 'node:test';
import assert from 'node:assert/strict';
import {planShot,makeHole,recordThrow} from '../dist/lib/caddy.js';
import {recommendPower} from '../dist/lib/caddy-power.js';
import {normalizePlayer} from '../dist/lib/player-profile.js';
import {actualInput,normalizeActualShot} from '../dist/lib/shot-shape.js';
import {discStats,validateHistory,historyBackup} from '../dist/lib/disc-history.js';
import {normalizeShot} from '../dist/lib/caddy.js';
const disc={id:'stable',brand:'Test',model:'Stable',type:'Fairway',speed:7,glide:5,turn:0,fade:2};
const item={id:'copy-one',discId:'stable',distance:300,alternateDistance:260};
const shot={distanceFt:220,fairway:'straight',hand:'right',type:'auto'};
const plan=(raw={},profile={},history=[],d=disc,b=item)=>planShot({...shot,...raw},[b],[d],history,{profile});

test('automatic styles mirror for both throwing hands and either bend',()=>{
 for(const [hand,fairway,type] of [['right','left','backhand'],['right','right','forehand'],['left','left','forehand'],['left','right','backhand']]){
  const c=plan({hand,fairway}).candidates[0];assert.equal(c.throwType,type);assert.equal(c.release.fadeSide,fairway);assert.equal(c.release.path,'holding-hyzer');
 }
 assert.equal(makeHole().draft.type,'auto');
});
test('a preferred forehand is a familiarity preference and never locks out backhand',()=>{
 assert.equal(plan({fairway:'left'},{preferredThrow:'forehand'}).candidates[0].throwType,'backhand');
 assert.equal(plan({fairway:'right'},{preferredThrow:'backhand'}).candidates[0].throwType,'forehand');
});
test('all lower skill levels exclude advanced flights even with aggressive risk and wind',()=>{
 const under={...disc,turn:-3,fade:3};
 for(const skill of ['unknown','beginner','intermediate','amateur'])for(const fairway of ['straight','left','right','woods']){
  const p=plan({fairway,risk:'attack',windDirection:'head',windStrength:'strong'},{skill},[],under);
  assert.ok(p.candidates.length);assert.ok(p.candidates.every(c=>['flat','holding-hyzer','early-finish'].includes(c.release.path)));assert.ok(p.candidates.every(c=>c.releaseAngle!=='anhyzer'));
 }
});
test('Advanced and Pro can use hyzer-flips and anhyzer releases when appropriate',()=>{
 for(const skill of ['advanced','pro']){
  assert.equal(normalizePlayer({skill}).skill,skill);
  assert.equal(plan({releaseAngle:'hyzer'},{skill},[],{...disc,turn:-3}).candidates[0].release.path,'hyzer-flip');
  assert.equal(plan({releaseAngle:'anhyzer'},{skill}).candidates[0].releaseAngle,'anhyzer');
 }
});
test('advanced release history cannot bypass a lower skill setting',()=>{
 const rows=Array.from({length:3},(_,i)=>({id:'log-'+i,usedBagId:item.id,input:{...normalizeShot(shot),type:'backhand'},actualShot:{hand:'right',type:'backhand',releaseAngle:'hyzer',effort:'stock'},feedback:{flight:'flipped-flat',quality:'great',execution:'clean'},outcome:'planned',throwDistanceFt:300,distanceMethod:'measured',clearFlight:true,recordedAt:Date.now()-i}));
 const c=plan({type:'backhand'},{skill:'beginner'},rows).candidates[0];assert.equal(c.releaseAngle,'flat');assert.notEqual(c.release.path,'hyzer-flip');
 assert.equal(plan({type:'backhand'},{skill:'pro'},rows).candidates[0].release.path,'hyzer-flip');
});
test('unverified alternate styles are labeled and have their own estimated reference',()=>{
 const p=planShot(shot,[{...item,alternateDistance:null}],[disc],[],{profile:{averageBackhandFt:300,averageForehandFt:120}});
 assert.equal(p.candidates[0].throwType,'backhand');
 const c=planShot({...shot,type:'forehand'},[{...item,alternateDistance:null}],[disc],[],{profile:{averageForehandFt:120}}).candidates[0];
 assert.equal(c.rangeFt,null);assert.ok(c.estimatedRange.highFt<200);assert.match(c.power.basis,/unverified/);
});
test('power responds to this disc’s personal range and the actual landing target',()=>{
 const easy=plan({distanceFt:100,type:'backhand'}).candidates[0],stock=plan({distanceFt:240,type:'backhand'}).candidates[0],firm=plan({distanceFt:300,type:'backhand'}).candidates[0];
 assert.equal(easy.power.effort,'easy');assert.deepEqual(easy.power.band,[40,60]);assert.equal(stock.power.effort,'stock');assert.equal(firm.power.effort,'firm');
 assert.equal(plan({distanceFt:600,landingFt:120,type:'backhand'}).candidates[0].power.targetFt,120);
 assert.match(stock.power.basis,/saved distance/);assert.match(stock.power.basis,/not measured speed/);
});
test('a long staged hole does not prescribe power against the full basket distance',()=>{
 const p=plan({distanceFt:750,type:'backhand'}),c=p.candidates[0];assert.equal(p.staged,true);assert.equal(c.power.targetFt,p.comparisonTargetFt);assert.ok(c.power.targetFt<400);assert.ok(c.power.band[1]<=90);
});
test('wind and elevation influence planning demand without claiming measured power',()=>{
 const a=plan({distanceFt:240,type:'backhand'}).candidates[0].power;
 const b=plan({distanceFt:240,type:'backhand',elevation:'uphill',windDirection:'head',windStrength:'strong'}).candidates[0].power;
 assert.ok(b.targetFt>a.targetFt);assert.match(b.basis,/starting|feel/);assert.ok(!b.label.includes('100%'));
});
test('putting has a pace cue and no driver-power percentage',()=>{
 const putter={...disc,type:'Putter',speed:2};const p=plan({type:'putt',distanceFt:20,hazard:'none'},{},[],putter,{...item,puttingRange:30});
 assert.match(p.candidates[0].power.label,/putting pace/);assert.equal(p.candidates[0].power.band,undefined);
 assert.match(recommendPower({putting:true,layup:true}).label,/lay-up/);
});
test('suggested power stays distinct from actual effort and survives history backup',()=>{
 const p=plan(),h=recordThrow(makeHole(),{plan:p,usedBagId:item.id,outcome:'short',remainingFt:80,actualShot:{hand:'right',type:p.candidates[0].throwType,releaseAngle:'flat',effort:'easy'},throwDistanceFt:150});
 const t=h.throws[0];assert.equal(t.plannedShot.effort,p.candidates[0].power.effort);assert.equal(t.recommendations[0].power.label,p.candidates[0].power.label);assert.equal(actualInput(t).effort,'easy');
 const restored=validateHistory(historyBackup([h]),normalizeShot)[0].throws[0];assert.equal(restored.actualShot.effort,'easy');assert.equal(restored.plannedShot.effort,t.plannedShot.effort);
});
test('unknown or easy actual effort does not become a normal-power distance reference',()=>{
 const p=plan(),rows=['a','b','c'].map(id=>({...recordThrow(makeHole(),{plan:p,usedBagId:item.id,outcome:'planned',remainingFt:20,throwDistanceFt:200,actualShot:{hand:'right',type:'backhand',releaseAngle:'flat',effort:'unknown'}}).throws[0],id}));
 assert.equal(discStats(rows,item.id,{hand:'right',type:'backhand'}).baseline.rangeCount,0);
 assert.equal(discStats(rows.map(t=>({...t,actualShot:{...t.actualShot,effort:'stock'}})),item.id,{hand:'right',type:'backhand'}).baseline.rangeCount,3);
 assert.throws(()=>normalizeActualShot({effort:'maximum'},rows[0].plannedShot),/effort/);
});

test('a long understable backhand cannot hide a shorter forehand on a right dogleg',async()=>{
 const {DISCS}=await import('../dist/lib/discs.js');
 const copies=[{id:'under',discId:'innova-mamba',distance:320},{id:'control',discId:'innova-teebird',distance:300,alternateDistance:150},{id:'approach',discId:'discraft-zone',distance:230,alternateDistance:130}];
 const p=planShot({...shot,distanceFt:350,fairway:'right'},copies,DISCS,[],{profile:{skill:'intermediate',averageBackhandFt:300,averageForehandFt:150}});
 const c=p.candidates[0];assert.equal(c.throwType,'forehand');assert.equal(c.lineFit.kind,'natural-finish');assert.equal(c.placement,true);assert.ok(c.targetFt<=150);assert.ok(c.power.targetFt<=150);assert.ok(!p.candidates.some(c=>c.throwType==='backhand'&&c.discId==='innova-mamba'));assert.match(c.cautions.join(' '),/Add the bend distance/);
});
test('placement selection mirrors across left/right hands and either first bend',()=>{
 for(const [hand,fairway,type]of [['right','right','forehand'],['left','left','forehand'],['right','left','backhand'],['left','right','backhand']]){
  const b={...item,distance:150,alternateDistance:150};const c=plan({distanceFt:350,hand,fairway},{preferredThrow:type},[],disc,b).candidates[0];assert.equal(c.throwType,type);assert.equal(c.placement,true);assert.ok(c.targetFt<150);
 }
});
test('general forehand averages influence the placement estimate without becoming disc measurements',()=>{
 const p=plan({distanceFt:350,fairway:'right'},{averageBackhandFt:300,averageForehandFt:150},[],disc,{...item,alternateDistance:null});
 const c=p.candidates.find(c=>c.throwType==='forehand');assert.ok(c);assert.equal(c.rangeFt,null);assert.equal(c.statistics.measuredCount,0);assert.ok(c.targetFt<150);assert.match(c.power.basis,/unverified/);
});
test('a known landing target is respected instead of shortened to the forehand average',()=>{
 const p=plan({distanceFt:350,landingFt:240,fairway:'right',type:'forehand'},{},[],disc,{...item,alternateDistance:150});const c=p.candidates[0];assert.equal(c.targetFt,240);assert.equal(c.placement,false);assert.ok(c.power.targetFt>=240);assert.equal(p.shot.landingFt,240);
});
test('straight long holes keep the driving strategy rather than force a short forehand',()=>{
 const c=plan({distanceFt:750},{},[],disc,{...item,distance:300,alternateDistance:100}).candidates[0];assert.equal(c.throwType,'backhand');assert.equal(c.lineFit.kind,'straight');assert.ok(c.targetFt>=250);
});
test('the same physical copy can offer a reachable forehand alongside a longer advanced backhand',()=>{
 const p=plan({distanceFt:350,fairway:'slight-right'},{skill:'pro'},[],disc,{...item,distance:450,alternateDistance:45});
 assert.ok(p.candidates.some(c=>c.throwType==='backhand'));const fh=p.candidates.find(c=>c.throwType==='forehand');assert.ok(fh);assert.equal(new Set(p.candidates.map(c=>c.bagId)).size,1);assert.equal(new Set(p.candidates.map(c=>c.optionKey)).size,p.candidates.length);assert.ok(fh.targetFt<45);
});
test('choosing the forehand variant saves that plan and never invents the result',()=>{
 const p=plan({distanceFt:350,fairway:'slight-right'},{skill:'pro'},[],disc,{...item,distance:450,alternateDistance:45}),fh=p.candidates.find(c=>c.throwType==='forehand');p.selectedOptionKey=fh.optionKey;
 const h=recordThrow(makeHole(),{plan:p,usedBagId:item.id,outcome:'unknown',remainingFt:''}),t=h.throws[0];assert.equal(t.plannedShot.type,'forehand');assert.equal(t.recommendationKey,fh.optionKey);assert.equal(t.plannedTargetFt,fh.targetFt);assert.equal(t.input.landingFt,fh.targetFt);assert.equal(t.input.distanceFt,350);assert.equal(t.remainingFt,null);assert.equal(t.throwDistanceFt,null);
 const restored=validateHistory(historyBackup([h]),normalizeShot)[0].throws[0];assert.equal(restored.plannedTargetFt,fh.targetFt);assert.equal(restored.recommendationKey,fh.optionKey);assert.equal(restored.plannedShot.type,'forehand');
});
test('a missing selection key falls back by physical copy and does not choose another disc',()=>{
 const p=plan({distanceFt:350,fairway:'slight-right'},{skill:'pro'},[],disc,{...item,distance:450,alternateDistance:45});p.selectedOptionKey='a-removed-key';const t=recordThrow(makeHole(),{plan:p,usedBagId:item.id,outcome:'unknown',remainingFt:''}).throws[0];assert.equal(t.plannedShot.type,p.candidates[0].throwType);
});
test('a sharp-bend flat turnover still requires advanced skill',()=>{
 for(const skill of ['beginner','intermediate','amateur','unknown']){const p=plan({distanceFt:240,fairway:'right',type:'backhand'},{skill},[],{...disc,turn:-3,fade:1});assert.equal(p.candidates.length,0)}
 assert.ok(plan({distanceFt:240,fairway:'right',type:'backhand'},{skill:'pro'},[],{...disc,turn:-3,fade:1}).candidates.length);
});
test('combo holes use only the first bend and do not claim one shot solves both',()=>{
 const p=plan({distanceFt:450,fairway:'right-left'},{},[],disc,{...item,alternateDistance:150});const c=p.candidates.find(c=>c.throwType==='forehand'&&c.lineFit.kind==='natural-finish');assert.ok(c);assert.equal(c.lineFit.bend,'right');assert.equal(c.placement,true);assert.match(p.notes.join(' '),/both directions/);
});
