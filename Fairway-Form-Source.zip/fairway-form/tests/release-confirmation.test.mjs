import {test} from 'node:test';import assert from 'node:assert/strict';
import {review} from '../dist/lib/analysis.js';
import {derivePhases} from '../dist/lib/phases.js';
import {makeCoachPlan,summarizeCoaching} from '../dist/lib/coaching-language.js';
import {summaryMarkup} from '../dist/lib/report-ui.js';
function moving(){return Array.from({length:41},(_,i)=>{const t=i*.04,p=Array.from({length:33},()=>({x:.5,y:.5,visibility:1}));p[11]={x:.4,y:.3,visibility:1};p[12]={x:.5,y:.3,visibility:1};p[23]={x:.4,y:.65,visibility:1};p[24]={x:.5,y:.65,visibility:1};p[14]={x:.6,y:.4,visibility:1};p[16]={x:.15+t*.4,y:.5,visibility:1};return {t,p}})}
test('an automatic motion peak has a bounded review window and is not labeled a confirmed release',()=>{
 const frames=moving(),result=derivePhases(frames,{aspect:1,direction:'right',stance:'standstill'}),phase=result.phases.release;
 assert.ok(result.release);assert.equal(phase.origin,'estimated');assert.equal(phase.title,'Release check');assert.ok(phase.reviewWindow.start<phase.t);assert.ok(phase.reviewWindow.start>=frames[0].t);assert.ok(phase.reviewWindow.end<=frames.at(-1).t);
});
test('unconfirmed release does not produce praise/fault judgments or a default technique correction',()=>{
 const report=review(moving(),{aspect:1,direction:'right',stance:'standstill'});assert.equal(report.estimated,true);assert.equal(report.quality.releaseConfirmed,false);assert.ok(report.findings.every(f=>!['attention','positive'].includes(f.kind)));
 const plan=makeCoachPlan(report),summary=summarizeCoaching(report,plan);assert.equal(plan.needsReleaseConfirmation,true);assert.equal(plan.selectedFocus,'release');assert.match(plan.text,/fastest hand movement does not prove/);assert.equal(summary.keep,null);assert.equal(summary.focus,null);assert.match(summary.practice,/Mark release here/);assert.match(summaryMarkup(summary,report),/data-lesson="study-release"/);
});
test('a source-frame release marker replaces the motion estimate and reanchors the other checks',()=>{
 const before=review(moving(),{aspect:1,stance:'standstill'}),after=review(moving(),{aspect:1,stance:'standstill',markers:{release:.8}});
 assert.equal(after.release,.8);assert.equal(after.estimated,false);assert.equal(after.quality.releaseConfirmed,true);assert.equal(after.phases.find(p=>p.id==='release').origin,'marked');assert.equal(makeCoachPlan(after).needsReleaseConfirmation,undefined);assert.notEqual(before.release,after.release);
});
