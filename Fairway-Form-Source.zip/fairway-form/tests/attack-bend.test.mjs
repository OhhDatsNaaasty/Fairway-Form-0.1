import {test} from 'node:test';
import assert from 'node:assert/strict';
import {planShot,makeHole,recordThrow,normalizeShot,strategyForCandidate} from '../dist/lib/caddy.js';
import {landingPlan} from '../dist/lib/caddy-safety.js';
import {DISCS} from '../dist/lib/discs.js';
import {historyBackup,validateHistory} from '../dist/lib/disc-history.js';
import {suggestLanding,landingSketch} from '../dist/lib/landing-zone.js';
import {scenePoint} from '../dist/lib/hole-scene.js';
import {ATTACK_BEND_NOTES,ATTACK_BEND_DRY_NOTES,ATTACK_BEND_BAG} from './fixtures/attack-bend.mjs';
const raw={distanceFt:475,fairway:'slight-left',risk:'attack',type:'auto',hand:'right',hazard:'both',wooded:true,layoutNotes:ATTACK_BEND_NOTES};
const plan=(changes={},bag=ATTACK_BEND_BAG,profile={skill:'intermediate'})=>planShot({...raw,...changes},bag,DISCS,[],{profile});
for(const notes of [ATTACK_BEND_NOTES,ATTACK_BEND_DRY_NOTES])test('Attack advances past the known left bend: '+notes,()=>{
 const p=plan({layoutNotes:notes}),c=p.candidates[0];assert.equal(p.layout.cornerFt,250);assert.equal(c.discId,'innova-teebird');assert.equal(c.throwType,'backhand');assert.equal(c.releaseAngle,'flat');assert.equal(c.lineFit.fade,'left');assert.equal(c.tactic,'attack-bend');assert.ok(c.targetFt>270&&c.targetFt<=330);assert.equal(c.landing.hazardous,false);assert.ok(c.power.targetFt<=c.power.referenceFt);assert.match(p.strategy,/past the left bend at 250 ft/);assert.ok(p.candidates.some(c=>c.landing.phase==='before-bend'));assert.match(c.cautions.join(' '),/gap stays open/);assert.doesNotMatch(c.cautions.join(' '),/Add the bend distance/);
});
test('removing distant water leaves the actual attacking comparison unchanged',()=>{
 const a=plan(),b=plan({layoutNotes:ATTACK_BEND_DRY_NOTES});assert.deepEqual(a.candidates.map(c=>[c.optionKey,c.targetFt,c.score]),b.candidates.map(c=>[c.optionKey,c.targetFt,c.score]));
});
test('Safe and Attack change tactics rather than just their labels',()=>{
 const a=plan(),s=plan({risk:'safe'});assert.equal(a.candidates[0].tactic,'attack-bend');assert.equal(s.candidates[0].landing.phase,'before-bend');assert.ok(a.candidates[0].targetFt>s.candidates[0].targetFt);assert.ok(s.candidates.some(c=>c.tactic==='attack-bend'));
});
test('Attack with only the short putter never invents carry through the bend',()=>{
 const p=plan({},[ATTACK_BEND_BAG[0]]);assert.ok(p.candidates.length);assert.ok(p.candidates.every(c=>c.targetFt<150&&c.tactic!=='attack-bend'));assert.equal(p.candidates[0].landing.hazardous,false);assert.match(p.strategy,/before the bend/);
});
test('a useful nearer placement outranks the short putter when no disc reaches past the bend',()=>{
 const p=plan({},ATTACK_BEND_BAG.slice(0,2));assert.equal(p.candidates[0].discId,'discraft-buzzz');assert.ok(p.candidates[0].targetFt>200&&p.candidates[0].targetFt<250);assert.ok(p.candidates.every(c=>c.tactic!=='attack-bend'));
});
for(const [hand,side,type]of [['right','left','backhand'],['right','right','forehand'],['left','right','backhand'],['left','left','forehand']])test(`${hand}-hand ${type} naturally attacks a ${side} bend`,()=>{
 const p=plan({hand,fairway:'slight-'+side,layoutNotes:ATTACK_BEND_DRY_NOTES.replace('Left',side)},[{...ATTACK_BEND_BAG[2],referenceHand:hand,distance:330,alternateDistance:330}]),c=p.candidates[0];assert.equal(c.tactic,'attack-bend');assert.equal(c.throwType,type);assert.equal(c.lineFit.fade,side);assert.ok(c.targetFt>250);
});
test('an opposed finish is not relabeled as an attacking route',()=>{
 const p=plan({type:'backhand',fairway:'slight-right',layoutNotes:ATTACK_BEND_DRY_NOTES.replace('Left','Right')});assert.ok(p.candidates.every(c=>c.tactic!=='attack-bend'&&c.targetFt<250));
});
test('blocked styles and a selected maximum speed still constrain Attack',()=>{
 const blocked=plan({layoutNotes:ATTACK_BEND_NOTES+'. Backhand blocked.'});assert.ok(blocked.candidates.every(c=>c.throwType==='forehand'&&c.tactic!=='attack-bend'));
 const speed=plan({maxSpeed:5});assert.ok(speed.candidates.every(c=>c.tactic!=='attack-bend'));
});
test('an explicit nearer target and an open direct route remain separate choices',()=>{
 const p=plan({landingFt:100});assert.ok(p.candidates.every(c=>c.targetFt===100&&c.tactic!=='attack-bend'));
 const direct=plan({layoutNotes:ATTACK_BEND_NOTES+'. Open straight line to basket.'});assert.ok(direct.candidates.every(c=>c.tactic!=='attack-bend'));
});
test('early-turning discs and early-finish personal profiles cannot prove a late wooded turn',()=>{
 const p=plan({},[{id:'under',discId:'innova-mamba',distance:380}]);assert.ok(p.candidates.every(c=>c.tactic!=='attack-bend'));
 const copy={...ATTACK_BEND_BAG[2],observedFlight:'turns'};assert.ok(plan({},[copy]).candidates.every(c=>c.tactic!=='attack-bend'));
});
test('uphill headwind demand reduces an attacking target and can remove the option',()=>{
 const calm=plan(),hard=plan({elevation:'uphill',windDirection:'head',windStrength:'strong'});assert.ok(hard.candidates.every(c=>c.tactic!=='attack-bend'||c.targetFt<calm.candidates[0].targetFt));assert.ok(hard.candidates.every(c=>c.tactic!=='attack-bend'||c.power.targetFt<=c.power.referenceFt));
});
test('water near an attacking landing retains a controlled landing margin',()=>{
 const p=plan({distanceFt:340},[{...ATTACK_BEND_BAG[2],distance:400}]);const a=p.candidates.find(c=>c.tactic==='attack-bend');assert.ok(a);assert.ok(a.landing.hazardous);assert.ok(a.targetFt<340);assert.ok(a.power.targetFt/a.power.referenceFt<=.820001);assert.match(suggestLanding(p,a).description,/short of trouble/);
});
test('a bend just before tight long trouble can remove Attack despite a long range reference',()=>{
 const p=plan({distanceFt:300},[{...ATTACK_BEND_BAG[2],distance:400}]);assert.ok(p.candidates.every(c=>c.tactic!=='attack-bend'));assert.ok(p.candidates.every(c=>c.targetFt<250));
});
test('actual near-side goal, rather than full disc reference, determines long-hazard proximity',()=>{
 const layout={hazards:['long'],cornerFt:250,longClearanceFt:20};
 const near=landingPlan({shot:{distanceFt:475,type:'backhand'},layout,referenceFt:600,targetFt:475});assert.equal(near.targetFt,237.5);assert.equal(near.hazardous,false);
 const far=landingPlan({shot:{distanceFt:475,type:'backhand'},layout,referenceFt:600,targetFt:475,tactic:'attack-bend'});assert.equal(far.hazardous,true);assert.ok(far.targetFt<475);
});
test('required carry is never discarded to manufacture a before-corner or attack target',()=>{
 const p=plan({layoutNotes:ATTACK_BEND_NOTES+'. Must carry 340 ft over water.'});assert.equal(p.candidates.length,0);
});
test('one physical disc can compare both tactics and selecting either logs its exact target',()=>{
 const p=plan({},[ATTACK_BEND_BAG[2]]);assert.equal(p.candidates.length,2);assert.equal(new Set(p.candidates.map(c=>c.optionKey)).size,2);
 for(const c of p.candidates){p.selectedOptionKey=c.optionKey;const h=recordThrow(makeHole(),{plan:p,usedBagId:c.bagId,outcome:'unknown',remainingFt:''}),t=h.throws[0],restore=validateHistory(historyBackup([h]),normalizeShot)[0].throws[0];for(const saved of [t,restore]){assert.equal(saved.recommendationKey,c.optionKey);assert.equal(saved.plannedTargetFt,c.targetFt);assert.equal(saved.throwDistanceFt,null);assert.equal(saved.remainingFt,null);assert.equal(saved.input.distanceFt,475)}assert.match(strategyForCandidate(p,c),c.tactic==='attack-bend'?/past the left bend/:/before the bend/)}
});
test('landing artwork puts Attack beyond the scaled corner and the layup before it',()=>{
 const p=plan({},[ATTACK_BEND_BAG[2]]),a=p.candidates.find(c=>c.tactic==='attack-bend'),l=p.candidates.find(c=>c.landing.phase==='before-bend'),az=suggestLanding(p,a),lz=suggestLanding(p,l);assert.ok(!az.blocked&&!lz.blocked);const corner=scenePoint(az.scene,250);assert.ok(az.point.y<corner.y&&lz.point.y>corner.y);assert.ok(az.point.x<corner.x);assert.match(az.description,/left bend at about 250 ft.*left finish/);assert.match(lz.description,/before the bend/);assert.match(landingSketch(az),/data-landing-target/);assert.equal(az.targetFt,a.targetFt);
});
test('meters change presentation, not route distances or physical carry',()=>{
 const p=plan({unit:'m'}),a=p.candidates[0];assert.match(p.strategy,/76.2 m/);assert.match(suggestLanding(p,a).description,/91 m/);assert.equal(a.targetFt,297);
});
