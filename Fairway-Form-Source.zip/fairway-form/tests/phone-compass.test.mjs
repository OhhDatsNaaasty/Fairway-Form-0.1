import {test} from 'node:test';
import assert from 'node:assert/strict';
import {normalizeHeading,angleDifference,compassWindow,watchPhoneCompass} from '../dist/lib/phone-compass.js';
import {relativeWind} from '../dist/lib/caddy-weather.js';
function fixture(){
 let time=100000,serial=0,requestId;const tasks=new Map(),events=new EventTarget(),updates=[],errors=[],stopped=[];
 const schedule=(fn,ms)=>{const id=++serial;tasks.set(id,{at:time+ms,fn});return id},unschedule=id=>tasks.delete(id);
 function advance(ms){const until=time+ms;while(true){const next=[...tasks].filter(([,v])=>v.at<=until).sort((a,b)=>a[1].at-b[1].at)[0];if(!next)break;time=next[1].at;tasks.delete(next[0]);next[1].fn()}time=until}
 const bridge={startCompass:(id,latitude,longitude)=>{requestId=id;assert.equal(latitude,40.123);assert.equal(longitude,-75.45)},stopCompass:id=>stopped.push(id)};
 const watch=watchPhoneCompass({latitude:40.123,longitude:-75.45,events,bridge,onUpdate:r=>updates.push(r),onError:m=>errors.push(m),now:()=>time,schedule,unschedule});
 function emit(extra={}){events.dispatchEvent(new CustomEvent('fairway-compass',{detail:{id:requestId,heading:90,trueNorth:true,accuracy:3,accuracyDegrees:5,level:true,rotation:0,timestamp:time,...extra}}))}
 function settle(heading=90){for(let i=0;i<10;i++){emit({heading:typeof heading==='function'?heading(i):heading});advance(200)}}
 return {watch,events,advance,emit,settle,errors,updates,stopped,tasks,now:()=>time};
}
test('headings normalize across north and angle differences take the short direction',()=>{assert.equal(normalizeHeading(360),0);assert.equal(normalizeHeading(-1),359);assert.equal(angleDifference(1,359),2);assert.equal(angleDifference(359,1),-2)});
test('a stable series crossing north uses a circular mean rather than averaging to south',()=>{
 const rows=Array.from({length:10},(_,i)=>({heading:i%2?1:359,timestamp:100000+i*200})),reading=compassWindow(rows,101800);assert.equal(reading.ready,true);assert.ok(Math.abs(angleDifference(reading.heading,0))<.001);
});
test('a single fix or a fast turn cannot be mistaken for a settled aim',()=>{
 assert.equal(compassWindow([{heading:90,timestamp:100000}],100000).ready,false);const rows=Array.from({length:10},(_,i)=>({heading:i*15,timestamp:100000+i*200}));assert.equal(compassWindow(rows,101800).ready,false);
});
test('GPS location is passed for correction but only a true-north heading is returned',()=>{
 const f=fixture();f.settle();const value=f.watch.getReading();assert.equal(value.heading,90);assert.equal(value.reference,'true-north');assert.equal(value.method,'phone-compass');assert.doesNotMatch(JSON.stringify(value),/latitude|longitude/);f.watch.stop();assert.equal(f.stopped.length,1);assert.equal(f.tasks.size,0);
});
test('a north-crossing watch returns zero degrees, preserving headwind and crosswind signs',()=>{
 const f=fixture();f.settle(i=>i%2?1:359);const bearing=f.watch.getReading().heading;assert.equal(bearing,0);assert.equal(relativeWind(0,bearing,10).direction,'head');assert.equal(relativeWind(90,bearing,10).direction,'right-left');f.watch.stop();
});
test('a missing or unsupported native compass gives manual-entry guidance',()=>{
 assert.throws(()=>watchPhoneCompass({bridge:{},latitude:0,longitude:0}),/Android app/);assert.throws(()=>watchPhoneCompass({bridge:{startCompass(){},stopCompass(){}},latitude:NaN,longitude:0}),/Get local weather/);
});
test('wrong-request callbacks cannot fill the current heading',()=>{const f=fixture();for(let i=0;i<10;i++){f.emit({id:'old-request'});f.advance(200)}assert.equal(f.watch.getReading(),null);f.watch.stop()});
test('sensor errors unregister and surface a useful error without inventing a bearing',()=>{
 const f=fixture();f.emit({error:'No usable compass sensor.'});assert.equal(f.watch.getReading(),null);assert.deepEqual(f.errors,['No usable compass sensor.']);assert.equal(f.stopped.length,1);assert.equal(f.tasks.size,0);
});
test('stale, future, duplicate and invalid timestamps cannot fabricate a settled direction',()=>{
 const f=fixture();for(let i=0;i<10;i++){f.emit({timestamp:90000});f.emit({timestamp:200000});f.emit({timestamp:NaN});f.emit({timestamp:100000});f.advance(200)}assert.equal(f.watch.getReading(),null);f.watch.stop();
});
test('low sensor accuracy revokes a previously ready reading and keeps calibration guidance visible',()=>{
 const f=fixture();f.settle();assert.ok(f.watch.getReading());f.emit({accuracy:1});f.advance(300);assert.equal(f.watch.getReading(),null);assert.match(f.updates.at(-1).message,/figure eight/);assert.equal(f.updates.at(-1).ready,false);f.watch.stop();
});
test('large or invalid heading-error estimates cannot be accepted even when steady',()=>{
 for(const accuracyDegrees of [40,-1,NaN,Infinity]){const f=fixture();for(let i=0;i<10;i++){f.emit({accuracyDegrees});f.advance(200)}assert.equal(f.watch.getReading(),null);f.watch.stop()}
});
test('an unavailable numeric error estimate does not fabricate a number or reject good status alone',()=>{
 const f=fixture();for(let i=0;i<10;i++){f.emit({accuracyDegrees:null,accuracy:2});f.advance(200)}assert.equal(f.watch.getReading().heading,90);f.watch.stop();
});
test('tilting the phone prevents use and requires a new settled window after leveling',()=>{
 const f=fixture();f.settle();f.emit({level:false});assert.equal(f.watch.getReading(),null);f.advance(200);f.emit();assert.equal(f.watch.getReading(),null);assert.match(f.updates.at(-2).message,/screen facing up/);f.settle();assert.ok(f.watch.getReading());f.watch.stop();
});
test('magnetic-only, nonfinite and out-of-range headings cannot become true-north wind inputs',()=>{
 for(const extra of [{trueNorth:false},{heading:NaN},{heading:360},{heading:-1},{accuracy:undefined}]){const f=fixture();for(let i=0;i<10;i++){f.emit(extra);f.advance(200)}assert.equal(f.watch.getReading(),null);f.watch.stop()}
});
test('screen rotation discards the previous window before accepting the new screen-top direction',()=>{
 const f=fixture();f.settle(90);f.emit({rotation:1,heading:180});assert.equal(f.watch.getReading(),null);for(let i=0;i<10;i++){f.advance(200);f.emit({rotation:1,heading:180})}assert.equal(f.watch.getReading().heading,180);f.watch.stop();
});
test('a previously settled direction expires when sensor updates stop',()=>{
 const f=fixture();f.settle();assert.ok(f.watch.getReading());f.advance(1600);assert.equal(f.watch.getReading(),null);assert.equal(f.updates.at(-1).ready,false);f.watch.stop();
});
test('cancel removes callbacks and timers and ignores any late reading',()=>{
 const f=fixture();const count=f.updates.length;f.watch.stop();f.watch.stop();f.settle();assert.equal(f.updates.length,count);assert.equal(f.stopped.length,1);assert.equal(f.tasks.size,0);assert.equal(f.watch.getReading(),null);
});
test('an unattended capture times out and stops the native sensor stream',()=>{
 const f=fixture();f.advance(30000);assert.equal(f.tasks.size,0);assert.equal(f.stopped.length,1);assert.match(f.errors[0],/timed out/);assert.equal(f.watch.getReading(),null);
});

test('a screen orientation signal revokes readiness before the first remapped sensor event',()=>{
 const f=fixture();f.settle();assert.ok(f.watch.getReading());f.events.dispatchEvent(new Event('orientationchange'));assert.equal(f.watch.getReading(),null);assert.match(f.updates.at(-1).message,/Screen rotated/);f.settle(180);assert.equal(f.watch.getReading().heading,180);f.watch.stop();
});
