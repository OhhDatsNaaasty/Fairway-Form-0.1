import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {distanceMeters,endpointMeasurement,captureEndpoint,createThrowMeter} from '../dist/lib/throw-measure.js';
import {preciseLocationPermission} from '../dist/lib/throw-measure-ui.js';
import {distanceMeasurement,discStats,personalRange,historyBackup,validateHistory} from '../dist/lib/disc-history.js';
import {makeHole,normalizeShot,planShot,recordThrow} from '../dist/lib/caddy.js';
const start={latitude:0,longitude:0,accuracy:3,samples:4},end={latitude:0,longitude:.0009,accuracy:4,samples:5};
const measurement=()=>endpointMeasurement(start,end);
const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});return {promise,resolve,reject}};
function fixture(){
 let time=100000,id=0,good,bad;const tasks=new Map(),cleared=[];
 const schedule=(fn,ms)=>{const key=++id;tasks.set(key,{at:time+ms,fn});return key},unschedule=key=>tasks.delete(key);
 function advance(ms){const until=time+ms;while(true){const next=[...tasks].filter(([,t])=>t.at<=until).sort((a,b)=>a[1].at-b[1].at)[0];if(!next)break;time=next[1].at;tasks.delete(next[0]);next[1].fn()}time=until}
 const geolocation={watchPosition(success,error,options){good=success;bad=error;assert.equal(options.enableHighAccuracy,true);assert.equal(options.maximumAge,0);return 17},clearWatch:key=>cleared.push(key)};
 return {options:{geolocation,now:()=>time,schedule,unschedule},advance,emit:(coords={},timestamp=time)=>good({timestamp,coords:{...start,speed:0,...coords}}),error:code=>bad({code}),cleared,tasks};
}
test('WGS84 endpoint distance matches known equatorial and meridional baselines',()=>{
 assert.ok(Math.abs(distanceMeters(start,{latitude:0,longitude:.001})-111.3194908)<.001);
 assert.ok(Math.abs(distanceMeters(start,{latitude:.001,longitude:0})-110.5742758)<.001);
 assert.equal(distanceMeters(start,start),0);assert.ok(Math.abs(distanceMeters({latitude:0,longitude:179.9995},{latitude:0,longitude:-179.9995})-111.3194908)<.001);
});
test('endpoints give straight-line carry, not a walked path, and altitude is ignored',()=>{
 const result=measurement();assert.ok(Math.abs(result.throwDistanceFt-328.699)<.01);assert.equal(result.distanceGps.uncertaintyM,7);assert.equal(result.distanceMethod,'gps');assert.equal(result.unresolved,false);
 assert.equal(distanceMeters({...start,altitude:100},end),distanceMeters(start,{...end,altitude:200}));assert.doesNotMatch(JSON.stringify(result),/latitude|longitude|altitude/);
});
test('invalid coordinates, missing accuracy and impossible throw lengths are rejected',()=>{
 assert.throws(()=>distanceMeters({...start,latitude:91},end));assert.throws(()=>endpointMeasurement({...start,accuracy:NaN},end));assert.throws(()=>endpointMeasurement(start,start),/less than a foot/);assert.throws(()=>endpointMeasurement(start,{...end,longitude:1}),/1,500/);
 assert.equal(endpointMeasurement(start,{...end,longitude:.00001}).unresolved,true);
});
test('a fresh stationary endpoint settles before returning and clears the location watch',async()=>{
 const f=fixture(),p=captureEndpoint({...f.options,settleMs:8000});f.emit();f.advance(3000);f.emit({accuracy:2});f.advance(3000);f.emit({accuracy:4});f.advance(2000);const point=await p;assert.equal(point.accuracy,2);assert.equal(point.samples,3);assert.deepEqual(f.cleared,[17]);assert.equal(f.tasks.size,0);
});
test('one fresh fix can settle when a stationary provider does not emit repeated updates',async()=>{
 const f=fixture(),p=captureEndpoint(f.options);f.emit();f.advance(8000);assert.equal((await p).samples,1);assert.equal(f.cleared.length,1);
});
test('cached, future, invalid and duplicate timestamps cannot fabricate more readings',async()=>{
 const f=fixture(),p=captureEndpoint(f.options);f.emit({},90000);f.emit({},110000);f.emit({accuracy:Infinity});f.emit({latitude:100});f.emit();f.emit();f.advance(8000);assert.equal((await p).samples,1);
});
test('permission denial stops promptly and leaves manual distance available',async()=>{
 const f=fixture(),p=captureEndpoint(f.options);f.error(1);await assert.rejects(p,/not allowed/);assert.deepEqual(f.cleared,[17]);assert.equal(f.tasks.size,0);
});
test('poor or stale locations time out instead of returning a false precise distance',async()=>{
 const f=fixture(),p=captureEndpoint(f.options);for(let i=0;i<6;i++){f.emit({accuracy:500});f.advance(5000)}await assert.rejects(p,/too uncertain/);assert.equal(f.cleared.length,1);
 const stale=fixture(),waiting=captureEndpoint(stale.options);stale.emit({accuracy:15});stale.advance(30000);await assert.rejects(waiting,/too uncertain/);
});
test('a modest fix can be used at the deadline with its original uncertainty',async()=>{
 const f=fixture(),p=captureEndpoint(f.options);for(let i=0;i<6;i++){f.emit({accuracy:12});f.advance(5000)}assert.equal((await p).accuracy,12);assert.equal(f.cleared.length,1);
});
test('walking readings and a drifting endpoint cannot settle early',async()=>{
 const f=fixture(),controller=new AbortController(),p=captureEndpoint({...f.options,signal:controller.signal,settleMs:8000});f.emit({speed:2});f.advance(8000);assert.equal(f.cleared.length,0);f.emit({longitude:0});f.advance(2000);f.emit({longitude:.01});f.advance(1000);assert.equal(f.cleared.length,0);controller.abort();await assert.rejects(p,{name:'AbortError'});assert.equal(f.tasks.size,0);assert.equal(f.cleared.length,1);
});
test('cancelling capture also ignores any late provider callback',async()=>{
 const f=fixture(),controller=new AbortController(),p=captureEndpoint({...f.options,signal:controller.signal});controller.abort();f.emit();await assert.rejects(p,{name:'AbortError'});assert.deepEqual(f.cleared,[17]);assert.equal(f.tasks.size,0);
});
test('Start, Stop and Save retain uncertainty and discard raw coordinates on Save',async()=>{
 const values=[start,end],m=createThrowMeter({context:()=> 'hole:0',capture:async()=>values.shift()});assert.throws(()=>m.save());await m.action();assert.equal(m.state.phase,'walking');await m.action();assert.equal(m.state.phase,'ready');const saved=m.save();assert.equal(saved.distanceGps.uncertaintyM,7);assert.equal(m.state.phase,'saved');assert.equal(m.state.start,null);assert.doesNotMatch(JSON.stringify(saved),/latitude|longitude/);
});
test('capture failure at the landing keeps the start so Stop can be retried',async()=>{
 let calls=0;const m=createThrowMeter({context:()=> 'h:1',capture:async()=>{if(++calls===1)return start;if(calls===2)throw Error('No GPS');return end}});await m.action();await m.action();assert.equal(m.state.phase,'walking');assert.equal(m.state.start,start);await m.action();assert.equal(m.state.phase,'ready');
});
test('Cancel and changing holes prevent a late capture from attaching to another throw',async()=>{
 let key='h:0',gate=deferred();const m=createThrowMeter({context:()=>key,capture:()=>gate.promise}),pending=m.action();m.cancel();gate.resolve(start);await pending;assert.equal(m.state.phase,'idle');assert.equal(m.state.start,null);
 gate=deferred();const again=m.action();key='other:0';gate.resolve(start);await again;assert.equal(m.state.phase,'idle');assert.throws(()=>m.save());
});
test('pausing endpoint capture aborts the watch and permits a safe retry',async()=>{
 let calls=0,aborted=false;const m=createThrowMeter({context:()=> 'h:0',capture:({signal})=>{if(++calls===1)return Promise.resolve(start);return new Promise((resolve,reject)=>signal.addEventListener('abort',()=>{aborted=true;reject(Object.assign(Error('Cancelled'),{name:'AbortError'}))}))}});await m.action();const pending=m.action();m.suspend();await pending;assert.equal(aborted,true);assert.equal(m.state.phase,'walking');assert.equal(m.state.start,start);
});
test('Android precise permission correlates callbacks and rejects an approximate-only grant',async()=>{
 const events=new EventTarget();let id;const bridge={requestPreciseLocation:value=>{id=value}};const p=preciseLocationPermission(null,{bridge,events});events.dispatchEvent(new CustomEvent('fairway-location-permission',{detail:{id:'other',granted:true}}));events.dispatchEvent(new CustomEvent('fairway-location-permission',{detail:{id,granted:false}}));await assert.rejects(p,/Precise location/);
 const allowed=preciseLocationPermission(null,{bridge,events});events.dispatchEvent(new CustomEvent('fairway-location-permission',{detail:{id,granted:true}}));await allowed;
});
test('cancelling Android permission removes the callback listener and ignores a late grant',async()=>{
 const controller=new AbortController(),events=new EventTarget();let id;const p=preciseLocationPermission(controller.signal,{events,bridge:{requestPreciseLocation:value=>{id=value}}});controller.abort();events.dispatchEvent(new CustomEvent('fairway-location-permission',{detail:{id,granted:true}}));await assert.rejects(p,{name:'AbortError'});
});
test('GPS metadata is validated, sanitized and removed when the distance is cleared or corrected manually',()=>{
 const raw=measurement(),stored=distanceMeasurement({...raw,distanceGps:{...raw.distanceGps,latitude:123}});assert.equal(stored.distanceMethod,'gps');assert.equal(stored.distanceGps.latitude,undefined);assert.throws(()=>distanceMeasurement({...raw,distanceGps:null}));assert.throws(()=>distanceMeasurement({...raw,distanceGps:{...raw.distanceGps,uncertaintyM:1}}));assert.equal(distanceMeasurement({...raw,distanceMethod:'measured'}).distanceGps,null);assert.equal(distanceMeasurement({...raw,throwDistanceFt:null}).distanceGps,null);
});
test('GPS averages and farthest throws stay separate; uncertain short throws cannot establish carry',()=>{
 const records=[1,2,3].map(i=>({id:String(i),usedBagId:'bag',input:{hand:'right',type:'backhand',releaseAngle:'flat',effort:'stock',elevation:'level',windStrength:'calm'},actualShot:{hand:'right',type:'backhand',releaseAngle:'flat'},outcome:'planned',clearFlight:true,...distanceMeasurement(measurement())}));
 const stats=discStats(records,'bag');assert.equal(stats.gpsCount,3);assert.equal(stats.measuredCount,0);assert.equal(stats.averageFt,null);assert.equal(stats.gpsAverageFt,measurement().throwDistanceFt);
 const shot={...records[0].input},range=personalRange({id:'bag',distance:250},shot,records);assert.ok(range.feet>328);assert.match(range.source,/GPS/);
 const noisy=records.map(r=>({...r,distanceGps:{...r.distanceGps,uncertaintyM:30}}));assert.equal(personalRange({id:'bag',distance:250},shot,noisy).feet,250);
 const short=records.map(r=>({...r,throwDistanceFt:20}));assert.equal(personalRange({id:'bag',distance:250},shot,short).feet,250);
});
test('GPS carry round-trips through canonical throw logs and bag history backups without coordinates',()=>{
 const disc={id:'d',brand:'Test',model:'Fairway',speed:7,glide:5,turn:-1,fade:2,type:'Fairway'},bag=[{id:'bag',discId:'d',distance:300}],shot={distanceFt:350,hand:'right',type:'backhand',fairway:'straight'},plan=planShot(shot,bag,[disc]);
 const hole=recordThrow(makeHole(),{plan,usedBagId:'bag',outcome:'planned',remainingFt:30,...measurement()}),rows=historyBackup([hole]),restored=validateHistory(rows,normalizeShot);assert.equal(restored[0].throws[0].distanceMethod,'gps');assert.equal(restored[0].throws[0].distanceGps.uncertaintyM,7);assert.equal(restored[0].throws[0].throwDistanceFt,hole.throws[0].throwDistanceFt);assert.doesNotMatch(JSON.stringify(restored),/latitude|longitude/);
});
test('Android upgrade requests coarse and fine together; location remains foreground only',async()=>{
 const java=await fs.readFile(new URL('../android/app/src/main/java/com/fairwayform/app/MainActivity.java',import.meta.url),'utf8'),manifest=await fs.readFile(new URL('../android/app/src/main/AndroidManifest.xml',import.meta.url),'utf8');assert.match(java,/ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION/);assert.match(java,/PRECISE_LOCATION_PERMISSION/);assert.match(manifest,/ACCESS_FINE_LOCATION/);assert.doesNotMatch(manifest,/ACCESS_BACKGROUND_LOCATION|FOREGROUND_SERVICE_LOCATION/);
});

test('the default fast capture accepts a fresh accurate stationary fix in two seconds',async()=>{const f=fixture(),p=captureEndpoint(f.options);f.emit({accuracy:4});f.advance(1750);assert.equal(f.cleared.length,0);f.advance(250);const result=await p;assert.equal(result.accuracy,4);assert.equal(f.cleared.length,1);assert.equal(f.tasks.size,0)});
