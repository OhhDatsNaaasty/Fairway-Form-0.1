import {test} from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {review} from '../dist/lib/analysis.js';import {derivePhases} from '../dist/lib/phases.js';
const fixture=name=>JSON.parse(fs.readFileSync(new URL('./fixtures/reference-poses/'+name+'.json',import.meta.url)));
const opts=data=>({hand:'right',type:'backhand',view:'side',cameraStable:true,stance:'walkup',aspect:data.provenance.dimensions[0]/data.provenance.dimensions[1]});
const at=(r,id)=>r.phases.find(p=>p.id===id),inside=(t,a,b)=>assert.ok(Number.isFinite(t)&&t>=a&&t<=b,`${t} is outside ${a}–${b}`);
test('uncropped normal-speed reference selects the initial forward swing rather than later recovery',()=>{
 const d=fixture('fullspeed-full-frame'),r=review(d.frames,opts(d));inside(r.release,1.98,2.07);inside(at(r,'plant').t,1.77,1.91);inside(at(r,'reachback').t,1.8,1.9);inside(at(r,'pocket').t,1.9,1.97);assert.ok(at(r,'plant').t<r.release);assert.equal(r.quality.releaseConfirmed,false);assert.ok(r.findings.every(f=>!['attention','positive'].includes(f.kind)));
});
test('a selected review range retains the same supported stroke and preparation instead of reversing direction',()=>{
 const d=fixture('fullspeed-full-frame'),r=review(d.frames,{...opts(d),reviewWindow:{start:.8,end:4.9}});inside(r.release,1.98,2.07);inside(at(r,'reachback').t,1.8,1.9);inside(at(r,'plant').t,1.77,1.91);
});
test('cropping the video viewport retains the already-correct swing/plant and can recover arm loading',()=>{
 const d=fixture('fullspeed-video-crop'),r=review(d.frames,opts(d));inside(r.release,1.98,2.07);inside(at(r,'plant').t,1.77,1.91);inside(at(r,'pocket').t,1.9,1.97);assert.equal(r.quality.releaseConfirmed,false);
});
test('a genuine source-frame correction is never overwritten by the new automatic candidate logic',()=>{
 const d=fixture('fullspeed-full-frame'),r=review(d.frames,{...opts(d),markers:{release:2.331911,plant:2.432389}});assert.equal(r.release,2.331911);assert.equal(at(r,'plant').t,2.432389);assert.equal(at(r,'release').origin,'marked');assert.equal(at(r,'plant').origin,'marked');
});
test('the heavily retimed reference remains ungraded when there are competing motion sequences',()=>{
 const d=fixture('slowed-displayed-orientation'),r=review(d.frames,opts(d));assert.equal(r.release,null);assert.equal(r.quality.ambiguousRelease,true);assert.equal(r.findings.length,0);
});
test('the production event selector uses decoded times and leaves reference landmarks unchanged',()=>{
 const d=fixture('fullspeed-full-frame'),before=JSON.stringify(d.frames),r=derivePhases(d.frames,opts(d));assert.equal(JSON.stringify(d.frames),before);for(const p of Object.values(r.phases))if(p.t!==null)assert.ok(d.frames.some(f=>f.t===p.t));
});
test('brief hand occlusion does not discard every actual swing sample from the recorded sequence',()=>{
 const d=fixture('fullspeed-full-frame'),r=derivePhases(d.frames,opts(d));assert.ok(r.speed.some(s=>s.sampleEnd-s.sampleStart>.09&&s.sampleEnd-s.sampleStart<=.3&&s.displacementX<0));inside(r.release.t,1.98,2.07);
});
