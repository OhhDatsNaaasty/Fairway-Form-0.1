import {test} from 'node:test';
import assert from 'node:assert/strict';
import {PUTTING_PROMPT_FT,puttingBand,normalizePutting,puttingStats,puttingEvidence} from '../dist/lib/putting.js';
import {puttingBandLabel,puttingProfile} from '../dist/lib/putting-ui.js';
import {planShot,makeHole,recordThrow,normalizeShot,toFeet} from '../dist/lib/caddy.js';
import {historyBackup,validateHistory,personalRange} from '../dist/lib/disc-history.js';
import {discProfile} from '../dist/lib/disc-profile.js';
const discs=[{id:'putter',brand:'Test',model:'Putter',type:'Putter',speed:2,glide:3,turn:0,fade:1},{id:'driver',brand:'Test',model:'Driver',type:'Distance',speed:12,glide:5,turn:-1,fade:3}];
const bag=[{id:'a',discId:'putter',distance:250,puttingRange:30},{id:'b',discId:'putter',distance:200,puttingRange:30,puttingPreferred:true},{id:'d',discId:'driver',distance:350}];
const shot={type:'putt',hand:'right',distanceFt:20,fairway:'straight',elevation:'level',windStrength:'calm',windDirection:'calm',risk:'balanced',puttIntent:'run'};
let id=0;
function row({distance=20,outcome='made',intent='attempt',bagId='a',type='putt',hand='right',conditions={},putting=true}={}){return {id:'throw-'+(++id),holeId:'hole',number:id,recordedAt:Date.now(),usedBagId:bagId,outcome,remainingFt:outcome==='made'?0:5,input:{...shot,...conditions,type,hand},actualShot:{type,hand,releaseAngle:'unknown'},putting:putting?{startDistanceFt:distance,distanceMethod:'estimated',intent}:null,feedback:{quality:'unknown',execution:'unknown',flight:'unknown'}}}
test('the requested bands cover positive distances exactly once, with inclusive upper boundaries',()=>{
 assert.equal(PUTTING_PROMPT_FT,50);for(const [value,band]of [[.5,'inside10'],[10,'inside10'],[10.001,'10to20'],[20,'10to20'],[20.001,'20to25'],[25,'20to25'],[25.001,'over25'],[80,'over25']])assert.equal(puttingBand(value),band);for(const value of [0,-1,null,NaN,Infinity])assert.equal(puttingBand(value),null);
});
test('meter conversion preserves the 10/20/25 foot boundary assignments',()=>{for(const [m,band]of [[3.048,'inside10'],[6.096,'10to20'],[7.62,'20to25']])assert.equal(puttingBand(toFeet(m,'m')),band);assert.equal(puttingBand(toFeet(6.1,'m')),'20to25');assert.equal(puttingBandLabel('over25','m'),'>7.62 m')});
test('missing history shows no percentage; a confirmed miss correctly gives zero percent',()=>{
 const empty=puttingStats([],'a');assert.equal(empty.bands[0].percentage,null);const stats=puttingStats([row({distance:8,outcome:'missed'})],'a');assert.equal(stats.bands[0].percentage,0);assert.equal(stats.bands[0].attempts,1);assert.match(puttingProfile('a',[]),/—/);
});
test('per-copy statistics count confirmed attempts in each band without mixing other discs',()=>{
 const records=[row({distance:10}),row({distance:10,outcome:'missed'}),row({distance:20}),row({distance:25}),row({distance:30}),row({distance:10,bagId:'b'})],stats=puttingStats(records,'a');assert.deepEqual(stats.bands.map(b=>[b.attempts,b.makes]),[[2,1],[1,1],[1,1],[1,1]]);assert.equal(stats.attempts,5);assert.equal(stats.bands[0].percentage,50);
});
test('layups, unknown results and unknown start distances never become misses',()=>{
 const records=[row({intent:'layup',outcome:'missed'}),row({intent:'layup',outcome:'made'}),row({outcome:'unknown'}),row({intent:'unknown'}),row({distance:null})],stats=puttingStats(records,'a');assert.equal(stats.attempts,0);assert.equal(stats.layups,2);assert.equal(stats.unclassified,3);assert.ok(stats.bands.every(b=>b.percentage===null));
});
test('putter drives and non-putting actual throws cannot inflate putting accuracy',()=>{
 const records=[row({type:'backhand'}),row({type:'forehand'})];assert.equal(puttingStats(records,'a').count,0);assert.equal(normalizePutting({startDistanceFt:20}, {type:'backhand'}),null);
});
test('misses from pulled or slipped putts still count in actual accuracy',()=>{
 const r=row({outcome:'missed'});r.feedback.execution='slipped';assert.equal(puttingStats([r],'a').bands[1].attempts,1);assert.equal(puttingStats([r],'a').bands[1].percentage,0);
});
test('duplicate IDs and restored copies do not double-count attempts',()=>{const r=row();assert.equal(puttingStats([r,structuredClone(r)],'a').attempts,1)});
test('putting evidence respects hand, distance band, weather and slope',()=>{
 const records=Array.from({length:6},()=>row());assert.equal(puttingEvidence(records,'a',shot).used,true);assert.equal(puttingEvidence(records,'a',{...shot,hand:'left'}).used,false);assert.equal(puttingEvidence(records,'a',{...shot,distanceFt:30}).used,false);assert.equal(puttingEvidence(records,'a',{...shot,windStrength:'strong',windDirection:'head'}).used,false);assert.equal(puttingEvidence(records,'a',{...shot,elevation:'uphill'}).used,false);
});
test('fewer than five comparable attempts cannot alter the putting rank',()=>{const history=Array.from({length:4},()=>row());assert.equal(puttingEvidence(history,'a',shot).score,0);assert.equal(puttingEvidence(history,'a',shot).used,false)});
test('observed accuracy can inform putter choice without bringing a driver into the list',()=>{
 const history=[...Array.from({length:40},()=>row({bagId:'a',outcome:'made'})),...Array.from({length:40},()=>row({bagId:'b',outcome:'missed'}))];const plan=planShot(shot,bag,discs,history);assert.equal(plan.candidates[0].bagId,'a');assert.ok(plan.candidates.every(c=>c.disc.type==='Putter'));assert.ok(plan.candidates[0].reasons.some(r=>/40 confirmed attempts/.test(r)));assert.ok(Math.abs(puttingEvidence(history,'a',shot).score)<=8);
});
test('putting guidance distinguishes the 50-foot prompt from the 10-meter balance rule',()=>{
 const near=planShot(shot,bag,discs);assert.ok(near.notes.some(n=>/PDGA 10-meter/.test(n)));const far=planShot({...shot,distanceFt:40},bag,discs);assert.ok(far.notes.some(n=>/Outside the 10-meter/.test(n)));assert.ok(far.sources.includes('puttingrules'));assert.ok(far.sources.includes('puttingpractice'));
});
test('a miss records putting start distance separately from GPS/throw carry and next-lie distance',()=>{
 const plan=planShot(shot,bag,discs),h=makeHole();h.draft.type='putt';h.draft.throwTypeBeforePutting='forehand';const next=recordThrow(h,{plan,usedBagId:'a',outcome:'missed',remainingFt:5,actualShot:{type:'putt',hand:'right'},throwDistanceFt:22,distanceMethod:'measured',putting:{startDistanceFt:20,distanceMethod:'estimated',intent:'attempt'}});const r=next.throws[0];assert.equal(r.putting.startDistanceFt,20);assert.equal(r.throwDistanceFt,22);assert.equal(r.remainingFt,5);assert.equal(next.draft.distanceFt,5);assert.equal(next.draft.type,'forehand');assert.equal(next.draft.puttingDecision,'unanswered');assert.equal(next.status,'open');
});
test('a made putt finishes the hole and enters accuracy once; a holed layup stays separate',()=>{
 const plan=planShot(shot,bag,discs),record=intent=>recordThrow(makeHole(),{plan,usedBagId:'a',outcome:'made',remainingFt:'',actualShot:{type:'putt',hand:'right'},putting:{startDistanceFt:20,distanceMethod:'measured',intent}});const made=record('attempt');assert.equal(made.status,'finished');assert.equal(puttingStats(made.throws,'a').makes,1);assert.equal(puttingStats(record('layup').throws,'a').attempts,0);
});
test('legacy explicit putting results keep their estimated planned distance, without guessing an unplanned putt distance',()=>{
 const legacy=row({putting:false});assert.equal(puttingStats([legacy],'a').attempts,1);assert.equal(puttingStats([{...legacy,input:{...legacy.input,puttIntent:'auto'}}],'a').attempts,0);assert.equal(normalizePutting(null,{type:'putt'},shot,'made').basis,'legacy planned distance');const unexpected=normalizePutting(null,{type:'putt'},{...shot,type:'backhand',distanceFt:300},'made');assert.equal(unexpected.startDistanceFt,null);assert.equal(puttingStats([row({putting:false,outcome:'planned'})],'a').attempts,0);
});
test('putting data round-trips through canonical backups and rejects invalid imported distances',()=>{
 const r=row(),copy=validateHistory(historyBackup([{id:'hole',title:'Test',throws:[r]}]),normalizeShot);assert.equal(copy[0].throws[0].putting.startDistanceFt,20);assert.equal(puttingStats(copy[0].throws,'a').attempts,1);assert.throws(()=>validateHistory([{...r,putting:{...r.putting,startDistanceFt:-3}}],normalizeShot),/putting start/);assert.throws(()=>normalizePutting({...r.putting,distanceMethod:'gps'},{type:'putt'}),/estimated or measured/);
});
test('all existing disc profile features remain and corrected putting feedback recalculates the accuracy bands',()=>{
 const r=row(),before=discProfile(bag[0],[r]);assert.equal(before.initial.distance,250);assert.ok(before.groups.length);assert.equal(before.putting.bands[1].makes,1);const corrected={...r,putting:{...r.putting,startDistanceFt:8}};assert.equal(discProfile(bag[0],[corrected]).putting.bands[0].makes,1);assert.equal(discProfile(bag[0],[corrected]).putting.bands[1].attempts,0);
});
test('putting accuracy cannot turn a putter’s comfortable putting range into throwing carry',()=>{
 const history=Array.from({length:20},()=>row());assert.equal(personalRange(bag[0],shot,history).feet,30);assert.equal(personalRange(bag[0],{...shot,type:'backhand'},history).feet,250);
});
test('short tap-ins and putts beyond fifty feet can be explicitly planned without a fixed cutoff',()=>{
 assert.ok(planShot({...shot,distanceFt:.5},bag,discs).candidates.length);assert.ok(planShot({...shot,distanceFt:60},bag,discs).candidates.length);assert.throws(()=>planShot({...shot,distanceFt:0},bag,discs));
});
