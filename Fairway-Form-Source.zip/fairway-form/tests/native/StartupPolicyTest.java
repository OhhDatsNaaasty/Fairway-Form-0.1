package com.fairwayform.app;

public final class StartupPolicyTest {
 private static int checks;
 private static void expect(boolean condition,String message){checks++;if(!condition)throw new AssertionError(message);}
 public static void main(String[] args){
  StartupPolicy policy=new StartupPolicy();
  expect(policy.onStart(),"Cold launch must play the intro");
  expect(!policy.onStart(),"A duplicate start while visible must not replay");
  policy.onStop(false);expect(policy.onStart(),"Returning from Home must replay");
  policy.onStop(false);expect(policy.onStart(),"Every subsequent foreground opening must replay");
  policy.onStop(true);expect(!policy.onStart(),"Returning from an app-launched picker or camera must not replay");
  expect(!policy.onStart(),"The external-return decision must not start a second intro");
  policy.onStop(false);expect(policy.onStart(),"External-task suppression must not leak into the next normal opening");
  policy.onStop(true);expect(!policy.onStart(),"A second app-launched task must still preserve its workflow");
  policy.onStop(false);expect(policy.onStart(),"An app-switcher return must replay after the external workflow ends");
  expect(!policy.onStart(),"A short pause/resume without a stop must not replay");
  StartupPolicy recreated=new StartupPolicy();expect(recreated.onStart(),"A recreated process must play on its first opening");
  expect(!recreated.onStart(),"Recreated process must still avoid duplicate starts");
  System.out.println("Startup lifecycle rules: "+checks+" checks passed.");
 }
}
