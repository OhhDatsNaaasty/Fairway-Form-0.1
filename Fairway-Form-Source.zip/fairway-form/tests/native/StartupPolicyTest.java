package com.fairwayform.app;

public final class StartupPolicyTest {
 private static int checks;
 private static void expect(boolean condition,String message){checks++;if(!condition)throw new AssertionError(message);}
 public static void main(String[] args){
  StartupPolicy policy=new StartupPolicy();
  expect(policy.onStart(),"A fresh app opening must play the intro");
  expect(!policy.onStart(),"A repeated start must not replay");
  policy.onStop(false);expect(!policy.onStart(),"Returning from Home must not replay");
  policy.onStop(false);expect(!policy.onStart(),"Returning from the app switcher must not replay");
  policy.onStop(false);expect(!policy.onStart(),"Unlocking the screen must not replay");
  policy.onStop(true);expect(!policy.onStart(),"Returning from Gallery or camera must not replay");
  policy.onStop(true);expect(!policy.onStart(),"Returning from a permission or range task must not replay");
  for(int i=0;i<3;i++){policy.onStop(false);expect(!policy.onStart(),"Repeated background cycles must not restart the intro");}
  StartupPolicy reopened=new StartupPolicy();expect(reopened.onStart(),"Closing and newly opening the app must play again");
  expect(!reopened.onStart(),"The reopened session also plays at most once");
  System.out.println("Startup lifecycle rules: "+checks+" checks passed.");
 }
}
