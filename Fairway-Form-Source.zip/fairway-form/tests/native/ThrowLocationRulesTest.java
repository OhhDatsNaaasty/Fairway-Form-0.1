package com.fairwayform.app;
public final class ThrowLocationRulesTest {
 private static int checks=0;private static void check(boolean b){checks++;if(!b)throw new AssertionError("Location check "+checks);}
 public static void main(String[] args){
  long now=5000000000L;check(ThrowLocationRules.accept(42,-89,1.2f,0,false,now,now-1000000000L,now-1000000000L));
  check(!ThrowLocationRules.accept(42,-89,1,1501,false,now,now,0));check(!ThrowLocationRules.accept(42,-89,1,-1,false,now,now,0));
  check(!ThrowLocationRules.accept(42,-89,1,0,true,now,now,0));check(!ThrowLocationRules.accept(42,-89,Float.NaN,0,false,now,now,0));
  check(!ThrowLocationRules.accept(42,-89,0,0,false,now,now,0));check(!ThrowLocationRules.accept(91,-89,1,0,false,now,now,0));check(!ThrowLocationRules.accept(42,181,1,0,false,now,now,0));
  check(!ThrowLocationRules.accept(Double.NaN,-89,1,0,false,now,now,0));check(!ThrowLocationRules.accept(42,-89,1,0,false,now,now,now));check(!ThrowLocationRules.accept(42,-89,1,0,false,now-2000000000L,now,0));
  check(ThrowLocationRules.validId("capture-123"));check(!ThrowLocationRules.validId(null));check(!ThrowLocationRules.validId("bad'\\"));
  System.out.println("Native throw-location rules: "+checks+" checks passed.");
 }
}
