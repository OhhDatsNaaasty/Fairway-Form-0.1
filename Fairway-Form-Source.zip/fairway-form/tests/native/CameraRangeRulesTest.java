package com.fairwayform.app;
import java.util.Arrays;
public class CameraRangeRulesTest {
 private static int checks=0;
 private static void check(boolean pass,String reason){checks++;if(!pass)throw new AssertionError(reason);}
 public static void main(String[] args){
  int[] z={2000,2010,1990,2000,2005,1995,2000,2000,2000},q={255,255,255,255,255,255,255,255,255};
  check(Math.abs(CameraRangeRules.depthMeters(z,q)-2)<.001,"millimeters must convert to meters");
  check(Float.isNaN(CameraRangeRules.depthMeters(z,new int[9])),"low confidence cannot become a distance");
  check(Float.isNaN(CameraRangeRules.depthMeters(new int[]{0,0,0,0,0,0,0,0,0},q)),"missing pixels are not a target");
  check(Float.isNaN(CameraRangeRules.depthMeters(new int[]{2000,2000,2000,2000,2000,2000,4000,4000,4000},q)),"mixed foreground/background surfaces must be rejected");
  check(Float.isNaN(CameraRangeRules.depthMeters(new int[]{15000,15000,15000,15000,15000,15000,15000,15000,15000},q)),"out of range depth must be rejected");
  float[][] points=new float[6][3];for(float[] p:points){p[0]=3;p[1]=1;p[2]=4;}
  check(CameraRangeRules.stablePoint(points,600)!=null,"a stable surface should be available");
  check(CameraRangeRules.stablePoint(points,100)==null,"a single quick glimpse must not qualify");
  points[5][0]=4;check(CameraRangeRules.stablePoint(points,600)==null,"a jumping target must not qualify");
  points[5][0]=Float.NaN;check(CameraRangeRules.stablePoint(points,600)==null,"invalid pose must not qualify");
  check(CameraRangeRules.horizontalMeters(new float[]{0,0,0},new float[]{3,100,4},10)==5,"distance is horizontal displacement, not slope or walked route");
  check(Double.isNaN(CameraRangeRules.horizontalMeters(new float[]{0,0,0},new float[]{11,0,0},10)),"target mode cannot imply long range depth");
  check(Double.isNaN(CameraRangeRules.horizontalMeters(new float[]{0,0,0},new float[]{151,0,0},150)),"walking estimate needs a length cap");
  check(!CameraRangeRules.continuous(false,100,1000),"lost tracking invalidates a walk");
  check(!CameraRangeRules.continuous(true,2000,1000),"missing frames invalidate a walk");
  check(!CameraRangeRules.continuous(true,100,300001),"overlong walks cannot be accepted");
  check(CameraRangeRules.continuous(true,100,1000),"normal continuous tracking remains available");
  check(!CameraRangeRules.plausibleStep(new float[]{0,0,0},new float[]{10,0,0},100),"a relocalization jump cannot become a throw");
  check(CameraRangeRules.plausibleStep(new float[]{0,0,0},new float[]{.2f,0,0},100),"normal walking should remain possible");
  check(!CameraRangeRules.plausibleStep(new float[]{0,0,0},new float[]{Float.NaN,0,0},100),"invalid pose increments must be rejected");
  System.out.println("Native camera measurement rules: "+checks+" checks passed.");
 }
}
