package com.fairwayform.app;
public final class VideoFrameRulesTest {
 private static int checks=0;
 private static void check(boolean ok){checks++;if(!ok)throw new AssertionError("Video rule "+checks);}
 public static void main(String[] args){
  check(VideoFrameRules.keep(0,-1));check(!VideoFrameRules.keep(-1,-1));check(!VideoFrameRules.keep(10000,0));check(VideoFrameRules.keep(16666,0));check(!VideoFrameRules.keep(0,0));check(!VideoFrameRules.keep(100,1000));
  int[] landscape=VideoFrameRules.dimensions(3840,2160);check(landscape[0]==960&&landscape[1]==540);
  int[] portrait=VideoFrameRules.dimensions(1080,1920);check(portrait[0]==540&&portrait[1]==960);
  int[] small=VideoFrameRules.dimensions(320,240);check(small[0]==320&&small[1]==240);
  check(VideoFrameRules.rgb(16,0,0,false,false)==0xff000000);check(VideoFrameRules.rgb(235,0,0,false,false)==0xffffffff);
  check(VideoFrameRules.rgb(0,0,0,true,true)==0xff000000);check(VideoFrameRules.rgb(255,0,0,true,true)==0xffffffff);
  System.out.println("Native video frame rules: "+checks+" checks passed.");
 }
}
