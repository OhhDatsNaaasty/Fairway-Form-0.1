import {test} from 'node:test';
import assert from 'node:assert/strict';
import {sampleVideoFrame} from '../dist/lib/video-frames.js';

function videoCallbacks(){
 let next=0;const callbacks=new Map();
 return {currentTime:0,duration:3.76,readyState:2,seeking:false,callbacks,
  requestVideoFrameCallback(fn){callbacks.set(++next,fn);return next},
  cancelVideoFrameCallback(id){callbacks.delete(id)},
  present(t){const pending=[...callbacks.values()];callbacks.clear();for(const fn of pending)fn(1,{mediaTime:t})}
 };
}
test('the only frame callback may arrive before the seek promise resolves',async()=>{
 const video=videoCallbacks();
 const frame=await sampleVideoFrame(video,async t=>{assert.equal(video.callbacks.size,1);video.currentTime=t;video.present(.3)},.31);
 assert.equal(frame.t,.3);assert.equal(frame.exact,true);assert.equal(video.callbacks.size,0);
});
test('older browser fallback remains labeled approximate',async()=>{
 const video={currentTime:0};const frame=await sampleVideoFrame(video,async t=>video.currentTime=t,.31);
 assert.equal(frame.t,.31);assert.equal(frame.exact,false);
});
test('failed seeks reject even if metadata arrived, and remove callbacks',async()=>{
 const video=videoCallbacks();
 await assert.rejects(sampleVideoFrame(video,async t=>{video.currentTime=t;video.present(t);throw Error('bad clip')},.2),/bad clip/);
 assert.equal(video.callbacks.size,0);
});
test('metadata queued from the old end of the clip is rejected on a backward seek',async()=>{
 const video=videoCallbacks();video.currentTime=3.7;
 const frame=await sampleVideoFrame(video,async t=>{video.present(3.7);video.currentTime=t;video.present(3.3)},3.31);
 assert.equal(frame.t,3.3);assert.equal(frame.exact,true);assert.equal(video.callbacks.size,0);
});
test('metadata while still seeking is rejected, and absent callbacks cannot hang analysis',async()=>{
 const video=videoCallbacks();
 const frame=await sampleVideoFrame(video,async t=>{video.currentTime=t;video.seeking=true;video.present(t);video.seeking=false},.31,{callbackTimeout:5});
 assert.equal(frame.t,.31);assert.equal(frame.exact,false);assert.equal(video.callbacks.size,0);
});
