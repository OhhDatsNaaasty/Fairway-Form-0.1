import {test} from 'node:test';import assert from 'node:assert/strict';
import {reviewMode,displayedObservation,paintAnalysisFrame} from '../dist/lib/analysis-display.js';
import {analyzeVideo} from '../dist/lib/video-analysis.js';
import {createNativeFrameSource} from '../dist/lib/native-video.js';
test('original video is the default even when an older or invalid preference is present',()=>{
 for(const value of [undefined,null,'','native','legacy','bad'])assert.equal(reviewMode(value),'original');assert.equal(reviewMode('prepared'),'prepared');
});
test('an exact displayed frame cannot borrow an 80ms-old or adjacent unmeasured pose',()=>{
 const frames=[{t:1,p:'first'},{t:1.08,p:'next'}];assert.equal(displayedObservation(frames,1),frames[0]);assert.equal(displayedObservation(frames,1.04),null);assert.equal(displayedObservation(frames,1.016667),null);
 assert.equal(displayedObservation(frames,1.01,{exact:false}),frames[0]);
});
test('preview copies source pixels and refuses landmarks belonging to a different timestamp',()=>{
 const canvas={width:0,height:0,dataset:{},getContext:()=>({drawImage:source=>{canvas.pixels=source.pixels}})},source={width:640,height:360,pixels:'source-at-2'},observation={t:2,p:'pose-at-2'};
 const shown=paintAnalysisFrame(canvas,{t:2,source},observation);assert.equal(shown.observation,observation);assert.equal(canvas.pixels,'source-at-2');assert.equal(canvas.dataset.sourceTime,'2');assert.equal(canvas.dataset.observationTime,'2');
 assert.throws(()=>paintAnalysisFrame(canvas,{t:2.08,source},observation),/do not belong/);assert.equal(canvas.dataset.sourceTime,'2');
});
test('body and hand inference publish advancing native images paired with the measured observation',async()=>{
 const times=Array.from({length:31},(_,i)=>i/30),source=createNativeFrameSource({duration:1.02,width:640,height:360,times},{id:'qa-display',loadImage:async url=>({width:640,height:360,index:Number(url.match(/\/(\d+)\.jpg/)[1])})});
 const displayed=[],canvas={width:0,height:0,dataset:{},getContext:()=>({drawImage:image=>{canvas.index=image.index}})};
 const result=await analyzeVideo({video:{duration:1.02},createSampler:()=>source.sampler(),fps:30,detectBody:async image=>({p:{index:image.index}}),prepareHands:async()=>{},detectHand:async image=>({index:image.index}),findRelease:()=>.75,onFrame:info=>{
  const shown=paintAnalysisFrame(canvas,info,info.observation);assert.equal(canvas.index,info.observation.p.index);assert.equal(shown.t,info.observation.t);displayed.push({phase:info.phase,t:info.t,index:canvas.index});
 }});
 const body=displayed.filter(d=>d.phase==='body'),hands=displayed.filter(d=>d.phase==='hands');assert.equal(body.length,result.frames.length);assert.ok(body.length>=30);assert.ok(body.every((d,i)=>!i||d.t>body[i-1].t));assert.ok(hands.length>3);assert.ok(hands.every(d=>d.t>=.5));assert.ok(result.frames.every(f=>!('source' in f)));source.close();
});
