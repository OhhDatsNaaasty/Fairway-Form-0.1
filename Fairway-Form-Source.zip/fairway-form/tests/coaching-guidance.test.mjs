import {test}from'node:test';import assert from'node:assert/strict';
import {explainFinding,makeCoachPlan,summarizeCoaching}from'../dist/lib/coaching-language.js';
import {summaryMarkup,practiceSessionMarkup}from'../dist/lib/report-ui.js';
import {coachingReferences,resourceMarkup}from'../dist/lib/resource-ui.js';
import {filterResources,RESEARCH_RESOURCES,DISC_RESOURCES}from'../dist/lib/research-index.js';
import {COACHING_GUIDES}from'../dist/lib/coaching-guides.js';
import {KNOWLEDGE,SOURCES}from'../dist/lib/knowledge.js';
import {PRACTICE_DRILLS,drillsFor,practiceSession}from'../dist/lib/practice-library.js';
const finding=(id,kind='observe')=>({id,kind,t:.9,title:id,sourceIds:[id]});
const report=(id='brace',kind='attention',options={})=>({release:1.2,estimated:false,findings:[finding(id,kind)],quality:{},options:{type:'backhand',stance:'walkup',...options},metrics:{},phases:[{id:'plant',t:.8,origin:'marked'},{id:'release',t:1.2,origin:'marked'}]});
test('all supported topics have an explanation, action and outcome check without creating a new observation',()=>{
 for(const id of Object.keys(COACHING_GUIDES)){const r=report(id),copy=explainFinding(r.findings[0],r);assert.ok(copy.why.length>100,id);assert.ok(copy.action.length>100,id);assert.ok(copy.check.length>60,id);assert.ok(copy.lessonIds.every(id=>KNOWLEDGE.some(k=>k.id===id)));assert.equal(r.findings[0].kind,'attention')}
});
test('default, detailed and spoken coaching share the same topic and practical comparison',()=>{
 const r=report(),p=makeCoachPlan(r),s=summarizeCoaching(r,p),copy=explainFinding(r.findings[0],r);assert.equal(s.focus.why,copy.why);assert.equal(s.focus.action,copy.action);assert.ok(p.text.includes(copy.why));assert.ok(p.text.includes(copy.action));assert.ok(s.readout.includes(copy.why));assert.ok(s.readout.includes(s.session.check));assert.equal(s.session.id,p.selectedDrill);assert.deepEqual(makeCoachPlan(r),p);
});
test('a positive pattern receives maintenance advice rather than a stock fault explanation',()=>{
 const r=report('arm','positive'),s=summarizeCoaching(r);assert.equal(s.title,'A pattern to keep');assert.match(s.focus.action,/Keep/);assert.doesNotMatch(s.focus.action,/little arm opening/);assert.match(s.focus.observation,/opens/);assert.equal((summaryMarkup(s,r).match(/coach-takeaway keep/g)??[]).length,0);
});
test('observations stay experiments and unknown checks cannot acquire a corrective practice task',()=>{
 const r=report('coil','observe'),s=summarizeCoaching(r);assert.equal(s.keep,null);assert.equal(s.focus.kind,'observe');assert.match(makeCoachPlan(r).text,/optional practice experiment/);
 const unknown=report('brace','unknown'),u=summarizeCoaching(unknown);assert.equal(u.focus,null);assert.equal(u.session,null);assert.doesNotMatch(summaryMarkup(u,unknown),/Practice this next/);
});
test('an estimated but supported posture review links posture instruction rather than release-only help',()=>{
 const r={...report('posture'),estimated:true,quality:{sequence:{supported:true}}},s=summarizeCoaching(r),refs=coachingReferences(s,r);assert.ok(refs.length);assert.ok(!refs.every(s=>s.id==='backhandVideos'));const html=summaryMarkup(s,r);assert.match(html,/shot-plane-practice|study-posture/);assert.doesNotMatch(html,/data-lesson="study-release"/);assert.match(html,/Why it matters/);assert.match(html,/How to tell whether it helped/);assert.match(html,/https:\/\//);
});
test('a weak release estimate still gets a release-specific source and no guessed body correction',()=>{
 const r={...report('arm'),estimated:true,quality:{}},s=summarizeCoaching(r);assert.equal(s.focus,null);assert.ok(coachingReferences(s,r).some(s=>s.id==='backhandVideos'));assert.doesNotMatch(summaryMarkup(s,r),/Practice this next/);
});
test('forehand and putting practice preserve their own setup and do not import a backhand X-step',()=>{
 const r=report('timing','observe',{type:'forehand'}),s=summarizeCoaching(r);assert.equal(s.session.id,'forehand-window');assert.doesNotMatch(s.focus.action,/one-step backhand|back foot crosses/);assert.ok(coachingReferences(s,r).some(s=>/forehand|sidearm/i.test(s.title)));
 const p=practiceSession(drillsFor('finish',{options:{type:'putt'}})[0],{options:{type:'putt'}});assert.match(p.record,/starting distance/i);assert.doesNotMatch(p.progress,/normal approach/);
});
test('recommended practical tasks have distinct goals, a setup, result check and progression',()=>{
 const selected=['timing','arm','coil','brace','posture','finish','wrist'].map(id=>practiceSession(drillsFor(id,report())[0],report()));assert.equal(new Set(selected.map(d=>d.id)).size,selected.length);for(const s of selected){assert.ok(s.steps.length>=3);assert.ok(s.setup&&s.check&&s.record&&s.progress);assert.match(s.basis,/Original app practice/);assert.ok(s.lessons.every(id=>KNOWLEDGE.some(k=>k.id===id)))}
});
test('every registered source is searchable even without an attached lesson, with duplicate URLs combined',()=>{
 for(const [id,s]of Object.entries(SOURCES))assert.ok(RESEARCH_RESOURCES.some(r=>r.url===s.url),id);assert.equal(new Set(RESEARCH_RESOURCES.map(s=>s.url.replace(/\/$/,''))).size,RESEARCH_RESOURCES.length);assert.ok(filterResources({query:'Simon Lizotte'}).some(s=>s.id==='comparisonVideo'));assert.ok(filterResources({query:'force',publisher:'University of Jyväskylä / Finna'}).length);assert.equal(filterResources({query:'zzzz-none'}).length,0);
});
test('all catalog records remain searchable as explicitly dated disc references with their source types',()=>{
 assert.equal(DISC_RESOURCES.length,1092);const pixel=filterResources({view:'discs',query:'Pixel',publisher:'Axiom'});assert.equal(pixel.length,1);assert.match(pixel[0].preview,/speed 2, glide 4/);assert.ok(pixel[0].reviewed);assert.ok(filterResources({view:'discs',query:'flight chart'}).length);assert.ok(DISC_RESOURCES.every(s=>s.title&&s.url.startsWith('https://')&&s.preview));
});
test('source and task markup escapes content, retains provenance and uses valid video chapter links',()=>{
 const source={...SOURCES.walkupVideo,title:'<img src=x>',preview:'<script>bad</script>'},html=resourceMarkup(source,{compact:true});assert.doesNotMatch(html,/<script>|<img src=x>/);assert.match(html,/written tutorial outline/);assert.match(html,/t=125s/);const session=practiceSession(PRACTICE_DRILLS[0]);assert.doesNotMatch(practiceSessionMarkup({...session,name:'<script>bad</script>'}),/<script>/);
});
