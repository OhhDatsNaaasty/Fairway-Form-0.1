import {test} from 'node:test';
import assert from 'node:assert/strict';
import {loadVideoMetadata,seekVideoFrame,createVideoSeeker} from '../dist/lib/video-player.js';
import {sampleVideoFrame} from '../dist/lib/video-frames.js';

class Video extends EventTarget {
 constructor(){super();this.duration=3.76;this.readyState=2;this.seeking=false;this.error=null;this.time=0;this.listeners=new Map();this.requests=[]}
 addEventListener(event,listener,options){super.addEventListener(event,listener,options);if(!this.listeners.has(event))this.listeners.set(event,new Set());this.listeners.get(event).add(listener)}
 removeEventListener(event,listener,options){super.removeEventListener(event,listener,options);this.listeners.get(event)?.delete(listener)}
 get currentTime(){return this.time}
 set currentTime(time){this.time=time;this.seeking=true;this.requests.push(time)}
 complete(event=true){this.seeking=false;this.readyState=2;if(event)this.dispatchEvent(new Event('seeked'))}
 get listenerCount(){return [...this.listeners.values()].reduce((sum,set)=>sum+set.size,0)}
 load(){this.readyState=0;this.seeking=false}
}
const fast={timeout:100,pollInterval:2};
const later=fn=>setTimeout(fn,5);

test('Android frame readiness succeeds when seeked is never emitted',async()=>{
 const video=new Video();const waiting=seekVideoFrame(video,3.48,fast);
 later(()=>video.complete(false));
 assert.equal(await waiting,3.48);assert.equal(video.listenerCount,0);
});
test('a seeked event alone cannot approve a frame that is still seeking',async()=>{
 const video=new Video();const waiting=seekVideoFrame(video,.6,{...fast,timeout:25});
 video.dispatchEvent(new Event('seeked'));
 await assert.rejects(waiting,/frame at 0.60s could not be decoded/);assert.equal(video.listenerCount,0);
});
test('readyState must include image data before inference may start',async()=>{
 const video=new Video();const waiting=seekVideoFrame(video,.6,fast);
 video.seeking=false;video.readyState=1;video.dispatchEvent(new Event('seeked'));
 let finished=false;waiting.then(()=>finished=true);await new Promise(resolve=>setTimeout(resolve,8));assert.equal(finished,false);
 video.readyState=2;await waiting;assert.equal(video.listenerCount,0);
});
test('requesting the existing paused frame never waits for an unnecessary event',async()=>{
 const video=new Video();assert.equal(await seekVideoFrame(video,0,fast),0);assert.equal(video.requests.length,0);assert.equal(video.listenerCount,0);
});
test('a target at the existing playhead still waits if a seek is in progress',async()=>{
 const video=new Video();video.time=.5;video.seeking=true;const waiting=seekVideoFrame(video,.5,fast);later(()=>video.complete());await waiting;assert.equal(video.listenerCount,0);
});
test('seeks clamp outside the clip without seeking to its unplayable exact end',async()=>{
 const video=new Video();const waiting=seekVideoFrame(video,20,fast);assert.equal(video.requests[0],video.duration-.001);video.complete();await waiting;
 const back=seekVideoFrame(video,-2,fast);assert.equal(video.requests.at(-1),0);video.complete();await back;
});
test('a decoder stall never passes stale pixels into the frame sampler',async()=>{
 const video=new Video();let subscribed=false;video.requestVideoFrameCallback=()=>{subscribed=true;return 1};
 await assert.rejects(sampleVideoFrame(video,t=>seekVideoFrame(video,t,{...fast,timeout:20}),1),/frame at 1.00s/);
 assert.equal(subscribed,false);assert.equal(video.listenerCount,0);
});
test('cancel interrupts a waiting decoder and removes its listeners',async()=>{
 const video=new Video(),controller=new AbortController();const waiting=seekVideoFrame(video,1,{...fast,signal:controller.signal});controller.abort();
 await assert.rejects(waiting,{name:'AbortError'});assert.equal(video.listenerCount,0);
});
test('new scrubs supersede pending seeks without approving the older target',async()=>{
 const video=new Video(),seek=createVideoSeeker(video,fast);const first=seek(.2);const rejected=assert.rejects(first,{name:'AbortError'});const second=seek(1.2);
 video.complete();await rejected;assert.equal(await second,1.2);assert.equal(video.listenerCount,0);
});
test('metadata readiness also tolerates a missing metadata event',async()=>{
 const video=new Video();const waiting=loadVideoMetadata(video,'blob:clip',fast);assert.equal(video.src,'blob:clip');later(()=>video.readyState=1);
 await waiting;assert.equal(video.listenerCount,0);
});
test('opening timeouts are distinguished from frame-seek timeouts',async()=>{
 const video=new Video();await assert.rejects(loadVideoMetadata(video,'blob:clip',{...fast,timeout:20}),/video could not open in time/);assert.equal(video.listenerCount,0);
});
test('format advice is reserved for an actual unsupported-format decoder error',async()=>{
 const video=new Video();const waiting=seekVideoFrame(video,.6,fast);video.error={code:4};video.dispatchEvent(new Event('error'));
 await assert.rejects(waiting,/cannot decode this video format/);assert.equal(video.listenerCount,0);
});
test('invalid durations cannot lead to fabricated frame observations',async()=>{
 const video=new Video();video.duration=Infinity;await assert.rejects(seekVideoFrame(video,1,fast),/no usable duration/);assert.equal(video.requests.length,0);
});
