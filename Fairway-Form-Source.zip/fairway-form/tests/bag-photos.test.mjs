import {test} from 'node:test';
import assert from 'node:assert/strict';
import {photoDimensions,validatePersonalPhoto,prepareBagPhoto,MAX_PHOTO_BYTES} from '../dist/lib/bag-photos.js';
const photo={schemaVersion:1,dataUrl:'data:image/jpeg;base64,/9j/2Q==',width:600,height:400,updated:123};
test('large portrait/landscape photos shrink proportionally without upscaling',()=>{
 assert.deepEqual(photoDimensions(4000,3000),{width:960,height:720});assert.deepEqual(photoDimensions(3000,4000),{width:720,height:960});assert.deepEqual(photoDimensions(120,80),{width:120,height:80});assert.throws(()=>photoDimensions(20000,20000),/too large/);
});
test('personal photo metadata round-trips in JSON; old bag copies may have no photo',()=>{
 assert.deepEqual(validatePersonalPhoto(JSON.parse(JSON.stringify(photo))),photo);assert.equal(validatePersonalPhoto(undefined),null);assert.equal(validatePersonalPhoto(null),null);
});
test('external URLs, active image formats, malformed base64 and oversized photos are rejected',()=>{
 for(const dataUrl of ['https://example.com/image.jpg','data:image/svg+xml;base64,PHN2Zz4=','data:image/jpeg;base64,xxxx','data:image/jpeg;base64,/9j/2Q=','data:image/jpeg;base64,/9j/'+('A'.repeat(Math.ceil(MAX_PHOTO_BYTES/3)*4))])assert.throws(()=>validatePersonalPhoto({...photo,dataUrl}),/photo/);
 assert.throws(()=>validatePersonalPhoto({...photo,width:0}),/size/);assert.throws(()=>validatePersonalPhoto({...photo,height:961}),/size/);
});
test('input size/type rejection happens before decoding',async()=>{
 await assert.rejects(prepareBagPhoto({size:31*1024*1024,type:'image/jpeg'}),/30 MB/);await assert.rejects(prepareBagPhoto({size:10,type:'image/svg+xml'}),/JPG/);await assert.rejects(prepareBagPhoto({size:10,type:'text/html'}),/JPG/);
});
test('photo preparation re-encodes bounded pixels, closes the decoded bitmap and drops source metadata',async()=>{
 const saved=new Map(),set=(name,value)=>{saved.set(name,globalThis[name]);globalThis[name]=value};let closed=false,drawn=false,requested='';
 try{
  set('createImageBitmap',async()=>({width:4000,height:3000,close(){closed=true},sourceEXIF:'not copied'}));
  set('document',{createElement:()=>({width:0,height:0,getContext:()=>({fillRect(){},drawImage(){drawn=true}}),toBlob(callback,type){requested=type;callback(new Blob([new Uint8Array([255,216,255,217])],{type}))}})});
  set('FileReader',class{readAsDataURL(){this.result=photo.dataUrl;queueMicrotask(()=>this.onload())}});
  const prepared=await prepareBagPhoto({size:100,type:'image/jpeg'});assert.equal(prepared.width,960);assert.equal(prepared.height,720);assert.equal(requested,'image/jpeg');assert.ok(drawn&&closed);assert.equal(prepared.sourceEXIF,undefined);assert.equal(prepared.dataUrl,photo.dataUrl);
 }finally{for(const [name,value]of saved)if(value===undefined)delete globalThis[name];else globalThis[name]=value;}
});
