import {test} from 'node:test';import assert from 'node:assert/strict';
import {FORM_SOURCE_EDITS,FORM_STUDY_LESSONS,sequenceStudy} from '../dist/lib/form-study.js';
import {KNOWLEDGE,SOURCES} from '../dist/lib/knowledge.js';
import {sequenceStudyMarkup} from '../dist/lib/report-ui.js';
import {filterLessons,lessonMarkup} from '../dist/lib/knowledge-ui.js';
import {createNativeFrameSource} from '../dist/lib/native-video.js';
const report={options:{type:'backhand',markers:{release:1}},phases:[{id:'release',t:1.03,origin:'estimated'},{id:'plant',t:.8,origin:'estimated'}]};
test('reviewed tutorial lessons resolve to source records with explicit access provenance',()=>{
 for(const lesson of FORM_STUDY_LESSONS){assert.ok(KNOWLEDGE.some(k=>k.id===lesson.id));for(const id of lesson.sourceIds)assert.ok(SOURCES[id]?.url.startsWith('https://'))}
 for(const id of Object.keys(FORM_SOURCE_EDITS)){assert.equal(SOURCES[id].reviewed,'2026-10-31');assert.ok(SOURCES[id].evidence)}
 assert.match(SOURCES.postureTranscript.evidence,/transcript.*not verified/);assert.match(SOURCES.xStepChart.evidence,/visually reviewed/);
 assert.ok(filterLessons({query:'disc separation'}).some(k=>k.id==='study-release'));assert.match(lessonMarkup(KNOWLEDGE.find(k=>k.id==='study-posture')),/Publisher transcript reviewed/);
});
test('sequence study uses marked source times ahead of uncertain estimates and never fabricates missing events',()=>{
 const cards=sequenceStudy(report,{frameRef:t=>({t,src:'/__throw_frames/qa/30.jpg'})}),release=cards.find(c=>c.id==='release');assert.equal(release.time,1);assert.equal(release.origin,'marked');assert.equal(release.image.t,1);assert.equal(cards.find(c=>c.id==='reachback').time,null);
 const html=sequenceStudyMarkup(report);assert.match(html,/<details class="sequence-study">/);assert.doesNotMatch(html,/<details class="sequence-study" open/);assert.match(html,/data-study-time="1"/);assert.match(html,/data-lesson="study-release"/);assert.match(html,/Not found/);
});
test('only nearby images from the private native cache may be shown as user source frames',()=>{
 for(const value of [{t:1,src:'https://example.com/pro.jpg'},{t:1.5,src:'/__throw_frames/qa/30.jpg'},{t:1,src:'/__throw_frames/../30.jpg'}])assert.equal(sequenceStudy(report,{frameRef:()=>value}).find(c=>c.id==='release').image,null);
 const source=createNativeFrameSource({duration:1.1,width:320,height:180,times:[0,.5,1]},{id:'qa-source'});
 const html=sequenceStudyMarkup(report,{frameRef:t=>source.frameRef(t)});assert.match(html,/Your video · 1.00s/);assert.match(html,/src="\/__throw_frames\/qa-source\/2.jpg"/);source.close();assert.equal(source.frameRef(1),null);
});
test('forehand study does not inherit the backhand crossover or power-pocket cards',()=>{
 const cards=sequenceStudy({...report,options:{type:'forehand'}});assert.ok(!cards.some(c=>['crossover','pocket'].includes(c.id)));assert.ok(cards.every(c=>c.lessonId==='study-forehand'));
});
