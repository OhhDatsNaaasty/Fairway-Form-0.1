import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parseSignText,markedRoute} from '../dist/lib/caddy-sign.js';
import {confirmedSignSetup} from '../dist/lib/sign-setup.js';
import {analyzeSignDiagram,diagramShape,signLabelCandidates} from '../dist/lib/sign-diagram.js';
import {photoPoint,moveSignMarker,setupSignMarkers,paintSignOverlay} from '../dist/lib/sign-markers.js';

// Literal transcriptions of user examples. These test parsing, not ML Kit OCR.
const screenshot='Anna Page Park - West\nWhite baskets\nPar 57 189 Holes 18 Long\n18\n1\nHole 1\nPar 3\n297 ft\nOB - on parking lot, bathrooms or shelter Pavement\nOverview\n1 2 3\nHome Courses Play You';
const physical='Belvidere\nDiscGolfPark\n#1\nPar 3\n255 ft\nPlease let the group in front of you finish the hole before you begin to tee off.';
test('selected-hole screenshot keeps course total separate and retains written OB',()=>{
 const p=parseSignText(screenshot);assert.equal(p.courseName,'Anna Page Park - West');assert.equal(p.hole,'1');assert.equal(p.par,3);assert.deepEqual(p.distances.map(d=>d.feet),[297]);assert.deepEqual(p.ruleNotes,['OB - on parking lot, bathrooms or shelter Pavement']);assert.equal(p.hazard,null);
});
test('physical sign recognizes hash number and split designer course heading',()=>{
 const p=parseSignText(physical);assert.equal(p.courseName,'Belvidere DiscGolfPark');assert.equal(p.hole,'1');assert.equal(p.par,3);assert.equal(p.distances[0].feet,255);
});
test('two different hole cards require selection and parse only the selected card',()=>{
 const text='Example Park\nHole 1 Par 3\n297 ft\nOB on pavement\n\nHole 2 Par 4\n120 m\nDogleg right';const both=parseSignText(text);assert.equal(both.hole,null);assert.throws(()=>confirmedSignSetup(both,null),/Several holes/);const p=parseSignText(text,{selectedHole:2});assert.equal(p.par,4);assert.equal(p.distances.length,1);assert.equal(p.distances[0].unit,'m');assert.deepEqual(p.ruleNotes,[]);assert.equal(p.fairway,'right');
});
test('two endpoints apply straight, preserving explicit distance and uncertain hazard side',()=>{
 const route=markedRoute({tee:{x:.5,y:.8},basket:{x:.5,y:.2}},{aspect:.45}),result=confirmedSignSetup(parseSignText(screenshot),route,{draft:{distanceFt:400,hazard:'none',layoutNotes:'Keep current note'}});assert.equal(result.draft.distanceFt,297);assert.equal(result.draft.fairway,'straight');assert.equal(result.draft.hazard,'none');assert.match(result.draft.layoutNotes,/Keep current note\nOB/);assert.equal(result.courseName,'Anna Page Park - West');assert.equal(result.par,3);
});
test('reapplying a sign does not duplicate rules or erase unrelated setup fields',()=>{
 const p=parseSignText(screenshot),a=confirmedSignSetup(p,null,{draft:{bearing:82,windMph:7}}),b=confirmedSignSetup(p,null,a);assert.equal(b.draft.layoutNotes,a.draft.layoutNotes);assert.equal(b.draft.bearing,82);assert.equal(b.draft.windMph,7);
});
test('written dogleg wins over automatic pixel guesses; corrected markers can override it',()=>{
 const p=parseSignText('Hole 1 Par 3 297 ft Dogleg right');assert.equal(confirmedSignSetup(p,{fairway:'left'}).draft.fairway,'right');assert.equal(confirmedSignSetup(p,{fairway:'left',origin:'markers'}).draft.fairway,'left');assert.equal(confirmedSignSetup(parseSignText('wooded'),{fairway:'right'}).draft.fairway,'right');
});
test('a multi-layout sign requires distance/par confirmation and protects an in-progress hole',()=>{
 const p=parseSignText('Hole 2 Blue 300 ft Red 200 ft Par 3 Par 4');assert.throws(()=>confirmedSignSetup(p,null),/distance/);assert.throws(()=>confirmedSignSetup(p,null,{distanceIndex:0}),/par/);assert.equal(confirmedSignSetup(p,null,{distanceIndex:1,parChoice:4}).par,4);assert.throws(()=>confirmedSignSetup(p,null,{holeNumber:1,throws:1}),/different hole/);
});
test('layout headers are choices, not spatial basket anchors',()=>{
 const c=signLabelCandidates([{text:'White baskets',box:{x:.1,y:.1,width:.4,height:.05}},{text:'Tee',box:{x:.3,y:.8,width:.1,height:.03}}]);assert.equal(c.baskets[0].layoutOnly,true);assert.equal(c.baskets[0].x,undefined);assert.ok(c.tees[0].x>.3);
});
test('physical image aspect keeps a shallow bend shallow on a tall screenshot',()=>{
 const p=[{x:.3,y:.9},{x:.3,y:.5},{x:.6,y:.2}];assert.equal(diagramShape(p,{aspect:.4}).fairway,'slight-right');assert.equal(diagramShape(p,{aspect:2}).fairway,'right');
});

// Original synthetic diagrams; no third-party map artwork is redistributed.
function pixels(width=240,height=360,color=[16,40,34]){
 const data=new Uint8ClampedArray(width*height*4);for(let i=0;i<data.length;i+=4)data.set([...color,255],i);
 const rect=(x,y,w,h,c)=>{for(let yy=Math.max(0,Math.floor(y));yy<Math.min(height,y+h);yy++)for(let xx=Math.max(0,Math.floor(x));xx<Math.min(width,x+w);xx++)data.set([...c,255],(yy*width+xx)*4)};
 const stroke=(points,c=[190,190,190],thickness=2,dashed=false)=>{let total=0;for(let j=1;j<points.length;j++){const a=points[j-1],b=points[j],steps=Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1]));for(let i=0;i<=steps;i++){if(!dashed||Math.floor((total+i)/6)%2===0)rect(a[0]+(b[0]-a[0])*i/steps,a[1]+(b[1]-a[1])*i/steps,thickness,thickness,c)}total+=steps}};
 const basket=(x,y)=>{const c=[245,245,245];rect(x-7,y-14,14,12,c);rect(x-2,y-2,4,7,c);rect(x-9,y+5,18,4,c);rect(x-2,y+9,4,7,c)};
 return {width,height,data,rect,stroke,basket};
}
test('aerial-style neutral route and basket/tee shapes yield usable endpoints',()=>{
 const p=pixels();p.stroke([[90,305],[90,170],[150,70]]);p.rect(85,307,11,14,[200,200,200]);p.basket(150,48);const r=analyzeSignDiagram(p);assert.ok(r.points);assert.ok(r.points.tee.y>.75);assert.ok(r.points.basket.y<.25);assert.equal(r.fairway,'slight-right');assert.equal(r.directionConfirmed,false);
});
test('disconnected dashed centerline on a green schematic is joined into a route',()=>{
 const p=pixels(240,360,[44,150,54]);p.stroke([[100,310],[100,180],[165,100]],[15,15,15],2,true);const r=analyzeSignDiagram(p);assert.ok(r.points);assert.ok(r.points.tee.y>.75);assert.ok(r.points.basket.y<.4);assert.equal(r.fairway,'right');
});
test('explicit label anchors disambiguate an adjacent fairway and orient the selected route',()=>{
 const p=pixels();p.stroke([[65,310],[65,60]]);p.stroke([[170,320],[170,40]]);const r=analyzeSignDiagram(p,{tee:{x:65/240,y:310/360},basket:{x:65/240,y:60/360}});assert.ok(Math.abs(r.points.tee.x-65/240)<.04);assert.equal(r.directionConfirmed,true);
});
test('a decorative border does not become a fairway',()=>{
 const p=pixels();p.rect(0,0,240,2,[240,240,240]);p.rect(0,0,2,360,[240,240,240]);p.rect(238,0,2,360,[240,240,240]);p.rect(0,358,240,2,[240,240,240]);assert.equal(analyzeSignDiagram(p).fairway,null);
});
test('a multi-hole overview without an active-route anchor asks rather than choosing arbitrarily',()=>{
 const p=pixels();p.stroke([[65,310],[65,60]]);p.stroke([[170,320],[170,40]]);const lines=[1,2,3,4].map((n,i)=>({text:String(n),box:{x:.8,y:.2+i*.1,width:.05,height:.03}}));const r=analyzeSignDiagram(p,{lines});assert.equal(r.points,null);assert.match(r.message,/course overview/);
});

function markerFixture(onChange=()=>{}){
 const stage=new EventTarget();stage.getBoundingClientRect=()=>({left:20,top:40,width:300,height:600});stage.setPointerCapture=id=>stage.captured=id;stage.releasePointerCapture=id=>stage.released=id;
 let sign={imageAspect:.5,points:{tee:{x:.2,y:.8},bend:{x:.2,y:.5},bend2:{x:.6,y:.5},basket:{x:.6,y:.2}}},identity='hole1',mode=null,commits=0;
 const cleanup=setupSignMarkers({element:stage,getSign:()=>sign,getIdentity:()=>identity,getMode:()=>mode,setMode:v=>mode=v,onChange:v=>{sign=v;onChange(v)},onCommit:()=>commits++});
 const send=(type,x,y,more={})=>{const e=new Event(type,{cancelable:true});Object.assign(e,{clientX:20+x*300,clientY:40+y*600,pointerId:1,button:0,...more});stage.dispatchEvent(e)};
 return {stage,send,cleanup,get sign(){return sign},get commits(){return commits},set identity(v){identity=v},set mode(v){mode=v}};
}
for(const name of ['tee','bend','bend2','basket'])test('existing '+name+' drags without a placement button and commits once',()=>{
 const f=markerFixture(),p=f.sign.points[name];f.send('pointerdown',p.x,p.y);f.send('pointermove',.4,.4);f.send('pointerup',.45,.42);assert.equal(f.sign.points[name].x,.45);assert.equal(f.sign.pointsSource,'manual');assert.equal(f.commits,1);assert.equal(f.stage.captured,1);assert.equal(f.stage.released,1);f.cleanup();
});
test('cancelled drag restores the previous route, without committing it',()=>{
 const f=markerFixture(),before=f.sign;f.send('pointerdown',.2,.8);f.send('pointermove',.4,.4);f.send('pointercancel',.4,.4);assert.equal(f.sign,before);assert.equal(f.commits,0);f.cleanup();
});
test('late drag events cannot write into a new hole/image',()=>{
 const f=markerFixture();f.send('pointerdown',.2,.8);f.identity='hole2';const before=f.sign;f.send('pointermove',.9,.9);f.send('pointerup',.9,.9);assert.equal(f.sign,before);assert.equal(f.commits,0);f.cleanup();
});
test('new marker placement and boundary clamping share the drag workflow',()=>{
 const f=markerFixture();f.mode='bend';f.send('pointerdown',.5,.5);f.send('pointerup',2,-1);assert.equal(f.sign.points.bend.x,1);assert.equal(f.sign.points.bend.y,0);assert.equal(f.commits,1);assert.deepEqual(photoPoint({clientX:0,clientY:0},{left:10,top:10,width:20,height:20}),{x:0,y:0});f.cleanup();
});
test('keyboard movement supports fine marker correction and updates the shape',()=>{
 const f=markerFixture(),e=new Event('keydown',{cancelable:true});Object.defineProperty(e,'target',{value:{dataset:{marker:'basket'}}});Object.assign(e,{key:'ArrowRight',shiftKey:true});f.stage.dispatchEvent(e);assert.equal(f.sign.points.basket.x,.62);assert.equal(f.commits,1);f.cleanup();
});
test('moving a marker discards stale auto trace without mutating the saved original',()=>{
 const original={points:{tee:{x:.2,y:.8},basket:{x:.5,y:.2}},trace:[{x:.9,y:.9}],pointsSource:'automatic'},next=moveSignMarker(original,'basket',{x:.3,y:.1});assert.equal(original.points.basket.x,.5);assert.deepEqual(next.trace,[]);assert.equal(next.diagram.origin,'markers');
});

test('hole-layout sources and original summaries are searchable in the offline library',async()=>{
 const {HOLE_SIGN_SOURCES,HOLE_SIGN_LESSONS}=await import('../dist/lib/hole-sign-research.js'),{SOURCES,KNOWLEDGE}=await import('../dist/lib/knowledge.js'),{filterResources}=await import('../dist/lib/research-index.js');
 for(const [id,s]of Object.entries(HOLE_SIGN_SOURCES)){assert.equal(SOURCES[id].url,s.url);assert.ok(s.preview.length>220);assert.equal(s.reviewed,'2026-11-02');assert.ok(s.evidence.length>30);assert.ok(filterResources({query:id}).some(r=>r.aliases.includes(id)))}
 for(const lesson of HOLE_SIGN_LESSONS)assert.ok(KNOWLEDGE.some(k=>k.id===lesson.id&&k.sourceIds.every(id=>SOURCES[id])));
 assert.ok(filterResources({query:'aerial'}).some(s=>s.id==='signOmahaBook'));
});

// A small SVG-node test double: a rewrite fails immediately, so movement and
// cancellation must retain the active event target rather than merely its HTML.
function overlayFixture(){
 const attrs=()=>({values:{},setAttribute(k,v){this.values[k]=String(v)},getAttribute(k){return this.values[k]}}),stroke=attrs(),groups=new Map(),overlay={...attrs(),querySelector(selector){if(selector==='[data-sign-path]')return stroke;return groups.get(selector.match(/data-marker="([^"]+)"/)?.[1])??null},querySelectorAll(){return [...groups.values()]},insertAdjacentHTML(where,html){add(html.match(/data-marker="([^"]+)"/)[1])},set innerHTML(value){throw Error('Live SVG handles must not be replaced during pointer capture')}};
 function add(name){const hit=attrs(),dot=attrs(),text=attrs(),g={dataset:{marker:name},isConnected:true,querySelector:s=>s==='.sign-marker-hit'?hit:s==='.sign-marker-dot'?dot:text,remove(){groups.delete(name);g.isConnected=false}};groups.set(name,g);return g}
 for(const name of ['tee','bend','bend2','basket'])add(name);return {overlay,groups,stroke};
}
test('real renderer updates during a captured drag keep every SVG handle connected',()=>{
 const {overlay,groups}=overlayFixture(),original=[...groups.values()],f=markerFixture(sign=>paintSignOverlay(overlay,{points:sign.points,aspect:.5,width:300}));f.send('pointerdown',.2,.8);f.send('pointermove',.4,.4);f.send('pointerup',.45,.42);assert.deepEqual([...groups.values()],original);assert.ok(original.every(g=>g.isConnected));assert.equal(groups.get('tee').querySelector('.sign-marker-dot').getAttribute('cx'),'450');assert.equal(f.commits,1);f.cleanup();
});
test('cancel restores displayed coordinates without recreating a focused/captured handle',()=>{
 const {overlay,groups}=overlayFixture(),tee=groups.get('tee'),f=markerFixture(sign=>paintSignOverlay(overlay,{points:sign.points,aspect:.5,width:300}));f.send('pointerdown',.2,.8);f.send('pointermove',.4,.4);f.send('pointercancel',.4,.4);assert.equal(groups.get('tee'),tee);assert.equal(tee.querySelector('.sign-marker-dot').getAttribute('cx'),'200');assert.equal(tee.querySelector('.sign-marker-dot').getAttribute('cy'),'1600');assert.equal(f.commits,0);f.cleanup();
});
test('resizing/removing another point preserves the remaining handle identities and round geometry',()=>{
 const {overlay,groups}=overlayFixture(),tee=groups.get('tee');paintSignOverlay(overlay,{points:{tee:{x:.2,y:.8},basket:{x:.6,y:.2}},aspect:.5,width:250});assert.equal(groups.get('tee'),tee);assert.equal(groups.has('bend'),false);assert.equal(overlay.values.viewBox,'0 0 1000 2000');assert.equal(tee.querySelector('.sign-marker-dot').getAttribute('r'),'40');assert.equal(tee.querySelector('.sign-marker-hit').getAttribute('r'),'112');
});
