import {test} from 'node:test';
import assert from 'node:assert/strict';
import {treeImage} from './fixtures/tree-images.mjs';
import {scanTreeSymbols} from '../dist/lib/sign-corridor.js';
import {scanMapCanopies,editImageTree} from '../dist/lib/tree-vision.js';
import {analyzeSignDiagram} from '../dist/lib/sign-diagram.js';
import {confirmedSignDiagram,normalizeSignDiagram,buildSignScene,signReviewFromDiagram} from '../dist/lib/sign-scene.js';
import {sceneForRound,normalizeLayoutArt} from '../dist/lib/layout-art.js';
import {holeSceneSVG} from '../dist/lib/hole-scene.js';
import {setupSignMarkers} from '../dist/lib/sign-markers.js';
const near=(a,b,tol=4)=>Math.hypot(a.x-b.x,a.y-b.y)<tol;
const route=[{x:.5,y:.9},{x:.5,y:.1}];
test('sign trees retain small and large crowns, dark star-shaped pine and cropped edge crowns',()=>{
 const img=treeImage(),trees=scanTreeSymbols(img);assert.equal(trees.length,img.expected.length);for(const p of img.expected){const t=trees.find(t=>near({x:t.x*img.width,y:t.y*img.height},p));assert.ok(t,'missing tree '+JSON.stringify(p));if(p.x>20)assert.ok(Math.abs(t.radiusY*img.height-p.r)<p.r*.4);assert.equal(t.treeType,p.type)}
});
test('satellite mode finds centers of isolated textured canopies beside the active route',()=>{
 const img=treeImage('satellite'),options={tee:route[0],basket:route[1]},trees=scanMapCanopies(img,options);for(const p of img.expected)assert.ok(trees.some(t=>near({x:t.x*img.width,y:t.y*img.height},p,7)),'missing canopy '+JSON.stringify(p));assert.ok(trees.every(t=>t.treeType==='unknown'));assert.deepEqual(scanMapCanopies(img),[]);
 const r=analyzeSignDiagram(img,{...options,imageKind:'satellite'});assert.deepEqual(r.points,options);assert.deepEqual(r.trees,trees);
});
test('satellite scan ignores UI outside the active route, masked labels and uniform lawns',()=>{
 const img=treeImage('satellite'),options={tee:route[0],basket:route[1]},before=img.data.slice();const p=img.expected[0],trees=scanMapCanopies(img,{...options,lines:[{box:{x:(p.x-25)/img.width,y:(p.y-25)/img.height,width:50/img.width,height:50/img.height}}]});assert.ok(!trees.some(t=>near({x:t.x*img.width,y:t.y*img.height},p,10)));assert.deepEqual(img.data,before);
 for(let i=0;i<img.data.length;i+=4)img.data.set([50,120,60,255],i);assert.equal(scanMapCanopies(img,options).length,0);
});
test('tree shape and proportional radius survive confirmation, course artwork and JSON restore',()=>{
 const sign={imageAspect:.8,imageKind:'satellite',points:{tee:route[0],basket:route[1]},pointsSource:'manual',visual:{trees:[{x:.4,y:.6,radius:.02,treeType:'round'},{x:.6,y:.4,radius:.04,treeType:'pine'}]}},d=confirmedSignDiagram(sign),a=normalizeLayoutArt(JSON.parse(JSON.stringify({signDiagram:d}))),s=buildSignScene(a.signDiagram,300);assert.equal(d.imageKind,'satellite');assert.equal(s.features[1].treeType,'pine');assert.equal(s.features[1].symbolRadius/s.features[0].symbolRadius,2);const reopened=signReviewFromDiagram(d);assert.deepEqual(confirmedSignDiagram(reopened),d);
 const scene=sceneForRound({layoutArt:a},{distanceFt:300,fairway:'straight'}),svg=holeSceneSVG(scene,{tilt:90});assert.match(svg,/data-tree-type="pine"/);assert.match(svg,/data-canopy-radius="13.1"/);assert.match(svg,/data-canopy-radius="6.55"/);assert.equal(normalizeSignDiagram({...d,trees:[{x:.5,y:.5,treeType:'<script>'}]}).trees[0].treeType,'unknown');
});
test('adding, editing and deleting image trees preserves the route and other crowns',()=>{
 let sign={imageAspect:1,points:{tee:route[0],basket:route[1]},visual:{trees:[{x:.3,y:.4,radius:.03,treeType:'round'}]}},before=structuredClone(sign);sign=editImageTree(sign,1,{x:.6,y:.7,treeType:'pine'});assert.equal(sign.visual.trees.length,2);assert.equal(sign.visual.trees[1].radius,.018);sign=editImageTree(sign,1,{radius:.06,x:.65});assert.equal(sign.visual.trees[1].treeType,'pine');assert.equal(sign.visual.trees[1].radius,.06);sign=editImageTree(sign,0,null);assert.equal(sign.visual.trees.length,1);assert.deepEqual(sign.points,before.points);assert.equal(before.visual.trees.length,1);assert.equal(editImageTree(sign,0,{x:2}),sign);
});
test('tree editing captures vertical drags, supports cancellation and does not move route markers',()=>{
 const element=new EventTarget();element.style={};element.setPointerCapture=()=>{};element.releasePointerCapture=()=>{};let sign={imageAspect:1,points:{tee:route[0],basket:route[1]},visual:{trees:[{x:.3,y:.4,radius:.02,treeType:'pine'}]}},selected=-1,commits=0;const original=structuredClone(sign),off=setupSignMarkers({element,getSign:()=>sign,getMode:()=>'tree',getBounds:()=>({left:0,top:0,width:300,height:300}),onChange:s=>sign=s,onTreeSelect:i=>selected=i,onCommit:()=>commits++});
 const send=(type,x,y)=>{const e=new Event(type,{cancelable:true});Object.assign(e,{pointerId:1,clientX:x,clientY:y,button:0,isPrimary:true});element.dispatchEvent(e);assert.ok(e.defaultPrevented||type==='pointercancel')};send('pointerdown',90,120);send('pointermove',90,180);send('pointerup',90,180);assert.equal(selected,0);assert.equal(commits,1);assert.equal(sign.visual.trees[0].y,.6);assert.equal(sign.visual.trees[0].treeType,'pine');assert.deepEqual(sign.points,original.points);const before=sign;send('pointerdown',90,180);send('pointermove',120,200);send('pointercancel',120,200);assert.deepEqual(sign,before);off();
});

test('moving an image tree with the existing 3D feature editor retains its shape and canopy scale',()=>{
 const d={version:1,aspect:1,confirmed:true,route,trees:[{x:.6,y:.5,radius:.04,treeType:'pine'}]},scene=sceneForRound({layoutArt:{signDiagram:d}},{distanceFt:300,fairway:'straight'}),f=scene.features[0],art=normalizeLayoutArt({signDiagram:d,featureEdits:{[f.id]:{...f,alongFt:100,lateralFt:25}}}),restored=sceneForRound({layoutArt:art},{distanceFt:300,fairway:'straight'}),tree=restored.features.find(t=>t.id===f.id);assert.equal(tree.treeType,'pine');assert.equal(tree.symbolRadius,f.symbolRadius);assert.equal(tree.alongFt,100);
});
