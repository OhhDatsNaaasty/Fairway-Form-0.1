import {test} from 'node:test';import assert from 'node:assert/strict';
import {createPlaybackSeeker,createPresentedFrameClock} from '../dist/lib/video-preview.js';
const gate=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve}};
test('a completed paused seek keeps original video and does not allocate a recovery sampler',async()=>{
 const shown=[],pending=[];const seek=createPlaybackSeeker({}, {seek:async()=>1,onVideo:t=>shown.push(t),makeSampler:()=>{throw Error('not needed')},onPending:p=>pending.push(p)});
 assert.equal(await seek(1),1);assert.deepEqual(shown,[1]);assert.deepEqual(pending,[true,false]);
});
test('a stuck paused seek runs original playback and shows actual decoded time before disposing its image',async()=>{
 let closed=false;const shown=[];
 const seek=createPlaybackSeeker({}, {seek:async()=>{throw Error('paused seek stalled')},makeSampler:({timeout})=>{assert.ok(timeout<=5000);return {sample:async()=>({t:68/30,source:'decoded-original'}),close(){closed=true}}},onFrozen:frame=>{assert.equal(closed,false);shown.push(frame)}});
 assert.equal(await seek(2.28),68/30);assert.deepEqual(shown,[{t:68/30,source:'decoded-original'}]);assert.equal(closed,true);
});
test('rapid scrubbing cancels the old recovery and cannot repaint over the later source image',async()=>{
 const requests=[],shown=[];
 const seek=createPlaybackSeeker({}, {seek:async()=>{throw Error('paused seek stalled')},makeSampler:({signal})=>({sample:async t=>{const g=gate();requests.push({...g,t,signal});return g.promise},close(){}}),onFrozen:f=>shown.push(f.t)});
 const first=seek(1);await new Promise(r=>setTimeout(r,0));const firstRejected=assert.rejects(first,{name:'AbortError'});const next=seek(2);await new Promise(r=>setTimeout(r,0));
 assert.equal(requests[0].signal.aborted,true);requests[1].resolve({t:2,source:{}});await next;requests[0].resolve({t:1,source:{}});await firstRejected;assert.deepEqual(shown,[2]);
});
test('cancellation blocks recovery and unsupported samplers retain an explicit failure',async()=>{
 const controller=new AbortController();controller.abort();let samples=0;
 const seek=createPlaybackSeeker({}, {seek:async()=>{throw Error('source not decoded')},makeSampler:()=>{samples++;return null}});
 await assert.rejects(seek(1,{signal:controller.signal}),{name:'AbortError'});assert.equal(samples,0);await assert.rejects(seek(1),/source not decoded/);assert.equal(samples,1);
});
test('presented-frame clock uses decoder timestamps and ignores callbacks from a replaced clip',()=>{
 const callbacks=new Map(),removed=[],seen=[];let id=0;
 const video={requestVideoFrameCallback(fn){callbacks.set(++id,fn);return id},cancelVideoFrameCallback(i){removed.push(i);callbacks.delete(i)}};
 const clock=createPresentedFrameClock(video,t=>seen.push(t));const old=callbacks.get(1);callbacks.delete(1);old(0,{mediaTime:.5});assert.equal(clock.time,.5);const stale=callbacks.get(2);clock.reset();stale(0,{mediaTime:9});assert.equal(clock.time,null);
 const current=callbacks.get(3);callbacks.delete(3);current(0,{mediaTime:.1});assert.equal(clock.time,.1);assert.deepEqual(seen,[.5,.1]);clock.close();assert.equal(callbacks.size,0);assert.ok(removed.length>=2);
});
test('a stale callback cannot erase the current frame subscription before closing',()=>{
 const callbacks=new Map();let id=0;const video={requestVideoFrameCallback(fn){callbacks.set(++id,fn);return id},cancelVideoFrameCallback(i){callbacks.delete(i)}};
 const clock=createPresentedFrameClock(video),old=callbacks.get(1);clock.reset();old(0,{mediaTime:9});clock.close();assert.equal(callbacks.size,0);
});
