import {test} from 'node:test';import assert from 'node:assert/strict';
import {angle,lean,nearestFrame,review} from '../dist/lib/analysis.js';
const point=(x,y,v=1)=>({x,y,visibility:v});
function pose(t=0,hand='right'){const p=Array.from({length:33},()=>point(.5,.5));p[11]=point(.4,.3);p[12]=point(.6,.3);p[23]=point(.43,.65);p[24]=point(.57,.65);let s=hand==='right'?12:11;p[s+2]=point(.65,.4);p[s+4]=point(.65+t*.2,.55-t*.15);return p}
test('angle corrects for image aspect ratio',()=>{assert.equal(Math.round(angle(point(0,0),point(0,1),point(1,1),2)),90);assert.equal(Math.round(angle(point(.5,0),point(0,0),point(.5,1),2)),45)});
test('rejects hidden landmarks and degenerate angles',()=>{assert.equal(angle(point(0,0,.2),point(0,1),point(1,1)),null);assert.equal(angle(point(0,0),point(0,0),point(1,1)),null)});
test('torso vertical has zero lean',()=>assert.equal(lean(pose(),1),0));
test('overlay never borrows pose from distant frame',()=>{assert.equal(nearestFrame([{t:0,p:pose()}],2),null);assert.equal(nearestFrame([{t:0,p:pose()}],.04).t,0)});
test('insufficient or occluded footage yields no invented review',()=>{const r=review([{t:0,p:null}]);assert.equal(r.findings.length,0);assert.equal(r.release,null);assert.match(r.summary,/Not enough/)});
test('manual release anchors evidence, including for left hand',()=>{const frames=Array.from({length:20},(_,i)=>({t:i/15,p:pose(i/15,'left')}));const r=review(frames,{hand:'left',releaseTime:.6,aspect:1.5,type:'forehand'});assert.equal(r.release,.6);assert.equal(r.estimated,false);assert.equal(r.coverage,1);assert.ok(r.metrics.elbow>0);assert.ok(r.findings.every(f=>f.kind==='unknown'?f.t===null:frames.some(x=>x.t===f.t)));assert.ok(r.findings.every(f=>!f.title.includes('score')))});
test('unseen marked release cannot fabricate a measurement',()=>{const frames=Array.from({length:12},(_,i)=>({t:i/15,p:pose(i/15)}));const r=review(frames,{releaseTime:4});assert.equal(r.release,null);assert.equal(r.findings.length,0)});
test('stationary frames cannot invent peak hand motion',()=>{const frames=Array.from({length:12},(_,i)=>({t:i/15,p:pose()}));assert.equal(review(frames).release,null)});
