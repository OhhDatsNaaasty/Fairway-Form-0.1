import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {normalizePlayer} from '../dist/lib/player-profile.js';
import {makeHole} from '../dist/lib/caddy.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../dist');
const html=await fs.readFile(path.join(root,'index.html'),'utf8');
const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});return {promise,resolve,reject}};
class Element extends EventTarget{
 constructor(){super();this._value='';this.textContent='';this.innerHTML='';this.dataset={};this.attrs={};this.inert=false;this.hidden=false;this.classList={add(){},remove(){},toggle(){}}}
 get value(){return this._value}set value(value){this._value=String(value)}
 setAttribute(key,value){this.attrs[key]=String(value)}
 removeAttribute(key){delete this.attrs[key]}
 querySelectorAll(){return []}
}
async function fixture({saved=[],player=normalizePlayer({maxSpeed:9,comfortablePuttFt:25}),waitAt='catalog',bagCopies=[]}={}){
 const elements=new Map([...html.matchAll(/\bid="([\w-]+)"/g)].map(m=>[m[1],new Element()]));
 const el=id=>{assert.ok(elements.has(id),'Unknown control '+id);return elements.get(id)};
 // These preloaded labels caused the old browser check to pass before initialization.
 el('caddyLie').textContent='THROW 1 · TEE';el('caddy').hidden=false;
 const document=new EventTarget();document.getElementById=el;document.hidden=false;
 const window=new EventTarget(),gate=deferred();let held=true,fail=false;const persisted=saved.map(h=>structuredClone(h));
 async function hold(at){if(held&&waitAt===at){held=false;await gate.promise}if(fail)throw Error('QA storage unavailable')}
 const storage={listBag:async()=>{await hold('bag');return structuredClone(bagCopies)},listCatalog:async()=>{await hold('catalog');return []},getPlayer:async()=>{await hold('player');return player},listPlayerSessions:async()=>[],listCaddyHoles:async()=>{await hold('holes');return structuredClone(persisted)},storeCaddyHole:async h=>{await hold('save');const i=persisted.findIndex(v=>v.id===h.id);if(i>=0)persisted[i]=structuredClone(h);else persisted.push(structuredClone(h))}};
 const context=vm.createContext({document,window,localStorage:{getItem:()=>null,setItem(){}},crypto:globalThis.crypto,structuredClone,URL,Blob,console,setTimeout,clearTimeout,Event,CustomEvent});
 const modules=new Map();
 function module(file){
  if(modules.has(file))return modules.get(file);
  const m=file===path.join(root,'lib/storage.js')?new vm.SyntheticModule(Object.keys(storage),function(){for(const [key,value]of Object.entries(storage))this.setExport(key,value)},{context,identifier:file}):new vm.SourceTextModule(code.get(file),{context,identifier:file});modules.set(file,m);return m;
 }
 const code=new Map();for(const name of await fs.readdir(path.join(root,'lib')))if(name.endsWith('.js')){const file=path.join(root,'lib',name);code.set(file,await fs.readFile(file,'utf8'))}
 const entry=module(path.join(root,'lib/caddy-ui.js'));await entry.link((specifier,parent)=>module(path.resolve(path.dirname(parent.identifier),specifier)));await entry.evaluate();
 entry.namespace.setupCaddy({notify(){},download(){}});
 return {el,document,render:entry.namespace.renderCaddy,gate,persisted,fail:value=>{fail=value}};
}

test('a visible Throw 1 placeholder is not readiness while profile and hole storage are delayed',async()=>{
 const f=await fixture(),opening=f.render();
 assert.equal(f.el('caddyLie').textContent,'THROW 1 · TEE');assert.equal(f.el('caddyPuttRange').value,'');
 assert.equal(f.el('caddy').dataset.state,'loading');assert.equal(f.el('caddyWorkspace').inert,true);
 f.gate.resolve();await opening;
 assert.equal(f.el('caddy').dataset.state,'ready');assert.equal(f.el('caddyWorkspace').inert,false);assert.equal(f.el('caddy').attrs['aria-busy'],'false');
 assert.equal(f.el('caddyPuttRange').value,'25');assert.equal(f.el('caddyMaxSpeed').value,'9');assert.equal(f.persisted.length,1);assert.equal(f.persisted[0].draft.maxSpeed,9);
});
test('readiness waits through the player read, rather than only the bag read',async()=>{
 const f=await fixture({waitAt:'player'}),opening=f.render();await new Promise(resolve=>setImmediate(resolve));
 assert.equal(f.el('caddy').dataset.state,'loading');assert.equal(f.el('caddyWorkspace').inert,true);f.gate.resolve();await opening;assert.equal(f.el('caddyMaxSpeed').value,'9');assert.equal(f.el('caddy').dataset.state,'ready');
});
test('resuming an existing hole preserves explicit per-lie limits',async()=>{
 const hole=makeHole('Existing');hole.draft.maxSpeed=7;hole.draft.comfortablePuttFt=18;
 const f=await fixture({saved:[hole]}),opening=f.render();f.gate.resolve();await opening;
 assert.equal(f.el('caddyMaxSpeed').value,'7');assert.equal(f.el('caddyPuttRange').value,'18');assert.equal(f.persisted.length,1);
});
test('concurrent opens wait for one initialization and never create duplicate holes',async()=>{
 const f=await fixture(),first=f.render(),second=f.render();f.gate.resolve();await Promise.all([first,second]);
 assert.equal(f.persisted.length,1);assert.equal(f.el('caddy').dataset.state,'ready');assert.equal(f.el('caddyWorkspace').inert,false);assert.equal(f.el('caddyMaxSpeed').value,'9');
});
test('a failed storage read stays visibly unavailable and reopening can retry',async()=>{
 const f=await fixture(),opening=f.render();f.fail(true);f.gate.resolve();await opening;
 assert.equal(f.el('caddy').dataset.state,'error');assert.equal(f.el('caddyWorkspace').inert,true);assert.match(f.el('caddyLoadStatus').textContent,/could not open/i);
 f.fail(false);await f.render();assert.equal(f.el('caddy').dataset.state,'ready');assert.equal(f.el('caddyWorkspace').inert,false);assert.equal(f.el('caddyPuttRange').value,'25');
});

test('backgrounding during a delayed profile read cannot autosave blank controls over defaults',async()=>{
 const f=await fixture({waitAt:'player'}),opening=f.render();await new Promise(resolve=>setImmediate(resolve));
 f.document.hidden=true;f.document.dispatchEvent(new Event('visibilitychange'));f.gate.resolve();await opening;
 assert.equal(f.persisted.length,1);assert.equal(f.persisted[0].draft.maxSpeed,9);assert.equal(f.persisted[0].draft.comfortablePuttFt,25);
});

test('a real caddy recommendation and log preserve measured carry independently from basket remainder',async()=>{
 const f=await fixture({bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:280}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='750';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();
 assert.match(f.el('caddyPlan').innerHTML,/Build this hole in stages/);assert.match(f.el('caddyPlan').innerHTML,/Flight role, range/);
 f.el('caddyRemaining').value='500';f.el('caddyActualDistance').value='250';f.el('caddyDistanceMethod').value='measured';f.el('caddyClearFlight').checked=true;await f.el('caddyRecord').onclick();
 assert.equal(f.persisted[0].throws[0].throwDistanceFt,250);assert.equal(f.persisted[0].throws[0].remainingFt,500);assert.equal(f.persisted[0].throws[0].usedBagId,'test-driver');assert.equal(f.el('caddyDistance').value,'500');
});
test('new caddy distance measurements convert meters before storage',async()=>{
 const f=await fixture({player:normalizePlayer({unit:'m'}),bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:280}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='100';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();
 f.el('caddyActualDistance').value='60';f.el('caddyRemaining').value='40';await f.el('caddyRecord').onclick();
 assert.ok(Math.abs(f.persisted[0].throws[0].throwDistanceFt-60/.3048)<.01);assert.ok(Math.abs(f.persisted[0].throws[0].remainingFt-40/.3048)<.01);
});
test('reopening caddy takes a corrected stored record rather than overwriting it from a stale view',async()=>{
 const saved=makeHole();saved.throws=[{id:'one',number:1,input:{type:'backhand',distanceFt:300},usedBagId:'test-driver',outcome:'short',remainingFt:50,recommendations:[],throwDistanceFt:250,distanceMethod:'measured'}];
 const f=await fixture({saved:[saved]}),opening=f.render();f.gate.resolve();await opening;
 f.persisted[0].throws[0].throwDistanceFt=200;await f.render();assert.match(f.el('caddyHistory').innerHTML,/Actual carry: 200 ft/);assert.equal(f.persisted[0].throws[0].throwDistanceFt,200);
});

test('actual angle, changed hand/style and rich feedback survive a real caddy save and reopen',async()=>{
 const f=await fixture({bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:280,alternateDistance:200}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='230';f.el('caddyFairway').value='straight';f.el('caddyReleaseAngle').value='hyzer';await f.el('caddyRecommend').onclick();
 assert.match(f.el('caddyPlan').innerHTML,/Hyzer/);f.el('caddyActualHand').value='left';f.el('caddyActualType').value='forehand';f.el('caddyActualAngle').value='anhyzer';f.el('caddyQuality').value='great';f.el('caddyExecution').value='clean';f.el('caddyFlight').value='turned';f.el('caddyOutcome').value='right';f.el('caddyActualDistance').value='200';f.el('caddyRemaining').value='70';await f.el('caddyRecord').onclick();
 const t=f.persisted[0].throws[0];assert.equal(t.actualShot.hand,'left');assert.equal(t.actualShot.type,'forehand');assert.equal(t.actualShot.releaseAngle,'anhyzer');assert.equal(t.plannedShot.releaseAngle,'hyzer');assert.equal(t.feedback.quality,'great');assert.equal(t.feedback.flight,'turned');assert.equal(t.throwDistanceFt,200);await f.render();assert.match(f.el('caddyHistory').innerHTML,/left-HAND forehand/);assert.match(f.el('caddyHistory').innerHTML,/Anhyzer/);assert.match(f.el('caddyHistory').innerHTML,/Great throw/);
});
test('a recommendation never silently confirms the actual angle or a successful result',async()=>{
 const f=await fixture({bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:280}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='230';f.el('caddyFairway').value='left';f.el('caddyReleaseAngle').value='hyzer';await f.el('caddyRecommend').onclick();assert.equal(f.el('caddyActualAngle').value,'unknown');assert.equal(f.el('caddyOutcome').value,'unknown');await f.el('caddyRecord').onclick();assert.equal(f.persisted[0].throws[0].actualShot.releaseAngle,'unknown');assert.equal(f.persisted[0].throws[0].outcome,'unknown');
});
test('style comparison shows a specific forehand recommendation and prepares its actual-style control',async()=>{
 const f=await fixture({bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:300,alternateDistance:220}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='210';f.el('caddyFairway').value='right';f.el('caddyType').value='auto';f.el('caddyReleaseAngle').value='auto';await f.el('caddyRecommend').onclick();assert.match(f.el('caddyPlan').innerHTML,/right-hand forehand/);assert.equal(f.el('caddyActualType').value,'forehand');assert.equal(f.el('caddyActualAngle').value,'unknown');
});
