import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {normalizePlayer} from '../dist/lib/player-profile.js';
import {makeHole} from '../dist/lib/caddy.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../dist');
const html=await fs.readFile(path.join(root,'index.html'),'utf8');
const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});return {promise,resolve,reject}};
class Element extends EventTarget{
 constructor(){super();this._value='';this.textContent='';this.innerHTML='';this.dataset={};this.attrs={};this.inert=false;this.hidden=false;this.classList={add(){},remove(){},toggle(){}}}
 get value(){return this._value}set value(value){this._value=String(value)}
 setAttribute(key,value){this.attrs[key]=String(value)}
 removeAttribute(key){delete this.attrs[key]}
}
async function fixture({saved=[],player=normalizePlayer({maxSpeed:9,comfortablePuttFt:25}),waitAt='catalog'}={}){
 const elements=new Map([...html.matchAll(/\bid="([\w-]+)"/g)].map(m=>[m[1],new Element()]));
 const el=id=>{assert.ok(elements.has(id),'Unknown control '+id);return elements.get(id)};
 // These preloaded labels caused the old browser check to pass before initialization.
 el('caddyLie').textContent='THROW 1 · TEE';el('caddy').hidden=false;
 const document=new EventTarget();document.getElementById=el;document.hidden=false;
 const window=new EventTarget(),gate=deferred();let held=true,fail=false;const persisted=saved.map(h=>structuredClone(h));
 async function hold(at){if(held&&waitAt===at){held=false;await gate.promise}if(fail)throw Error('QA storage unavailable')}
 const storage={listBag:async()=>{await hold('bag');return []},listCatalog:async()=>{await hold('catalog');return []},getPlayer:async()=>{await hold('player');return player},listPlayerSessions:async()=>[],listCaddyHoles:async()=>{await hold('holes');return structuredClone(persisted)},storeCaddyHole:async h=>{await hold('save');const i=persisted.findIndex(v=>v.id===h.id);if(i>=0)persisted[i]=structuredClone(h);else persisted.push(structuredClone(h))}};
 const context=vm.createContext({document,window,localStorage:{getItem:()=>null,setItem(){}},crypto:globalThis.crypto,structuredClone,URL,Blob,console,setTimeout,clearTimeout,Event,CustomEvent});
 const modules=new Map();
 function module(file){
  if(modules.has(file))return modules.get(file);
  const m=file===path.join(root,'lib/storage.js')?new vm.SyntheticModule(Object.keys(storage),function(){for(const [key,value]of Object.entries(storage))this.setExport(key,value)},{context,identifier:file}):new vm.SourceTextModule(code.get(file),{context,identifier:file});modules.set(file,m);return m;
 }
 const code=new Map();for(const name of await fs.readdir(path.join(root,'lib')))if(name.endsWith('.js')){const file=path.join(root,'lib',name);code.set(file,await fs.readFile(file,'utf8'))}
 const entry=module(path.join(root,'lib/caddy-ui.js'));await entry.link((specifier,parent)=>module(path.resolve(path.dirname(parent.identifier),specifier)));await entry.evaluate();
 entry.namespace.setupCaddy({notify(){},download(){}});
 return {el,document,render:entry.namespace.renderCaddy,gate,persisted,fail:value=>{fail=value}};
}

test('a visible Throw 1 placeholder is not readiness while profile and hole storage are delayed',async()=>{
 const f=await fixture(),opening=f.render();
 assert.equal(f.el('caddyLie').textContent,'THROW 1 · TEE');assert.equal(f.el('caddyPuttRange').value,'');
 assert.equal(f.el('caddy').dataset.state,'loading');assert.equal(f.el('caddyWorkspace').inert,true);
 f.gate.resolve();await opening;
 assert.equal(f.el('caddy').dataset.state,'ready');assert.equal(f.el('caddyWorkspace').inert,false);assert.equal(f.el('caddy').attrs['aria-busy'],'false');
 assert.equal(f.el('caddyPuttRange').value,'25');assert.equal(f.el('caddyMaxSpeed').value,'9');assert.equal(f.persisted.length,1);assert.equal(f.persisted[0].draft.maxSpeed,9);
});
test('readiness waits through the player read, rather than only the bag read',async()=>{
 const f=await fixture({waitAt:'player'}),opening=f.render();await new Promise(resolve=>setImmediate(resolve));
 assert.equal(f.el('caddy').dataset.state,'loading');assert.equal(f.el('caddyWorkspace').inert,true);f.gate.resolve();await opening;assert.equal(f.el('caddyMaxSpeed').value,'9');assert.equal(f.el('caddy').dataset.state,'ready');
});
test('resuming an existing hole preserves explicit per-lie limits',async()=>{
 const hole=makeHole('Existing');hole.draft.maxSpeed=7;hole.draft.comfortablePuttFt=18;
 const f=await fixture({saved:[hole]}),opening=f.render();f.gate.resolve();await opening;
 assert.equal(f.el('caddyMaxSpeed').value,'7');assert.equal(f.el('caddyPuttRange').value,'18');assert.equal(f.persisted.length,1);
});
test('concurrent opens wait for one initialization and never create duplicate holes',async()=>{
 const f=await fixture(),first=f.render(),second=f.render();f.gate.resolve();await Promise.all([first,second]);
 assert.equal(f.persisted.length,1);assert.equal(f.el('caddy').dataset.state,'ready');assert.equal(f.el('caddyWorkspace').inert,false);assert.equal(f.el('caddyMaxSpeed').value,'9');
});
test('a failed storage read stays visibly unavailable and reopening can retry',async()=>{
 const f=await fixture(),opening=f.render();f.fail(true);f.gate.resolve();await opening;
 assert.equal(f.el('caddy').dataset.state,'error');assert.equal(f.el('caddyWorkspace').inert,true);assert.match(f.el('caddyLoadStatus').textContent,/could not open/i);
 f.fail(false);await f.render();assert.equal(f.el('caddy').dataset.state,'ready');assert.equal(f.el('caddyWorkspace').inert,false);assert.equal(f.el('caddyPuttRange').value,'25');
});

test('backgrounding during a delayed profile read cannot autosave blank controls over defaults',async()=>{
 const f=await fixture({waitAt:'player'}),opening=f.render();await new Promise(resolve=>setImmediate(resolve));
 f.document.hidden=true;f.document.dispatchEvent(new Event('visibilitychange'));f.gate.resolve();await opening;
 assert.equal(f.persisted.length,1);assert.equal(f.persisted[0].draft.maxSpeed,9);assert.equal(f.persisted[0].draft.comfortablePuttFt,25);
});
