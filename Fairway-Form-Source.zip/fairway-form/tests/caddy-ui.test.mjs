import {assertCaddySelection} from '../scripts/lib/caddy-smoke.mjs';
import {DISCS} from '../dist/lib/discs.js';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {normalizePlayer} from '../dist/lib/player-profile.js';
import {createThrowMeter} from '../dist/lib/throw-measure.js';
import {makeHole} from '../dist/lib/caddy.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../dist');
const html=await fs.readFile(path.join(root,'index.html'),'utf8');
const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});return {promise,resolve,reject}};
class Element extends EventTarget{
 constructor(){super();this._value='';this.textContent='';this.innerHTML='';this.dataset={};this.attrs={};this.inert=false;this.hidden=false;const classes=new Set();this.classList={add:v=>classes.add(v),remove:v=>classes.delete(v),contains:v=>classes.has(v),toggle:(v,on)=>{if(on===undefined)on=!classes.has(v);on?classes.add(v):classes.delete(v)}}}
 get value(){return this._value}set value(value){this._value=String(value)}
 setAttribute(key,value){this.attrs[key]=String(value)}
 removeAttribute(key){delete this.attrs[key]}
 showModal(){this.open=true}
 close(){this.open=false;this.dispatchEvent(new Event('close'))}
 querySelectorAll(){return []}
}
async function fixture({saved=[],player=normalizePlayer({maxSpeed:9,comfortablePuttFt:25}),waitAt='catalog',bagCopies=[],capture=null,compass=null,fetcher=null,geolocation=null,savedCourses=[]}={}){
 const elements=new Map([...html.matchAll(/\bid="([\w-]+)"/g)].map(m=>[m[1],new Element()]));
 elements.set('caddySignDistance',new Element());elements.set('caddySignPar',new Element());const el=id=>{assert.ok(elements.has(id),'Unknown control '+id);return elements.get(id)};
 // These preloaded labels caused the old browser check to pass before initialization.
 el('caddyLie').textContent='THROW 1 · TEE';el('caddy').hidden=false;
 const document=new EventTarget();document.getElementById=el;document.hidden=false;
 const window=new EventTarget(),gate=deferred();let held=true,fail=false,writePause=null;const persisted=saved.map(h=>structuredClone(h));
 async function hold(at){if(held&&waitAt===at){held=false;await gate.promise}if(fail)throw Error('QA storage unavailable')}
 const courses=structuredClone(savedCourses);const storage={listCourses:async()=>structuredClone(courses),storeCourse:async c=>{if(fail)throw Error('QA storage unavailable');const i=courses.findIndex(v=>v.id===c.id);if(i>=0)courses[i]=structuredClone(c);else courses.push(structuredClone(c))},storeCourses:async rows=>{for(const c of rows)await storage.storeCourse(c)},listBag:async()=>{await hold('bag');return structuredClone(bagCopies)},listCatalog:async()=>{await hold('catalog');return []},getPlayer:async()=>{await hold('player');return player},listPlayerSessions:async()=>[],listCaddyHoles:async()=>{await hold('holes');return structuredClone(persisted)},storeCaddyHole:async h=>{await hold('save');if(writePause){const wait=writePause;writePause=null;await wait.promise}const i=persisted.findIndex(v=>v.id===h.id);if(i>=0)persisted[i]=structuredClone(h);else persisted.push(structuredClone(h))}};
 const context=vm.createContext({document,window,localStorage:{getItem:()=>null,setItem(){}},crypto:globalThis.crypto,structuredClone,URL,URLSearchParams,Blob,console,navigator:{geolocation},fetch:fetcher??(async()=>{throw Error('No weather fetch in this test')}),AbortSignal,setTimeout,clearTimeout,Event,CustomEvent,AbortController});
 const modules=new Map();
 function module(file){
  if(modules.has(file))return modules.get(file);
  const m=compass&&file===path.join(root,'lib/phone-compass.js')?new vm.SyntheticModule(['watchPhoneCompass'],function(){this.setExport('watchPhoneCompass',compass)},{context,identifier:file}):capture&&file===path.join(root,'lib/throw-measure.js')?new vm.SyntheticModule(['captureEndpoint','createThrowMeter'],function(){this.setExport('captureEndpoint',capture);this.setExport('createThrowMeter',createThrowMeter)},{context,identifier:file}):file===path.join(root,'lib/storage.js')?new vm.SyntheticModule(Object.keys(storage),function(){for(const [key,value]of Object.entries(storage))this.setExport(key,value)},{context,identifier:file}):new vm.SourceTextModule(code.get(file),{context,identifier:file});modules.set(file,m);return m;
 }
 const code=new Map();for(const name of await fs.readdir(path.join(root,'lib')))if(name.endsWith('.js')){const file=path.join(root,'lib',name);code.set(file,await fs.readFile(file,'utf8'))}
 const entry=module(path.join(root,'lib/caddy-ui.js'));await entry.link((specifier,parent)=>module(path.resolve(path.dirname(parent.identifier),specifier)));await entry.evaluate();
 entry.namespace.setupCaddy({notify(){},download(){}});
 return {el,document,window,render:entry.namespace.renderCaddy,flush:entry.namespace.flushCaddyDraft,gate,persisted,courses,fail:value=>{fail=value},pauseNextWrite:()=>{writePause=deferred();return writePause}};
}

test('a visible Throw 1 placeholder is not readiness while profile and hole storage are delayed',async()=>{
 const f=await fixture(),opening=f.render();
 assert.equal(f.el('caddyLie').textContent,'THROW 1 · TEE');assert.equal(f.el('caddyPuttRange').value,'');
 assert.equal(f.el('caddy').dataset.state,'loading');assert.equal(f.el('caddyWorkspace').inert,true);
 f.gate.resolve();await opening;
 assert.equal(f.el('caddy').dataset.state,'ready');assert.equal(f.el('caddyWorkspace').inert,false);assert.equal(f.el('caddy').attrs['aria-busy'],'false');
 assert.equal(f.el('caddyPuttRange').value,'25');assert.equal(f.el('caddyMaxSpeed').value,'9');assert.equal(f.persisted.length,1);assert.equal(f.persisted[0].draft.maxSpeed,9);
});
test('readiness waits through the player read, rather than only the bag read',async()=>{
 const f=await fixture({waitAt:'player'}),opening=f.render();await new Promise(resolve=>setImmediate(resolve));
 assert.equal(f.el('caddy').dataset.state,'loading');assert.equal(f.el('caddyWorkspace').inert,true);f.gate.resolve();await opening;assert.equal(f.el('caddyMaxSpeed').value,'9');assert.equal(f.el('caddy').dataset.state,'ready');
});
test('resuming an existing hole preserves explicit per-lie limits',async()=>{
 const hole=makeHole('Existing');hole.draft.maxSpeed=7;hole.draft.comfortablePuttFt=18;
 const f=await fixture({saved:[hole]}),opening=f.render();f.gate.resolve();await opening;
 assert.equal(f.el('caddyMaxSpeed').value,'7');assert.equal(f.el('caddyPuttRange').value,'18');assert.equal(f.persisted.length,1);
});
test('concurrent opens wait for one initialization and never create duplicate holes',async()=>{
 const f=await fixture(),first=f.render(),second=f.render();f.gate.resolve();await Promise.all([first,second]);
 assert.equal(f.persisted.length,1);assert.equal(f.el('caddy').dataset.state,'ready');assert.equal(f.el('caddyWorkspace').inert,false);assert.equal(f.el('caddyMaxSpeed').value,'9');
});
test('a failed storage read stays visibly unavailable and reopening can retry',async()=>{
 const f=await fixture(),opening=f.render();f.fail(true);f.gate.resolve();await opening;
 assert.equal(f.el('caddy').dataset.state,'error');assert.equal(f.el('caddyWorkspace').inert,true);assert.match(f.el('caddyLoadStatus').textContent,/could not open/i);
 f.fail(false);await f.render();assert.equal(f.el('caddy').dataset.state,'ready');assert.equal(f.el('caddyWorkspace').inert,false);assert.equal(f.el('caddyPuttRange').value,'25');
});

test('backgrounding during a delayed profile read cannot autosave blank controls over defaults',async()=>{
 const f=await fixture({waitAt:'player'}),opening=f.render();await new Promise(resolve=>setImmediate(resolve));
 f.document.hidden=true;f.document.dispatchEvent(new Event('visibilitychange'));f.gate.resolve();await opening;
 assert.equal(f.persisted.length,1);assert.equal(f.persisted[0].draft.maxSpeed,9);assert.equal(f.persisted[0].draft.comfortablePuttFt,25);
});

test('a real caddy recommendation and log preserve measured carry independently from basket remainder',async()=>{
 const f=await fixture({bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:280}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='750';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();
 assert.match(f.el('caddyPlan').innerHTML,/Build this hole in stages/);assert.match(f.el('caddyPlan').innerHTML,/Flight role, range/);
 f.el('caddyRemaining').value='500';f.el('caddyActualDistance').value='250';f.el('caddyDistanceMethod').value='measured';f.el('caddyClearFlight').checked=true;await f.el('caddyRecord').onclick();
 assert.equal(f.persisted[0].throws[0].throwDistanceFt,250);assert.equal(f.persisted[0].throws[0].remainingFt,500);assert.equal(f.persisted[0].throws[0].usedBagId,'test-driver');assert.equal(f.el('caddyDistance').value,'500');
});
test('new caddy distance measurements convert meters before storage',async()=>{
 const f=await fixture({player:normalizePlayer({unit:'m'}),bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:280}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='100';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();
 f.el('caddyActualDistance').value='60';f.el('caddyRemaining').value='40';await f.el('caddyRecord').onclick();
 assert.ok(Math.abs(f.persisted[0].throws[0].throwDistanceFt-60/.3048)<.01);assert.ok(Math.abs(f.persisted[0].throws[0].remainingFt-40/.3048)<.01);
});
test('reopening caddy takes a corrected stored record rather than overwriting it from a stale view',async()=>{
 const saved=makeHole();saved.throws=[{id:'one',number:1,input:{type:'backhand',distanceFt:300},usedBagId:'test-driver',outcome:'short',remainingFt:50,recommendations:[],throwDistanceFt:250,distanceMethod:'measured'}];
 const f=await fixture({saved:[saved]}),opening=f.render();f.gate.resolve();await opening;
 f.persisted[0].throws[0].throwDistanceFt=200;await f.render();assert.match(f.el('caddyHistory').innerHTML,/Actual carry: 200 ft/);assert.equal(f.persisted[0].throws[0].throwDistanceFt,200);
});

test('actual angle, changed hand/style and rich feedback survive a real caddy save and reopen',async()=>{
 const f=await fixture({bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:280,alternateDistance:200}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='230';f.el('caddyFairway').value='straight';f.el('caddyReleaseAngle').value='hyzer';await f.el('caddyRecommend').onclick();
 assert.match(f.el('caddyPlan').innerHTML,/Hyzer/);f.el('caddyActualHand').value='left';f.el('caddyActualType').value='forehand';f.el('caddyActualAngle').value='anhyzer';f.el('caddyQuality').value='great';f.el('caddyExecution').value='clean';f.el('caddyFlight').value='turned';f.el('caddyOutcome').value='right';f.el('caddyActualDistance').value='200';f.el('caddyRemaining').value='70';await f.el('caddyRecord').onclick();
 const t=f.persisted[0].throws[0];assert.equal(t.actualShot.hand,'left');assert.equal(t.actualShot.type,'forehand');assert.equal(t.actualShot.releaseAngle,'anhyzer');assert.equal(t.plannedShot.releaseAngle,'flat');assert.equal(t.feedback.quality,'great');assert.equal(t.feedback.flight,'turned');assert.equal(t.throwDistanceFt,200);await f.render();assert.match(f.el('caddyHistory').innerHTML,/left-HAND forehand/);assert.match(f.el('caddyHistory').innerHTML,/Anhyzer/);assert.match(f.el('caddyHistory').innerHTML,/Great throw/);
});
test('a recommendation never silently confirms the actual angle or a successful result',async()=>{
 const f=await fixture({bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:280}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='230';f.el('caddyFairway').value='left';f.el('caddyReleaseAngle').value='hyzer';await f.el('caddyRecommend').onclick();assert.equal(f.el('caddyActualAngle').value,'unknown');assert.equal(f.el('caddyOutcome').value,'unknown');await f.el('caddyRecord').onclick();assert.equal(f.persisted[0].throws[0].actualShot.releaseAngle,'unknown');assert.equal(f.persisted[0].throws[0].outcome,'unknown');
});
test('style comparison shows a specific forehand recommendation and prepares its actual-style control',async()=>{
 const f=await fixture({bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:300,alternateDistance:220}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='210';f.el('caddyFairway').value='right';f.el('caddyType').value='auto';f.el('caddyReleaseAngle').value='auto';await f.el('caddyRecommend').onclick();assert.match(f.el('caddyPlan').innerHTML,/right-hand forehand/);assert.equal(f.el('caddyActualType').value,'forehand');assert.equal(f.el('caddyActualAngle').value,'unknown');
});

const gpsStart={latitude:0,longitude:0,accuracy:3,samples:3},gpsEnd={latitude:0,longitude:.0009,accuracy:4,samples:4};
async function gpsFixture(options={}){const points=[gpsStart,gpsEnd],f=await fixture({bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:280}],capture:async()=>points.shift(),...options}),opening=f.render();f.gate.resolve();await opening;return f}
async function measure(f){await f.el('throwMeasureAction').onclick();assert.match(f.el('throwMeasureAction').textContent,/Stop/);await f.el('throwMeasureAction').onclick();assert.equal(f.el('throwMeasureSave').disabled,false)}
test('GPS Save persists a per-throw draft, converts meters and survives recommendation resets',async()=>{
 const f=await gpsFixture({player:normalizePlayer({unit:'m'})});assert.equal(f.el('throwMeasureUnits').value,'ft');await measure(f);assert.match(f.el('throwMeasureResult').textContent,/329 ft/);
 f.el('throwMeasureUnits').value='m';f.el('throwMeasureUnits').onchange();assert.match(f.el('throwMeasureResult').textContent,/100 m/);await f.el('throwMeasureSave').onclick();
 assert.ok(Math.abs(Number(f.el('caddyActualDistance').value)-100.2)<.1);assert.equal(f.el('caddyDistanceMethod').value,'gps');assert.equal(f.persisted[0].pendingMeasurement.throwNumber,1);assert.doesNotMatch(JSON.stringify(f.persisted),/latitude|longitude/);
 f.el('caddyDistance').value='150';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();assert.equal(f.el('caddyDistanceMethod').value,'gps');assert.ok(Number(f.el('caddyActualDistance').value)>100);await f.render();await f.el('caddyRecommend').onclick();assert.equal(f.el('caddyDistanceMethod').value,'gps');assert.match(f.el('caddyMeasuredCarry').textContent,/Saved GPS estimate/);
 f.el('caddyRemaining').value='50';await f.el('caddyRecord').onclick();const t=f.persisted[0].throws[0];assert.equal(t.distanceMethod,'gps');assert.equal(t.distanceGps.uncertaintyM,7);assert.ok(t.throwDistanceFt>328);assert.equal(f.persisted[0].pendingMeasurement,null);assert.equal(f.el('throwMeasureSave').disabled,true);assert.match(f.el('throwMeasureAction').textContent,/Start/);
});
test('cancelling an endpoint keeps late callbacks out of the feedback draft',async()=>{
 const pending=deferred(),f=await gpsFixture({capture:()=>pending.promise});const capturing=f.el('throwMeasureAction').onclick();await new Promise(resolve=>setImmediate(resolve));f.el('throwMeasureCancel').onclick();pending.resolve(gpsStart);await capturing;assert.equal(f.el('throwMeasureSave').disabled,true);assert.equal(f.persisted[0].pendingMeasurement,undefined);assert.equal(f.el('caddyActualDistance').value,'');
});
test('new holes discard unsaved GPS endpoints and never inherit another throw’s measurement',async()=>{
 const f=await gpsFixture();await measure(f);await f.el('caddyNew').onclick();assert.equal(f.el('throwMeasureSave').disabled,true);assert.equal(f.el('throwMeasureResult').textContent,'');await f.el('throwMeasureSave').onclick();assert.ok(f.persisted.every(h=>!h.pendingMeasurement));
});
test('GPS draft save failure leaves the distance unsaved and allows a retry',async()=>{
 const f=await gpsFixture();await measure(f);f.fail(true);await f.el('throwMeasureSave').onclick();assert.equal(f.el('throwMeasureSave').disabled,false);assert.match(f.el('throwMeasureStatus').textContent,/could not be saved/);assert.equal(f.el('caddyActualDistance').value,'');assert.equal(f.persisted[0].pendingMeasurement,undefined);f.fail(false);await f.el('throwMeasureSave').onclick();assert.equal(f.el('caddyDistanceMethod').value,'gps');assert.equal(f.el('throwMeasureSave').disabled,true);
});
test('manual distance edits discard GPS metadata before the next canonical save',async()=>{
 const f=await gpsFixture();await measure(f);await f.el('throwMeasureSave').onclick();f.el('caddyDistance').value='350';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();f.el('caddyActualDistance').value='270';f.el('caddyActualDistance').dispatchEvent(new Event('input'));assert.equal(f.el('caddyDistanceMethod').value,'estimated');f.el('caddyRemaining').value='80';await f.el('caddyRecord').onclick();assert.equal(f.persisted[0].throws[0].throwDistanceFt,270);assert.equal(f.persisted[0].throws[0].distanceGps,null);assert.equal(f.persisted[0].throws[0].distanceMethod,'estimated');
});
test('leaving Caddy pauses an active endpoint without leaving a location watch running',async()=>{
 let signal;const f=await gpsFixture({capture:options=>{signal=options.signal;return new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(Object.assign(Error('cancelled'),{name:'AbortError'}))))}});const capturing=f.el('throwMeasureAction').onclick();await new Promise(resolve=>setImmediate(resolve));f.window.dispatchEvent(new CustomEvent('fairway-page-changed',{detail:'discs'}));await capturing;assert.equal(signal.aborted,true);assert.equal(f.el('throwMeasureSave').disabled,true);assert.match(f.el('throwMeasureStatus').textContent,/paused/);
});
test('finished holes cannot start a measurement',async()=>{
 const h=makeHole();h.status='finished';let calls=0;const f=await gpsFixture({saved:[h],capture:()=>{calls++;return gpsStart}});assert.equal(f.el('throwMeasureAction').disabled,true);await f.el('throwMeasureAction').onclick();assert.equal(calls,0);
});

test('recording feedback waits for the GPS distance draft to finish saving',async()=>{
 const f=await gpsFixture();f.el('caddyDistance').value='350';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();await measure(f);const gate=f.pauseNextWrite(),saving=f.el('throwMeasureSave').onclick();await new Promise(resolve=>setImmediate(resolve));f.el('caddyRemaining').value='20';await f.el('caddyRecord').onclick();assert.equal(f.persisted[0].throws.length,0);gate.resolve();await saving;await f.el('caddyRecord').onclick();assert.equal(f.persisted[0].throws.length,1);assert.equal(f.persisted[0].throws[0].distanceMethod,'gps');
});

function compassFixture(options={}){
 const calls=[];let active=null;
 const compass=config=>{const state={config,stopped:false,reading:{heading:90,reference:'true-north'}};calls.push(state);active=state;config.onUpdate({ready:true,heading:90,message:'Direction settled.'});return {stop(){state.stopped=true},getReading:()=>state.stopped?null:state.reading}};
 const fetcher=async()=>({ok:true,json:async()=>({current_units:{wind_speed_10m:'mp/h',wind_gusts_10m:'mp/h',temperature_2m:'°C',precipitation:'mm'},current:{time:new Date().toISOString().slice(0,16),wind_speed_10m:10,wind_gusts_10m:15,wind_direction_10m:90,temperature_2m:20,precipitation:0}})});
 const geolocation={getCurrentPosition:resolve=>resolve({coords:{latitude:40.123,longitude:-75.45}})};
 return {options:{compass,fetcher,geolocation,...options},calls,get active(){return active}};
}
async function weatherFixture(options={}){const control=compassFixture(options),f=await fixture(control.options),opening=f.render();f.gate.resolve();await opening;return {...f,control}}
test('Get local weather automatically opens the compass and Use applies wind without typed degrees',async()=>{
 const f=await weatherFixture();f.el('caddyWeather').onclick();assert.equal(f.el('caddyWeatherConsent').open,true);await f.el('caddyWeatherContinue').onclick();assert.equal(f.el('caddyCompassDialog').open,true);assert.equal(f.control.calls.length,1);assert.equal(f.control.active.config.latitude,40.123);assert.equal(f.el('caddyBearing').value,'');assert.equal(f.el('caddyCompassUse').disabled,false);assert.match(f.el('caddyCompassWind').textContent,/headwind/);
 f.el('caddyCompassUse').onclick();assert.equal(f.el('caddyCompassDialog').open,false);assert.equal(f.control.active.stopped,true);assert.equal(f.el('caddyBearing').value,'90');assert.equal(f.el('caddyWindDirection').value,'head');assert.equal(f.el('caddyWindMph').value,'10.0');assert.match(f.el('caddyHeadingStatus').textContent,/phone compass, true north/);assert.match(f.el('caddyWeatherStatus').textContent,/captured with your phone compass/);
 f.el('caddyHoleTitle').onchange();await f.render();assert.equal(f.persisted[0].draft.bearing,'90');assert.doesNotMatch(JSON.stringify(f.persisted),/latitude|longitude/);
});
test('cancel stops compass sensing and preserves previous manual heading and wind',async()=>{
 const f=await weatherFixture();f.el('caddyBearing').value='270';f.el('caddyWindDirection').value='tail';await f.el('caddyWeatherContinue').onclick();f.el('caddyCompassCancel').onclick();assert.equal(f.control.active.stopped,true);assert.equal(f.el('caddyCompassDialog').open,false);assert.equal(f.el('caddyBearing').value,'270');assert.equal(f.el('caddyWindDirection').value,'tail');
});
test('a stale last reading cannot be used just because the compass button was previously enabled',async()=>{
 const f=await weatherFixture();await f.el('caddyWeatherContinue').onclick();f.control.active.reading=null;f.el('caddyCompassUse').onclick();assert.equal(f.el('caddyBearing').value,'');assert.equal(f.el('caddyCompassUse').disabled,true);assert.match(f.el('caddyCompassStatus').textContent,/fresh settled/);f.el('caddyCompassCancel').onclick();
});
test('after recording a throw the heading clears and each next line can use the compass again',async()=>{
 const f=await weatherFixture({bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:280}]});await f.el('caddyWeatherContinue').onclick();f.el('caddyCompassUse').onclick();f.el('caddyDistance').value='350';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();f.el('caddyRemaining').value='60';await f.el('caddyRecord').onclick();assert.equal(f.el('caddyBearing').value,'');assert.equal(f.el('caddyWindDirection').value,'unknown');f.el('caddyCompass').onclick();assert.equal(f.el('caddyCompassDialog').open,true);assert.equal(f.control.calls.length,2);f.control.active.reading={heading:270};f.el('caddyCompassUse').onclick();assert.equal(f.el('caddyWindDirection').value,'tail');assert.equal(f.el('caddyBearing').value,'270');
});
test('leaving the page or backgrounding stops the compass and prevents a late apply',async()=>{
 const f=await weatherFixture();await f.el('caddyWeatherContinue').onclick();f.window.dispatchEvent(new CustomEvent('fairway-page-changed',{detail:'discs'}));assert.equal(f.control.active.stopped,true);assert.equal(f.el('caddyCompassDialog').open,false);f.el('caddyCompassUse').onclick();assert.equal(f.el('caddyBearing').value,'');f.el('caddyCompass').onclick();f.document.hidden=true;f.document.dispatchEvent(new Event('visibilitychange'));assert.equal(f.control.active.stopped,true);assert.equal(f.el('caddyCompassDialog').open,false);
});
test('changing holes closes the compass; late weather responses cannot open it on another hole',async()=>{
 const response=deferred(),f=await weatherFixture({fetcher:()=>response.promise});const request=f.el('caddyWeatherContinue').onclick();await new Promise(resolve=>setImmediate(resolve));await f.el('caddyNew').onclick();response.resolve({ok:false});await request;assert.equal(f.control.calls.length,0);assert.equal(f.el('caddyCompassDialog').open??false,false);assert.equal(f.el('caddyBearing').value,'');assert.equal(f.el('caddyCompass').disabled,true);
});
test('missing compass hardware keeps fetched weather and manual direction entry usable',async()=>{
 const f=await weatherFixture({compass:()=>{throw Error('No compass hardware; enter direction manually.')}});await f.el('caddyWeatherContinue').onclick();assert.match(f.el('caddyCompassStatus').textContent,/No compass/);f.el('caddyCompassCancel').onclick();f.el('caddyBearing').value='180';f.el('caddyBearing').dispatchEvent(new Event('change'));f.el('caddyWeatherApply').onclick();assert.equal(f.el('caddyWindDirection').value,'left-right');assert.match(f.el('caddyHeadingStatus').textContent,/manual entry/);
});
test('location denial never starts the compass and leaves manual weather inputs available',async()=>{
 const f=await weatherFixture({geolocation:{getCurrentPosition:(resolve,reject)=>reject({code:1})}});await f.el('caddyWeatherContinue').onclick();assert.match(f.el('caddyWeatherStatus').textContent,/not allowed/);assert.equal(f.control.calls.length,0);assert.equal(f.el('caddyCompass').disabled,true);assert.equal(f.el('caddyWeather').disabled,false);
});

test('the top and feedback measurement controls share one capture and save separately on subsequent throws',async()=>{
 const points=[gpsStart,gpsEnd,gpsStart,{...gpsEnd,longitude:.00045}],f=await gpsFixture({capture:async()=>points.shift()});
 f.el('caddyDistance').value='350';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();assert.match(f.el('feedbackMeasureTitle').textContent,/throw 1/);
 await f.el('feedbackMeasureAction').onclick();assert.match(f.el('throwMeasureAction').textContent,/Stop/);await f.el('throwMeasureAction').onclick();assert.equal(f.el('feedbackMeasureResult').textContent,f.el('throwMeasureResult').textContent);await f.el('feedbackMeasureSave').onclick();f.el('caddyRemaining').value='100';await f.el('caddyRecord').onclick();assert.equal(f.persisted[0].throws.length,1);assert.match(f.el('feedbackMeasureTitle').textContent,/throw 2/);assert.equal(f.el('feedbackMeasureSave').disabled,true);
 f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();await f.el('throwMeasureAction').onclick();await f.el('feedbackMeasureAction').onclick();await f.el('feedbackMeasureSave').onclick();assert.equal(f.persisted[0].pendingMeasurement.throwNumber,2);f.el('caddyRemaining').value='30';await f.el('caddyRecord').onclick();const [a,b]=f.persisted[0].throws;assert.ok(a.throwDistanceFt>328);assert.ok(b.throwDistanceFt>164&&b.throwDistanceFt<165);assert.equal(a.number,1);assert.equal(b.number,2);assert.equal(f.persisted[0].pendingMeasurement,null);
});
test('either measurement control can cancel and both unit selectors show the same result units',async()=>{
 const pending=deferred(),f=await gpsFixture({capture:()=>pending.promise});const start=f.el('throwMeasureAction').onclick();await new Promise(resolve=>setImmediate(resolve));f.el('feedbackMeasureCancel').onclick();pending.resolve(gpsStart);await start;assert.equal(f.el('throwMeasureSave').disabled,true);assert.equal(f.el('feedbackMeasureSave').disabled,true);assert.equal(f.el('throwMeasureStatus').textContent,f.el('feedbackMeasureStatus').textContent);f.el('feedbackMeasureUnits').value='m';f.el('feedbackMeasureUnits').onchange();assert.equal(f.el('throwMeasureUnits').value,'m');
});
const puttingBag=[{id:'test-driver',discId:'innova-teebird',distance:280},{id:'test-putter',discId:'innova-aviar',distance:180,puttingRange:25,puttingPreferred:true}];
async function puttingUI(options={}){const f=await fixture({bagCopies:puttingBag,...options}),opening=f.render();f.gate.resolve();await opening;return f}
function pin(f,value){f.el('caddyPinDistance').value=value;f.el('caddyPinDistance').dispatchEvent(new Event('input'))}
test('within 50 feet the caddy asks before choosing putting or throwing, rather than guessing',async()=>{
 const f=await puttingUI();pin(f,50);assert.equal(f.el('caddyDistance').value,'50');assert.equal(f.el('caddyPuttingPrompt').hidden,false);await f.el('caddyRecommend').onclick();assert.match(f.el('caddyStatus').textContent,/Are you putting/);assert.equal(f.el('caddyPlan').innerHTML,'');f.el('caddyPromptThrow').onclick();assert.equal(f.el('caddyPuttingPrompt').hidden,true);assert.notEqual(f.el('caddyType').value,'putt');await f.el('caddyRecommend').onclick();assert.ok(f.el('caddyPlan').innerHTML.length);
});
test('the putting prompt uses feet internally while a player enters meters',async()=>{
 const f=await puttingUI({player:normalizePlayer({unit:'m'})});pin(f,15.24);assert.equal(f.el('caddyPuttingPrompt').hidden,false);pin(f,15.25);assert.equal(f.el('caddyPuttingPrompt').hidden,true);f.el('caddyMarkPutt').onclick();assert.equal(f.el('caddyPuttingPanel').hidden,false);assert.equal(f.el('caddyType').value,'putt');
});
test('drive, missed putt and made putt each keep their own lie, result and putter profile',async()=>{
 const f=await puttingUI();pin(f,300);await f.el('caddyRecommend').onclick();f.el('caddyRemaining').value='20';await f.el('caddyRecord').onclick();assert.equal(f.el('caddyPuttingPrompt').hidden,false);f.el('caddyPromptPutt').onclick();assert.equal(f.el('caddyPuttingPanel').hidden,false);await f.el('caddyPuttRecommend').onclick();assert.equal(f.el('caddyUsedDisc').value,'test-putter');assert.equal(f.el('caddyPuttFeedback').hidden,false);assert.equal(f.el('caddyPuttStartDistance').value,'20');
 f.el('caddyPuttResult').value='missed';f.el('caddyPuttResult').onchange();f.el('caddyRemaining').value='8';await f.el('caddyRecord').onclick();assert.match(f.el('caddyLie').textContent,/THROW 3/);assert.equal(f.el('caddyPuttingPrompt').hidden,false);assert.equal(f.persisted[0].throws[1].putting.startDistanceFt,20);assert.equal(f.persisted[0].throws[1].outcome,'missed');assert.equal(f.persisted[0].throws[1].throwDistanceFt,null);
 f.el('caddyPromptPutt').onclick();await f.el('caddyPuttRecommend').onclick();f.el('caddyPuttResult').value='made';f.el('caddyPuttResult').onchange();assert.equal(f.el('caddyRemaining').value,'0');await f.el('caddyRecord').onclick();assert.equal(f.persisted[0].status,'finished');assert.equal(f.persisted[0].throws.length,3);assert.equal(f.persisted[0].throws[2].putting.startDistanceFt,8);assert.equal(f.persisted[0].throws[2].outcome,'made');assert.match(f.el('caddyPuttingProfiles').innerHTML,/1 \/ 1 made/);assert.match(f.el('caddyPuttingProfiles').innerHTML,/0 \/ 1 made/);assert.equal(f.el('feedbackMeasureAction').disabled,false);assert.equal(f.el('caddyHoleNumber').value,'2');assert.match(f.el('caddyLie').textContent,/THROW 1/);
});
test('putt start distance and carry remain independent, including a GPS measurement saved from feedback',async()=>{
 const points=[{...gpsStart,accuracy:.3},{...gpsEnd,accuracy:.4,longitude:.000054}],f=await puttingUI({capture:async()=>points.shift()});pin(f,20);f.el('caddyPromptPutt').onclick();await f.el('caddyPuttRecommend').onclick();await f.el('feedbackMeasureAction').onclick();await f.el('feedbackMeasureAction').onclick();await f.el('feedbackMeasureSave').onclick();assert.equal(f.el('caddyPuttStartDistance').value,'20');f.el('caddyPuttStartDistance').value='25';f.el('caddyPuttResult').value='missed';f.el('caddyPuttResult').onchange();f.el('caddyRemaining').value='6';await f.el('caddyRecord').onclick();const r=f.persisted[0].throws[0];assert.equal(r.putting.startDistanceFt,25);assert.equal(r.distanceMethod,'gps');assert.ok(r.throwDistanceFt>19&&r.throwDistanceFt<20);assert.equal(r.remainingFt,6);
});
test('putting start distances convert from meters and do not drift over a 20-foot band boundary',async()=>{
 const f=await puttingUI();pin(f,20);f.el('caddyUnits').value='m';f.el('caddyUnits').onchange();assert.equal(f.el('caddyDistance').value,'6.096');f.el('caddyPromptPutt').onclick();await f.el('caddyPuttRecommend').onclick();assert.equal(f.el('caddyPuttStartDistance').value,'6.096');f.el('caddyPuttResult').value='made';f.el('caddyPuttResult').onchange();await f.el('caddyRecord').onclick();assert.ok(Math.abs(f.persisted[0].throws[0].putting.startDistanceFt-20)<1e-8);
});
test('a putt marked as layup is logged without a made/missed basket attempt assumption',async()=>{
 const f=await puttingUI();pin(f,40);f.el('caddyPromptPutt').onclick();f.el('caddyPuttIntent').value='layup';await f.el('caddyPuttRecommend').onclick();assert.equal(f.el('caddyPuttAttempt').value,'layup');f.el('caddyPuttResult').value='missed';f.el('caddyPuttResult').onchange();f.el('caddyRemaining').value='6';await f.el('caddyRecord').onclick();assert.equal(f.persisted[0].throws[0].putting.intent,'layup');assert.match(f.el('caddyPuttingProfiles').innerHTML,/1 layups/);assert.match(f.el('caddyPuttingProfiles').innerHTML,/0 confirmed attempts/);
});
test('a bag without putters gets a clear message rather than a driver putting recommendation',async()=>{
 const f=await puttingUI({bagCopies:[puttingBag[0]]});pin(f,20);f.el('caddyPromptPutt').onclick();await f.el('caddyPuttRecommend').onclick();assert.match(f.el('caddyPlan').innerHTML,/No putter is available/);assert.equal(f.el('caddyLogPanel').hidden,true);
});
test('changing an actual throw to a putt does not invent its starting distance from a driving plan',async()=>{
 const f=await puttingUI();pin(f,300);await f.el('caddyRecommend').onclick();f.el('caddyActualType').value='putt';f.el('caddyActualType').dispatchEvent(new Event('change'));assert.equal(f.el('caddyPuttFeedback').hidden,false);assert.equal(f.el('caddyPuttStartDistance').value,'');f.el('caddyPuttAttempt').value='attempt';f.el('caddyPuttStartSource').value='estimated';f.el('caddyPuttResult').value='made';f.el('caddyPuttResult').onchange();await f.el('caddyRecord').onclick();assert.equal(f.persisted[0].throws[0].putting.startDistanceFt,null);
});

test('declining the putting prompt and returning from putting keep automatic style comparison',async()=>{
 const f=await puttingUI({player:normalizePlayer({preferredThrow:'forehand'})});pin(f,20);assert.equal(f.el('caddyType').value,'auto');f.el('caddyPromptThrow').onclick();assert.equal(f.el('caddyType').value,'auto');f.el('caddyMarkPutt').onclick();assert.equal(f.el('caddyType').value,'putt');f.el('caddyMarkThrow').onclick();assert.equal(f.el('caddyType').value,'auto');
});

const fillCourse=(f,{number=1,distance=750,par=4}={})=>{for(const [id,value]of Object.entries({caddyCourseName:'QA Riverside',caddyHoleNumber:number,caddyPar:par,caddyDistance:distance,caddyFairway:'left',caddyElevation:'uphill',caddyHazard:'right',caddyHoleNotes:'Blue tee. Creek is OB.'}))f.el(id).value=value;f.el('caddyTrees').checked=true;};
test('My Courses saves hole settings, survives reopening and plays a fresh independent round',async()=>{
 const f=await fixture({bagCopies:[{id:'driver',discId:'innova-teebird',distance:280}]}),opening=f.render();f.gate.resolve();await opening;fillCourse(f);await f.el('caddySaveLayout').onclick();
 assert.equal(f.courses.length,1);assert.equal(f.courses[0].holes[0].distanceFt,750);assert.equal(f.courses[0].holes[0].par,4);assert.equal(f.el('coursePlay').disabled,false);
 await f.el('coursePlay').onclick();assert.equal(f.el('caddyDistance').value,'750');assert.equal(f.el('caddyFairway').value,'left');assert.equal(f.el('caddyElevation').value,'uphill');assert.equal(f.el('caddyHazard').value,'right');assert.equal(f.el('caddyMaxSpeed').value,'9');
 await f.el('caddyQuickRecommend').onclick();assert.equal(f.el('caddyReview').hidden,false);f.el('caddyRemaining').value='470';await f.el('caddyRecord').onclick();assert.equal(f.el('caddyDistance').value,'470');assert.equal(f.courses[0].holes[0].distanceFt,750);assert.equal(f.el('caddy').dataset.step,'setup');
 await f.el('caddySaveLayout').onclick();assert.match(f.el('caddyLayoutStatus').textContent,/tee distance/);
 const saved=f.persisted.find(h=>h.courseId);assert.equal(saved.holeNumber,1);assert.equal(saved.par,4);assert.equal(saved.courseLayout.distanceFt,750);assert.equal(saved.throws.length,1);
 const reopened=await fixture({saved:[saved],savedCourses:f.courses}),ready=reopened.render();reopened.gate.resolve();await ready;assert.equal(reopened.el('courseSelect').value,saved.courseId);assert.equal(reopened.el('courseHoleSelect').value,'1');assert.match(reopened.el('coursePreview').textContent,/750/);assert.equal(reopened.el('caddyDistance').value,'470');
 await reopened.el('coursePlay').onclick();assert.equal(reopened.el('caddyDistance').value,'750');assert.equal(reopened.persisted.filter(h=>h.courseId).length,2);assert.equal(reopened.persisted.find(h=>h.id===saved.id).throws.length,1);
});
test('course meters convert without changing the tee distance and another hole does not overwrite the first',async()=>{
 const f=await fixture(),opening=f.render();f.gate.resolve();await opening;fillCourse(f,{distance:300});f.el('caddyUnits').value='m';f.el('caddyUnits').onchange();assert.ok(Math.abs(Number(f.el('caddyDistance').value)-91.44)<.00001);await f.el('caddySaveLayout').onclick();assert.ok(Math.abs(f.courses[0].holes[0].distanceFt-300)<.00001);fillCourse(f,{number:2,distance:100,par:3});await f.el('caddySaveLayout').onclick();assert.equal(f.courses[0].holes.length,2);assert.ok(Math.abs(f.courses[0].holes[1].distanceFt-100/.3048)<.00001);assert.equal(f.courses[0].holes[0].par,4);
});
test('finishing a course hole enables the next saved hole and keeps the previous log',async()=>{
 const f=await fixture({bagCopies:[{id:'driver',discId:'innova-teebird',distance:280}]}),opening=f.render();f.gate.resolve();await opening;fillCourse(f);await f.el('caddySaveLayout').onclick();fillCourse(f,{number:2,distance:300,par:3});await f.el('caddySaveLayout').onclick();f.el('courseHoleSelect').value='1';f.el('courseHoleSelect').onchange();await f.el('coursePlay').onclick();assert.equal(f.el('courseNext').disabled,true);
 await f.el('caddyQuickRecommend').onclick();f.el('caddyOutcome').value='made';await f.el('caddyRecord').onclick();assert.equal(f.el('courseNext').disabled,true);assert.equal(f.el('caddyDistance').value,'300');assert.equal(f.el('caddyLie').textContent,'THROW 1 · TEE');assert.equal(f.persisted.find(h=>h.courseId&&h.holeNumber===1).status,'finished');assert.equal(f.persisted.find(h=>h.courseId&&h.holeNumber===2).par,3);
});
test('course storage failure never advances or discards the active round',async()=>{
 const f=await fixture(),opening=f.render();f.gate.resolve();await opening;fillCourse(f);await f.el('caddySaveLayout').onclick();const original=f.persisted[0].id;f.fail(true);await f.el('coursePlay').onclick();assert.match(f.el('courseStatus').textContent,/storage unavailable/);assert.equal(f.persisted.length,1);assert.equal(f.persisted[0].id,original);f.fail(false);await f.el('coursePlay').onclick();assert.equal(f.persisted.length,1);assert.equal(f.el('caddyDistance').value,'750');
});

test('course review after bag cleanup requires a real bag copy and then advances correctly',async()=>{
 // Reproduce the browser sequence: an earlier check removed every bag copy.
 const bagCopies=[],savedCourses=[{id:'qa-course',name:'QA Riverside',created:1,updated:1,holes:[{number:1,par:4,distanceFt:750,fairway:'left',elevation:'uphill',hazard:'right',wooded:true,notes:'Creek OB'},{number:2,par:3,distanceFt:290,fairway:'straight',elevation:'level',hazard:'none',wooded:false,notes:''}]}];
 const f=await fixture({bagCopies,savedCourses}),opening=f.render();f.gate.resolve();await opening;
 f.el('courseSelect').value='qa-course';f.el('courseSelect').onchange();f.el('courseHoleSelect').value='1';f.el('courseHoleSelect').onchange();await f.el('coursePlay').onclick();
 assert.equal(f.el('caddyDistance').value,'750');await f.el('caddyQuickRecommend').onclick();
 assert.equal(f.el('caddyLogPanel').hidden,true);assert.match(f.el('caddyStatus').textContent,/Your bag is empty/);assert.ok(!f.el('caddyPlan').innerHTML.includes('data-caddy-choice='));
 // The course smoke scenario must seed its own disc rather than relying on prior tests.
 bagCopies.push({id:'qa-course-driver',discId:'innova-teebird',plastic:'QA course check only',condition:'Stock',distance:280,distanceThrow:'backhand',referenceHand:'right'});
 await f.el('caddyQuickRecommend').onclick();assert.equal(f.el('caddyLogPanel').hidden,false);assert.equal(f.el('caddyUsedDisc').value,'qa-course-driver');assert.match(f.el('caddyPlan').innerHTML,/Innova Teebird|Innova.*TeeBird/);const canonical=DISCS.find(d=>d.id==='innova-teebird');assertCaddySelection({bagId:'qa-course-driver',brand:canonical.brand,model:canonical.model,plastic:'QA course check only'},f.document);
 f.el('caddyRemaining').value='470';await f.el('caddyRecord').onclick();const played=f.persisted.find(h=>h.courseId==='qa-course');assert.equal(played.throws.length,1);assert.equal(played.throws[0].usedBagId,'qa-course-driver');assert.equal(played.draft.distanceFt,470);assert.equal(f.courses[0].holes[0].distanceFt,750);
 await f.el('caddyFinish').onclick();assert.equal(f.el('courseNext').disabled,false);await f.el('courseNext').onclick();assert.equal(f.el('caddyDistance').value,'290');assert.equal(f.el('caddyLie').textContent,'THROW 1 · TEE');
});

test('GPS Save immediately persists a disc-profile entry and feedback updates the same saved throw',async()=>{
 const {throwRecords,discStats}=await import('../dist/lib/disc-history.js'),f=await gpsFixture();await measure(f);await f.el('throwMeasureSave').onclick();
 const pending=f.persisted[0].pendingMeasurement;assert.equal(pending.usedBagId,'test-driver');assert.equal(f.el('caddy').dataset.step,'feedback');assert.equal(discStats(throwRecords(f.persisted),'test-driver').gpsCount,1);assert.equal(discStats(throwRecords(f.persisted),'test-driver').rangeCount,0);
 f.el('caddyRemaining').value='50';await f.el('caddyRecord').onclick();const rows=throwRecords(f.persisted);assert.equal(rows.length,1);assert.equal(rows[0].id,pending.id);assert.equal(rows[0].input.distanceFt,null);assert.equal(rows[0].distanceMethod,'gps');assert.equal(f.el('caddy').dataset.step,'setup');assert.equal(f.persisted[0].pendingMeasurement,null);
});
test('focused task switching hides unrelated setup and keeps the active result editable',async()=>{
 const f=await gpsFixture();assert.equal(f.el('caddy').dataset.step,'setup');assert.equal(f.el('caddyMeasureCard').classList.contains('workflow-off'),true);f.el('caddyDistance').value='300';await f.el('caddyRecommend').onclick();assert.equal(f.el('caddy').dataset.step,'throw');assert.equal(f.el('caddyConditions').classList.contains('workflow-off'),true);f.el('caddyStepFeedback').onclick();assert.equal(f.el('caddyLogPanel').classList.contains('workflow-off'),false);assert.equal(f.el('caddyMeasureCard').classList.contains('workflow-off'),true);
 f.el('caddyActualAngle').value='hyzer';f.el('caddyStepThrow').onclick();f.el('caddyStepFeedback').onclick();assert.equal(f.el('caddyActualAngle').value,'hyzer');
});
test('combined result chips save short plus left and retain both in the disc history',async()=>{
 const f=await gpsFixture();f.el('caddyDistance').value='300';await f.el('caddyRecommend').onclick();for(const id of ['short','left']){f.el('caddyResult_'+id).checked=true;f.el('caddyResult_'+id).dispatchEvent(new Event('change'))}f.el('caddyRemaining').value='80';await f.el('caddyRecord').onclick();assert.deepEqual(Array.from(f.persisted[0].throws[0].outcomes),['short','left']);assert.match(f.el('caddyHistory').innerHTML,/short \+ left/);
});
test('the live setup form adds course holes as played and a made putt opens the next hole',async()=>{
 const f=await gpsFixture();await f.el('caddyAddCourse').onclick();f.el('caddyCourseName').value='On Course';f.el('caddyHoleNumber').value='1';f.el('caddyPar').value='3';f.el('caddyDistance').value='310';f.el('caddyFairway').value='slight-left';await f.el('caddyRecommend').onclick();assert.equal(f.courses.length,1);assert.equal(f.courses[0].holes[0].distanceFt,310);assert.equal(f.courses[0].holes[0].fairway,'slight-left');
 f.el('caddyOutcome').value='made';f.el('caddyOutcome').onchange();assert.match(f.el('caddyRecord').textContent,/next hole/);await f.el('caddyRecord').onclick();assert.equal(f.el('caddyHoleNumber').value,'2');assert.equal(f.el('caddyDistance').value,'');f.el('caddyDistance').value='420';f.el('caddyFairway').value='right-left';f.el('caddyPar').value='4';await f.el('caddyRecommend').onclick();assert.equal(f.courses[0].holes.length,2);assert.equal(f.courses[0].holes[1].par,4);assert.equal(f.courses[0].holes[0].distanceFt,310);assert.equal(f.persisted.find(h=>h.holeNumber===1&&h.courseName==='On Course').status,'finished');
});
test('typed OCR suggestions fill the shared setup fields including par and slight dogleg',async()=>{
 const f=await gpsFixture();f.el('caddySignText').value='Hole 8 Par 4 Blue 320 ft Slight dogleg right OB left';f.el('caddyParseSign').onclick();f.el('caddySignDistance').value='0';f.el('caddyApplySign').onclick();await f.render();assert.equal(f.el('caddyDistance').value,'320');assert.equal(f.el('caddyHoleNumber').value,'8');assert.equal(f.el('caddyPar').value,'4');assert.equal(f.el('caddyFairway').value,'slight-right');assert.equal(f.el('caddyHazard').value,'left');assert.equal(f.el('caddy').dataset.step,'setup');
});

test('each new sign asks to keep the last tee setup and allows alternating on the next hole',async()=>{
 const course={id:'course-pref',name:'Preference Course',created:1,updated:1,signPreferences:{teeLabel:'Long',basketLabel:''},holes:[{number:1,par:3,distanceFt:355,fairway:'straight',elevation:'level',hazard:'none'},{number:2,par:3,distanceFt:405,fairway:'straight',elevation:'level',hazard:'none'}]},f=await gpsFixture({savedCourses:[course]});
 f.el('courseSelect').value=course.id;f.el('courseSelect').onchange();f.el('courseHoleSelect').value='1';await f.el('coursePlay').onclick();f.el('caddySignText').value='Hole 1 Par 3 Long 350 ft Short 240 ft';f.el('caddyParseSign').onclick();assert.equal(f.el('caddySignPreference').hidden,false);assert.match(f.el('caddySignPreferenceQuestion').textContent,/Long/);
 f.el('caddyApplySign').onclick();assert.equal(f.el('caddyDistance').value,'355');f.el('caddySignKeep').onclick();assert.equal(f.el('caddyDistance').value,'350');assert.equal(f.el('caddySignPreference').hidden,true);
 await f.el('caddyFinish').onclick();await f.el('courseNext').onclick();f.el('caddySignText').value='Hole 2 Par 3 Long 400 ft Short 250 ft';f.el('caddyParseSign').onclick();assert.equal(f.el('caddySignPreference').hidden,false);f.el('caddySignChange').onclick();f.el('caddySignTee').value='1';await f.el('caddySignTee').onchange();f.el('caddyApplySign').onclick();assert.equal(f.el('caddyDistance').value,'250');
});

test('a saved measurement stays with its actual disc and forehand style after a new recommendation',async()=>{
 const f=await gpsFixture({bagCopies:[{id:'driver',discId:'innova-teebird',distance:280},{id:'putter',discId:'innova-aviar',distance:180}]}),history=await import('../dist/lib/disc-history.js');f.el('caddyDistance').value='300';await f.el('caddyRecommend').onclick();assert.equal(f.el('caddyMeasureDisc').value,f.el('caddyUsedDisc').value);
 f.el('caddyMeasureDisc').value='putter';f.el('caddyActualType').value='forehand';f.el('caddyActualAngle').value='flat';await measure(f);await f.el('throwMeasureSave').onclick();const id=f.persisted[0].pendingMeasurement.id;assert.equal(f.persisted[0].pendingMeasurement.usedBagId,'putter');assert.equal(f.persisted[0].pendingMeasurement.actualShot.type,'forehand');await f.el('caddyRecommend').onclick();assert.equal(f.el('caddyUsedDisc').value,'putter');assert.equal(f.el('caddyActualType').value,'forehand');f.el('caddyRemaining').value='40';await f.el('caddyRecord').onclick();const rows=history.throwRecords(f.persisted);assert.equal(rows.length,1);assert.equal(rows[0].id,id);assert.equal(rows[0].usedBagId,'putter');assert.equal(rows[0].actualShot.type,'forehand');
});

test('finishing a hole cannot silently discard an already saved measured throw',async()=>{const f=await gpsFixture();await measure(f);await f.el('throwMeasureSave').onclick();const id=f.persisted[0].pendingMeasurement.id;await f.el('caddyFinish').onclick();assert.equal(f.persisted[0].status,'open');assert.equal(f.persisted[0].pendingMeasurement.id,id);assert.equal(f.el('caddy').dataset.step,'feedback')});

test('quick measure and Log this throw expose one task while retaining the selected physical copy',async()=>{
 const f=await fixture({bagCopies:[{id:'one',discId:'innova-teebird',distance:280,plastic:'Star'},{id:'two',discId:'discraft-buzzz',plastic:'Fuzed Z · BuzzzSaw'}]}),opening=f.render();f.gate.resolve();await opening;
 assert.equal(f.el('caddyQuickTools').inert,false);f.el('caddyStartManual').onclick();assert.equal(f.el('caddy').dataset.step,'throw');assert.equal(f.el('caddyConditions').inert,true);assert.equal(f.el('caddyThrowActions').inert,false);
 f.el('caddyMeasureDisc').value='two';f.el('caddyMeasureDisc').dispatchEvent(new Event('change'));assert.match(f.el('caddySelectedDisc').textContent,/Buzzz.*BuzzzSaw/);f.el('caddyLogThrow').onclick();assert.equal(f.el('caddy').dataset.step,'feedback');assert.equal(f.el('caddyUsedDisc').value,'two');assert.equal(f.el('caddyMeasureCard').inert,true);assert.equal(f.el('caddyLogPanel').inert,false);
 f.el('caddyEditPlan').onclick();assert.equal(f.el('caddy').dataset.step,'setup');assert.equal(f.el('caddyQuickTools').inert,false);
});
test('reopening a saved measured throw restores its result task and completes the same disc record',async()=>{
 const first=await gpsFixture();await measure(first);await first.el('throwMeasureSave').onclick();const pending=structuredClone(first.persisted[0]),id=pending.pendingMeasurement.id;
 const f=await fixture({saved:[pending],bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:280}]}),opening=f.render();f.gate.resolve();await opening;
 assert.equal(f.el('caddy').dataset.step,'feedback');assert.equal(f.el('caddyLogPanel').hidden,false);assert.equal(f.el('caddyLogPanel').inert,false);assert.equal(f.el('caddyUsedDisc').value,'test-driver');assert.equal(f.el('caddyDistanceMethod').value,'gps');assert.match(f.el('caddyTaskStatus').textContent,/measured throw is saved/);
 f.el('caddyRemaining').value='50';await f.el('caddyRecord').onclick();assert.equal(f.persisted[0].throws.length,1);assert.equal(f.persisted[0].throws[0].id,id);assert.equal(f.persisted[0].pendingMeasurement,null);
});
test('empty-bag planning and refreshed stale tasks return to a visible, usable setup',async()=>{
 const f=await fixture(),opening=f.render();f.gate.resolve();await opening;f.el('caddyDistance').value='250';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();assert.equal(f.el('caddy').dataset.step,'setup');assert.match(f.el('caddyTaskStatus').textContent,/bag is empty/);f.el('caddyStepThrow').onclick();await f.render();assert.equal(f.el('caddy').dataset.step,'setup');assert.equal(f.el('caddyConditions').inert,false);
});
test('collapsed wind and trouble summaries expose selected conditions without opening all settings',async()=>{
 const f=await fixture(),opening=f.render();f.gate.resolve();await opening;f.el('caddyWindDirection').value='head';f.el('caddyWindMph').value='12';f.el('caddyHazard').value='left';f.el('caddyLanding').value='180';f.el('caddyStepSetup').onclick();assert.match(f.el('caddyWindSummary').textContent,/Headwind.*12 mph/);assert.match(f.el('caddyOptionsSummary').textContent,/landing 180 ft.*trouble left/);
});

test('mapped course review clears unknown lie fields, retains attribution and saves a confirmed layout',async()=>{
 const {importedCourse,osmSource}=await import('../dist/lib/course-directory.js'),mapped={key:'way/200',number:1,label:'Hole 1 · Blue tee',par:null,distanceFt:300,geometryDistanceFt:310,route:[],association:'nearby',source:osmSource('way/200')},course=importedCourse({name:'Mapped QA',source:osmSource('node/100',{snapshotAt:'2026-10-23T12:00:00Z'}),layouts:[mapped]});
 const f=await fixture({savedCourses:[course],bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:280}]}),opening=f.render();f.gate.resolve();await opening;f.el('courseSelect').value=course.id;f.el('courseSelect').onchange();f.el('courseHoleSelect').value='osm-way-200';await f.el('coursePlay').onclick();
 assert.equal(f.el('caddyPar').value,'');assert.equal(f.el('caddyDistance').value,'300');assert.equal(f.el('caddyFairway').value,'');assert.equal(f.el('caddyElevation').value,'');assert.equal(f.el('caddyHazard').value,'');assert.match(f.el('courseSourceNotice').textContent,/OpenStreetMap.*ODbL/);
 await f.el('caddyRecommend').onclick();assert.equal(f.el('caddy').dataset.step,'setup');assert.match(f.el('caddyStatus').textContent,/par/);f.el('caddyPar').value='3';f.el('caddyFairway').value='straight';f.el('caddyElevation').value='level';f.el('caddyHazard').value='none';await f.el('caddyRecommend').onclick();assert.equal(f.el('caddy').dataset.step,'throw');assert.equal(f.courses[0].holes[0].source.osmKey,'way/200');assert.equal(f.courses[0].holes[0].distanceFt,300);
});
test('an imported name-only course can add a hole without changing the preceding course log',async()=>{
 const {importedCourse,osmSource}=await import('../dist/lib/course-directory.js'),c=importedCourse({name:'Map without holes',source:osmSource('node/101'),layouts:[]});const f=await fixture({savedCourses:[c]}),opening=f.render();f.gate.resolve();await opening;const oldId=f.persisted[0].id;f.el('courseSelect').value=c.id;f.el('courseSelect').onchange();await f.el('courseAddHole').onclick();assert.equal(f.el('caddyCourseName').value,c.name);assert.equal(f.persisted.length,2);assert.equal(f.persisted.find(v=>v.id===oldId).courseId,undefined);f.el('caddyDistance').value='275';f.el('caddyFairway').value='straight';await f.el('caddySaveLayout').onclick();assert.equal(f.courses.length,1);assert.equal(f.courses[0].id,c.id);assert.equal(f.courses[0].holes[0].distanceFt,275);
});
test('UDisc reference saving validates the URL and leaves course facts unchanged',async()=>{
 const {saveCourseHole}=await import('../dist/lib/courses.js');const c=saveCourseHole(null,'Reference QA',{number:1,par:3,distanceFt:300,fairway:'straight',elevation:'level',hazard:'none'}),f=await fixture({savedCourses:[c]}),opening=f.render();f.gate.resolve();await opening;f.el('courseSelect').value=c.id;f.el('courseSelect').onchange();f.el('courseUDiscUrl').value='https://udisc.com/courses/example?tracking=true';await f.el('courseSaveUDisc').onclick();assert.equal(f.courses[0].udiscUrl,'https://udisc.com/courses/example');assert.equal(f.courses[0].holes[0].distanceFt,300);assert.equal(f.el('courseOpenUDisc').href,'https://udisc.com/courses/example');f.el('courseUDiscUrl').value='https://udisc.com/api/course';await f.el('courseSaveUDisc').onclick();assert.match(f.el('courseStatus').textContent,/course-page/);assert.equal(f.courses[0].udiscUrl,'https://udisc.com/courses/example');
});

test('after a made shot multiple mapped tee routes ask for the next choice instead of assuming one',async()=>{
 const {importedCourse,osmSource}=await import('../dist/lib/course-directory.js'),{saveCourseHole}=await import('../dist/lib/courses.js');let c=importedCourse({name:'Two tees QA',source:osmSource('node/103'),layouts:[201,202].map((id,i)=>({key:'way/'+id,number:2,label:'Hole 2 '+(i?'Blue':'Red'),par:3,distanceFt:i?400:300,geometryDistanceFt:null,route:[],association:'relation',source:osmSource('way/'+id)}))});c=saveCourseHole(c,c.name,{number:1,par:3,distanceFt:250,fairway:'straight',elevation:'level',hazard:'none'});const f=await fixture({savedCourses:[c],bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:280}]}),opening=f.render();f.gate.resolve();await opening;f.el('courseSelect').value=c.id;f.el('courseSelect').onchange();f.el('courseHoleSelect').value='1';await f.el('coursePlay').onclick();await f.el('caddyRecommend').onclick();f.el('caddyOutcome').value='made';await f.el('caddyRecord').onclick();assert.equal(f.el('caddyHoleNumber').value,'2');assert.equal(f.el('caddyDistance').value,'');assert.equal(f.el('caddyCoursesCard').open,true);assert.equal(f.el('courseHoleSelect').value,'');assert.match(f.el('courseStatus').textContent,/Choose the tee.*route for hole 2/);
});


test('the exact serialized browser guard accepts the canonical catalog name after a real recommendation',async()=>{
 const disc=DISCS.find(d=>d.id==='innova-teebird'),item={id:'qa-course-driver',discId:disc.id,plastic:'QA course check only',distance:280},f=await fixture({bagCopies:[item]}),opening=f.render();f.gate.resolve();await opening;f.el('caddyDistance').value='750';f.el('caddyFairway').value='left';await f.el('caddyQuickRecommend').onclick();
 const expected={bagId:item.id,brand:disc.brand,model:disc.model,plastic:item.plastic},expression='('+assertCaddySelection.toString()+')('+JSON.stringify(expected)+')';
 assert.equal(vm.runInNewContext(expression,{document:f.document}),true);assert.equal(f.el('caddy').dataset.step,'throw');
 f.el('caddySelectedDisc').textContent='';assert.throws(()=>vm.runInNewContext(expression,{document:f.document}),/summary mismatch.*received ""/);
});
test('the browser guard detects a different physical copy even when its mold name is identical',async()=>{
 const disc=DISCS.find(d=>d.id==='innova-teebird'),f=await fixture({bagCopies:[{id:'first-copy',discId:disc.id,plastic:'Star',distance:280},{id:'second-copy',discId:disc.id,plastic:'Champion',distance:260}]}),opening=f.render();f.gate.resolve();await opening;f.el('caddyDistance').value='275';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();
 f.el('caddyMeasureDisc').value='second-copy';f.el('caddyMeasureDisc').dispatchEvent(new Event('change'));const expected={bagId:'second-copy',brand:disc.brand,model:disc.model,plastic:'Champion'};assert.equal(assertCaddySelection(expected,f.document),true);
 f.el('caddyMeasureDisc').value='first-copy';assert.throws(()=>assertCaddySelection(expected,f.document),/bag copy mismatch/);f.el('caddyMeasureDisc').value='second-copy';f.el('caddySelectedDisc').textContent='Throwing: '+disc.brand+' '+disc.model+' · Star';assert.throws(()=>assertCaddySelection(expected,f.document),/summary mismatch/);
});
test('camera walk estimate saves immediately to the selected physical disc and final feedback keeps the same record',async()=>{const f=await gpsFixture();let opens=0;f.window.AndroidFiles={measureWithCamera(id,mode){opens++;f.window.dispatchEvent(new CustomEvent('fairway-camera-range',{detail:{id,mode,meters:90}}))}};await f.el('cameraThrow').onclick();const draft=f.persisted[0].pendingMeasurement;assert.ok(draft);assert.equal(draft.usedBagId,'test-driver');assert.equal(draft.distanceMethod,'estimated');assert.equal(draft.distanceCamera.provider,'ARCore');assert.match(f.el('caddyMeasuredCarry').textContent,/camera estimate/);assert.equal(f.el('caddyDistanceMethod').value,'estimated');f.el('caddyRemaining').value='30';await f.el('caddyRecord').onclick();const entry=f.persisted[0].throws[0];assert.equal(entry.id,draft.id);assert.equal(entry.distanceCamera.mode,'walk');assert.equal(entry.usedBagId,'test-driver');assert.equal(entry.distanceMethod,'estimated');assert.equal(f.persisted[0].pendingMeasurement,null);await f.el('feedbackCameraThrow').onclick();assert.equal(opens,2);assert.equal(f.persisted[0].pendingMeasurement.throwNumber,2);assert.notEqual(f.persisted[0].pendingMeasurement.id,entry.id)});
test('camera basket estimate populates only the active pin distance and invites putting without recording a throw',async()=>{const f=await gpsFixture();f.window.AndroidFiles={measureWithCamera(id,mode){f.window.dispatchEvent(new CustomEvent('fairway-camera-range',{detail:{id,mode,meters:5}}))}};await f.el('cameraPin').onclick();assert.equal(Number(f.el('caddyDistance').value),16.4);assert.equal(f.el('caddyPuttingPrompt').hidden,false);assert.equal(f.persisted[0].pendingMeasurement,undefined);assert.equal(f.persisted[0].throws.length,0)});
test('camera cancellation and storage failure never claim a distance was saved to a disc',async()=>{const f=await gpsFixture();f.window.AndroidFiles={measureWithCamera(id){f.window.dispatchEvent(new CustomEvent('fairway-camera-range',{detail:{id,cancelled:true}}))}};await f.el('cameraThrow').onclick();assert.match(f.el('cameraRangeStatus').textContent,/cancelled/);assert.equal(f.persisted[0].pendingMeasurement,undefined);f.fail(true);f.window.AndroidFiles={measureWithCamera(id,mode){f.window.dispatchEvent(new CustomEvent('fairway-camera-range',{detail:{id,mode,meters:50}}))}};await f.el('cameraThrow').onclick();assert.match(f.el('cameraRangeStatus').textContent,/could not be saved/);assert.equal(f.persisted[0].pendingMeasurement,undefined);assert.equal(f.el('cameraThrow').disabled,false)});
test('a short throw overwhelmed by GPS uncertainty cannot populate or save a disc-profile distance',async()=>{const points=[gpsStart,{...gpsEnd,longitude:.000054}],f=await gpsFixture({capture:async()=>points.shift()});await f.el('throwMeasureAction').onclick();await f.el('throwMeasureAction').onclick();assert.equal(f.el('throwMeasureSave').disabled,true);assert.equal(f.el('feedbackMeasureSave').disabled,true);assert.match(f.el('throwMeasureResult').textContent,/Save is blocked/);await f.el('feedbackMeasureSave').onclick();assert.equal(f.persisted[0].pendingMeasurement,undefined)});

const settled=async check=>{for(let i=0;i<80;i++){if(check())return;await new Promise(r=>setTimeout(r,5))}assert.ok(check(),'Caddy action did not settle')};
test('adding a named course saves an unfinished hole, then the shared setup autosaves without recommending',async()=>{
 const f=await gpsFixture();f.el('caddyCourseName').value='Build As You Play';await f.el('caddyAddCourse').onclick();assert.equal(f.courses.length,1);assert.equal(f.courses[0].holes.length,0);assert.equal(f.courses[0].draftHoles[0].number,1);assert.match(f.el('caddyLayoutStatus').textContent,/setup in progress/);
 f.el('caddyDistance').value='325';f.el('caddyDistance').dispatchEvent(new Event('input'));for(const [id,value]of Object.entries({caddyPar:4,caddyFairway:'slight-left',caddyElevation:'uphill',caddyHazard:'left',caddyHoleNotes:'Creek beyond basket'})){f.el(id).value=value;f.el(id).dispatchEvent(new Event('change'))}
 await settled(()=>f.courses[0].holes.length===1);assert.equal(f.courses[0].holes[0].distanceFt,325);assert.equal(f.courses[0].holes[0].par,4);assert.equal(f.courses[0].holes[0].fairway,'slight-left');assert.equal(f.courses[0].holes[0].notes,'Creek beyond basket');assert.equal(f.courses[0].draftHoles.length,0);assert.equal(f.el('caddyPlan').innerHTML,'');assert.equal(f.el('caddyCourseName').value,'Build As You Play');
});
test('partial hole setup survives reopening and can be completed later',async()=>{
 const f=await gpsFixture();f.el('caddyCourseName').value='Half Done';await f.el('caddyAddCourse').onclick();f.el('caddyElevation').value='';f.el('caddyHazard').value='';f.el('caddyDistance').value='280';f.el('caddyDistance').dispatchEvent(new Event('input'));await f.render();
 assert.equal(f.courses[0].holes.length,0);assert.equal(f.courses[0].draftHoles[0].distanceFt,280);const reopened=await gpsFixture({saved:f.persisted,savedCourses:f.courses});assert.equal(reopened.el('caddyCourseName').value,'Half Done');assert.equal(reopened.el('caddyDistance').value,'280');assert.equal(reopened.el('caddyElevation').value,'');assert.equal(reopened.el('caddyHazard').value,'');reopened.el('caddyElevation').value='level';reopened.el('caddyHazard').value='none';await reopened.el('caddySaveLayout').onclick();assert.equal(reopened.courses[0].holes[0].distanceFt,280);
});
test('course-name suggestions select a saved course and changing the inline hole recalls that hole',async()=>{
 const c={id:'local-course',name:'Riverside Park',created:1,updated:1,holes:[{number:1,par:4,distanceFt:500,fairway:'left',elevation:'uphill',hazard:'right'},{number:2,par:3,distanceFt:290,fairway:'straight',elevation:'level',hazard:'none'}]},f=await gpsFixture({savedCourses:[c]});
 f.el('caddyCourseName').value='Riversde';f.el('caddyCourseName').dispatchEvent(new Event('input'));assert.match(f.el('caddyCourseMatches').innerHTML,/Riverside Park/);assert.equal(f.el('caddyCourseMatches').hidden,false);const arrow=new Event('keydown');Object.defineProperty(arrow,'key',{value:'ArrowDown'});f.el('caddyCourseName').dispatchEvent(arrow);const enter=new Event('keydown');Object.defineProperty(enter,'key',{value:'Enter'});f.el('caddyCourseName').dispatchEvent(enter);await settled(()=>f.el('caddyCourseName').value==='Riverside Park');assert.equal(f.el('caddyDistance').value,'500');assert.equal(f.el('caddyPar').value,'4');assert.equal(f.courses.length,1);
 f.el('caddyHoleNumber').value='2';f.el('caddyHoleNumber').dispatchEvent(new Event('change'));await settled(()=>f.el('caddyDistance').value==='290');assert.equal(f.el('caddyPar').value,'3');assert.equal(f.el('caddyFairway').value,'straight');assert.equal(f.courses[0].holes[0].distanceFt,500);
});
test('new inline hole saves into the same course and later lies cannot replace its tee layout',async()=>{
 const f=await gpsFixture();fillCourse(f,{distance:450});await f.el('caddySaveLayout').onclick();const id=f.courses[0].id;f.el('caddyHoleNumber').value='2';f.el('caddyHoleNumber').dispatchEvent(new Event('change'));await settled(()=>f.el('caddyDistance').value==='');assert.equal(f.el('caddyCourseName').value,'QA Riverside');f.el('caddyDistance').value='320';f.el('caddyFairway').value='right';f.el('caddyElevation').value='level';f.el('caddyHazard').value='none';f.el('caddyDistance').dispatchEvent(new Event('input'));await f.el('caddyRecommend').onclick();assert.equal(f.courses.length,1);assert.equal(f.courses[0].id,id);assert.equal(f.courses[0].holes[1].distanceFt,320);
 f.el('caddyRemaining').value='90';await f.el('caddyRecord').onclick();f.el('caddyDistance').value='85';f.el('caddyFairway').value='left';f.el('caddyPar').value='4';f.el('caddyPar').dispatchEvent(new Event('change'));await f.render();assert.equal(f.courses[0].holes[1].distanceFt,320);assert.equal(f.courses[0].holes[1].fairway,'right');assert.equal(f.courses[0].holes[1].par,4);assert.equal(f.el('caddyDistance').value,'85');
});
test('course autosave failure is visible and retry retains entered hole details',async()=>{
 const f=await gpsFixture();f.el('caddyCourseName').value='Save Retry';await f.el('caddyAddCourse').onclick();f.fail(true);f.el('caddyDistance').value='333';f.el('caddyDistance').dispatchEvent(new Event('input'));await f.el('caddySaveLayout').onclick();assert.match(f.el('caddyLayoutStatus').textContent,/QA storage unavailable/);assert.equal(f.el('caddyDistance').value,'333');assert.equal(f.courses[0].holes.length,0);f.fail(false);await f.el('caddySaveLayout').onclick();assert.equal(f.courses[0].holes[0].distanceFt,333);
});
test('course changes cannot discard a measured throw and practice keeps saved courses intact',async()=>{
 const f=await gpsFixture();fillCourse(f,{distance:300});await f.el('caddySaveLayout').onclick();await measure(f);await f.el('throwMeasureSave').onclick();await f.el('caddyPractice').onclick();assert.match(f.el('caddyLayoutStatus').textContent,/Finish this measured throw/);assert.ok(f.persisted[0].pendingMeasurement);assert.equal(f.el('caddyCourseName').value,'QA Riverside');
 f.el('caddyRemaining').value='20';await f.el('caddyRecord').onclick();await f.el('caddyPractice').onclick();assert.equal(f.el('caddyCourseName').value,'');assert.equal(f.courses[0].holes[0].distanceFt,300);assert.equal(f.persisted.find(h=>h.courseName==='QA Riverside').throws.length,1);
});

test('queued autosaves keep the newest hole fields and never duplicate the course',async()=>{
 const f=await gpsFixture();fillCourse(f,{distance:300});await f.el('caddySaveLayout').onclick();const id=f.courses[0].id,gate=f.pauseNextWrite();f.el('caddyDistance').value='350';const first=f.el('caddySaveLayout').onclick();await new Promise(r=>setImmediate(r));f.el('caddyDistance').value='400';f.el('caddyFairway').value='right';const second=f.el('caddySaveLayout').onclick();gate.resolve();await Promise.all([first,second]);assert.equal(f.courses.length,1);assert.equal(f.courses[0].id,id);assert.equal(f.courses[0].holes[0].distanceFt,400);assert.equal(f.courses[0].holes[0].fairway,'right');assert.equal(f.el('caddyDistance').value,'400');assert.equal(f.persisted.find(h=>h.id===f.persisted[0].id).draft.distanceFt,400);
});
test('adding an exact saved name with different case recalls its canonical course instead of duplicating it',async()=>{
 const c={id:'existing-case',name:'Saint Jérôme',created:1,updated:1,holes:[{number:1,par:3,distanceFt:280,fairway:'straight',elevation:'level',hazard:'none'}]},f=await gpsFixture({savedCourses:[c]});f.el('caddyCourseName').value='saint jerome';await f.el('caddyAddCourse').onclick();assert.equal(f.courses.length,1);assert.equal(f.courses[0].name,'Saint Jérôme');assert.equal(f.el('caddyCourseName').value,'Saint Jérôme');assert.equal(f.el('caddyDistance').value,'280');
});

test('the setup removes throw-style, release and power questions and upgrades old draft locks',async()=>{
 for(const id of ['caddyType','caddyReleaseAngle','caddyEffort'])assert.match(html,new RegExp('<input type="hidden" id="'+id+'"'));
 const saved=makeHole();Object.assign(saved.draft,{type:'forehand',releaseAngle:'anhyzer',effort:'firm'});
 const f=await fixture({saved:[saved],bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:300,alternateDistance:220}]}),opening=f.render();f.gate.resolve();await opening;
 assert.equal(f.el('caddyType').value,'auto');f.el('caddyDistance').value='210';f.el('caddyFairway').value='right';await f.el('caddyRecommend').onclick();
 assert.equal(f.persisted[0].draft.type,'auto');assert.equal(f.persisted[0].draft.releaseAngle,'auto');assert.equal(f.persisted[0].draft.effort,'stock');assert.equal(f.el('caddyActualType').value,'forehand');
});
test('recommended power is visible but only confirmed actual effort enters the throw history',async()=>{
 const f=await fixture({bagCopies:[{id:'test-driver',discId:'innova-teebird',distance:300}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='230';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();
 assert.match(f.el('caddyPlan').innerHTML,/caddy-power/);assert.match(f.el('caddyPlan').innerHTML,/65–80% effort/);assert.equal(f.el('caddyActualEffort').value,'unknown');
 f.el('caddyActualEffort').value='easy';f.el('caddyActualAngle').value='flat';f.el('caddyActualDistance').value='180';f.el('caddyRemaining').value='50';await f.el('caddyRecord').onclick();
 const t=f.persisted[0].throws[0];assert.equal(t.actualShot.effort,'easy');assert.equal(t.plannedShot.effort,'stock');assert.equal(t.recommendations[0].power.effort,'stock');assert.equal(f.el('caddyType').value,'auto');await f.render();assert.equal(f.persisted[0].throws[0].actualShot.effort,'easy');
});
test('Advanced enables a hyzer-flip while the same lower-skill bag gets a simple release',async()=>{
 for(const skill of ['beginner','advanced']){
  const f=await fixture({player:normalizePlayer({skill}),bagCopies:[{id:'test-driver',discId:'innova-leopard',distance:300}]}),opening=f.render();f.gate.resolve();await opening;
  f.el('caddyDistance').value='220';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();
  if(skill==='beginner')assert.doesNotMatch(f.el('caddyPlan').innerHTML,/caddy-shot-label"><b>Hyzer-flip/);
  else assert.match(f.el('caddyPlan').innerHTML,/Hyzer-flip option/);
 }
});

test('a shorter forehand gets a visible placement option and its own planned distance',async()=>{
 const f=await fixture({player:normalizePlayer({skill:'intermediate',averageBackhandFt:300,averageForehandFt:150}),bagCopies:[{id:'under',discId:'innova-mamba',distance:320},{id:'control',discId:'innova-teebird',distance:300,alternateDistance:150},{id:'approach',discId:'discraft-zone',distance:230,alternateDistance:130}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='350';f.el('caddyFairway').value='right';await f.el('caddyRecommend').onclick();
 assert.equal(f.el('caddyActualType').value,'forehand');assert.match(f.el('caddySelectedShot').textContent,/forehand.*placement/);assert.match(f.el('caddyPlan').innerHTML,/Placement option/);assert.equal(f.el('caddyRemaining').value,'');assert.equal(f.el('caddyActualDistance').value,'');
 f.el('caddyActualDistance').value='120';f.el('caddyActualEffort').value='stock';await f.el('caddyRecord').onclick();
 const t=f.persisted[0].throws[0];assert.equal(t.plannedShot.type,'forehand');assert.ok(t.plannedTargetFt<=150);assert.equal(t.input.distanceFt,350);assert.equal(t.input.landingFt,t.plannedTargetFt);assert.equal(t.throwDistanceFt,120);assert.equal(t.remainingFt,null);assert.equal(f.el('caddyDistance').value,'');
});

test('layout notes reach the planner and water behind the pin changes the target and power',async()=>{
 const f=await fixture({bagCopies:[{id:'fairway',discId:'innova-teebird',distance:260},{id:'mid',discId:'discraft-buzzz',distance:230}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='250';f.el('caddyFairway').value='straight';f.el('caddyHoleNotes').value='Water just past basket. Hard ground.';f.el('caddyHoleNotes').dispatchEvent(new Event('input'));await f.el('caddyRecommend').onclick();
 const shownTarget=Number(f.el('caddyPlan').innerHTML.match(/data-landing-ft="([\d.]+)"/)[1]);assert.ok(shownTarget>0&&shownTarget<250);assert.match(f.el('caddyPlan').innerHTML,/data-landing-target/);
 assert.match(f.el('caddyPlan').innerHTML,/Layout details/);assert.match(f.el('caddyPlan').innerHTML,/Leave room for the miss/);assert.doesNotMatch(f.el('caddyPlan').innerHTML,/80–90% effort/);assert.equal(f.el('caddyRemaining').value,'');assert.equal(f.el('caddyActualDistance').value,'');assert.match(f.el('caddyNotesStatus').textContent,/Hazard beyond/);
 f.el('caddyRemaining').value='40';await f.el('caddyRecord').onclick();const t=f.persisted[0].throws[0];assert.equal(t.input.layoutNotes,'Water just past basket. Hard ground.');assert.equal(t.input.hazard,'long');assert.ok(t.plannedTargetFt<250);assert.equal(t.plannedTargetFt,shownTarget);
});
test('Clear layout notes survives reopening and updates that saved course hole only',async()=>{
 const f=await fixture({bagCopies:[{id:'driver',discId:'innova-teebird',distance:280}],savedCourses:[{id:'qa-clear',name:'QA Clear',created:1,updated:1,holes:[{number:1,par:3,distanceFt:250,fairway:'straight',elevation:'level',hazard:'none',wooded:false,notes:'Water behind basket.'},{number:2,par:3,distanceFt:300,fairway:'right',elevation:'level',hazard:'left',wooded:false,notes:'Keep hole two notes.'}]}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyCourseName').value='QA Clear';f.el('caddyCourseName').dispatchEvent(new Event('change'));await f.el('caddySaveLayout').onclick();await f.render();
 // Select the existing saved hole through the same course controls used on a phone.
 f.el('courseSelect').value='qa-clear';f.el('courseSelect').onchange();f.el('courseHoleSelect').value='1';f.el('courseHoleSelect').onchange();await f.el('coursePlay').onclick();
 assert.equal(f.el('caddyHoleNotes').value,'Water behind basket.');f.el('caddyClearLayoutNotes').onclick();await f.flush();await f.render();assert.equal(f.el('caddyHoleNotes').value,'');assert.equal(f.el('caddyClearLayoutNotes').disabled,true);const course=f.courses.find(c=>c.id==='qa-clear');assert.equal(course.holes.find(h=>h.number===1).notes,'');assert.equal(course.holes.find(h=>h.number===2).notes,'Keep hole two notes.');
});
test('Clear throw notes changes only the current feedback text, preserving distance and old notes',async()=>{
 const saved=makeHole();saved.throws=[{id:'old-note',number:1,input:{type:'backhand',distanceFt:300},actualShot:{type:'backhand',hand:'right',releaseAngle:'flat'},usedBagId:'driver',outcome:'short',remainingFt:230,notes:'Keep the old throw note.',recommendations:[]}];saved.draft.distanceFt=230;
 const f=await fixture({saved:[saved],bagCopies:[{id:'driver',discId:'innova-teebird',distance:280}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='230';f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();f.el('caddyThrowNotes').value='Erase this draft';f.el('caddyActualDistance').value='190';f.el('caddyClearThrowNotes').onclick();assert.equal(f.el('caddyActualDistance').value,'190');assert.equal(f.el('caddyThrowNotes').value,'');f.el('caddyRemaining').value='40';await f.el('caddyRecord').onclick();assert.equal(f.persisted[0].throws[0].notes,'Keep the old throw note.');assert.equal(f.persisted[0].throws[1].notes,'');
});
test('blocked forehand and corner notes are interpreted without changing the stored dropdown',async()=>{
 const f=await fixture({bagCopies:[{id:'driver',discId:'innova-teebird',distance:300,alternateDistance:150}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='350';f.el('caddyFairway').value='left';f.el('caddyHoleNotes').value='Straight for 200 ft then dogleg right. Forehand blocked.';f.el('caddyHoleNotes').dispatchEvent(new Event('input'));await f.el('caddyRecommend').onclick();assert.equal(f.el('caddyActualType').value,'backhand');assert.match(f.el('caddyPlan').innerHTML,/Before the bend/);assert.match(f.el('caddyPlan').innerHTML,/uses the notes/);assert.equal(f.el('caddyFairway').value,'left');
});
test('current-lie note edits are distinguished from inherited tee route distances',async()=>{
 const f=await fixture({bagCopies:[{id:'driver',discId:'innova-teebird',distance:300}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='350';f.el('caddyFairway').value='straight';f.el('caddyHoleNotes').value='Corner at 200 ft.';f.el('caddyHoleNotes').dispatchEvent(new Event('input'));await f.el('caddyRecommend').onclick();f.el('caddyRemaining').value='240';await f.el('caddyRecord').onclick();f.el('caddyFairway').value='straight';await f.el('caddyRecommend').onclick();assert.match(f.el('caddyPlan').innerHTML,/new lie/);
 f.el('caddyHoleNotes').value='Corner at 180 ft.';f.el('caddyHoleNotes').dispatchEvent(new Event('input'));await f.el('caddyRecommend').onclick();assert.match(f.el('caddyPlan').innerHTML,/Before the bend/);assert.equal(f.persisted[0].draft.layoutNotesCurrent,true);
});
test('raw layout-note markup is escaped in the visible interpretation',async()=>{
 const f=await fixture({bagCopies:[{id:'driver',discId:'innova-teebird',distance:300}]}),opening=f.render();f.gate.resolve();await opening;f.el('caddyDistance').value='250';f.el('caddyFairway').value='straight';f.el('caddyHoleNotes').value='Water behind basket. <script>run()</script>';await f.el('caddyRecommend').onclick();assert.match(f.el('caddyPlan').innerHTML,/&lt;script&gt;/);assert.doesNotMatch(f.el('caddyPlan').innerHTML,/<script>/);
});

test('screenshot facts populate Caddy and save the same course hole, including rule notes',async()=>{
 const f=await gpsFixture();f.el('caddySignText').value='Anna Page Park - West\nWhite baskets\nPar 57\nHole 1\nPar 3\n297 ft\nOB - on parking lot, bathrooms or shelter Pavement\nOverview';f.el('caddyParseSign').onclick();f.el('caddySignDistance').value='0';f.el('caddyApplySign').onclick();await f.flush();
 assert.equal(f.el('caddyCourseName').value,'Anna Page Park - West');assert.equal(f.el('caddyPar').value,'3');assert.equal(f.el('caddyDistance').value,'297');assert.match(f.el('caddyHoleNotes').value,/parking lot/);const course=f.courses.find(c=>c.name==='Anna Page Park - West');assert.ok(course);assert.equal(course.holes[0].distanceFt,297);assert.equal(course.holes[0].par,3);assert.match(course.holes[0].notes,/shelter Pavement/);
 const reopened=await gpsFixture({saved:f.persisted,savedCourses:f.courses});assert.equal(reopened.el('caddyDistance').value,'297');assert.match(reopened.el('caddyHoleNotes').value,/parking lot/);
});
test('dragged sign markers apply and persist a combo route through canonical course setup',async()=>{
 const saved=makeHole();saved.sign={text:'Example Park\nHole 1 Par 3 300 ft',imageAspect:.5,pointsSource:'automatic',points:{tee:{x:.2,y:.8},bend:{x:.2,y:.5},bend2:{x:.6,y:.5},basket:{x:.6,y:.2}}};const f=await gpsFixture({saved:[saved]});f.el('caddySignStage').getBoundingClientRect=()=>({left:0,top:0,width:300,height:600});
 for(const [type,x,y]of [['pointerdown',.2,.5],['pointermove',.2,.55],['pointerup',.2,.55]]){const event=new Event(type,{cancelable:true});Object.assign(event,{pointerId:1,clientX:x*300,clientY:y*600,button:0});f.el('caddySignStage').dispatchEvent(event)}
 f.el('caddySignDistance').value='0';f.el('caddyApplySign').onclick();await f.flush();assert.equal(f.el('caddyFairway').value,'right-left');const course=f.courses.find(c=>c.name==='Example Park');assert.equal(course.holes[0].fairway,'right-left');assert.equal(f.persisted[0].sign.pointsSource,'manual');assert.equal(f.persisted[0].sign.points.bend.y,.55);assert.match(f.el('caddySignOverlay').innerHTML,/data-marker="basket"/);assert.equal(f.el('caddySignOverlay').attrs.viewBox,'0 0 1000 2000');assert.equal(f.el('caddySignOverlay').attrs.preserveAspectRatio,'xMidYMid meet');
});
test('a different named course in a photo cannot silently replace the selected course',async()=>{
 const f=await gpsFixture();f.el('caddyCourseName').value='My Existing Park';f.el('caddySignText').value='Other Park\nHole 1 Par 3 297 ft';f.el('caddyParseSign').onclick();f.el('caddySignDistance').value='0';f.el('caddyApplySign').onclick();assert.equal(f.el('caddyCourseName').value,'My Existing Park');assert.match(f.el('caddySignStatus').textContent,/different course/);
});
test('choosing the active hole from a multi-hole text card applies only that hole',async()=>{
 const f=await gpsFixture();f.el('caddySignText').value='Example Park\nHole 1 Par 3 200 ft\n\nHole 2 Par 4 120 m\nDogleg right\nOB left';f.el('caddyParseSign').onclick();f.el('caddySignDistance').value='0';f.el('caddyApplySign').onclick();assert.match(f.el('caddySignStatus').textContent,/Several holes/);f.el('caddySignHole').value='2';f.el('caddySignHole').onchange();f.el('caddySignDistance').value='0';f.el('caddyApplySign').onclick();await f.flush();assert.equal(f.el('caddyHoleNumber').value,'2');assert.equal(f.el('caddyPar').value,'4');assert.equal(f.el('caddyFairway').value,'right');assert.ok(Math.abs(Number(f.el('caddyDistance').value)-393.7)<.1);assert.match(f.courses[0].holes.find(h=>h.number===2).notes,/OB left/);
});

test('ordinary saved prose stays quiet and never displays an undefined interpretation status',async()=>{
 const f=await fixture({bagCopies:[{id:'mid',discId:'discraft-buzzz',distance:230}]}),opening=f.render();f.gate.resolve();await opening;
 f.el('caddyDistance').value='200';f.el('caddyFairway').value='straight';f.el('caddyHoleNotes').value='A pretty hole in the park.';f.el('caddyHoleNotes').dispatchEvent(new Event('input'));await f.el('caddyRecommend').onclick();
 assert.equal(f.el('caddyNotesStatus').textContent,'');assert.equal(f.el('caddyNotesStatus').hidden,true);assert.doesNotMatch(f.el('caddyPlan').innerHTML,/no layout constraint|check the wording|undefined/);assert.match(f.el('caddyPlan').innerHTML,/SUGGESTED LANDING/);assert.equal(f.persisted[0].draft.layoutNotes,'A pretty hole in the park.');
});
