import {test} from 'node:test';import assert from 'node:assert/strict';
import {walkupSequence} from './fixtures/walkup-sequence.mjs';
import {derivePhases} from '../dist/lib/phases.js';
import {review} from '../dist/lib/analysis.js';
import {findFollowThrough,coilEvidence} from '../dist/lib/sequence-evidence.js';
import {makeCoachPlan,summarizeCoaching} from '../dist/lib/coaching-language.js';
import {sequenceStudy} from '../dist/lib/form-study.js';
const at=(r,id)=>r.phases instanceof Array?r.phases.find(p=>p.id===id):r.phases[id];
test('three, five and seven step approaches select the final front-foot contact at 15/30/60 samples per second',()=>{
 for(const steps of [3,5,7])for(const fps of [15,30,60]){const f=walkupSequence({steps,fps}),r=derivePhases(f.frames,f.options);
 assert.ok(Math.abs(at(r,'plant').t-f.plant)<=1/fps+.015,`${steps}/${fps} plant`);
 assert.ok(Math.abs(at(r,'reachback').t-f.backswing)<=1/fps+.02,`${steps}/${fps} backswing`);
 assert.ok(r.release.t>=f.release-.12&&r.release.t<=f.release+.05);assert.ok(at(r,'finish').t>r.release.t);assert.equal(r.sequence.supported,true);
 }
});
test('final-stride selection mirrors both hands and both screen directions',()=>{
 for(const hand of ['left','right'])for(const direction of ['left','right']){const f=walkupSequence({hand,direction,steps:7}),r=derivePhases(f.frames,f.options);assert.ok(Math.abs(at(r,'plant').t-f.plant)<.06);assert.ok(Math.abs(at(r,'reachback').t-f.backswing)<.06);assert.equal(r.indexes.leadFoot,hand)}
});
test('fast and slowed playback preserve the final contact instead of moving it into earlier steps',()=>{
 for(const tempo of [.6,1,2]){const f=walkupSequence({steps:7,tempo}),r=derivePhases(f.frames,f.options);assert.ok(Math.abs(at(r,'plant').t-f.plant)<.08*tempo);assert.ok(at(r,'finish').t>r.release.t);assert.ok(at(r,'finish').t-r.release.t>.4*tempo)}
});
test('earlier walk-up contact cannot win after that foot takes another airborne stride',()=>{
 const f=walkupSequence({steps:7}),r=derivePhases(f.frames,f.options);assert.ok(at(r,'plant').t>2.6);assert.notEqual(at(r,'plant').t,at(r,'reachback').t);assert.ok(r.frames.some(f=>f.t===at(r,'plant').t));
});
test('a late plant is left late instead of forcing it onto the backswing',()=>{
 const f=walkupSequence({plantShift:.15}),r=derivePhases(f.frames,{...f.options,markers:{release:f.release}});assert.ok(at(r,'plant').t>=f.plant-.04);assert.ok(at(r,'plant').t-at(r,'reachback').t>.1);
});
test('follow-through survives far-side torso occlusion and uses continuing relative arm motion',()=>{
 const f=walkupSequence({hiddenFinishHip:true}),r=review(f.frames,f.options);assert.ok(at(r,'finish').t>r.release);assert.notEqual(r.findings.find(f=>f.id==='finish').kind,'unknown');
 const frozen=f.frames.map(f=>({...f,p:f.p.map(p=>({...p}))}));for(const row of frozen)row.p[16]={...row.p[12],x:row.p[12].x+.08,y:row.p[12].y+.1};
 assert.equal(findFollowThrough(frozen,f.release,{s:12,w:16},{aspect:1}),null);
});
test('a cropped post-release clip does not fabricate a finish and competing throws are bounded',()=>{
 const f=walkupSequence(),short=f.frames.filter(s=>s.t<=f.release);assert.equal(findFollowThrough(short,f.release,{s:12,w:16},{aspect:1}),null);
 assert.equal(findFollowThrough(f.frames,f.release,{s:12,w:16},{aspect:1,nextThrow:f.release+.02}),null);
});
test('a supported automatic sequence gets an observational coaching plan without requiring manual markers',()=>{
 const f=walkupSequence(),r=review(f.frames,f.options),plan=makeCoachPlan(r);assert.equal(r.estimated,true);assert.equal(r.quality.releaseConfirmed,false);assert.equal(r.quality.sequence.supported,true);assert.notEqual(plan.needsReleaseConfirmation,true);assert.ok(plan.moments.length);assert.ok(summarizeCoaching(r,plan).focus);assert.ok(r.findings.every(f=>!['positive','attention'].includes(f.kind)));
});
test('timeline crossover uses the crossing rather than the Before the crossover review moment',()=>{
 const f=walkupSequence({steps:7}),r=review(f.frames,f.options),cross=r.quality.xStep.moments.find(m=>m.label==='Suggested crossover');assert.ok(cross);assert.equal(at(r,'crossover').t,cross.t);assert.ok(at(r,'crossover').t>r.quality.xStep.moments[0].t);
});
test('coil tracks a shoulder/hip sequence and exposes an editable phase and linked study',()=>{
 const f=walkupSequence(),r=review(f.frames,f.options),coil=r.findings.find(f=>f.id==='coil');assert.equal(coil.kind,'observe');assert.ok(at(r,'coil').t);assert.ok(r.metrics.shoulderTurnEstimate>10);assert.ok(r.metrics.hipTurnEstimate>5);assert.match(coil.evidence,/model-estimated/);assert.ok(sequenceStudy(r).some(s=>s.id==='coil'&&s.lessonId==='coil-sequence'));
 const noDepth=f.frames.map(({world,...s})=>s);assert.equal(coilEvidence(noDepth),null);assert.equal(review(noDepth,f.options).findings.find(f=>f.id==='coil').kind,'unknown');
});
test('constant depth headings do not fabricate a coil phase and forehands do not use backhand coil',()=>{
 const f=walkupSequence(),still=f.frames.map(s=>({...s,world:f.frames[0].world})),r=derivePhases(still,f.options);assert.equal(at(r,'coil').t,null);assert.equal(at(derivePhases(f.frames,{...f.options,type:'forehand'}),'coil').t,null);
});
test('standstill and moving-camera modes cannot infer a landing and inputs remain unchanged',()=>{
 const f=walkupSequence(),before=JSON.stringify(f);for(const opt of [{stance:'standstill'},{cameraStable:false}])assert.equal(at(derivePhases(f.frames,{...f.options,...opt}),'plant').t,null);assert.equal(JSON.stringify(f),before);
});
test('a faster unrelated hand pump does not replace the complete later throwing sequence',()=>{
 const f=walkupSequence({steps:7});for(const row of f.frames)if(row.t>=.25&&row.t<=.6){const ramp=row.t<.425?(row.t-.25)/.175:(.6-row.t)/.175;row.p[16].x=row.p[12].x+.34*ramp}
 const r=derivePhases(f.frames,f.options);assert.ok(r.release.t>3&&r.release.t<3.2);assert.equal(r.sequence.supported,true);assert.ok(at(r,'plant').t>2.6);
});
test('new sequence lessons resolve to reviewed sources and the manual coil marker retains its source time',async()=>{
 const {SEQUENCE_SOURCES,SEQUENCE_LESSONS}=await import('../dist/lib/sequence-research.js'),{KNOWLEDGE,SOURCES}=await import('../dist/lib/knowledge.js');
 for(const [id,source]of Object.entries(SEQUENCE_SOURCES)){assert.equal(SOURCES[id].reviewed,'2026-11-01');assert.ok(source.preview.length>180);assert.ok(source.evidence)}
 for(const lesson of SEQUENCE_LESSONS){assert.ok(KNOWLEDGE.some(k=>k.id===lesson.id));for(const id of lesson.sourceIds)assert.ok(SOURCES[id]?.url.startsWith('https://'))}
 const f=walkupSequence(),r=review(f.frames,{...f.options,markers:{coil:1.2}});assert.equal(at(r,'coil').t,1.2);assert.equal(at(r,'coil').origin,'marked');
});

test('a post-release recovery step cannot replace an already settled final plant',()=>{
 const f=walkupSequence();for(const row of f.frames)if(row.t>f.release+.08){const u=Math.min(1,(row.t-f.release-.08)/.22),dx=u*.08,y=.95-.07*Math.sin(Math.PI*u);for(const k of [28,30,32]){row.p[k].x+=dx;row.p[k].y=y+(k===28?0:.01)}}
 const r=derivePhases(f.frames,{...f.options,markers:{release:f.release}});assert.ok(Math.abs(at(r,'plant').t-f.plant)<.06);
});

test('a clear standstill can receive an automatic plan without inventing a new plant or crossover',()=>{
 const f=walkupSequence();for(const row of f.frames){const offset=row.p[12].x-.5;for(const p of row.p)p.x-=offset;for(const [k,x]of [[27,.4],[29,.39],[31,.425],[28,.65],[30,.64],[32,.675]])row.p[k]={x,y:k<29?.95:.96,visibility:1}}
 const r=review(f.frames,{...f.options,stance:'standstill'});assert.equal(at(r,'plant').t,null);assert.equal(at(r,'crossover').t,null);assert.equal(r.quality.sequence.supported,true);assert.notEqual(makeCoachPlan(r).needsReleaseConfirmation,true);
});
