import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {writeFileSync} from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {rawResourceId,introResourceFiles,verifyApkIntro,sha256,captureProcess} from '../scripts/lib/startup-apk.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const resourceName='com.fairwayform.app:raw/fairway_intro',id='0x7f110000';
const payload=Buffer.from('ZIP transport fixture, not video or an Android application.');
const intro={resourceName,bytes:payload.length,sha256:sha256(payload)};
// Synthetic values in AAPT2's documented/AOSP Debug.cpp + FileReference format.
// A real Android build still runs the checker with the SDK's actual aapt2.
const dump=(file='res/A.mp4',name='raw/fairway_intro',resourceId=id)=>`Binary APK\nPackage name=com.fairwayform.app id=7f\n  type raw id=11 entryCount=1\n    resource ${resourceId} ${name}\n      () (file) ${file}\n`;
async function temp(fn){const dir=await fs.mkdtemp(path.join(os.tmpdir(),'fairway intro check '));try{return await fn(dir)}finally{await fs.rm(dir,{recursive:true,force:true})}}
// Stored ZIP fixtures exercise real unzip extraction without Android tooling.
const crcTable=Uint32Array.from({length:256},(_,value)=>{for(let i=0;i<8;i++)value=value&1?0xedb88320^(value>>>1):value>>>1;return value>>>0});
function crc32(bytes){let crc=0xffffffff;for(const b of bytes)crc=crcTable[(crc^b)&255]^(crc>>>8);return (crc^0xffffffff)>>>0}
function zip(file,entries){
 const local=[],central=[];let offset=0;
 for(const [name,bytes]of entries){
  const nameBytes=Buffer.from(name),crc=crc32(bytes),header=Buffer.alloc(30);
  header.writeUInt32LE(0x04034b50,0);header.writeUInt16LE(20,4);header.writeUInt32LE(crc,14);header.writeUInt32LE(bytes.length,18);header.writeUInt32LE(bytes.length,22);header.writeUInt16LE(nameBytes.length,26);
  const row=Buffer.alloc(46);row.writeUInt32LE(0x02014b50,0);row.writeUInt16LE(20,4);row.writeUInt16LE(20,6);row.writeUInt32LE(crc,16);row.writeUInt32LE(bytes.length,20);row.writeUInt32LE(bytes.length,24);row.writeUInt16LE(nameBytes.length,28);row.writeUInt32LE(offset,42);
  local.push(header,nameBytes,bytes);central.push(row,nameBytes);offset+=header.length+nameBytes.length+bytes.length;
 }
 const directory=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(entries.length,8);end.writeUInt16LE(entries.length,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);
 writeFileSync(file,Buffer.concat([...local,directory,end]));
}

test('reads raw movie ID from generated R.txt and package-aware symbols',()=>{
 assert.equal(rawResourceId(`int drawable tmp 0x7f080001\nint raw fairway_intro ${id}\n`),id);
 assert.equal(rawResourceId(`com.fairwayform.app\n int  raw  fairway_intro  0X7F110000\n`),id);
 assert.equal(rawResourceId('int raw different_movie 0x7f110000'),null);
});
test('conflicting generated movie IDs are rejected rather than guessed',()=>{
 assert.throws(()=>rawResourceId(`int raw fairway_intro ${id}\nint raw fairway_intro 0x7f110001`),/disagree/);
});
test('resolves a shortened release path from an unqualified AAPT2 raw entry',()=>{
 assert.deepEqual(introResourceFiles(dump(),{resourceName}),{resourceId:id,files:['res/A.mp4']});
});
test('resolves an unoptimized path and fully qualified resource names',()=>{
 assert.deepEqual(introResourceFiles(dump('res/raw/fairway_intro.mp4',resourceName),{resourceName}),{resourceId:id,files:['res/raw/fairway_intro.mp4']});
});
test('collapsed names are resolved by the generated resource ID',()=>{
 assert.deepEqual(introResourceFiles(dump('res/b.mp4','raw/0_resource_name_obfuscated'),{resourceName,resourceId:id}),{resourceId:id,files:['res/b.mp4']});
});
test('an unrelated movie is not accepted as the opening resource',()=>{
 assert.throws(()=>introResourceFiles(dump('res/A.mp4','raw/other'),{resourceName}),/does not resolve/);
});
test('stale generated symbols cannot silently select a different movie',()=>{
 assert.throws(()=>introResourceFiles(dump(),{resourceName,resourceId:'0x7f110001'}),/disagree/);
});
test('resource IDs outside app raw resources are rejected',()=>{
 assert.throws(()=>introResourceFiles(dump('res/A.mp4','drawable/other'),{resourceName,resourceId:id}),/outside/);
 assert.throws(()=>introResourceFiles(dump('res/A.mp4','other.package:raw/other'),{resourceName,resourceId:id}),/outside/);
});
test('every configured movie file must be checked, with duplicate paths checked once',()=>{
 const text=dump()+`      (en) (file) res/B.mp4\n      (fr) (file) res/A.mp4\n`;
 assert.deepEqual(introResourceFiles(text,{resourceName}).files,['res/A.mp4','res/B.mp4']);
});
test('empty resource values and invalid paths fail with a specific diagnostic',()=>{
 assert.throws(()=>introResourceFiles(`Package name=com.fairwayform.app id=7f\n resource ${id} raw/fairway_intro\n () (reference) @string/other`,{resourceName}),/no compiled file/);
 for(const file of ['../outside.mp4','/absolute.mp4','res/../outside.mp4','res\\outside.mp4'])assert.throws(()=>introResourceFiles(dump(file),{resourceName}),/invalid/);
});
test('a real ZIP with shortened movie path passes while the previous hardcoded extraction fails',async()=>temp(async dir=>{
 const apk=path.join(dir,'optimized fixture.apk');zip(apk,[['res/A.mp4',payload]]);
 const previous=captureProcess('unzip',['-p',apk,'res/raw/fairway_intro.mp4']);assert.notEqual(previous.status,0);
 assert.deepEqual(verifyApkIntro(apk,intro,dump()),{resourceId:id,files:['res/A.mp4']});
}));
test('a mapped movie with changed bytes of the same size is rejected',async()=>temp(async dir=>{
 const apk=path.join(dir,'changed fixture.apk'),changed=Buffer.from(payload);changed[0]^=1;zip(apk,[['res/A.mp4',changed]]);
 assert.throws(()=>verifyApkIntro(apk,intro,dump()),/does not match the approved/);
}));
test('a truncated movie is rejected',async()=>temp(async dir=>{
 const apk=path.join(dir,'truncated fixture.apk');zip(apk,[['res/A.mp4',payload.subarray(1)]]);
 assert.throws(()=>verifyApkIntro(apk,intro,dump()),/does not match the approved/);
}));
test('an approved decoy elsewhere in the ZIP cannot hide a missing mapped resource',async()=>temp(async dir=>{
 const apk=path.join(dir,'missing fixture.apk');zip(apk,[['assets/approved-decoy.mp4',payload]]);
 assert.throws(()=>verifyApkIntro(apk,intro,dump()),/points to res\/A.mp4, but extraction failed/);
}));
test('all configured versions need approved bytes',async()=>temp(async dir=>{
 const apk=path.join(dir,'variant fixture.apk');zip(apk,[['res/A.mp4',payload],['res/B.mp4',Buffer.from('wrong')]]);
 assert.throws(()=>verifyApkIntro(apk,intro,dump()+`      (en) (file) res/B.mp4\n`),/does not match the approved/);
}));
async function cliFixture(dir,table){
 const project=path.join(dir,'project'),sdk=path.join(dir,'SDK with spaces'),aapt=path.join(sdk,'build-tools/35.0.0/aapt2');
 await fs.mkdir(path.join(project,'scripts/lib'),{recursive:true});await fs.mkdir(path.join(project,'android/app/src/main/res/raw'),{recursive:true});await fs.mkdir(path.dirname(aapt),{recursive:true});
 await fs.writeFile(path.join(project,'package.json'),'{"type":"module"}');
 for(const name of ['check-startup-assets.mjs','lib/startup-apk.mjs'])await fs.copyFile(path.join(root,'scripts',name),path.join(project,'scripts',name));
 const metadata=JSON.parse(await fs.readFile(path.join(root,'android/startup-assets.json'),'utf8')),approved=await fs.readFile(path.join(root,metadata.intro.path));
 await fs.writeFile(path.join(project,'android/startup-assets.json'),JSON.stringify(metadata));await fs.writeFile(path.join(project,metadata.intro.path),approved);
 const apk=path.join(dir,'compiled ZIP fixture.apk');zip(apk,[['res/A.mp4',approved]]);
 await fs.writeFile(aapt,`#!${process.execPath}\nif(process.argv[2]!=='dump'||process.argv[3]!=='resources'||process.argv[4]!==${JSON.stringify(apk)})process.exit(3);process.stdout.write(${JSON.stringify(table)});\n`,{mode:0o700});
 return {project,sdk,aapt,apk,script:path.join(project,'scripts/check-startup-assets.mjs')};
}
test('CLI handles SDK tool paths with spaces, collapsed names and the release symbols rather than stale debug symbols',async()=>temp(async dir=>{
 const fixture=await cliFixture(dir,dump('res/A.mp4','raw/0_resource_name_obfuscated'));
 for(const [variant,resourceId]of [['release',id],['debug','0x7f110001']]){
  const processName=variant==='release'?'processReleaseResources':'processDebugResources',folder=path.join(fixture.project,'android/app/build/intermediates/runtime_symbol_list',variant,processName);
  await fs.mkdir(folder,{recursive:true});await fs.writeFile(path.join(folder,'R.txt'),`int raw fairway_intro ${resourceId}\n`);
 }
 const result=captureProcess(process.execPath,[fixture.script,fixture.apk,fixture.aapt,'release'],{encoding:'utf8',timeout:10000});
 assert.equal(result.status,0,result.stderr);assert.match(result.stdout,/0x7f110000.*res\/A.mp4/);assert.match(result.stdout,/SHA-256 match/);
}));
test('CLI can locate aapt2 from the configured SDK when a tool path is not provided',async()=>temp(async dir=>{
 const fixture=await cliFixture(dir,dump());const result=captureProcess(process.execPath,[fixture.script,fixture.apk],{encoding:'utf8',env:{...process.env,ANDROID_HOME:fixture.sdk},timeout:10000});
 assert.equal(result.status,0,result.stderr);assert.match(result.stdout,/res\/A.mp4/);
}));
test('CLI distinguishes aapt2 failure from a missing or damaged movie',async()=>temp(async dir=>{
 const fixture=await cliFixture(dir,dump());await fs.writeFile(fixture.aapt,`#!${process.execPath}\nprocess.stderr.write('fixture tool failed');process.exit(2);\n`,{mode:0o700});
 const result=captureProcess(process.execPath,[fixture.script,fixture.apk,fixture.aapt],{encoding:'utf8',timeout:10000});
 assert.notEqual(result.status,0);assert.match(result.stderr,/resource-table inspection failed.*fixture tool failed/);
}));
