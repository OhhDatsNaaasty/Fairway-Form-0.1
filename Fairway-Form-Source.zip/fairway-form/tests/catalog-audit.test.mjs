import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DISCS} from '../dist/lib/discs.js';
import {catalogMatches} from '../dist/lib/disc-catalog.js';
import {estimatedWindow,shapePath} from '../dist/lib/disc-flight.js';
import {normalizeShot,planShot} from '../dist/lib/caddy.js';
const read=file=>JSON.parse(fs.readFileSync(new URL(file,import.meta.url),'utf8'));
const previous=read('./fixtures/catalog-1.21.0.json'),audit=read('../scripts/catalog-audit-inventory-1.22.0.json'),added=read('../scripts/catalog-audit-additions-1.22.0.json').discs;
test('the complete shipped catalog retains every original identity and rating',()=>{
 assert.equal(previous.length,850);for(const old of previous){const d=DISCS.find(d=>d.id===old.id);assert.ok(d,old.id);for(const [key,value]of Object.entries(old))assert.deepEqual(d[key],value,old.id+' '+key)}
});
test('all 28 existing brands have an explicit dated audit and their counts reconcile',()=>{
 assert.equal(audit.brands.length,28);assert.equal(audit.catalogCount,DISCS.length);assert.equal(audit.newRecords,added.length);assert.equal(DISCS.length,previous.length+added.length);assert.ok(added.length>=240);
 for(const brand of audit.brands){assert.equal(brand.catalogCount,DISCS.filter(d=>d.brand===brand.brand).length);assert.equal(brand.added,added.filter(d=>d.brand===brand.brand).length);assert.ok(brand.manufacturerDirectoryAttempted.startsWith('https://'));assert.ok(brand.factSources.length>0)}
});
test('every reviewed reference row resolves to a preserved model or an explicit exclusion',()=>{
 assert.equal(audit.entries.length,audit.reviewedReferenceRows);assert.equal(audit.unresolvedReviewedRows,0);assert.ok(audit.entries.length>=990);
 for(const entry of audit.entries){assert.ok(entry.sourceUrl.startsWith('https://'));if(entry.status==='excluded'){assert.ok(entry.reason);continue}const d=DISCS.find(d=>d.id===entry.catalogId);assert.ok(d,entry.referenceName);assert.equal(d.brand,entry.brand)}
});
test('new entries have usable sourced numeric flight information without invented chart paths',()=>{
 for(const row of added){const d=DISCS.find(d=>d.brand===row.brand&&d.model===row.model);assert.ok(d,row.model);assert.ok(d.sourcePublisher);assert.ok(d.sourceUrl.startsWith('https://'));assert.equal(d.checked,'2026-10-30');const window=estimatedWindow(d);assert.ok(Number.isFinite(window.lowFt)&&window.highFt>window.lowFt);assert.doesNotMatch(shapePath(d),/NaN|undefined/)}
});
test('alternate brand, retail and accented names resolve without creating duplicate molds',()=>{
 for(const [query,id]of [['Above Ground Level Dogwood','agl-discs-dogwood'],['Loft Neon','l-ft-discs-neon'],['MVP Disc Sports Stasis','mvp-stasis'],['Innova Aviar P&A','innova-aviar'],['Innova Firefly','innova-ns-firefly'],['Lone Star Disc Tex','lone-star-disc-the-tex'],['Yikun Ancestor','yikun-zi-ya'],['Yikun Yangjian','yikun-yang-jian'],['Millennium Orion LF','millennium-orion']])assert.ok(catalogMatches(DISCS.find(d=>d.id===id),query),query);
 assert.equal(DISCS.filter(d=>d.brand==='Innova'&&['Aviar P&A','Firefly'].includes(d.model)).length,0);
});
test('original tooling and manufacturer-rated run variants keep their separate numbers',()=>{
 const disc=id=>DISCS.find(d=>d.id===id);assert.equal(disc('axiom-time-lapse').fade,2);assert.equal(disc('axiom-time-lapse-original').fade,3);assert.equal(disc('kastaplast-kaxe').glide,4);assert.equal(disc('kastaplast-kaxe-retooled').glide,5);assert.equal(disc('mint-discs-goat').turn,-1);assert.equal(disc('mint-discs-goat-eternal-et-gt01-23').turn,0);assert.equal(disc('lone-star-disc-penny-putter').glide,4);assert.equal(disc('lone-star-disc-penny-putter-victor').glide,5);
});
test('manufacturer corrections beat conflicting third-party additions and do not cross-label brands',()=>{
 const air=DISCS.find(d=>d.id==='gateway-air-strike');assert.deepEqual([air.speed,air.glide,air.turn,air.fade],[13,5,-2,2]);assert.equal(air.sourceType,'Manufacturer');assert.equal(DISCS.find(d=>d.id==='yikun-ne-zha').fade,1);assert.equal(DISCS.some(d=>d.id==='axiom-uplink'),false);assert.equal(DISCS.some(d=>d.id==='gateway-scale'),false);
});
test('tentative and conflicting references stay visible in Caddy when those discs are selected',()=>{
 for(const [id,phrase]of [['mvp-mass',/tentative manufacturer/],['yikun-qi',/Published flight ratings conflict/]]){
  const d=DISCS.find(d=>d.id===id),bag=[{id:'qa-copy',discId:d.id,distance:200,distanceThrow:'backhand'}],p=planShot(normalizeShot({distanceFt:180,fairway:'straight',hand:'right',type:'backhand'}),bag,[d]);assert.ok(p.candidates.length);assert.ok(p.candidates.every(c=>c.cautions.some(text=>phrase.test(text))));
 }
});
