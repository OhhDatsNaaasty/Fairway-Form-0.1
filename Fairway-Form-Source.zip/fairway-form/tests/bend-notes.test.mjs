import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parseLayoutNotes,applyLayoutNotes} from '../dist/lib/caddy-layout.js';
import {planShot} from '../dist/lib/caddy.js';
import {DISCS} from '../dist/lib/discs.js';
import {buildHoleScene,holeSceneSVG,scenePoint} from '../dist/lib/hole-scene.js';
import {landingScene,suggestLanding} from '../dist/lib/landing-zone.js';
import {USER_BEND_NOTES} from './fixtures/bend-notes.mjs';
const raw={distanceFt:475,fairway:'slight-right',type:'auto',hand:'right',lie:'tee',hazard:'both',layoutNotes:USER_BEND_NOTES};
const bag=[{id:'mid',discId:'latitude-64-claymore',distance:280,alternateDistance:140},{id:'fairway',discId:'innova-teebird',distance:320,alternateDistance:150}];
const profile={skill:'intermediate',averageBackhandFt:280,averageForehandFt:150};
const plan=(changes={},copies=bag)=>planShot({...raw,...changes},copies,DISCS,[],{profile});
test('the complete reported notes describe one gentle right bend with two distinct distances',()=>{
 const p=parseLayoutNotes(USER_BEND_NOTES);assert.equal(p.fairway,'slight-right');assert.equal(p.cornerFt,350);assert.equal(p.postBendFt,125);assert.equal(p.afterBendElevation,'downhill');assert.deepEqual(p.warnings,[]);assert.deepEqual(p.unmatched,[]);
});
for(const [notes,corner,post] of [
 ['Turns slightly right after about 350 feet. Basket 125 feet after the right bend.',350,125],
 ['Fairway bends gently right at roughly 350 ft. Basket is 125 ft beyond the bend.',350,125],
 ['Fairway turns right slightly after 350 ft. Basket 125 ft past the right bend.',350,125],
 ['A slight right dogleg starts around 350 feet. The basket is 125 feet after that bend.',350,125],
 ['Go straight for 350 ft then dogleg right. Basket 125 ft past the bend.',350,125],
 ['Fairway is straight for the first 350 ft. Then turns right. Basket 125 ft after the bend.',350,125],
 ['After about 350 feet the fairway turns right. The basket is 125 feet beyond the bend.',350,125],
 ['350 feet to the right bend. Basket 125 feet past the bend.',350,125],
 ['Right bend at 350 feet. Basket about 125 ft farther after the bend.',350,125],
 ['Bend at 100.5 meters to the right. Basket 30.5 m after the bend.',100.5/.3048,30.5/.3048]
])test('bend-distance phrasing: '+notes,()=>{
 const p=parseLayoutNotes(notes);assert.ok(Math.abs(p.cornerFt-corner)<1e-7,JSON.stringify(p));if(post===null)assert.equal(p.postBendFt,null);else assert.ok(Math.abs(p.postBendFt-post)<1e-7,JSON.stringify(p));assert.ok(!p.warnings.some(w=>w.includes('more than one fairway')));
});
test('a later noun reference preserves the earlier slight modifier for either side',()=>{
 for(const side of ['left','right']){const p=parseLayoutNotes(`Fairway turns slightly ${side} after 350 ft. Basket 125 ft after the ${side} bend.`);assert.equal(p.fairway,'slight-'+side);assert.equal(p.cornerFt,350);assert.equal(p.postBendFt,125);assert.deepEqual(p.warnings,[]);}
});
test('actual opposing route descriptions still require resolution',()=>{
 const p=parseLayoutNotes('Dogleg left. Dogleg right.');assert.equal(p.fairway,null);assert.match(p.warnings.join(' '),/more than one fairway/);
});
test('landmark offsets are not mistaken for the bend distance or basket section',()=>{
 for(const text of ['Tree 20 ft before the right bend.','Water 20 ft after the right bend.','Tree 20 ft after the bend near the basket.']){const p=parseLayoutNotes(text);assert.equal(p.cornerFt,null,text);assert.equal(p.postBendFt,null,text);}
});
test('negated turns cannot supply an automatic corner',()=>{
 const p=parseLayoutNotes('Fairway does not turn right after 350 feet.');assert.equal(p.fairway,null);assert.equal(p.cornerFt,null);
});
test('wooded edges and a clear interior are distinct from a tight tunnel',()=>{
 const p=plan();assert.equal(p.layout.woodedEdges,true);assert.equal(p.layout.clearFairway,true);assert.equal(p.shot.wooded,false);assert.deepEqual(p.layout.hazards,['left','right']);
 const tight=plan({layoutNotes:USER_BEND_NOTES+' Narrow fairway.'});assert.equal(tight.shot.wooded,true);
});
test('a known long straight approach to the bend does not prefer a short forehand just for its finish',()=>{
 const p=plan(),c=p.candidates[0];assert.equal(c.throwType,'backhand');assert.equal(c.lineFit.kind,'straight');assert.equal(c.landing.phase,'before-bend');assert.ok(c.targetFt>200&&c.targetFt<350);assert.ok(!p.warnings.some(w=>w.includes('beyond your usual')));assert.match(p.strategy,/350 ft/);
});
test('the downhill basket section does not penalize the first level straight placement',()=>{
 const down=plan(),level=plan({layoutNotes:USER_BEND_NOTES.replace('downhill slightly','level')});
 assert.deepEqual(down.candidates.map(c=>[c.optionKey,c.targetFt,c.score]),level.candidates.map(c=>[c.optionKey,c.targetFt,c.score]));
});
test('hole and landing pictures share the same measured section proportions and gentle direction',()=>{
 const p=plan(),home=buildHoleScene({distance:475,line:'Slight dogleg right',note:USER_BEND_NOTES,hazard:'both'}),landing=landingScene(p);
 assert.deepEqual(home.points,landing.points);assert.deepEqual(home.pointDistancesFt,[0,350,475]);
 const [a,b,c]=home.points,x=Math.hypot(b[0]-a[0],b[1]-a[1]),y=Math.hypot(c[0]-b[0],c[1]-b[1]);assert.ok(Math.abs(x/y-350/125)<1e-8);assert.equal(a[0],b[0]);assert.ok(c[0]>b[0]);const angle=Math.atan2(c[0]-b[0],b[1]-c[1])*180/Math.PI;assert.ok(angle>0&&angle<45);
 const at=scenePoint(home,350);assert.equal(at.x,b[0]);assert.equal(at.y,b[1]);assert.equal(home.wooded,true);assert.match(holeSceneSVG(home,{labels:true}),/350 ft to bend · 125 ft after · downhill/);
});
test('changing section lengths changes the actual sketch shape and bend position',()=>{
 const a=buildHoleScene({distance:475,line:'Slight dogleg right',note:USER_BEND_NOTES}),b=buildHoleScene({distance:475,line:'Slight dogleg right',note:USER_BEND_NOTES.replace('350','200').replace('125','275')});
 assert.notDeepEqual(a.points,b.points);assert.ok(a.points[1][1]<b.points[1][1]);
});
test('a shorter reachable placement is explained relative to the distant bend',()=>{
 const p=plan({},[{...bag[0],distance:200}]),z=suggestLanding(p,p.candidates[0]);assert.ok(z.targetFt<200);assert.match(z.description,/before the bend at about 350 ft/);assert.match(z.description,/125 ft beyond that on a downhill section/);
});
test('stale tee section lengths never become distances from a later lie',()=>{
 const p=plan({lie:'fairway',distanceFt:180,layoutNotesCurrent:false});assert.equal(p.layout.cornerFt,null);assert.equal(p.layout.postBendFt,null);assert.equal(landingScene(p,{throws:[{input:raw}],courseLayout:raw}).pointDistancesFt,undefined);
});
test('notes never overwrite an entered basket distance or mutate source data',()=>{
 const input={...raw,distanceFt:500},before=JSON.stringify({input,bag,profile}),p=planShot(input,bag,DISCS,[],{profile});assert.equal(p.shot.distanceFt,500);assert.equal(JSON.stringify({input,bag,profile}),before);
});
