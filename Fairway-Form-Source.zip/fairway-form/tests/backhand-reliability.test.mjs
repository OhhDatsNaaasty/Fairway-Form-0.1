import {test} from 'node:test';import assert from 'node:assert/strict';
import {walkupSequence} from './fixtures/walkup-sequence.mjs';
import {derivePhases} from '../dist/lib/phases.js';import {findFollowThrough} from '../dist/lib/sequence-evidence.js';
import {review} from '../dist/lib/analysis.js';import {explainFinding,summarizeCoaching,makeCoachPlan} from '../dist/lib/coaching-language.js';
const phase=(r,id)=>r.phases instanceof Array?r.phases.find(p=>p.id===id):r.phases[id];
for(const steps of [3,5,7])test('side-on normal-speed '+steps+'-step throw retains visible plant during elbow occlusion',()=>{
 const f=walkupSequence({steps});for(const row of f.frames)if(Math.abs(row.t-f.plant)<.13)row.p[14].visibility=.1;const r=derivePhases(f.frames,f.options);assert.ok(r.release);assert.ok(Math.abs(phase(r,'plant').t-f.plant)<.06);assert.ok(phase(r,'plant').reviewWindow.start<=phase(r,'plant').t);assert.ok(phase(r,'plant').reviewWindow.end>=phase(r,'plant').t);
});
test('a clear toe contact can support plant when the heel is hidden',()=>{
 const f=walkupSequence();for(const row of f.frames)if(Math.abs(row.t-f.plant)<.15)row.p[30].visibility=.1;const r=derivePhases(f.frames,f.options);assert.ok(Math.abs(phase(r,'plant').t-f.plant)<.06);
});
test('the follow-through can use a later visible segment without bridging an occluded interval',()=>{
 const f=walkupSequence();for(const row of f.frames)if(row.t>f.release+.12&&row.t<f.release+.5)row.p[16].visibility=.1;const result=findFollowThrough(f.frames,f.release,{s:12,w:16},{aspect:1});assert.ok(result);assert.ok(result.t>f.release+.5);assert.ok(result.eventWindow.start>f.release);
});
test('a long visibility gap alone does not manufacture continuing arm movement',()=>{
 const f=walkupSequence();for(const row of f.frames){row.p[16]={...row.p[12],x:row.p[12].x+.1,y:.5};if(row.t>f.release+.1&&row.t<f.release+.6)row.p[16].visibility=.1}assert.equal(findFollowThrough(f.frames,f.release,{s:12,w:16},{aspect:1}),null);
});
test('missing final-foot evidence does not move plant to an earlier shallow walk-up contact',()=>{
 const f=walkupSequence({steps:7});for(const row of f.frames)if(row.t>f.plant-.3&&row.t<f.release+.05)for(const i of [28,30,32])row.p[i].visibility=.1;const r=derivePhases(f.frames,{...f.options,markers:{release:f.release}});assert.equal(phase(r,'plant').t,null);
});
test('manual event corrections remain exact and are never forced to an ideal order',()=>{
 const f=walkupSequence(),r=derivePhases(f.frames,{...f.options,markers:{release:f.release,plant:f.release+.1,reachback:f.release-.6}});assert.ok(Math.abs(phase(r,'plant').t-(f.release+.1))<.025);assert.equal(phase(r,'plant').origin,'marked');assert.ok(phase(r,'plant').t>phase(r,'release').t);
});
test('clip-specific timing advice survives the general guidance merge',()=>{
 const f=walkupSequence(),r=review(f.frames,{...f.options,markers:{release:f.release,plant:f.release+.1}}),finding=r.findings.find(f=>f.id==='timing'),copy=explainFinding(finding,r);assert.match(copy.action,/Recheck foot contact/);assert.match(copy.observation,/at or before/);assert.ok(copy.why.length>100);assert.ok(copy.lessonIds.length);assert.equal(copy.evidence,finding.evidence);
});
test('posture instructions name the measured change and give a concrete comparison',()=>{
 const r={options:{type:'backhand'},phases:[{id:'release',t:1.5,origin:'marked'}],metrics:{torsoRange:18}},copy=explainFinding({id:'posture',kind:'attention',evidence:'measured change'},r);assert.match(copy.observation,/18°/);assert.match(copy.action,/same disc and shot shape/);assert.match(copy.action,/count/);assert.equal(copy.evidence,'measured change');
});
test('automatic supported reviews stay observational and include a source-linked task',()=>{
 const f=walkupSequence(),r=review(f.frames,f.options),plan=makeCoachPlan(r),summary=summarizeCoaching(r,plan);assert.ok(r.findings.every(f=>!['attention','positive'].includes(f.kind)));assert.ok(summary.focus?.evidence);assert.ok(summary.focus?.lessonIds.length);assert.ok(summary.session.steps.length>=2);assert.ok(summary.focus.action.length>100);
});
