import {test} from 'node:test';
import assert from 'node:assert/strict';
import {prepareNativeFrames,createNativeFrameSource,validateFrameManifest,supportsNativeFrames} from '../dist/lib/native-video.js';
import {analyzeVideo} from '../dist/lib/video-analysis.js';
const manifest={duration:2.61,width:960,height:540,times:Array.from({length:79},(_,i)=>i/30)};
const tick=()=>new Promise(resolve=>setTimeout(resolve,0));
test('browsers and older APK bridges stay on the existing path without pretending to have a native cache',async()=>{
 assert.equal(supportsNativeFrames({saveBase64(){}}),false);assert.equal(await prepareNativeFrames(new Blob(['video']),{bridge:{saveBase64(){}}}),null);
});
function bridgeFixture({finish=true}={}){
 const events=new EventTarget(),chunks=[],closed=[];let id;
 const emit=value=>events.dispatchEvent(new CustomEvent('fairway-video-frames',{detail:{id,...value}}));
 const bridge={beginVideoFrames(value,size){id=value;return JSON.stringify({ok:true})},appendVideoFrames(value,offset,bytes){chunks.push({id:value,offset,bytes:Uint8Array.from(atob(bytes),c=>c.charCodeAt(0))});return '{"ok":true}'},finishVideoFrames(){if(finish)queueMicrotask(()=>emit({type:'ready',...manifest}))},closeVideoFrames(value){closed.push(value)}};
 return {events,chunks,closed,bridge,emit};
}
test('native transfer uses bounded ordered chunks and the ready event returns a reusable frame source',async()=>{
 const f=bridgeFixture(),bytes=new Uint8Array(600000).map((_,i)=>i%251),progress=[];
 const source=await prepareNativeFrames(new Blob([bytes]),{id:'qa-native',bridge:f.bridge,eventTarget:f.events,onProgress:p=>progress.push(p),loadImage:async url=>({url})});
 assert.equal(source.mode,'native-cache');assert.deepEqual(f.chunks.map(c=>c.offset),[0,262144,524288]);assert.deepEqual(Buffer.concat(f.chunks.map(c=>Buffer.from(c.bytes))),Buffer.from(bytes));assert.ok(progress.some(p=>p.progress===1));
 const frame=await source.sample(2.28);assert.equal(frame.t,68/30);assert.equal(frame.exact,true);assert.match(frame.source.url,/68\.jpg$/);source.close();assert.deepEqual(f.closed,['qa-native']);
});
test('native cancellation and no-progress timeout release the cache and ignore late ready events',async()=>{
 for(const cancel of [true,false]){
  const f=bridgeFixture({finish:false}),controller=new AbortController();
  const pending=prepareNativeFrames(new Blob(['video']),{id:'qa-timeout',bridge:f.bridge,eventTarget:f.events,signal:controller.signal,idleTimeout:30,timeout:100});
  if(cancel){await tick();controller.abort()}
  await assert.rejects(pending,cancel?{name:'AbortError'}:/stopped preparing/);assert.deepEqual(f.closed,['qa-timeout']);f.emit({type:'ready',...manifest});
 }
});
test('preparation has a total deadline even while progress events continue',async()=>{
 const f=bridgeFixture({finish:false});f.bridge.finishVideoFrames=()=>{};
 const heartbeat=setInterval(()=>f.emit({type:'progress',progress:.5}),5);
 try{await assert.rejects(prepareNativeFrames(new Blob(['video']),{id:'qa-total',bridge:f.bridge,eventTarget:f.events,timeout:40,idleTimeout:200}),/exceeded two minutes/);assert.deepEqual(f.closed,['qa-total'])}finally{clearInterval(heartbeat)}
});
test('native errors, incomplete transfers and malformed timelines cannot become a successful preparation',async()=>{
 const f=bridgeFixture({finish:false});f.bridge.finishVideoFrames=()=>f.emit({type:'error',error:'Unsupported HDR'});
 await assert.rejects(prepareNativeFrames(new Blob(['video']),{id:'qa-error',bridge:f.bridge,eventTarget:f.events}),/Unsupported HDR/);assert.equal(f.closed.length,1);
 for(const invalid of [{times:[0,0,2.6]},{times:[0,2.5,2.4]},{times:[0,.1]},{width:4000},{times:[0,NaN,2.6]},{duration:Infinity}])assert.throws(()=>validateFrameManifest({...manifest,...invalid}));
 const bad=bridgeFixture();bad.bridge.appendVideoFrames=()=>'{"ok":false,"error":"disk full"}';
 await assert.rejects(prepareNativeFrames(new Blob(['video']),{id:'qa-disk',bridge:bad.bridge,eventTarget:bad.events}),/disk full/);assert.equal(bad.closed.length,1);
});
test('frame source uses actual presentation times for VFR, steps and clamped ends with bounded decoded-image memory',async()=>{
 const times=[0,.033,.081,.14,.2,.251],images=[];
 const source=createNativeFrameSource({duration:.28,width:300,height:200,times},{id:'qa-vfr',cacheSize:2,loadImage:async url=>{const image={url,closed:false,close(){this.closed=true}};images.push(image);return image}});
 assert.equal((await source.sample(.08)).t,.081);assert.equal(source.step(.081,1),.14);assert.equal(source.step(.081,-1),.033);
 assert.equal((await source.sample(3)).t,.251);assert.equal((await source.sample(-1)).t,0);assert.equal(images[0].closed,true);assert.equal(images.filter(i=>!i.closed).length,2);source.close();assert.ok(images.every(i=>i.closed));await assert.rejects(source.sample(.1),{name:'AbortError'});
});
test('late image completion after cancellation cannot leave a live bitmap in the cache',async()=>{
 let ready;const image={closed:false,close(){this.closed=true}},controller=new AbortController();
 const source=createNativeFrameSource(manifest,{id:'qa-late',loadImage:()=>new Promise(resolve=>ready=resolve)});
 const pending=source.sample(1,{signal:controller.signal});controller.abort();ready(image);await assert.rejects(pending,{name:'AbortError'});assert.equal(image.closed,true);source.close();
});
test('native image cache drives body and hand analysis without any HTML-video seek, play or frame callback',async()=>{
 const source=createNativeFrameSource(manifest,{id:'qa-analysis',loadImage:async url=>({index:Number(url.match(/\/(\d+)\.jpg$/)[1])})});
 const times=[],hands=[],info={};
 const result=await analyzeVideo({video:{duration:manifest.duration},seek(){throw Error('WebView must not seek')},createSampler:()=>source.sampler(),fps:60,sampleInfo:info,detectBody:async image=>{times.push(image.index/30);return {p:{index:image.index}}},prepareHands:async()=>{},detectHand:async(image,p)=>{assert.equal(image.index,p.index);hands.push(image.index);return {}},findRelease:()=>2.35});
 assert.equal(info.decodeMode,'native-cache');assert.equal(info.bodyComplete,true);assert.equal(info.detailIncomplete,false);assert.equal(result.frames.length,79);assert.equal(new Set(times).size,79);assert.ok(result.frames.every(f=>f.decodedTime));assert.ok(hands.length>=7);source.close();
});
