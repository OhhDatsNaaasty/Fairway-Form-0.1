import {test} from 'node:test';
import assert from 'node:assert/strict';
import {chooseVoice,eligibleVoices,speechParts} from '../dist/lib/voice.js';
const voice=(id,quality,extra={})=>({id,lang:'en-US',quality,network:false,installed:true,...extra});
test('automatic narration prefers higher-quality installed offline voices',()=>{
 const list=[voice('standard',300),voice('premium',500),voice('online',600,{network:true})];
 assert.equal(chooseVoice(list).id,'premium');assert.equal(chooseVoice(list,{allowOnline:true}).id,'online');
});
test('a saved voice that requires internet cannot bypass offline preference',()=>{
 const list=[voice('offline',300),voice('online',500,{network:true})];
 assert.equal(chooseVoice(list,{voice:'online'}).id,'offline');
 assert.equal(chooseVoice(list,{voice:'online',allowOnline:true}).id,'online');
});
test('missing voice data or non-English voices cannot be used as installed English narration',()=>{
 assert.equal(eligibleVoices([voice('download',500,{installed:false}),voice('french',500,{lang:'fr-FR'})]).length,0);
 assert.equal(chooseVoice([voice('online',500,{network:true})]),null);
});
test('an available voice choice is respected even if automatic ranking differs',()=>{
 const list=[voice('chosen',300),voice('automatic',500)];assert.equal(chooseVoice(list,{voice:'chosen'}).id,'chosen');
});
test('a removed saved voice falls back to an eligible installed voice',()=>{
 assert.equal(chooseVoice([voice('ready',300)],{voice:'removed'}).id,'ready');
});
test('equal quality respects the preferred English region',()=>{
 const list=[voice('us',400),voice('british',400,{lang:'en-GB'})];assert.equal(chooseVoice(list,{language:'en-GB'}).id,'british');
});
test('spoken paragraphs retain their words and offer breathing space',()=>{
 const text='Keep the turn comfortable.\n\nTry three easy throws.';const parts=speechParts(text);
 assert.deepEqual(parts.map(p=>p.text),['Keep the turn comfortable.','Try three easy throws.']);assert.ok(parts.every(p=>p.pause>=180));
});
test('long coaching paragraphs are split without dropping words',()=>{
 const paragraph=Array.from({length:300},(_,i)=>'word'+i).join(' ');const parts=speechParts(paragraph);
 assert.ok(parts.length>1);assert.ok(parts.every(p=>p.text.length<=650));assert.equal(parts.map(p=>p.text).join(' '),paragraph);assert.equal(parts.at(-1).pause,220);
});
