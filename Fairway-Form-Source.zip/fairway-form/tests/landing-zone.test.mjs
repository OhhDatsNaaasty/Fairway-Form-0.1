import {test} from 'node:test';
import assert from 'node:assert/strict';
import {planShot} from '../dist/lib/caddy.js';
import {DISCS} from '../dist/lib/discs.js';
import {landingScene,suggestLanding,landingSketch,landingPlanMarkup} from '../dist/lib/landing-zone.js';
import {scenePoint} from '../dist/lib/hole-scene.js';

const bag=[{id:'my-buzzz',discId:'discraft-buzzz',distance:230,distanceThrow:'backhand',alternateDistance:150}];
const raw={distanceFt:300,fairway:'straight',hazard:'none',hand:'right',type:'backhand',unit:'ft',lie:'tee'};
const plan=(extra={},copies=bag)=>planShot({...raw,...extra},copies,DISCS,[],{profile:{skill:'intermediate'}});
const zone=(p,round={})=>suggestLanding(p,p.candidates[0],round);

test('landing uses the exact selected candidate distance and copy identity',()=>{
 const p=plan(),z=zone(p);assert.ok(z.point);assert.equal(z.targetFt,p.candidates[0].targetFt);assert.equal(z.optionKey,p.candidates[0].optionKey);assert.equal(z.bagId,'my-buzzz');assert.match(z.basis,/230 ft/);
});
test('changing the saved disc distance changes a staged landing target',()=>{
 const a=zone(plan({distanceFt:700})),b=zone(plan({distanceFt:700},[{...bag[0],distance:310}]));
 assert.ok(b.targetFt>a.targetFt);assert.match(a.basis,/230 ft/);assert.match(b.basis,/310 ft/);
});
test('forehand selection uses its own shorter saved distance rather than backhand carry',()=>{
 const p=plan({distanceFt:700,type:'forehand'}),z=zone(p);assert.equal(z.targetFt,p.candidates[0].targetFt);assert.match(z.basis,/forehand reference: 150 ft/);
});
test('long water keeps the same controlled target and power as the planner',()=>{
 const p=plan({distanceFt:250,layoutNotes:'Water 20 ft behind basket.'}),z=zone(p);
 assert.ok(z.targetFt<250);assert.equal(z.targetFt,p.candidates[0].landing.targetFt);assert.notEqual(p.candidates[0].power.effort,'firm');assert.match(z.description,/short of the trouble/);assert.ok(z.scene.features.some(f=>f.kind==='water'&&f.alongFt===270));
});
test('known dogleg distance places the before-bend target on the first leg',()=>{
 const p=plan({distanceFt:350,fairway:'right',layoutNotes:'Straight for 200 ft then dogleg right.'}),z=zone(p);
 assert.ok(z.targetFt<200);assert.equal(z.scene.pointDistancesFt[1],200);
 const corner=scenePoint(z.scene,200);assert.equal(corner.x,z.scene.points[1][0]);assert.equal(corner.y,z.scene.points[1][1]);assert.ok(z.point.y>corner.y);assert.match(z.description,/before the bend/);
});
test('side OB moves the suggested spot away from that edge and remains drawn',()=>{
 for(const hazard of ['left','right']){const p=plan({hazard}),z=zone(p);assert.equal(z.side,hazard==='left'?'right':'left');assert.ok(z.scene.features.some(f=>f.kind==='ob'&&f.side===hazard));}
});
test('trouble on both sides keeps a centered landing',()=>{
 const z=zone(plan({hazard:'both'}));assert.equal(z.side,'center');
});
test('hard-ground finish room mirrors with throwing hand',()=>{
 const r=zone(plan({layoutNotes:'Hard ground.',hand:'right'})),l=zone(plan({layoutNotes:'Hard ground.',hand:'left'}));
 assert.equal(r.finishSide,'left');assert.equal(r.side,'right');assert.equal(l.finishSide,'right');assert.equal(l.side,'left');
});
test('learned turnover tendency overrides the ordinary fade for finish room',()=>{
 const p=plan({layoutNotes:'Hard ground.'}),c={...p.candidates[0],experience:{learnedFlight:{flight:'turned'}}};
 const z=suggestLanding(p,c);assert.equal(z.finishSide,c.release.turnSide);assert.equal(z.side,c.release.fadeSide);
});
test('a next-lie sketch rebases basket hazards without moving old tee trees to the player',()=>{
 const notes='Large tree 50 ft from tee on the right. Water 20 ft behind basket.';
 const round={throws:[{input:{distanceFt:300,fairway:'straight'}}],courseLayout:{distanceFt:300,fairway:'straight'}};
 const p=plan({distanceFt:80,lie:'fairway',layoutNotes:notes,layoutNotesCurrent:false}),scene=landingScene(p,round);
 assert.equal(scene.distanceFt,80);assert.equal(scene.startLabel,'Your lie');assert.ok(scene.features.some(f=>f.kind==='water'&&f.alongFt===100));assert.ok(!scene.features.some(f=>f.kind==='tree'));
});
test('even newly edited tee-relative wording cannot invent a next-lie position',()=>{
 const p=plan({distanceFt:100,lie:'fairway',layoutNotes:'Large tree 50 ft from tee on the right.',layoutNotesCurrent:true});
 assert.ok(!landingScene(p).features.some(f=>f.kind==='tree'));
});
test('a mapped obstacle covering the target is not marked as a clear landing',()=>{
 const p=plan(),c=p.candidates[0],round={layoutArt:{extraFeatures:[{id:'blocker',kind:'tree',label:'Large oak',anchor:'tee',side:'center',alongFt:c.targetFt,large:true,positionKnown:true}]}};
 const z=zone(p,round);assert.equal(z.blocked,true);assert.equal(z.point,null);assert.match(z.description,/nearer landing point/);assert.doesNotMatch(landingSketch(z),/data-landing-target/);
});
test('meter presentation converts labels without changing the target geometry',()=>{
 const a=zone(plan()),b=zone(plan({unit:'m'}));assert.equal(a.targetFt,b.targetFt);assert.deepEqual(a.point,b.point);assert.match(b.description,/ m from/);
});
test('confirmed sign markers allow the landing ring on the saved photo',()=>{
 const p=plan(),round={layoutArt:{signImage:'data:image/jpeg;base64,YWJj'},sign:{confirmedAt:1,imageAspect:.5,points:{tee:{x:.5,y:.8},basket:{x:.5,y:.2}}}};
 const html=landingPlanMarkup(p,p.candidates[0],round);assert.match(html,/Saved hole sign with suggested landing/);assert.match(html,/<image href="data:image\/jpeg;base64,/);assert.match(html,/data-landing-target/);
 const later=plan({distanceFt:80,lie:'fairway'});assert.doesNotMatch(landingPlanMarkup(later,later.candidates[0],round),/<image href=/);
});
test('unregistered and degenerate sign routes use the sketch instead of a fabricated photo location',()=>{
 const p=plan(),round={layoutArt:{signImage:'data:image/jpeg;base64,YWJj'},sign:{confirmedAt:1,points:{tee:{x:.5,y:.5},basket:{x:.5,y:.5}}}};
 assert.doesNotMatch(landingPlanMarkup(p,p.candidates[0],round),/<image href=/);
 delete round.sign;assert.doesNotMatch(landingPlanMarkup(p,p.candidates[0],round),/<image href=/);
});
test('no candidate creates no landing, and displayed disc names remain escaped',()=>{
 const p=plan();assert.equal(suggestLanding(p,null),null);assert.equal(landingPlanMarkup(p,null),'');
 const c={...p.candidates[0],disc:{brand:'<script>bad</script>',model:'Model'}};assert.doesNotMatch(landingPlanMarkup(p,c),/<script>/);
});
test('the diagram is advisory and cannot mutate a plan, profile or stored hole',()=>{
 const p=plan({layoutNotes:'Water 20 ft behind basket.'}),round={throws:[],layoutArt:{}},before=JSON.stringify({p,round});
 landingPlanMarkup(p,p.candidates[0],round);assert.equal(JSON.stringify({p,round}),before);
});
