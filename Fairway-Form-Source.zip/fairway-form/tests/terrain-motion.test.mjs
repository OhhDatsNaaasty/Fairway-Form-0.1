import {test} from 'node:test';
import assert from 'node:assert/strict';
import {buildHoleScene,holeSceneSVG,createTerrainFrameRenderer} from '../dist/lib/hole-scene.js';
import {planShot} from '../dist/lib/caddy.js';
import {DISCS} from '../dist/lib/discs.js';
import {suggestLanding,landingPlanMarkup,landingSignSketch} from '../dist/lib/landing-zone.js';
import {sceneForRound} from '../dist/lib/layout-art.js';
import {analyzeSignDiagram} from '../dist/lib/sign-diagram.js';
import {confirmedSignDiagram} from '../dist/lib/sign-scene.js';
import {fairwaySign} from './fixtures/fairway-sign.mjs';

// Attribute-only DOM double: compare retained nodes against independent complete
// SVG renders. Actual DOM identity and touch behavior also run in the browser gate.
const attrs=tag=>Object.fromEntries([...tag.matchAll(/([\w-]+)="([^"]*)"/g)].map(m=>[m[1],m[2].replace(/&quot;/g,'"').replace(/&amp;/g,'&')]));
class Node{
 constructor(values){this.values=values;this.children=[]}
 getAttribute(k){return this.values[k]??null}
 setAttribute(k,v){this.values[k]=String(v)}
 insertBefore(n,before){this.children=this.children.filter(c=>c!==n);const at=before?this.children.indexOf(before):this.children.length;this.children.splice(at,0,n)}
}
function parse(svg){
 const nodes=new Map(),objects=new Node({});let root;
 for(const match of svg.matchAll(/<(?:svg|path|g|text|circle)\b[^>]*>/g)){
  const a=attrs(match[0]),node=new Node(a);if(match[0].startsWith('<svg '))root=node;
  if(a['data-orbit-key']){assert.ok(!nodes.has(a['data-orbit-key']),'duplicate moving element');nodes.set(a['data-orbit-key'],node);if(a['data-orbit-key'].startsWith('object-'))objects.children.push(node)}
 }
 return {nodes,objects,root};
}
function host(){return {writes:0,set innerHTML(value){this.writes++;this.markup=value;Object.assign(this,parse(value))},querySelector(s){return s==='svg'?this.root:s==='[data-orbit-objects]'?this.objects:null},querySelectorAll(){return [...this.nodes.values()]}}}
const scenarios=[
 ['flat', {distance:475,line:'Slight dogleg left',note:'Trees along both sides. Water 20 ft behind basket.'}],
 ['elevated', {distance:475,line:'Slight dogleg right',note:'Tee elevated 12 ft. Basket sits on a small hill 8 ft high. Tree 150 ft from the tee on the right. Water 20 ft behind basket.',hazard:'both'}],
 ['turns', {distance:440,line:'Left then right',note:'Fairway starts uphill at 120 ft and rises 20 ft over the next 160 ft. Road along the right side. Large group of trees 230 ft on the left.'}]
];
for(const [name,raw]of scenarios)test('retained '+name+' view matches independent complete renders through an orbit',()=>{
 const scene=buildHoleScene(raw),target={point:{x:150,y:240},targetFt:220},before=JSON.stringify({scene,target}),h=host(),paint=createTerrainFrameRenderer(h,scene,{target}),original=new Map(h.nodes);
 for(const angle of [0,.2,15,45,89.8,90,135,180,225,270,315,359.8,360]){
  paint(angle);const expected=parse(holeSceneSVG(scene,{labels:true,target,angle}));assert.equal(h.nodes.size,expected.nodes.size);
  for(const [key,node]of expected.nodes){assert.ok(h.nodes.has(key),key);assert.deepEqual(h.nodes.get(key).values,node.values,'Projection mismatch: '+key+' at '+angle);assert.equal(h.nodes.get(key),original.get(key),'Node replaced: '+key)}
  assert.deepEqual(h.objects.children.map(n=>n.getAttribute('data-orbit-key')),expected.objects.children.map(n=>n.getAttribute('data-orbit-key')));
 }
 assert.equal(h.writes,1);assert.equal(JSON.stringify({scene,target}),before);
});
test('flat ground uses one surface while genuine hills retain their terrain mesh',()=>{
 assert.equal((holeSceneSVG(buildHoleScene(scenarios[0][1])).match(/data-orbit-key="mesh-/g)??[]).length,0);
 assert.equal((holeSceneSVG(buildHoleScene(scenarios[1][1])).match(/data-orbit-key="mesh-/g)??[]).length,520);
});
test('tree and basket scale changes retain fractional precision at small angle steps',()=>{
 const s=buildHoleScene(scenarios[0][1]),h=host(),paint=createTerrainFrameRenderer(h,s),node=h.nodes.get('object-basket');paint(20);const first=node.getAttribute('transform');paint(20.2);assert.notEqual(first,node.getAttribute('transform'));assert.match(node.getAttribute('transform'),/scale\(\d\.\d{3,5}\)/);
});
test('confirmed photo remains available while landing defaults to the mapped 3D geometry',()=>{
 const f=fairwaySign(),a=analyzeSignDiagram(f),d=confirmedSignDiagram({...a,imageAspect:f.width/f.height,visual:{trees:a.trees,corridorHalfWidth:a.corridorHalfWidth}}),photo='data:image/jpeg;base64,YWJj',round={draft:{distanceFt:255,fairway:'straight'},layoutArt:{signImage:photo,signDiagram:d}},p=planShot({distanceFt:255,fairway:'straight',type:'backhand',hand:'right',hazard:'none'},[{id:'b',discId:'discraft-buzzz',distance:260}],DISCS),c=p.candidates[0],zone=suggestLanding(p,c,round),markup=landingPlanMarkup(p,c,round);
 assert.equal(sceneForRound(round).signImage,photo);assert.equal(zone.scene.geometrySource,'sign');assert.equal(zone.scene.features.filter(f=>f.imageDerived).length,9);assert.match(markup,/data-terrain-view="3d"/);assert.match(markup,/data-landing-target/);assert.doesNotMatch(markup,/<image|<img/);assert.equal(zone.targetFt,c.targetFt);assert.equal(zone.scene.signImage,photo);const photoView=landingSignSketch(zone,round);assert.match(photoView,/<image href=/);assert.match(photoView,/data-landing-target=/);
 const h=host(),paint=createTerrainFrameRenderer(h,zone.scene,{target:zone}),before=JSON.stringify(zone);for(let angle=0;angle<360;angle+=15)paint(angle);assert.equal(h.writes,1);assert.equal(h.nodes.get('target-ring').values['data-orbit-key'],'target-ring');assert.equal(JSON.stringify(zone),before);
});
