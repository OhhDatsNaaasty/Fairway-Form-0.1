import {test} from 'node:test';import assert from 'node:assert/strict';
import {prepareSignDrag,assertSignDrag} from '../scripts/lib/sign-drag-smoke.mjs';
async function fixture(run,{obstructed=false}={}){
 const old={document:globalThis.document,window:globalThis.window,requestAnimationFrame:globalThis.requestAnimationFrame};let frames=0,scrollOptions;const attributes={cx:'200',cy:'800'},dot={getAttribute:k=>attributes[k],getBoundingClientRect:()=>({left:100,top:frames>=2?300:-500,width:20,height:20})},group={dataset:{marker:'tee'},isConnected:true,scrollIntoView:v=>scrollOptions=v,querySelector:()=>dot},stage={closest:()=>null,getBoundingClientRect:()=>({left:20,top:40,width:300,height:600})};let current=group;
 const window={scrollX:0,scrollY:200,innerWidth:390,innerHeight:844},document={getElementById:id=>id==='caddySignOverlay'?{querySelector:()=>current}:id==='caddySignStage'?stage:{textContent:'Marker updated'},querySelector:()=>current,elementFromPoint:(x,y)=>!obstructed&&frames>=2&&x===110&&y===310?{closest:()=>current}:{tagName:'NAV',closest:()=>null},addEventListener(){}};
 globalThis.document=document;globalThis.window=window;globalThis.requestAnimationFrame=cb=>queueMicrotask(()=>{frames++;cb()});
 try{await run({window,attributes,group,replace:()=>current={...group},get frames(){return frames},get scrollOptions(){return scrollOptions}})}finally{for(const [key,v]of Object.entries(old))if(v===undefined)delete globalThis[key];else globalThis[key]=v}
}
test('drag preparation waits for final viewport coordinates and requests instant scrolling',async()=>{
 await fixture(async f=>{const p=await prepareSignDrag('tee');assert.deepEqual(p,{x:110,y:310});assert.equal(f.frames,2);assert.equal(f.scrollOptions.behavior,'instant');assert.equal(f.window.qaSignDrag.hit,'tee')});
});
test('an obstructed/off-target marker fails before sending a gesture, with hit-test diagnostics',async()=>{
 await fixture(async()=>{await assert.rejects(prepareSignDrag('tee'),/cannot start.*NAV/)},{obstructed:true});
});
test('an unchanged marker fails with its location and event evidence',async()=>{
 await fixture(async f=>{await prepareSignDrag('tee');f.window.qaSignEvents.push({type:'pointerdown',target:'NAV'});assert.throws(()=>assertSignDrag('tee'),/Marker did not move.*pointerdown.*NAV/)});
});
test('movement passes only when the same live SVG handle remains connected',async()=>{
 await fixture(async f=>{await prepareSignDrag('tee');f.attributes.cx='220';assert.equal(assertSignDrag('tee'),true);f.group.isConnected=false;assert.throws(()=>assertSignDrag('tee'),/handle was replaced/)});
});
test('a newly rendered replacement is rejected even when its markup position changes',async()=>{
 await fixture(async f=>{await prepareSignDrag('tee');f.attributes.cx='220';f.replace();assert.throws(()=>assertSignDrag('tee'),/handle was replaced/)});
});
