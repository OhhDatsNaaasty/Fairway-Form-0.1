import vm from 'node:vm';
import {assertReviewedCaddySources} from '../scripts/lib/research-smoke.mjs';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {planShot,makeHole,recordThrow,normalizeShot} from '../dist/lib/caddy.js';
import {DISCS} from '../dist/lib/discs.js';
import {CADDY_RESEARCH,CADDY_RESEARCH_LESSONS} from '../dist/lib/caddy-research.js';
import {SOURCES,KNOWLEDGE} from '../dist/lib/knowledge.js';
import {historyBackup,validateHistory} from '../dist/lib/disc-history.js';
const bag=[{id:'f',discId:'innova-teebird',distance:260,alternateDistance:150},{id:'m',discId:'discraft-buzzz',distance:230},{id:'p',discId:'innova-aviar',distance:170,puttingRange:25}];
const raw={distanceFt:250,fairway:'straight',type:'auto',hand:'right'};
const plan=(notes='',extra={},profile={skill:'intermediate'},copies=bag)=>planShot({...raw,layoutNotes:notes,...extra},copies,DISCS,[],{profile});
test('water just beyond the basket removes the near-maximum-power objective',()=>{for(const extra of [{},{windDirection:'head',windStrength:'strong',elevation:'uphill'},{risk:'attack'}]){const p=plan('Water just past basket.',extra);assert.ok(p.candidates.length);assert.match(p.strategy,/short of trouble/);for(const c of p.candidates){assert.equal(c.landing.hazardous,true);assert.notEqual(c.power.effort,'firm');assert.ok(c.power.targetFt/c.power.referenceFt<=.8200001);assert.ok(c.targetFt<250)}}});
test('structured long trouble also changes the target without requiring notes',()=>{const p=plan('',{hazard:'long'});assert.ok(p.candidates[0].targetFt<250);assert.notEqual(p.candidates[0].power.effort,'firm')});
test('a distant long hazard does not turn a 750-foot open first stage into a putter layup',()=>{const p=plan('Water behind basket.',{distanceFt:750});assert.equal(p.candidates[0].discId,'innova-teebird');assert.ok(p.candidates[0].targetFt>200);assert.equal(p.candidates[0].landing.hazardous,false)});
test('explicit large space beyond the basket differs from tight long trouble',()=>{const tight=plan('Water 10 ft behind basket.'),room=plan('Water 150 ft behind basket.');assert.ok(tight.candidates[0].landing.hazardous);assert.ok(!room.candidates[0].landing.hazardous);assert.ok(room.candidates[0].targetFt>tight.candidates[0].targetFt)});
test('blocked forehand and a known first corner create a controlled backhand placement',()=>{const p=plan('Straight for 200 ft then dogleg right. Forehand blocked.',{distanceFt:350,fairway:'right'});assert.ok(p.candidates.length);assert.ok(p.candidates.every(c=>c.throwType==='backhand'));assert.equal(p.candidates[0].landing.phase,'before-bend');assert.ok(p.candidates[0].targetFt<200);assert.equal(p.candidates[0].lineFit.kind,'straight')});
test('an explicitly open wider backhand route can outrank a forehand on a right dogleg',()=>{const p=plan('Wide backhand line open.',{distanceFt:280,fairway:'right'});assert.equal(p.candidates[0].throwType,'backhand');assert.equal(p.candidates[0].lineFit.kind,'alternate-route');assert.ok(p.candidates.some(c=>c.throwType==='forehand'))});
test('an open straight route is compared independently from the dogleg direction',()=>{const p=plan('Open straight line to basket.',{fairway:'right'});assert.equal(p.candidates[0].lineFit.kind,'straight');assert.match(p.strategy,/open straight route/)});
test('low ceilings and hard ground produce their own release/ground warnings',()=>{const p=plan('Low ceiling. Hard ground. Avoid skip.',{fairway:'left'},{skill:'pro'});assert.ok(p.candidates.length);assert.ok(p.candidates.every(c=>c.cautions.some(s=>s.includes('ground play'))));assert.ok(p.candidates.some(c=>c.cautions.some(s=>s.includes('Hard ground'))));assert.notEqual(p.candidates[0].release.path,'flex')});
test('notes can supply a missing line, but unknown notes cannot invent one',()=>{assert.ok(plan('Dogleg right.',{fairway:''}).candidates.length);assert.throws(()=>plan('Nice place.',{fairway:''}),/current lie/)});
test('required carry cannot be silently converted into a too-short automatic water layup',()=>{const p=plan('Must carry 220 ft over water. Water just past basket.');assert.equal(p.candidates.length,0);assert.match(p.warnings.join(' '),/required carry/)});
test('a sufficient crossing has margin and is never recorded as measured carry',()=>{const p=plan('Must carry 180 ft over water.',{distanceFt:280});assert.ok(p.candidates.length);assert.ok(p.candidates.every(c=>c.targetFt>=198));assert.ok(p.candidates.every(c=>c.rangeFt==null||c.rangeFt>=198));assert.ok(p.candidates.every(c=>c.statistics.measuredCount===0))});
test('an unclear crossing asks for a carry distance instead of guessing',()=>{const p=plan('Water carry unknown.');assert.equal(p.candidates.length,0);assert.match(p.warnings.join(' '),/required carry is unclear/)});
test('notes do not erase selected side hazards when they add trouble long',()=>{const p=plan('Water behind basket.',{hazard:'left'});assert.ok(p.layout.hazards.includes('left'));assert.ok(p.layout.hazards.includes('long'))});
test('unsupported or contradictory notes are exposed rather than treated as complete understanding',()=>{const p=plan('Nice place. Dogleg left. Dogleg right.');assert.match(p.warnings.join(' '),/more than one/);assert.ok(p.layout.unmatched.includes('nice place'));assert.ok(!p.warnings.some(s=>s.includes('no layout constraint')))});
test('only putting intent gets putting pace even when notes mention water',()=>{const p=plan('Water behind basket.',{type:'putt',distanceFt:20});assert.equal(p.candidates[0].throwType,'putt');assert.equal(p.candidates[0].power.band,undefined)});
test('layout evidence survives history backup without inventing a distance result',()=>{const p=plan('Water 20 ft behind basket. Low ceiling.'),h=recordThrow(makeHole(),{plan:p,usedBagId:p.candidates[0].bagId,outcome:'unknown',remainingFt:''}),t=validateHistory(historyBackup([h]),normalizeShot)[0].throws[0];assert.equal(t.input.layoutNotes,p.shot.layoutNotes);assert.equal(t.input.hazard,'long');assert.equal(t.throwDistanceFt,null);assert.equal(t.remainingFt,null);assert.ok(t.plannedTargetFt<250)});
test('the reviewed source database is bundled into both Caddy and the technique library',()=>{assert.equal(assertReviewedCaddySources(CADDY_RESEARCH,SOURCES),true);for(const k of CADDY_RESEARCH_LESSONS)assert.ok(KNOWLEDGE.find(x=>x.id===k.id));assert.match(CADDY_RESEARCH.scienceGeometry.reviewNote,/abstract/)});
test('planning never mutates bag, raw notes, manufacturer ratings or caller profile',()=>{const input={...raw,layoutNotes:'Water behind basket.'},copies=structuredClone(bag),catalog=structuredClone(DISCS),profile={skill:'beginner'},before=JSON.stringify({input,copies,catalog,profile});planShot(input,copies,catalog,[],{profile});assert.equal(JSON.stringify({input,copies,catalog,profile}),before)});

test('the exact browser source guard accepts the current expanded registry',()=>{
 const browserGuard=vm.runInNewContext('('+assertReviewedCaddySources.toString()+')');assert.ok(CADDY_RESEARCH.scienceSkyWeather);assert.equal(browserGuard(CADDY_RESEARCH,SOURCES),true);
});
test('source guard accepts another fully reviewed reference without a count mismatch',()=>{
 const additional={...CADDY_RESEARCH.scienceSkyWeather,title:'Additional documented reference',url:'https://example.org/qa-reviewed-reference'},browserGuard=vm.runInNewContext('('+assertReviewedCaddySources.toString()+')');assert.equal(browserGuard({...CADDY_RESEARCH,qaAdditional:additional},{...SOURCES,qaAdditional:additional}),true);
});
test('source guard names missing required references in either registry',()=>{
 for(const id of ['scienceFlight','scienceSkyWeather']){const research={...CADDY_RESEARCH},library={...SOURCES};delete research[id];assert.throws(()=>assertReviewedCaddySources(research,SOURCES),new RegExp(id));delete library[id];assert.throws(()=>assertReviewedCaddySources(CADDY_RESEARCH,library),new RegExp(id))}
});
test('source guard rejects missing review details and mismatched library links',()=>{
 const id='scienceSkyWeather';for(const edit of [{reviewed:''},{reviewNote:''},{preview:'too short'},{url:'http://example.org'},{title:''}])assert.throws(()=>assertReviewedCaddySources(CADDY_RESEARCH,{...SOURCES,[id]:{...SOURCES[id],...edit}}),/scienceSkyWeather/);
 assert.throws(()=>assertReviewedCaddySources(CADDY_RESEARCH,{...SOURCES,[id]:{...SOURCES[id],url:'https://example.org/wrong'}}),/scienceSkyWeather/);assert.throws(()=>assertReviewedCaddySources({...CADDY_RESEARCH,[id]:{...CADDY_RESEARCH[id],appliedTo:[]}},SOURCES),/scienceSkyWeather/);
});
