import {test} from 'node:test';import assert from 'node:assert/strict';
import {createScrubQueue} from '../dist/lib/review-scrub.js';
import {createFrameReview} from '../dist/lib/frame-review.js';
const gate=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no});return {promise,resolve,reject}};
const tick=()=>new Promise(resolve=>setImmediate(resolve));
test('a hundred rapid inputs produce one active decode and only the newest queued target',async()=>{
 const requests=[],states=[];const q=createScrubQueue({seek:(time,settings)=>{const g=gate();requests.push({time,...settings,...g});return g.promise},onState:s=>states.push(s)});const promises=[];for(let i=0;i<100;i++)promises.push(q.request(i/100));assert.equal(requests.length,1);assert.equal(requests[0].signal.aborted,false);assert.equal(q.target,.99);requests[0].resolve(0);await tick();assert.equal(requests.length,2);assert.equal(requests[1].time,.99);assert.equal(q.pending,true);requests[1].resolve(.9667);const values=await Promise.all(promises);assert.equal(values.at(-1),.9667);assert.ok(values.slice(0,-1).every(v=>v===null));assert.equal(q.pending,false);assert.equal(states.at(-1).pending,false);
});
test('cancelling for a new clip prevents an old decode from settling or draining its old target',async()=>{
 const requests=[];const q=createScrubQueue({seek:time=>{const g=gate();requests.push({time,...g});return g.promise}});const old=q.request(1),skipped=q.request(2);q.cancel();assert.equal(await old,null);assert.equal(await skipped,null);const fresh=q.request(.1);requests[0].resolve(1);await tick();assert.equal(q.pending,true);assert.equal(requests.length,2);requests[1].resolve(.1);assert.equal(await fresh,.1);assert.equal(q.pending,false);
});
test('only failure at the current final target is reported; earlier failed targets yield to a new target',async()=>{
 const requests=[],errors=[];const q=createScrubQueue({seek:()=>{const g=gate();requests.push(g);return g.promise},onError:e=>errors.push(e.message)});const a=q.request(1),b=q.request(2);requests[0].reject(Error('old decode'));await tick();assert.deepEqual(errors,[]);requests[1].reject(Error('latest decode'));await Promise.all([a,b]);assert.deepEqual(errors,['latest decode']);assert.equal(q.pending,false);assert.equal(await q.request(NaN),null);
});
test('an externally aborted prepared-image request cannot present late pixels',async()=>{
 const pending=gate(),shown=[],parent=new AbortController(),review=createFrameReview({times:[0,1],sample:()=>pending.promise,close(){}},{onFrame:f=>shown.push(f.t)});const work=review.seek(1,{signal:parent.signal,timeout:100});parent.abort();pending.resolve({t:1,source:{}});await work;assert.deepEqual(shown,[]);assert.equal(review.time,0);review.close();
});
test('a stalled prepared image has a bounded error and the last displayed time stays usable',async()=>{
 const review=createFrameReview({times:[0,1],sample:()=>new Promise(()=>{}),close(){}});await assert.rejects(review.seek(1,{timeout:12}),/taking too long/);assert.equal(review.canMark,true);assert.equal(review.time,0);review.close();
});
test('prepared review plus queued scrubbing does not cancel its active decode on each request',async()=>{
 const requests=[],shown=[];const review=createFrameReview({times:[0,1,2],sample:(t,{signal})=>{const g=gate();requests.push({t,signal,...g});return g.promise},close(){}},{onFrame:f=>shown.push(f.t)}),q=createScrubQueue({seek:(t,options)=>review.seek(t,options)});const a=q.request(1),b=q.request(2);assert.equal(requests[0].signal.aborted,false);requests[0].resolve({t:1,source:{}});await tick();assert.equal(q.pending,true);requests[1].resolve({t:2,source:{}});await Promise.all([a,b]);assert.deepEqual(shown,[1,2]);assert.equal(review.time,2);assert.equal(q.pending,false);review.close();
});
