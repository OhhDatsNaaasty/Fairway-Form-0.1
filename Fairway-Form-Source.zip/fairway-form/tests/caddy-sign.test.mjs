import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parseSignText,markedRoute,recognizeSignPhoto} from '../dist/lib/caddy-sign.js';
test('sign distances need explicit units and do not confuse hole/par labels with range',()=>{
 const result=parseSignText('Hole 7 Par 3 Blue 320 ft Red 84 m');
 assert.equal(result.hole,'7');assert.equal(result.distances.length,2);assert.equal(result.distances[0].feet,320);assert.ok(Math.abs(result.distances[1].feet-275.59055)<.01);
 assert.equal(parseSignText('Hole 7 Par 3 320').distances.length,0);
});
test('feet marks, decimals and comma distances are parsed within bounds',()=>{
 const result=parseSignText("White 285′ Red 80.5 meters Long 1,240 feet Bad 9999 ft");
 assert.deepEqual(result.distances.map(d=>d.value),[285,80.5,1240]);
});
test('multiple tees/baskets remain candidates and no active pin is guessed',()=>{
 const result=parseSignText('Tee A 200 ft Tee B 350 ft Basket C 400 ft');assert.equal(result.distances.length,3);assert.ok(!('selectedDistance'in result));
});
test('literal route, slope and hazard words are suggestions, not invented diagram recognition',()=>{
 const result=parseSignText('Hole 4 Dogleg left Uphill Water OB');assert.equal(result.fairway,'left');assert.equal(result.elevation,'uphill');assert.equal(result.hazards,true);
 assert.equal(parseSignText('Hole 4').fairway,null);assert.equal(parseSignText('uphill downhill dogleg left dogleg right').elevation,null);
});
test('a marked dogleg is rotation-independent in the sign image',()=>{
 const route={tee:{x:.2,y:.8},bend:{x:.2,y:.3},basket:{x:.7,y:.3}};
 assert.equal(markedRoute(route).fairway,'right');
 const rotated=Object.fromEntries(Object.entries(route).map(([k,p])=>[k,{x:1-p.y,y:p.x}]));assert.equal(markedRoute(rotated).fairway,'right');
 assert.equal(markedRoute({...route,basket:{x:.05,y:.3}}).fairway,'left');
});
test('missing, degenerate or out-of-image markers cannot establish a dogleg',()=>{
 for(const points of [{},{tee:{x:.1,y:.1},bend:{x:.1,y:.1},basket:{x:.7,y:.7}},{tee:{x:-1,y:.1},bend:{x:.2,y:.3},basket:{x:.7,y:.7}}])assert.equal(markedRoute(points).fairway,null);
 assert.match(markedRoute({tee:{x:.1,y:.1},bend:{x:.4,y:.4},basket:{x:.8,y:.8}}).note,/No map distance/);
});
test('the browser fallback explicitly declines automatic OCR instead of using a fake result',async()=>{
 await assert.rejects(recognizeSignPhoto('data:image/jpeg;base64,AA==',{bridge:null}),/updated Android APK/);
});
test('OCR bridge responses are request-matched and cleaned up after success or timeout',async()=>{
 const old=globalThis.window,events=new EventTarget();globalThis.window=events;
 try{
  const bridge={recognizeSign(id){queueMicrotask(()=>{const wrong=new Event('fairway-sign-text');wrong.detail={id:'another',text:'999 ft'};events.dispatchEvent(wrong);const event=new Event('fairway-sign-text');event.detail={id,text:'Hole 2 220 ft'};events.dispatchEvent(event)})}};
  assert.equal((await recognizeSignPhoto('data:image/jpeg;base64,AA==',{bridge})).distances[0].feet,220);
  await assert.rejects(recognizeSignPhoto('data:image/jpeg;base64,AA==',{bridge:{recognizeSign(){}},timeout:5}),/timed out/);
 }finally{if(old===undefined)delete globalThis.window;else globalThis.window=old}
});
