import {test} from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {PassThrough} from 'node:stream';
import {spawn} from 'node:child_process';
import {superviseBrowser} from '../scripts/lib/browser-supervisor.mjs';
import {listenForBrowserChecks} from '../scripts/lib/browser-progress.mjs';
class Worker extends EventEmitter{
 constructor(){super();this.stdout=new PassThrough();this.stderr=new PassThrough();this.signals=[];this.resist=false;this.dead=false}
 kill(signal){this.signals.push(signal);if(!this.resist||signal==='SIGKILL')this.close(null,signal)}
 close(code=0,signal=null){if(this.dead)return;this.dead=true;this.emit('close',code,signal)}
 progress(stage='QA stage',activity='QA activity',extra={}){this.emit('message',{type:'browser-progress',stage,activity,...extra})}
}
const defaults={timeoutMs:1000,idleMs:300,heartbeatMs:20,killGraceMs:20,log:()=>{}};
test('supervisor reports success only after worker exit and streams its live output',async()=>{
 const child=new Worker(),output=[],logs=[];const result=superviseBrowser({...defaults,spawnWorker:()=>child,output:(stream,data)=>output.push([stream,data.toString()]),log:line=>logs.push(line)});
 child.progress('Photo checks','Runtime.evaluate');child.stdout.write('QA progress\n');child.stderr.write('QA diagnostic\n');child.close(0);
 const r=await result;assert.equal(r.outcome,'passed');assert.equal(r.exitCode,0);assert.equal(r.lastStage,'Photo checks');assert.equal(r.lastActivity,'Runtime.evaluate');assert.match(r.stdoutTail,/QA progress/);assert.match(r.stderrTail,/QA diagnostic/);assert.equal(output.length,2);assert.ok(logs.some(line=>line.includes('Stage: Photo checks')));
});
test('an environment block is a distinct nonzero result, even if a worker reports exit zero',async()=>{
 const child=new Worker(),pending=superviseBrowser({...defaults,spawnWorker:()=>child});child.progress('Socket preflight','listen',{blocked:'EPERM: sockets denied'});child.close(0);const r=await pending;assert.equal(r.outcome,'blocked');assert.equal(r.exitCode,2);assert.match(r.error,/EPERM/);
});
test('a silent worker gets heartbeats, a bounded idle timeout and a force-stop if needed',async()=>{
 const child=new Worker(),logs=[];child.resist=true;const start=Date.now(),pending=superviseBrowser({...defaults,idleMs:60,heartbeatMs:10,spawnWorker:()=>child,log:line=>logs.push(line)});child.progress('Pose model check','Runtime.evaluate');const r=await pending;
 assert.equal(r.outcome,'timed-out');assert.equal(r.exitCode,124);assert.match(r.error,/No test-step progress/);assert.deepEqual(child.signals,['SIGTERM','SIGKILL']);assert.ok(logs.some(line=>line.includes('elapsed')&&line.includes('Pose model check')));assert.ok(Date.now()-start<1500);
});
test('the total deadline still stops a worker that continuously reports progress',async()=>{
 const child=new Worker(),ticker=setInterval(()=>child.progress('QA repeated progress'),5);try{const r=await superviseBrowser({...defaults,timeoutMs:70,spawnWorker:()=>child});assert.equal(r.outcome,'timed-out');assert.match(r.error,/total limit/);assert.deepEqual(child.signals,['SIGTERM'])}finally{clearInterval(ticker)}
});
test('worker launch and process errors fail without an unbounded wait',async()=>{
 const thrown=await superviseBrowser({...defaults,spawnWorker:()=>{throw Error('QA ENOENT')}});assert.equal(thrown.outcome,'failed');assert.match(thrown.error,/ENOENT/);
 const child=new Worker(),pending=superviseBrowser({...defaults,spawnWorker:()=>child});child.emit('error',Error('QA spawn error'));const r=await pending;assert.equal(r.outcome,'failed');assert.equal(r.exitCode,1);assert.match(r.error,/spawn error/);
});
test('user cancellation stops the worker and cannot be mistaken for a passing run',async()=>{
 const child=new Worker(),controller=new AbortController(),pending=superviseBrowser({...defaults,spawnWorker:()=>child,signal:controller.signal});controller.abort();const r=await pending;assert.equal(r.outcome,'interrupted');assert.equal(r.exitCode,130);assert.deepEqual(child.signals,['SIGTERM']);
});
test('a failed worker preserves the last test stage and nonzero exit code',async()=>{
 const child=new Worker(),pending=superviseBrowser({...defaults,spawnWorker:()=>child});child.progress('Caddy feedback','waiting for saved result');child.close(1);const r=await pending;assert.equal(r.outcome,'failed');assert.equal(r.exitCode,1);assert.equal(r.lastStage,'Caddy feedback');
});
class Server extends EventEmitter{listen(port,host,ready){assert.equal(host,'127.0.0.1');this.start?.(ready)}}
test('socket permission denial fails preflight promptly with an explicit blocked classification',async()=>{
 const server=new Server();server.start=()=>queueMicrotask(()=>server.emit('error',Object.assign(Error('QA denied'),{code:'EPERM'})));
 await assert.rejects(listenForBrowserChecks(server,{timeoutMs:40}),error=>{assert.equal(error.code,'BROWSER_ENV_BLOCKED');assert.match(error.message,/No browser checks passed/);assert.match(error.message,/GitHub/);return true});assert.equal(server.listenerCount('error'),0);
});
test('silent local-server startup is bounded, and successful startup removes its timer/listeners',async()=>{
 const silent=new Server();await assert.rejects(listenForBrowserChecks(silent,{timeoutMs:10}),/did not start/);assert.equal(silent.listenerCount('error'),0);
 const ready=new Server();ready.start=done=>queueMicrotask(done);await listenForBrowserChecks(ready,{timeoutMs:40});assert.equal(ready.listenerCount('error'),0);
});
test('an event-loop-blocked real Node worker is stopped by the separate supervisor',async()=>{
 let child;const start=Date.now();const r=await superviseBrowser({...defaults,idleMs:200,killGraceMs:40,spawnWorker:()=>child=spawn(process.execPath,['-e',"process.on('SIGTERM',()=>{});process.send({type:'browser-progress',stage:'Blocked JavaScript loop',activity:'QA CPU hang'},()=>{while(true){}})"],{detached:process.platform!=='win32',stdio:['ignore','pipe','pipe','ipc']})});assert.equal(r.outcome,'timed-out');assert.equal(r.exitCode,124);assert.equal(r.lastStage,'Blocked JavaScript loop');assert.ok(Date.now()-start<2500);assert.ok(child.killed||child.signalCode);assert.notEqual(child.exitCode,0);
});
