# Catalog flight audit and BuzzzSaw product version

Checked 2026-10-23. This release audits the existing expanded catalog and adds searchable product-version facts; it does not claim a new independent review of all 850 discs.

| Coverage | Count | Meaning |
| --- | ---: | --- |
| Catalog molds | 850 | Stable IDs across 28 brands |
| Complete speed/glide/turn/fade | 850 | Numeric reference ratings for every mold |
| Manufacturer-sourced rating records | 312 | Original manufacturer collection plus reviewed additions |
| Reference-catalog rating records | 538 | Dated DiscGolfDojo chart snapshots; labeled Reference catalog |
| Manufacturer-informed purpose summaries | 21 | Individual original written summaries in disc-flight-data.js |
| Reviewed manufacturer chart links | 44 | 42 mold-specific links plus Discmania FD/DD3 lineup-chart references |
| Rating-based role/range/shape | 850 | Computed planning interpretation, not manufacturer-rated distance |

Counts are computed by flightCoverage in dist/lib/disc-flight.js and tested against the bundled catalog. Existing manufacturer ID/rating preservation and catalog import round trips remain tested. A same-rated comparison, when available, is explicitly labeled an analogue and never establishes an exact flight or carry distance for a different mold. A brand chart link is not evidence that each mold on it was separately verified. All diagrams are illustrative; cross-brand ratings, weight, plastic, wear, release, spin and power introduce variation.

## BuzzzSaw is a version of Buzzz

Primary sources reviewed:

- Discraft, **Fuzed Z Buzzz with BuzzzSaw Pattern**: https://www.discraft.com/fuzed-z-buzzz-with-buzzzsaw-pattern-fuzbuzzz . Specifications identify MODEL Buzzz and PLASTIC BLEND Fuzed. Description supports a controlled straight-to-fade role and increased torque resistance. It does not publish a separate four-number BuzzzSaw rating in the readable specifications.
- Discraft, **Buzzz**: https://www.team.discraft.com/discs/buzzz . Publishes speed 5, glide 4, turn -1, fade 1 and a flight-path section. These remain the underlying mold’s baseline, not a newly measured Fuzed-only rating.
- Discraft, **Evolution of Discraft’s Buzzzsaw**: https://www.team.discraft.com/post/evolution-of-discraft-s-buzzzsaw . Manufacturer history describes the Buzzz-based molding process and several releases. Published September 19, 2024, updated October 4, 2024; this is historical context rather than a current stock-status claim.
- Discraft Support, **What are these numbers on my disc?**: https://support.discraft.com/support/solutions/articles/44001621475-what-are-these-numbers-on-my-disc- . Flight numbers describe idealized characteristics; individual players’ arm speed, release and form change actual flight.

Original app wording summarizes these facts; manufacturer articles are not copied into the app. The catalog-version module adds aliases including the user’s spelling buzzsaw. Its quick-add button sets the bag copy’s plastic/version, keeps the canonical discraft-buzzz mold ID, and creates a new physical-copy ID. This keeps all original bag references valid, counts ownership consistently, and lets the new copy learn separately from any ESP/Z Buzzz already in the bag. There is no fabricated BuzzzSaw photograph or independent flight chart.

For previous catalog source selection, merge precedence and rating differences, see DISC-CATALOG-EXPANSION-1.9.0.md and DISC-CATALOG-SOURCES.md. For role/range and weather/shot-shape rules, see CADDY-FLIGHT-RESEARCH-1.3.1.md and SHOT-PROFILE-RESEARCH-1.4.0.md. Caddy remains an explained rules engine using saved physical-copy history, not an AI simulation or guaranteed route prediction.
