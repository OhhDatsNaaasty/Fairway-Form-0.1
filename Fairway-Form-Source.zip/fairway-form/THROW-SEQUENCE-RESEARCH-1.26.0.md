# Throwing sequence research and analyzer changes — 1.26.0

The reported failure is automatic event selection: plant in an earlier walk-up
step, missed phases and an almost always missing follow-through. The goal is an
automatic review, with occasional correction instead of a required manual event
labeling task. Source code has been changed accordingly; the user's original
failing video remains unavailable, so on-device accuracy has not been measured.

## Research used

Six source records were reviewed on 2026-11-01. Four new sources are in the
app's offline knowledge database with original summaries, access provenance and
links. Existing Innova source identities remain intact. The library now has
92 lessons and 69 source records, including four new sequence lessons.

- [Innova illustrated X-step](https://www.innovadiscs.com/wp-content/uploads/pdf/X-Step_how-to.pdf):
  text and drawing inspected. The rear-foot crossover leads to the last
  throwing-side stride; pivot and body continuation are part of the sequence.
- [Innova backhand distance instruction](https://www.innovadiscs.com/tips/how-to-throw-backhands-really-far/):
  manufacturer guidance relates peak backswing to plant and support to release.
  Embedded videos were not played.
- [Inside the Circle DG: reachback timing](https://www.insidethecircledg.com/post/when-should-full-reach-back-happen-in-disc-golf):
  article and three linked Eagle McMahon stills visually inspected. They show
  the final foot approaching contact while the arm finishes its preparation,
  then toe contact with little further arm-position change. The article also
  describes player variation. These stills do not contain source timestamps
  and cannot establish a millisecond benchmark or forces under the foot.
- [Ultiworld: Don't Fake Your X-Step](https://discgolf.ultiworld.com/2022/07/26/tuesday-tips-dont-fake-your-x-step/):
  connects footwork with shoulder/hip turn. Its instructional sensations are
  not measurements or a validated detector. Linked videos were not played.
- [Ultiworld: Stop Rounding](https://discgolf.ultiworld.com/2022/01/11/tuesday-tips-stop-rounding-or-how-to-fix-disc-golfs-most-common-flaw/):
  allows compact and longer backswings connected to the body turn. A straight
  elbow or maximum reach is not necessary to identify preparation.
- [Ultiworld: Breaking Down the Backhand](https://discgolf.ultiworld.com/2017/03/28/tuesday-tips-breaking-backhand/):
  article and movement graphic visually inspected for phase definitions and
  continuing arm/body finish. Its older hip-lock wording conflicts with other
  teaching and is not adopted as an analysis rule.

The central inference is that final plant and end of backswing should be
compared as neighboring events, but never forced to share a timestamp. Doing
that would conceal early/late timing instead of detecting it. The approach
must not assume a three-step walk-up, a mandatory hop, a straight arm or a pro
silhouette. Research informs these definitions; the numeric noise tolerances
remain unvalidated app heuristics.

Machine-readable provenance, external image hashes and implementation uses are
in research/throw-sequence-review-1.26.0.json. No third-party screenshots, PDFs,
full transcripts or videos are bundled, and no pose weights were retrained.

## Changes to event logic

- Release candidates are compared using sustained forward hand motion plus
  preparation, final contact and continuation. Faster unrelated hand pumps
  need not win. Near-equal speed plateaus use their later portion instead of
  an arbitrary floating-point maximum. Genuine competing sequences can still
  ask for a range/correction. This remains a swing cue, not disc separation.
- Backswing finds the last visible reversal feeding the swing, including
  compact bent-arm motion, rather than the deepest wrist position anywhere in
  the preceding approach. Manual anchors stay authoritative when measurable.
- Plant combines near-ground foot settling, preceding movement, lead-foot
  identity and—in a side view—position ahead of the rear foot. An intervening
  airborne stride rules out earlier contacts. Consecutive settling samples
  are grouped so the event stays at the start of settling, not a later pause.
  A post-release recovery step cannot replace a foot already down at release.
  Backswing proximity is only a small candidate tie-breaker, never an equality
  constraint. Standstills and moving cameras do not invent new landings.
- The crossover timeline previously selected “Before the crossover” through a
  loose string match. It now selects “Suggested crossover” or the explicit
  user marker. Local torso orientation around the crossing is checked instead
  of requiring every early walk-up step to look sideways.
- Follow-through uses continuing arm motion relative to the shoulder, with
  a tempo-sensitive review horizon and a stop before another swing. It no
  longer picks the last frame in a fixed +0.2 to +0.7 second window. A visible
  near-side torso/arm can support this even with a hidden far hip. A cropped
  finish or stationary arm does not receive an invented event.
- Coil compares a series of model-estimated shoulder and hip headings: angular
  sweep, smoothed separation and its change. It has an editable timeline phase
  and a linked sequence lesson. Missing depth/far joints stay unavailable;
  absolute torso turn is not mislabeled as measured twist or stored energy.
- A coherent automatic preparation/landing/continuation sequence gets an
  observational coaching plan without mandatory release marking. A clear
  standstill can use preparation/continuation without inventing a plant.
  Weak/ambiguous sequences retain the focused release-check flow. Automatic
  events stay suggestions and do not certify good/bad biomechanics. Personal
  fault/praise judgments still require stronger anchoring; advice explains the
  visible sequence and a practical experiment rather than claiming certainty.

The decoder, landmark model, original-video default, compatibility frame cache,
startup behavior, signing identity, storage schema, bag/catalog and course data
are preserved. Existing saved sessions are recalculated when opened/analyzed
and only overwritten when saved by the user.

## Verification and remaining limits

700 JavaScript tests passed with zero failures/skips/cancellations, including
16 new regression tests. The coordinate fixtures cover 3/5/7-step approaches,
15/30/60 samples per second, both hands and screen directions, 0.6×/1×/2×
playback timing, delayed plant, faster unrelated pumps, far-hip occlusion,
recovery steps, standstill and missing/constant depth. They establish intended
logic behavior, not human-video accuracy or clinical correctness.

Changed JavaScript syntax and twelve embedded browser checked-step expressions
were parsed. The offline shell includes both new runtime modules. The required
GitHub browser gate adds a named synthetic sequence/UI check, while retaining
real H.264/model and prepared-frame checks. This synthetic UI report is not
stored as user/model evidence.

Fresh local browser run a7cdc2df-4fa6-47fc-b49d-5aa44636a0d6 at
2026-11-01T07:06:24Z was BLOCKED by socket EPERM in about 0.2 seconds. No local
browser/model or Android compile/signing/physical-device pass is claimed.
GitHub still must pass the mandatory browser/model, Android and APK checks.

No real human-labeled benchmark clips are present. Further accuracy work needs
independently identified events in real videos across viewpoints and codecs.
No guaranteed detection rate, exact release accuracy or universal timing/coil
threshold is claimed. Hidden feet/hand, pose identity swaps, motion blur,
perspective and heavily slowed or cropped footage can still defeat a cue.
