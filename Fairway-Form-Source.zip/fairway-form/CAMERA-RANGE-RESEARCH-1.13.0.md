# Camera measurement research and limits

Reviewed October 26, 2026. The user reports a Pixel 10 Pro-family phone and wants both basket ranging and completed-throw measurement. Google's support list includes Pixel 10 Pro and Pro XL with Depth API support. Runtime checks remain necessary; hardware names are not used as a substitute for device/service checks.

## What Android can do

ARCore combines camera observations and inertial sensors to estimate metric depth and movement. It is not a laser rangefinder. Google's Depth overview says depth is most accurate at about 0.5–5 meters (1.6–16.4 feet). Its Geospatial Depth guide describes ordinary depth observations typically reaching 20–30 meters with reduced accuracy/density at range. An available depth value is not a guarantee of measurement accuracy. Pixel laser autofocus and telephoto magnification do not expose a calibrated fairway laser-ranging instrument through these APIs.

The larger 65-meter Geospatial Depth range includes mapped buildings/terrain in supported VPS areas. It does not establish the location of a basket or disc, and is not a solution to accurate forest/fairway ranging. Cloud/Geospatial services are not enabled in this release. Apple also describes its Measure readings as approximate; a phone's camera-measuring interface does not imply laser accuracy.

Sources:
- https://developers.google.com/ar/devices
- https://developers.google.com/ar/develop/depth
- https://developers.google.com/ar/develop/java/depth/raw-depth
- https://developers.google.com/ar/develop/java/depth/geospatial-depth
- https://store.google.com/product/pixel_10_pro_specs
- https://support.apple.com/guide/iphone/measure-dimensions-iphd8ac2cfea/ios

## Implemented modes

Nearby basket: stand at the lie, aim the center crosshair at ground immediately beside the basket pole, gently scan and then hold steady. The app reads actual raw depth and matching confidence, transforms the image ray through camera intrinsics and pose into metric space, and displays horizontal distance. It does not recognize baskets automatically or infer their distance from apparent size. It rejects targets beyond 10 meters (about 33 feet); even within that cap, depth beyond 5 meters is outside Google's best-accuracy range. Missing depth causes no measurement, never a fabricated fallback.

Completed throw: after throwing, return to the release spot and scan/mark a ground point. Keep the camera session running and uncovered while walking to the first landing spot. Scan that ground position and Stop. Distance is horizontal displacement between the anchored start and the observed endpoint, rather than accumulated walked path. Local endpoint depth stays within 10 meters; total walking displacement is capped at 150 meters (about 492 feet). This cap is a guardrail, not a claim of accuracy at that distance. Walks can drift considerably, especially on long, featureless, wooded or poorly lit routes. This is an optional estimate to compare with GPS and known distances, not an advertised GPS-accuracy upgrade.

Both modes require six confident pixels in a 3×3 depth patch, reject mixed-depth patches, and require at least six distinct raw-depth observations spanning 0.5 seconds with a stable world point. These checks reduce some failure modes; they do not provide a calibrated error bound. Walk measurement becomes invalid after tracking loss, anchor loss, a frame gap over 1.5 seconds, a camera-position jump beyond plausible walking movement, application interruption, or more than five minutes. No long-range plane extension, instant-placement assumed distance, made-up confidence-to-feet conversion or GPS fallback is used.

The result freezes for review. The player must acknowledge that it is an estimate before Use estimate. Reset/Cancel remain available. Camera estimates are labeled in Caddy and disc histories, saved to the current physical bag copy and current throw, and retained through backup/restore. They do not establish measured carry averages or personal power references. Nearby basket distance updates the current lie, not carry or a completed throw. Changing lie/disc while a result is pending prevents misattachment. Existing confirmation of putting intent remains in place.

## GPS changes

The previous endpoint deadline could accept reported accuracy up to 25 meters per endpoint. The new limit is 8 meters even at the deadline. New saves are blocked if the sum of endpoint-reported uncertainties exceeds 20% of the measured distance. GPS values already stored remain compatible and labeled GPS; range learning keeps its existing stricter limits (at most 10 meters combined and 10% of distance). Reported GPS uncertainty is not a guaranteed error bound and does not detect all multipath errors. Neither averaging nor WGS84 calculations can turn poor fixes into one-foot accuracy. Short putts generally need another measurement method.

## Runtime and privacy

ARCore SDK com.google.ar:core:1.57.0 is pinned to the official current release reviewed here. AR remains optional in the manifest, and its Activity is not exported. Runtime support/depth checks and the standard Google Play Services for AR install/update flow run only when camera measurement is requested. Camera permission uses the normal Android prompt. Unsupported phones and the browser edition retain GPS/manual entry. The camera activity closes and releases its session on exit. Images, depth maps and camera/anchor poses are not saved in this app or uploaded by this feature. Saved throw metadata contains provider, mode and capture time only. The UI discloses Google's AR service and links its privacy policy; Google service data practices are separate from our local measurement logic. No API key, Cloud Anchors, VPS, Geospatial mode or recording is enabled.

- https://developers.google.com/ar/develop/java/enable-arcore
- https://developers.google.com/ar/develop/privacy-requirements
- https://github.com/google-ar/arcore-android-sdk/releases/tag/1.57.0
- https://developers.google.com/ar/develop/terms
- https://policies.google.com/privacy

## Validation before relying on distances

Java unit checks compile and run the actual native depth filtering, stability, horizontal-distance, continuity and position-jump rules. JavaScript tests exercise native-result correlation, cancellation, invalid ranges, timeouts, units, per-disc/current-throw persistence, backup, failures, and separation from measured averages. Native Java syntax is parsed separately. These checks do not validate sensor accuracy or resolve Android/ARCore APIs; full native compilation must run in the existing GitHub Actions build. No Android SDK, physical Pixel or functional bulk-download network connection is available in this workspace.

On the Pixel, compare repeated camera readings to a tape/laser baseline at 5, 10, 20 and 30 feet, then compare walked endpoints over known 50, 100, 200 and 300-foot baselines. Repeat in sunlight/shade and on grass/wooded ground, and check a dogleg walking route against straight endpoint distance. Test covered camera, phone locking, cancellation, unsupported/denied permission, Start over, feet/meters, later throws, bag-copy selection and backup restoration. Record signed errors, spread, failure rate and conditions. Do not advertise a numeric accuracy tolerance until supported by those device/field results. For dependable long-range stand-and-aim measurements within a foot or two, a dedicated laser rangefinder is the appropriate instrument; manual entry already accepts its reading. Bluetooth integration would require a specific device and documented protocol.
