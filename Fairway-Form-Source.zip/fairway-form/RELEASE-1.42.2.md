# Final Form - Disc Golf 1.42.2

The camera tilt slider ignored the requested angle because pausing the viewer refreshed the control before its input value was read. After the browser test tilted overhead, its attempt to restore 14 degrees stayed at 90 degrees. That changed the marker's screen projection and triggered the subsequent misleading “Pinch failed or moved the landing marker” error.

The slider now captures the requested value before pausing. Two regression tests reproduce the old failures and pass with the fix: pinch, overhead tilt and slider reset preserve the landing and zoom; slider input also pauses automatic rotation while applying the requested angle. The browser gate now checks pinch before tilt and explicitly verifies both the slider reset and retained zoom. Its original marker and ground-picking assertions remain enabled.

No hole geometry, saved data, disc selection, signing identity, package or storage key changes. All runtime differences from 1.42.1 are the one-line slider fix and release metadata. Version 1.42.2; fallback versionCode 74, with CI's increasing version code retained.

Validation totals and archive integrity are recorded in verification.json. Local browser execution is blocked by workspace socket permissions before tests run. No local real-browser or signed APK pass is claimed. The complete GitHub browser/model/native/APK gates remain required.

Replace repository-root Fairway-Form-Source.zip with this archive, keeping the exact filename, and run the existing workflow. Install its signed APK over the current app after all checks pass; do not uninstall.
