# Fairway Form 1.1.2 — simpler coaching, voice choice and normal dark mode

## Appearance

App & settings now separates Color palette from Appearance. Pick Forest, Coastal or Sunset, then Light, Dark or Follow phone setting. Dark mode uses dark-gray backgrounds while retaining your palette’s green/blue/clay accents. Existing Dark Forest or automatic-mode preferences carry forward. Your choice is saved locally.

## Coaching you can use

The practice plan comes first. It picks one supported thing to work on, explains it in everyday language and gives a short drill. For example, a front-side review prompt becomes “Slow the approach and give your front side time to support the turn. Keep the knee comfortable and let yourself finish.” This wording is shown only when that report has the corresponding finding.

The head-to-foot cards explain what the clip suggests and what to try. Measurements and source links are still available under Video details. Missing evidence stays a request for a clearer view. The app does not invent praise, diagnose a fault from missing information or apply backhand timing drills to other shot types. Plans still come from your actual report and the local coaching library.

## Voice

Open App & settings → Coach voice. Refresh the list, choose a voice and tap Preview voice. Pick Relaxed, Natural or Brisk pace. Automatic favors higher-quality installed English voices. The phone voice settings shortcut lets you install or change speech voices; return to the app and refresh afterward.

Offline voices are the default. Optional internet voices may sound different or offer higher quality, depending on the engine. If enabled, the phone’s speech provider may receive the spoken coaching text. The app does not send your video to that provider. Voice naturalness depends on what your device offers; this update does not bundle a new neural speech model or require a speech-service account.

Narration now uses plain coaching paragraphs with short pauses rather than reading the measurement dump. Stop works for the plan and preview. Changing settings or leaving the app also stops narration.

## Update from your phone

1. Download Fairway-Form-Source.zip. If the phone appends (1), rename it back to that exact filename.
2. Replace the existing root ZIP in the same private GitHub repository and commit to main. Keep it zipped.
3. Keep the existing working workflow, signing secret and encrypted key.
4. After the latest Actions run succeeds, download Fairway-Form-APK and extract it in Files.
5. Install Fairway-Form.apk over the existing app. Keep your current install so its local sessions and bag remain available.

This download contains editable source. GitHub still needs to run the browser checks, compile and sign the APK.

## Checks and phone verification

67 local tests pass, including the previous video/analysis tests, coaching selection, missing-evidence handling, shot-specific wording, voice ranking, offline policy and paragraph chunking. Static checks cover scripts, Android XML, controls, module imports, linked assets and offline shell entries. A rendering check verifies that evidence is retained in closed details panels and the narrated plan omits measurement jargon. Appearance migration and text contrast were checked, including unchanged palette accents in dark mode.

The local browser cannot start in this sandbox (socket operation not permitted). The GitHub real-browser check has been updated for independent dark mode, voice controls/preview and the new review layout. Native compilation and actual audio still need GitHub/phone verification.

After installing, open an old saved throw and review the new coaching. Expand Video details to confirm that measurements are still there. Switch every palette between Light and Dark, restart the app and try Follow phone setting. Preview a few voices, change pace, then listen to a real plan and test Stop. If you enable an internet voice, test its availability online and confirm that switching back to offline-only removes internet voices from the list. Confirm that saved sessions, bag and the frame-seek recovery still work.
