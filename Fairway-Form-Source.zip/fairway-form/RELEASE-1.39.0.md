# Final Form - Disc Golf 1.39.0

Confirmed hole-sign information now supplies more of Caddy's editable hole setup. The 3D hole also lets you mark an approximate landing or current lie, so subsequent recommendations can use the remaining route and surrounding layout.

## Hole-sign inputs and wording

- Printed hole distance remains separate from distances to bends, distances beyond bends, hazard offsets and elevation heights. Available sign text supplies direction, slope and hazard fields, and its detailed layout sentences are retained in the notes. Several tee/basket lengths still require the active choice.
- A confirmed drawn route can supply Caddy's direction and approximate distance to a bend, with the same route and trees retained in the artwork. Explicit route notes take priority. Endpoint irregularities in a straight trace do not become extra doglegs.
- Shared positional interpretation distinguishes “water right behind the basket” from “water to the right behind the basket.” The former means directly behind. Literal left/right obstacle positions and “turns right after 350 feet” retain their directional meaning.
- “There is 150 feet left to the basket” supplies the current remaining distance, rather than moving the basket left. Conflicting remaining distances do not choose one automatically, and stale tee notes do not replace a later lie's distance.

These are bounded on-device language and diagram rules. Numerical heights and OB classifications are taken from supplied information, not invented from the page angle or green shading. No new research sources were introduced; the existing sign-reading lesson now explains using the marked lie.

## Marking a landing or lie

1. In Result, tap Mark where it landed. Tap the ground or drag to place the disc on the 3D hole. The placement surface captures vertical gestures. Rotate view allows looking around before returning to Place disc.
2. Review the approximate distance and line, then tap Use this position. The remaining distance remains editable. Confirmation saves before the screen accepts the point; a failed write leaves it unaccepted.
3. Save the throw result. The marked landing becomes the next lie. The remaining route, bend location, elevation and hazard context feed the next setup and recommendation. A lie beyond the bend can therefore have a straight remaining line.

The whole-hole render remains visible with Your lie and the selected next landing. Mark / Move your lie on the hole also adjusts an existing lie. When the next distance is unknown, saving an unmarked result offers the position picker; manual distance entry remains available.

Positions and their drawing identity are stored with the round, not the reusable course. Editing the layout invalidates a point tied to the old geometry. A later throw without a new landing clears the old lie; a new hole starts without that position. Known entered remaining distance overrides the diagram estimate. Neither a sketch position nor its remaining-distance estimate creates measured throw carry, GPS evidence or a disc range measurement. Notes for the previous lie do not remain marked current after advancing.

## Verification

- Full automated suite: 1,045 passed, zero failures, cancellations or skips. Includes 24 new navigation/language/sign tests, four new Caddy UI tests and two new orbit/picking tests.
- Coverage includes ground picking on flat terrain and hills at six viewpoints; positions before/after bends and off the fairway; direction/height/hazard context; sign length classification; saved-round reopen; stale markers; editable distance overrides; measured-carry separation; pointer capture; and failed or delayed position saves.
- Syntax: 120 application/build JavaScript modules checked. All 409 previous static controls retained; 411 current IDs are unique. All 114 offline shell paths resolve.
- Fresh browser run 295687a9-127f-49f4-9fa6-82932bbc7803 started 2026-11-17T04:41:58.376Z and was BLOCKED by workspace socket permissions (EPERM) before browser tests ran. No browser checks passed locally. The mandatory GitHub browser/model gate remains enabled, including a real vertical touch placement, page/ancestor scroll checks, confirmation, persistence, next-lie setup and the retained whole-hole landing view.
- The preview uses the production renderer and sample data, showing a lie before and beyond a bend. It is an illustration, not a browser or Android screenshot. APK compilation/signing and Android touch verification remain pending.

Signing identity, package, WebView origin, saved course/bag data, measurement history, intro, video analysis, 3D-first view and smooth orbit behavior are preserved.

## Updating

Replace repository-root Fairway-Form-Source.zip, commit, and run the existing GitHub workflow. After every required check passes, install the signed APK over the current app without uninstalling. Version name is 1.39.0; fallback versionCode is 66 and CI retains its increasing code. Reapply a sign's confirmed details to use its expanded text inputs. Existing confirmed diagrams remain available. Use Mark where it landed during Result, or Mark your lie on the hole for an existing next throw.
