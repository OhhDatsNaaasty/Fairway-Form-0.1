# Final Form - Disc Golf 1.40.3

## Practice saved-round menu

The GitHub browser gate stopped with “Practice round did not provide its saved ID.” Starting Practice stored a new round and opened it without refreshing the cached saved-round list. The menu was rebuilt from the old cache, so it did not contain the new round's option. A real HTML select clears its value when assigned an ID absent from its options. The earlier unit-test double accepted arbitrary values and concealed this app defect.

The Practice handler now awaits a saved-round list refresh after storing the new round and before opening it. This matches the existing new-hole, course-play and next-hole paths. The menu immediately includes/selects the persisted practice ID, while previous rounds remain available.

The saved-round select double now enforces option matching and selection reset on option replacement. With that stricter model, both the earlier landing fixture test and a new repeated-practice test fail against 1.40.2 with an empty ID. They pass after the handler fix. Added checks cover missing options, three consecutive practice creations without lost or duplicate options, and retention of the current menu/selection if saving fails.

## Scope and validation

The ID-based landing fixture, three phone viewports, actual touch gestures, no-scroll and stable-ground checks, next-lie context and weighted-profile assertions remain required. The browser gate has not been weakened. No renderer fallback or invented route was added. Existing measurement, video, course and saved-data behavior is preserved; this change corrects the Practice menu refresh.

All 1,084 automated tests and 58 native host-rule checks passed. Source comparisons and archive checks are recorded in verification.json. Local browser execution is blocked by workspace socket permissions before any browser tests run. GitHub's browser/model/native/APK checks must still pass; no local signed APK or physical-phone accuracy pass is claimed.

## Install

Replace repository-root Fairway-Form-Source.zip, keeping the exact filename, and run the existing workflow. Once all required checks pass, install its signed APK over the current app. Package, signing identity, origin and storage keys are unchanged. Version name: 1.40.3. Fallback versionCode: 70; CI retains its increasing code.
