# Working on Final Form - Disc Golf

The user works from an Android phone and updates by replacing the private
repository-root Fairway-Form-Source.zip. Preserve the signing identity, package,
WebView origin, storage identifiers and existing saved data.

## Browser checks and communication

- Use `npm run test:browser` as the local browser-check entry point. It writes
  fresh artifacts/browser-check.log and browser-check-status.json, prints stage
  and heartbeat messages, and supervises the worker from a separate process.
- Run local checks under the default sandbox first. If the result is BLOCKED
  with EPERM/EACCES, explain that immediately and continue independent work.
  Do not automatically open an additional-permission/approval request just to
  rerun this optional local check. The required GitHub browser/model gate stays
  enabled and must pass before an APK is accepted.
- A BLOCKED, interrupted, failed or timed-out run is never a browser pass. Check
  the run ID and timestamps; never present an earlier log as a new result.
- Announce long checks before starting them. Use short yielding tool calls and
  give meaningful progress updates within 60 seconds while tools are responsive.
  Project timers cannot control a platform wait before a tool command starts.
- Keep one browser launch attempt in progress at a time. A local permission
  block is a reason to use CI, not to repeatedly queue permission-enabled launches.
- Retain the browser gate in scripts/build-android.sh and the protocol/model
  assertions. Fix failures rather than disabling checks to produce an APK.

## Releases

Run relevant automated checks. Package only reviewed source/runtime files and
test fixtures; exclude vendor downloads, build artifacts, signing material and
private IP-review documents. Record local browser/APK limitations honestly.

## Disc-golf research and coaching

Register every disc-golf instructional/research source used by the app in the
knowledge source registry, with a subject-specific title, an original accurate
overview, access/review provenance and a working source reference. Keep sources
searchable in the library even if no lesson currently links them. Catalog and
flight-chart references belong in its Disc flight references view. Never claim
a video was watched or a full paper read when only an outline/abstract was
available. New advice needs a relevant lesson/source link and a practical task
with a setup, outcome check and progression; repetition counts alone are not a
practice plan. Keep observations, uncertain suggestions and confirmed evidence
distinct. Preserve alignment between default, detailed and spoken coaching.
