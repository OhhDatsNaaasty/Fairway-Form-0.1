# Final Form - Disc Golf 1.36.0

Generated terrain views now start behind the tee and can orbit a full 360 degrees around the hole. Open the hole sketch or the selected landing picture, then drag horizontally, use the angle slider or arrow buttons, or tap Full circle. The automatic turn runs once, taking about 30 seconds on a responsive device, and returns to its starting angle. Behind tee resets the view; next-lie scenes use Behind lie. The compact Caddy summaries stay still until opened.

The camera follows a fixed circle with constant radius, altitude and a level horizon. The halfway view is behind the basket. It uses perspective, so distant trees and ground appear smaller instead of treating distance into the picture as a height increase. Actual terrain heights still deform the surface. Tee, basket, hazards, tree groups and the exact selected landing target share that projection. Ground footprints and the target ring are projected onto the surface, upright objects scale with depth, and object ordering uses camera depth. Labels avoid nearby label collisions while the view turns. This is a schematic renderer, not a measured terrain reconstruction or flight simulator.

Manual interaction pauses the automatic turn. Closing the sheet, changing page or hole, editing the scene, hiding the document or disconnecting the view disposes/pauses animation and pending drag renders. Horizontal dragging is separated from vertical sheet scrolling. Keyboard arrows/Home and a labeled slider provide alternatives. Rotation changes viewer state only; it does not change notes, recommended distances or measured results. Sign photographs keep their original display/marker behavior. View notes sketch opens the generated model.

## Verification

All 980 automated tests passed, including 15 new orbit/camera/controller regressions. Coverage includes starting behind the tee, the behind-basket reverse view, constant circle radius/altitude/horizon, angle wrapping, perspective with zero terrain height on a flat hole, physical side labels, selected-target preservation, arrow/slider/keyboard/reset controls, pointer dragging, vertical-scroll intent, one complete automatic orbit, manual pause, visibility/disconnection and disposal cleanup. Previous terrain, Caddy, notes, history, photo, analysis, native and workflow checks remain enabled.

Syntax checks cover 117 runtime/script files. All 111 offline paths exist, including the new camera and controller modules, and all 409 static controls remain unique and retained. Archive CRC, exact workspace equality and unchanged files against version 1.35.1 are checked.

The animated GIF/MP4 beside the ZIP are assembled from 36 production-renderer viewpoints of the same flat sample hole and selected landing. The preview is sped up to a 12-second circle; the app uses a slower turn. The GIF was decoded as 36 distinct frames and cardinal viewpoints were inspected. These are renderer previews, not a browser recording or a phone performance test. Sample disc range is hypothetical. A separate comparison shows flat/uphill/downhill terrain under the same starting camera.

Fresh local browser run 6d0924ee-edfd-4ec6-984d-3a6841cb0e32 stopped immediately with socket EPERM before Chrome started. No browser or physical-phone pass is claimed. The mandatory GitHub browser/model gate stays enabled and adds reverse-view, selected-target, real pointer-drag, full-circle start and close-cleanup checks. No APK was compiled or signed locally.

## Update

Replace repository-root Fairway-Form-Source.zip and run the existing GitHub workflow. After every required gate passes, install its signed APK over the current app without uninstalling. Version name is 1.36.0; fallback versionCode is 63 and CI retains its increasing code. Signing identity, package/origin, storage schema, approved intro, Caddy ranking/terrain interpretation and video-analysis engine are preserved.
