# Fairway Form 1.15.0 — Build your course as you play

Course entry now uses the same setup as Caddy. Web course search/import has been removed; course data is no longer downloaded or required during the APK build. No new external course-data source or commercial database is claimed.

## On your phone

1. Open Caddy → Set up. Course name, hole number and par are visible above distance and fairway setup.
2. Tap the course name to see your saved courses. Typing filters them, including close spelling matches. Tap a suggestion to use it, or type a new name and tap Add course. Matches are suggestions, not silent autocorrections. Leave the course blank for practice, or use Practice to start without a course.
3. Enter this hole’s distance, fairway shape, elevation, OB/trouble and notes in the usual Caddy fields. Changes save on this device automatically after a short pause; Save hole now is also available. Incomplete holes are kept as drafts and can be finished later.
4. Select another hole number to recall its saved setup, or start entering an unsaved hole. A made shot still completes the current hole and advances to the next. Later lies and throw distances stay in your round/disc history without replacing the course’s tee distance and fairway. Par corrections can still update the saved hole.
5. More → My Courses retains saved-hole management and export/restore. Old courses, previously imported facts, source notices, tee choices, bag copies and throw histories remain available. Finish a saved measured throw before changing course or starting practice.

Course name and hole number lock after a recorded throw to preserve that hole’s history. Use the next hole, Practice or saved-hole management to start another setup. Course details describe the setup you enter; review them when tees or basket placements change.

## Update from your phone

Replace and commit the repository-root **Fairway-Form-Source.zip** using the same filename. No workflow replacement is needed. Download the successful **Fairway-Form-APK** artifact, extract it, and install **Fairway-Form.apk** over your current app. Keep the existing encrypted signing key and password. Do not uninstall the app first.

The source ZIP root remains `fairway-form/`. Android package `com.fairwayform.app`, WebView origin and IndexedDB schema 5 are unchanged. Version name is 1.15.0; local fallback versionCode is 32 and GitHub supplies its run number as before.

## Verification

**506 JavaScript tests pass**, along with **19 native camera-rule checks**. Static checks also pass for modules, controls, offline assets, Android XML and shell scripts; 134 browser-check expressions compile. Automated checks cover saved-course matching and keyboard selection; shared-form autosave without recommending; partial-hole restore and backup validation; completing drafts; inline saved/new hole selection; same-name duplicate prevention; serialized saves; visible storage failures and retry; protection of measurements; and preservation of tee layouts, round logs, putting and disc profiles. The native camera-rule checks remain required. Real Chrome/model checks and Android compilation still run in GitHub Actions and have not been executed successfully in this restricted local environment. Phone usability and sensor behavior still need device testing.

The former course downloader/search/cache modules remain in the editable source for reference and legacy compatibility tests. They are not connected to Caddy, the assets command or the APK build gate. The offline shell no longer caches the course directory or its search interface. Existing imported course source/license metadata is retained in My Courses backups.
