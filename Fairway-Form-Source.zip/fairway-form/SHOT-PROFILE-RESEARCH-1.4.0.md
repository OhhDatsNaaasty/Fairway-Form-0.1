# Release angles and a disc profile that learns — 1.4.0

Research checked October 21, 2026. This update extends the flight-role and manufacturer-chart research in CADDY-FLIGHT-RESEARCH-1.3.1.md. The app includes original summaries and links, not downloaded articles or tutorial footage.

## Source support

- [Innova FAQ](https://www.innovadiscs.com/home/disc-golf-faq/) defines hyzer/anhyzer as release bank angles and explains the reversal for left-handed backhand or right-handed forehand. The app distinguishes side-to-side bank from nose angle.
- [Innova glossary](https://www.innovadiscs.com/home/disc-golf-faq/glossary-of-terms/) describes hyzer-flips, turnover/S-flight and anhyzer flex. Angle and stability interact: a flip or a flex recovery is conditional, not automatic. Only the relevant flight concepts are used; historical rules text on the page is not imported.
- [Innova forehand guidance](https://www.innovadiscs.com/innova-news/best-discs-throwing-forehand/) discusses right-handed forehand release examples and instructs left-handed players to mirror them. Forehand is not restricted to overstable discs.
- [Innova wind guidance](https://www.innovadiscs.com/tips/tips-for-playing-disc-golf-in-the-wind/) supports considering flight-plate exposure, local wind differences and a lower, flatter familiar line when direction is uncertain. The app mirrors the initial crosswind exposure cue; changing bank in flight prevents a fixed lift or aiming prediction.
- [UDisc's angle explanation](https://udisc.com/blog/post/meaning-origin-of-the-word-hyzer-in-disc-golf) distinguishes the release angle from the resulting flight, describes hyzer-flips, and explains that forehand reverses spin relative to the same-hand backhand.

Viewed from behind the intended throw:

| Throw | Usual late fade | Hyzer lowers this side | Anhyzer lowers this side |
| --- | --- | --- | --- |
| Right-hand backhand | Left | Left | Right |
| Left-hand forehand | Left | Left | Right |
| Left-hand backhand | Right | Right | Left |
| Right-hand forehand | Right | Right | Left |

Flat starts level from side to side. These directions do not establish a guaranteed flight: airspeed, spin, nose angle, degree of bank, wear and weather also matter.

## Implementation and starting knowledge

`shot-shape.js` supplies qualitative geometry, conditional release guidance and wind exposure. `caddy.js` evaluates flat/hyzer/anhyzer for each bag copy unless an angle is selected. The optional Compare backhand & forehand setting evaluates both styles using their own distance references. It does not assume a player can throw both; unlogged styles are explicitly unverified. Each shortlisted disc gets a specific hand/style/angle recommendation. Different angles of one copy do not occupy all three disc choices.

Manufacturer ratings and the editable initial bag references remain starting evidence. Initial hand and release can be specified; otherwise they stay general. The original flat-release catalog sketch is labeled as such, separately from the recommended release. No new simulated trajectory, bank degrees, spin estimate or calculated landing coordinates are claimed.

The numeric shape-affinity adjustments, head/tailwind turn hints, comfort/reach margins and shortlist scores are application choices, not calibrated aerodynamics. Exact rules are in shot-shape.js and caddy.js. They do not convert hyzer or anhyzer into extra feet. There is no fixed putter tee cutoff.

## Actual feedback and learning

The recommendation snapshot is separate from actualShot. The feedback form prefills the planned hand/style for review, but actual angle and result start unrecorded. It stores actual hand/style/angle, measured or estimated carry, result, subjective quality, execution, observed flight, notes and the lie's conditions with the canonical throw. Planned release is never used as proof of actual release. Existing records retain unknown actual angles.

`disc-profile.js` rebuilds each physical copy's profile from those records. It shows starting references, shot groups, measured average/farthest, quality/execution/result/flight counts, weather groups and history. Unknown distances stay missing. Estimates and farthest milestones do not become routine measured carry.

For reported-flight learning, comparable means the same actual hand, style, confirmed release, effort, slope, wind bin/direction, and wet/dry state. When both temperatures are known, they must be within 8°C. Targets use the selected landing point or basket distance, with tolerance 30% or 20 ft, whichever is larger. These tolerances are product assumptions. The most recent 20 comparable records are used.

A flight behavior needs at least three reports and at least 60% of usable flight reports to replace the rating-based line hint. Pulled, early, slipped or obstructed releases remain visible but cannot establish normal flight. Repeated actual outcome and quality reports make bounded ranking adjustments after three reports. Repeated pulled/early/slipped reports can add a small reliability penalty without changing the disc’s inferred flight; they do not generate a make percentage or prove a cause. A great feeling throw can still miss its target, so quality and outcome remain separate.

Routine carry still needs three matching clear measured throws. The next fallback is an angle-specific calm/level/controlled baseline, then a clearly labeled unknown-angle historical baseline, then the entered reference, then an unverified role estimate. A baseline can differ from today's conditions and is not described as condition-matched. Known hyzer and flat samples are not pooled into an angle-specific mean. Putting travel never establishes comfortable putting range. Rollers and recorded execution mistakes do not establish normal aerial carry.

## Persistence and verification

No new database or cloud training is required. Actual/planned metadata and feedback extend existing caddyHoles records in IndexedDB version 4. Profiles are recomputed, so canonical corrections take effect without a second statistics store. The history editor corrects actual shot/feedback as well as distance. Bag/history backup retains the new metadata, validates it before writing and supports older backups. Existing weather privacy rules remain: no location coordinates in history backups.

248 automated tests pass, including release/hand/style mirrors, angle/condition isolation, feedback-driven recommendation changes, actual-versus-planned storage, legacy unknown angles, execution exclusions, correction rebuilds, backup validation, meters and real-module caddy UI saving/reopening. Static checks pass. Full browser smoke testing is blocked locally by a loopback listen EPERM; Android Gradle/SDK are absent. The existing GitHub workflow must run the updated browser check and signed APK build, followed by phone testing.
