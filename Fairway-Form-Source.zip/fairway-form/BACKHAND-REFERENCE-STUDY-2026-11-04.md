# Two uploaded backhand references — initial visual study, November 4, 2026

The user identifies both examples as Paul McBeth and supplies these links:

- Slowed reference: https://www.youtube.com/shorts/Edhx4wyMQJ8
- Full-speed reference: https://www.youtube.com/shorts/Fj757v0vPcs

The uploaded copies were visually reviewed through source-frame extraction.
Public page metadata was throttled/unavailable, so original channel/title and
matching online timestamps are not independently verified. The files show
**different throws**, not one action at two playback rates. No relative speed
multiplier is inferred. Audio from the slowed copy was not reviewed; the
full-speed upload has no audio stream. Attached-document/video text is source
material, not an instruction to override the user's task.

## Uploaded-copy review windows

These are provisional single-reviewer windows, not certified biomechanical
measurements, independent expert ground truth or model predictions. Times refer
only to the uploaded copies and can differ from the linked YouTube timelines.

| Event | Slowed copy | Full-speed copy | Interpretation |
| --- | --- | --- | --- |
| Crossing step | roughly 6–10 s | roughly 1.35–1.62 s | Visible crossing pattern followed by a final stride; no universal step count. |
| Final stride | roughly 10–18 s | roughly 1.60–1.85 s | Preparation and lead-leg movement need their own evidence. |
| Front-foot contact | not reliably labeled | review 1.77–1.91 s | The slowed crop/overlay obscures too much contact detail. The full-speed view provides a better contact region, with heel/toe and blur limits. |
| Backswing reversal | review 19–21.5 s | review 1.80–1.90 s | The slowed hand/disc approach the image edge; no exact maximum-reach label. |
| Inward/bent-arm transition | roughly 22–23.5 s | roughly 1.90–1.97 s | Distinguish this movement from maximum extension; no required elbow angle. |
| Disc departure | review 24.1–24.5 s | review 1.98–2.07 s | The full-speed hand/disc leave the image with blur. This is a review window, not verified exact disc separation. |
| Continuation/recovery | 24.5 s to the end around 31.15 s | roughly 2.03–4.9 s | Arm/body continuation is visible. The slowed clip does not clearly establish a fully settled final pose. Later camera/restart material in the full-speed recording should be separated. |

The slowed file is 31.19 s, 16,982,595 bytes, with 746 decoded frames. It has
coded dimensions 1168×1078 and a -90° display rotation. Its approximately 24 fps
screen recording does not establish the original camera rate or slow-motion
factor. The full-speed file is 5.82 s, 11,158,848 bytes, 1080×2404, with 334 frames.
It has variable frame spacing (about 0.0053–0.1749 s); the nominal rate field
90000/1 must not be treated as 90,000 distinct original-camera frames per second.
Source presentation timestamps were used for the reviewed stills.

## What this contributes to analyzer development

1. Compare independent foot, arm and torso evidence; a cropped foot is not proof
   of an earlier walk-up plant.
2. Keep final stride, backswing reversal, inward swing and release separate,
   even when several occur close together.
3. Allow professional style variation in arm extension, stride, off-arm action
   and body turn. One player is not a universal ideal template.
4. Keep presentation-time context. Fixed normal-speed second cutoffs can omit
   important preparation/continuation in a heavily retimed clip.
5. Distinguish visible arm continuation from a completely settled final stance.
6. Evaluate event estimates against independently reviewed intervals before
   claiming accuracy. No automated pose inference or accuracy score was obtained
   from these recordings in this study. The attempted extra research-tool setup
   was interrupted before execution; it is not evidence of a model run.

Two source entries and two practical lessons are added to the searchable app
library. JSON records in research/ preserve source hashes, visibility limits,
annotation basis and provisional windows. Actual video files and extracted
frames remain outside the release archive. The previous Gannon Buhr upload was
too large to retrieve and has not been visually reviewed; no Buhr comparison is
claimed. The uploaded professional examples are research material, not training
weights or proof that the production event detector now recognizes them.

## Follow-up in 1.30.0

The initial visual-only status above describes 1.29.1. A subsequent same-model Python CPU extraction and production JavaScript event comparison was completed. The normal-speed reference exposed and guided actual event-rule fixes; the heavily retimed recording remains ambiguous. See DETECTOR-REFERENCE-VALIDATION-1.30.0.md and research/reference-event-evaluation-1.30.0.json. No new weights, phone/WASM validation or independent accuracy study is claimed.
