# Final Form - Disc Golf 1.16.1

**Current version 1.16.1** fixes the post-build opening-movie check: it follows Android’s compiled raw-resource mapping, including shortened paths and collapsed names, and verifies the exact approved bytes. Compilation and the previous browser/model checks passed in the reported 1.16.0 run; this patch corrects the verifier that ran afterward. See RELEASE-1.16.1.md.

Version 1.16.0 adds the approved five-second opening animation to the Android APK and renames the visible app to **Final Form - Disc Golf**. The app initializes behind the local, silent intro. It plays on a cold launch and each return from the background, with Skip intro and Android Remove animations support. Returning from the app’s gallery, camera, range measurement, permission or external-reference workflows does not replay it. The Android package, signing identity, storage schema and build filenames stay the same. See RELEASE-1.16.0.md.

An editable Android and browser app for disc-golf practice. Version 1.15.0 combines course entry with Caddy setup: local saved-course suggestions, inline hole/par fields, autosaved complete and unfinished holes, and tee-layout protection on later throws. Web course import and its build-time downloads/gates are removed. This supersedes the course-directory setup described in older release notes below. See RELEASE-1.15.0.md. Version 1.14.2 replaces the browser test’s stderr/debugging-port discovery with Chrome’s debugging pipe, a verified page attachment, one bounded fresh-profile retry and captured startup diagnostics. All real app/model checks remain required. See RELEASE-1.14.2.md. Version 1.14.1 fixes the APK failure when optional OSM providers time out or return HTTP 504. A deliberate outage notice now permits the build to continue; invalid/unexplained data remains rejected. A valid open-map directory can be cached on the phone for later updates. This supersedes the mandatory populated-directory policy in 1.12.2–1.14.0. See RELEASE-1.14.1.md. Version 1.14.0 adds ordered video-mode pose tracking, optional throw-only review windows, conservative limb-spike exclusion, tighter event-marker matching, corrected phase-chip selection and coaching tied to actual event order and movements. See RELEASE-1.14.0.md and THROW-ANALYSIS-RESEARCH-1.14.0.md. Actual coaching accuracy still needs expert-labeled real-video validation. Version 1.13.0 adds optional ARCore camera estimates for nearby basket distance and walked throw displacement, per-disc estimate provenance, and stricter GPS endpoint/save gates. Camera measurement is not laser ranging and needs physical-device accuracy testing; it supplements GPS. See RELEASE-1.13.0.md and CAMERA-RANGE-RESEARCH-1.13.0.md. Version 1.12.2 repairs silent empty course-directory builds, separates course-name and optional hole-map downloads, improves offline name search, shows dataset count/date and links to PlanetDG. See RELEASE-1.12.2.md and COURSE-SEARCH-RESEARCH-1.12.2.md. The assets/packaging steps now require a usable dated directory; this supersedes the optional-download behavior in 1.12.0/1.12.1. Version 1.12.1 fixes a false browser build failure caused by testing “Teebird” against the catalog’s “TeeBird”. The shared browser/handler guard now checks the canonical catalog label and the physical bag copy in measurement and feedback. See RELEASE-1.12.1.md. Version 1.12.0 adds offline search/import of a build-time OpenStreetMap course snapshot, reviewable mapped holes with source/license notices, external UDisc reference links, and a commercial licensing inquiry draft. The directory requires a successful assets-step extract; unavailable data is disclosed rather than replaced with sample courses. See RELEASE-1.12.0.md and COURSE-DATA-RESEARCH-1.12.0.md. Version 1.11.0 adds live physical-copy ownership counts in catalog searches, searchable BuzzzSaw/Fuzed Z versions of the existing Buzzz mold, explicit flight-data coverage, and a cleaner Plan → Throw → Result workflow with quick measuring, selected-disc context and saved-measurement resume. See RELEASE-1.11.0.md and CATALOG-FLIGHT-AUDIT-1.11.0.md. Version 1.10.0 focuses Caddy on Set up → Throw → Result, speeds fresh GPS endpoint capture, saves measurements immediately to physical-disc profiles with same-ID final feedback, supports combined miss results and made-putt next-hole progression, merges course entry with shot setup (including par), and adds local text-position/diagram sign suggestions with per-hole keep/change tee confirmation. See RELEASE-1.10.0.md and FIELDWORK-RESEARCH-1.10.0.md. Version 1.9.1 fixes the course browser build test by giving it a dedicated test bag copy after earlier bag-removal checks, with a regression covering empty-bag handling and subsequent course recommendations. See RELEASE-1.9.1.md. Version 1.9.0 adds 850 molds across 28 brands, a focused recommendation → feedback → next throw flow, and My Courses with reusable hole layouts/par, separate round logs and course backup/restore. See RELEASE-1.9.0.md and DISC-CATALOG-EXPANSION-1.9.0.md. Version 1.8.0 adds synchronized throw measurement at the top of What happened?, a per-lie distance-to-pin prompt, explicit putting mode with bag-only putter choices, and per-copy putting accuracy in 0–10, >10–20, >20–25 and >25 foot bands. Putting start distance, actual carry and remaining distance stay separate. See RELEASE-1.8.0.md and PUTTING-RESEARCH-1.8.0.md. Version 1.7.0 added an automatic phone-compass aiming screen after local weather loads. It uses Android magnetic sensors, adjusts for screen orientation and corrects to true north with the weather location; a settled heading can apply relative wind without entering degrees. Manual entry remains available. See RELEASE-1.7.0.md and COMPASS-RESEARCH-1.7.0.md. Version 1.6.0 added Start/Stop GPS endpoint measurement at the top of Caddy, a feet/meters display, saved per-throw distance drafts, reported uncertainty and quality-gated per-disc GPS history. Android requests precise foreground location only for this measurement flow. Phone GPS cannot guarantee 1–2 foot accuracy. See RELEASE-1.6.0.md and GPS-RESEARCH-1.6.0.md. Version 1.5.0 added summary-first coaching with internal lesson links, 74 expanded lessons with resource previews, conservative side-view X-step recognition and original course graphics with a Minimal option. See RELEASE-1.5.0.md and COACHING-RESEARCH-1.5.0.md. Version 1.4.0 added flat/hyzer/anhyzer shot recommendations, optional backhand/forehand comparison, and per-copy disc profiles learned from actual throw feedback and conditions. See RELEASE-1.4.0.md and SHOT-PROFILE-RESEARCH-1.4.0.md. Version 1.3.1 removed the fixed putter tee cutoff. Reliable putter carry can support longer tee shots, with competitive midrange/driver alternatives when available. It retains the researched flight-role guidance, manufacturer chart references, staged long-hole planning and measured per-disc distance history from 1.3.0. See RELEASE-1.3.1.md and CADDY-FLIGHT-RESEARCH-1.3.1.md. Version 1.2.3 aligns the Kotlin runtime dependencies to fix the Android duplicate-class build failure; see RELEASE-1.2.3.md. Version 1.2.2 fixes the caddy loading/readiness race that stopped the 1.2.1 GitHub build; see RELEASE-1.2.2.md. Version 1.2.1 adds a local player profile, skill-aware practice structure, separate throwing-distance references, and saved-review patterns shared with the caddy. See RELEASE-1.2.1.md for installation and phone checks. Version 1.2.0 added a dedicated course caddy using the actual bag, throw-by-throw hole logs, manual and optional local model weather, a putting caddy, and assisted sign-photo review with native on-device OCR. It includes the earlier video-frame and coaching updates. The GitHub workflow builds the signed APK for phone verification. Planning is rule-based and explained; it does not simulate a guaranteed disc trajectory.

## Update from your Android phone

Replace `Fairway-Form-Source.zip` in the SAME private repository with this update, using the SAME filename. Commit it and open the newest Actions run. Keep your existing `.github/workflows/build-apk.yml`, encrypted signing key and APP_SIGNING_PASSWORD secret. Download the new APK artifact after the run succeeds, extract it and install over the old app. The workflow's run number raises versionCode and the saved signing key allows an update without uninstalling. No workflow edit is needed for an existing working Ubuntu 24.04 setup.

The updated build script adds real browser checks on the GitHub runner before compiling. It uses the runner's Chrome, tests the interface and storage upgrade, and loads the real bundled pose/hand models on an empty image to check that they initialize without inventing detections. This check has been written and syntax-checked but cannot run in this restricted workspace. A green GitHub run is still required.

## New in 1.2.0

- A Caddy navigation section after Disc room and a home-page shortcut. Feet by default, optional meters, real bag-only options, individual calibration, conditions, line, slope, obstacles, effort and putting risk.
- Saved per-hole drafts and throws, actual used-disc snapshots, outcome feedback, next-lie planning, finish/resume and JSON export. IndexedDB version 3 preserves previous stores and adds caddyHoles.
- Optional one-time coarse location for Open-Meteo current model weather, with explicit relative-wind confirmation or a user-entered compass heading. No saved coordinates or background location tracking. The public endpoint is for current non-commercial testing; commercial distribution needs licensed weather access.
- Android sign photos from camera or scoped gallery selection, bundled ML Kit Latin OCR, explicit distance selection and assisted route markers. Photos/text process on-device; SDK diagnostics disclosure is included. The browser has manual text/route review when no native OCR bridge is present.

See RELEASE-1.2.0.md for phone steps and CADDY-RESEARCH.md for sources, policy and device-validation limits.

## New in 1.1.5

- Practice plans expose the video moments used and offer relevant focus/drill choices. Eighteen original exercises are filtered by throw and stance. Unavailable checks remain ungraded and grouped below visible movement.
- Plans distinguish a flagged review prompt from an optional practice experiment and a general X-step lesson. No new biomechanics thresholds or detectors were added.
- Twelve new lessons bring the library to 62 lessons and 46 linked resources from 23 publisher/coach/research groups. YouTube tutorial links disclose that written outlines were reviewed; public Overthrow transcripts and coach/manufacturer articles support the new notes.
- The fixed-camera setting gets a specific explanation when it prevents support assessment. Text practice exports include reference links.

See RELEASE-1.1.5.md and COACHING-RESEARCH-1.1.5.md for phone steps, the coaching audit, research access and validation limits.

## New in 1.1.4

- Completed frame seeks accept bounded source-frame rounding after decoder progress; a nearby unchanged stale frame cannot satisfy a silently ignored seek. Genuine stalls still stop inference.
- Compositor callbacks are registered before seeking so the only presentation of a paused frame is not missed. Out-of-window or still-seeking metadata is rejected; missing callbacks retain an explicitly approximate timestamp.
- Optional hand detail revisits the existing sampled release frames once, in source order. No automatic extra 60 Hz pass remains. Turning hand detail off eliminates the second pass. Select 60 samples/s in Settings for high-frame-rate source recordings when needed.
- Hand matching uses a pose detected on the same currently decoded pixels. Duplicate source times are deduplicated.
- A failed or cancelled hand close-up leaves completed body coverage available and discloses the missing detail. Its seeks have a three-second limit and are not automatically retried after failure. Cancellation or failure during the body pass still preserves an explicitly partial review.

See RELEASE-1.1.4.md for the phone update steps and validation limits.

## New in 1.1.3

- 301 manufacturer-sourced entries across Axiom, Discmania, Discraft, Dynamic Discs, Innova, Latitude 64°, MVP, Prodigy, Trash Panda and Westside Discs. Every original bundled mold ID is retained for existing bags.
- Source and reference-version notes, fractional ratings, Prodigy's updated rating system and the retooled Neutron Time-Lapse rating. Roc and Roc+ remain separate through catalog export/import.
- Product-photo figures in the catalog and bag. The existing asset command now downloads matching manufacturer images and records credits/coverage. Photos bundle into the APK where available. Missing or uncertain matches display Photo unavailable with a source link. The source ZIP's photo index is initially empty; live download coverage cannot be verified in this sandbox.
- Paginated browsing exposes the full catalog, with normalized search and all 28 brand filters. No silent 120-result ceiling remains.
- 50 practical lessons and 41 linked resources, including new material from the requested manufacturers. A library Source filter and publisher-aware search make that material easy to find. Product references remain distinct from instruction and do not establish form-diagnosis thresholds.

See RELEASE-1.1.3.md for phone update steps and DISC-CATALOG-SOURCES.md for the full rating/source table.

## New in 1.1.2

- Palette and Appearance are separate controls. Forest, Coastal and Sunset keep the same five accent tokens when switching between light and dark. Dark surfaces use charcoal gray. Follow phone setting works independently of the palette. Saved 1.1.1 Forest Dark/System preferences migrate on launch.
- A short practice plan appears before the part-by-part review. It selects one supported review prompt, mentions a visible pattern to keep only when the report supports it, and offers a cue plus a short drill. It does not invent a problem when no actionable prompt is supported.
- All thirteen body checks use everyday language first. Measurements, detailed caveats and source links are retained under closed Video details panels; coverage/angle metrics are optional. Unknown checks suggest better filming rather than guessed corrections. Forehand, standstill and specialty contexts retain their own limits.
- Coach voice settings include a voice list, preview, speaking pace, stop control and a shortcut to phone speech settings. Automatic chooses higher-quality installed English voices, with offline voices as default. Optional internet voices disclose that the speech provider may receive the spoken coaching text. Video and pose inference remain on-device.
- Android narration selects an actual available voice instead of always using the engine default. Short paragraph chunks and pauses support a more conversational delivery. Browser narration also respects voice, pace and offline/internet preference. Naturalness depends on the installed engine and voices; no voice model is bundled in this update.

See RELEASE-1.1.2.md for installation and the phone checklist.

## New in 1.1.1

- Settings → App theme: Forest, Dark Forest, Coastal, Sunset, or Follow phone setting. Dark Forest uses charcoal-gray backgrounds and forest-green accents, including cards, inputs, review panels, library and disc room. The preference persists on-device, applies before CSS on launch, and updates native system bars where supported.
- Android system appearance is read through the native bridge because a WebView may otherwise report the app's light theme rather than the phone's setting. Changing phone appearance updates the selected automatic palette without discarding the current video.
- Frame seeks check actual decoder readiness as well as events. Missing `seeked` events no longer cause a false load timeout when the requested image is ready. Overlapping scrubs supersede earlier seeks safely.
- Opening and individual-frame failures have distinct messages. Errors use a warm error color rather than the normal green notice. Genuine unsupported-format errors still explain how to re-save a video.
- Failed analysis retains collected frames in a labeled partial review, including the warning in saved reports and narrated plans. No stalled seek is passed into pose inference as a valid frame. Cancellation interrupts a pending analysis seek.
- A completed review remains available even if the final jump to its release frame fails.

See RELEASE-1.1.1.md for phone update steps and a short device checklist.

## Coaching and disc-room features

- Forest layout now has restrained clay, teal and warm yellow accents, topic colors and clearer review cards.
- Thirteen review checks: release; head-to-shoulder movement; torso posture; reachback; elbow opening; upper-arm/forearm position; estimated shoulder–hip coil; plant/release timing; stance; lead-leg support; hand alignment; off-arm movement; and follow-through.
- Separate labels for measured observations, visible patterns to keep, review prompts and missing evidence. No universal form score or fabricated fault diagnosis.
- Manual reachback, plant, arm-loading, release and finish markers. Automatic markers are suggestions; manual markers anchor more useful event comparisons.
- Pose Lite, Full and Heavy model choices. Full is default. More detailed models cost time and memory; they do not make every measurement reliable.
- Separate 21-point hand detection near release, using crops of actual source pixels with full-frame fallback and wrist-location matching. Ambiguous or missing matches are rejected.
- A single optional hand-detail revisit of sampled release frames, decoded frame timestamps where the browser exposes them, and explicit approximate timing when it does not. No generated/interpolated frames are treated as evidence.
- A local evidence-based practice-plan walkthrough, text export and optional phone voice playback. This is not a generative AI coach.
- 62 original practical lessons, 46 linked resources and 23 publisher/coach/research groups, with category, level and publisher filters.
- A 301-entry offline catalog across all ten requested brands. Ratings link to manufacturer references and are dated. Plastic-specific differences are noted where relevant.
- Bag records for multiple copies of a mold, plastic, weight, condition, notes and comfortable personal field distance. JSON backup/restore and custom catalog import.
- A dedicated caddy uses the actual bag, logged ranges, shot context and user-confirmed conditions. It gives an explained shortlist and per-throw feedback; map clearance and exact flight remain unverified.
- IndexedDB version 3 preserves sessions, bag and catalog and adds hole logs. The package name and Android asset origin remain unchanged.

## Run on a computer

Install Node 22+, Python 3, curl and a modern browser:

```sh
npm test
npm run assets
npm start
```

Open http://localhost:8080 on that computer. For phone camera access in a web install, serve dist/ over HTTPS. Directly opening index.html from a file is unsupported. Browser assets may fall back to pinned CDN downloads if not bundled. The Android build bundles the models.

## Build Android

Use JDK 21, Gradle 8.11.1 and Android SDK platform/build-tools 35. Set ANDROID_HOME to the SDK and run:

```sh
npm run assets
npm test
npm run android
```

The default command makes a debug APK for personal testing. To use your release keystore, set ANDROID_KEYSTORE, ANDROID_STORE_PASSWORD, ANDROID_KEY_ALIAS and ANDROID_KEY_PASSWORD, then run `bash scripts/build-android.sh assembleRelease`. The phone workflow manages an encrypted persistent release key automatically. Do not commit raw signing keys or passwords.

`npm run assets` bundles the pinned MediaPipe runtime, WASM, Pose Lite/Full/Heavy models and the hand model. It runs only on a machine with working internet. The source ZIP stays small because the model files are downloaded at build time. Useful offline content and model capabilities determine size; adding unused gigabytes would not improve the coach.

On CI, the Android build script runs `node scripts/browser-smoke.mjs` before Gradle. Chrome and localhost sockets are required. The GitHub Ubuntu 24.04 runner supplies Chrome and the Android SDK. No emulator is required for these browser checks. Actual Android camera, recorder and speech behavior still require phone testing.

## Interpretation and limits

The geometric calculations use source-image landmarks. Confidence gates reject hidden joints and multi-person ambiguity. A scale based on visible shoulders/hips or a visible near-side torso is used for comparison, not an actual body-length measurement in metres. Coil uses the pose model's estimated depth; it is not a calibrated 3D scan. Head position does not reveal gaze. Wrist/knuckle alignment does not reveal grip pressure, spin or disc nose angle. An ankle stopping is a plant cue, not proof of load or ground contact.

Review-prompt thresholds are documented application heuristics for visible changes, not validated biomechanical norms. The app does not measure joint forces, diagnose injury, guarantee ideal sequencing or certify competition rules. Intentional shot shape can change posture. Specialty throws and putting have limited interpretation, and backhand pocket/brace fault prompts are not transferred to them automatically.

Disc tracing remains assisted color tracking or manual timestamped points. It is not a learned universal disc detector, reliable occlusion tracker, spin measurement or 3D distance estimator. The disc catalog does not predict flight; manufacturer numbers vary by model/variant and throwing conditions.

See KNOWLEDGE-SOURCES.md for provenance and AI-COACH-ROADMAP.md for the planned generative coach and expanded caddy.

## Validation

396 automated tests pass for geometry, confidence gating, marked event timing, handedness/lead-foot mapping, near-side visibility fallback, translated-camera rejection, multi-person exclusion, missing coil/hand evidence, specialty-throw interpretation, hand ambiguity, catalog validation, personal-distance comparison, source references and source-frame timestamp handling, missing seek-event recovery, decoder stalls, cancellation, overlapping scrubs and incomplete-review disclosure, plain-language coaching selection and offline voice policy, 28-brand coverage, saved course/hole validation and round isolation, stable bag IDs, full-catalog round trips, photo identity matching, source/format validation and a photo-build transport test. Synthetic coordinates/pixels are used only in tests and are never exposed as personal results in the app.

JavaScript, workflow YAML/shell commands, Android XML, local file references and HTML control IDs are checked separately. This source update still requires the GitHub browser/model checks and Android compilation to pass, followed by tests with actual throws on the phone. Passing software checks does not establish coaching accuracy.
