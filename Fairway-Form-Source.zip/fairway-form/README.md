# Fairway Form 1.1.0

An editable Android and browser app for disc-golf video practice. The previous 1.0.2 APK was successfully built through the user's GitHub workflow and installed on their phone. This 1.1.0 update is source-ready; it has not yet been compiled or run on that phone. This workspace still blocks network sockets, so its local browser/model/Android build checks cannot run here. The existing GitHub build is the delivery path.

## Update from your Android phone

Replace `Fairway-Form-Source.zip` in the SAME private repository with this update, using the SAME filename. Commit it and open the newest Actions run. Keep your existing `.github/workflows/build-apk.yml`, encrypted signing key and APP_SIGNING_PASSWORD secret. Download the new APK artifact after the run succeeds, extract it and install over the old app. The workflow's run number raises versionCode and the saved signing key allows an update without uninstalling. No workflow edit is needed for an existing working Ubuntu 24.04 setup.

The updated build script adds real browser checks on the GitHub runner before compiling. It uses the runner's Chrome, tests the interface and storage upgrade, and loads the real bundled pose/hand models on an empty image to check that they initialize without inventing detections. This check has been written and syntax-checked but cannot run in this restricted workspace. A green GitHub run is still required.

## What changed

- Forest layout now has restrained clay, teal and warm yellow accents, topic colors and clearer review cards.
- Thirteen review checks: release; head-to-shoulder movement; torso posture; reachback; elbow opening; upper-arm/forearm position; estimated shoulder–hip coil; plant/release timing; stance; lead-leg support; hand alignment; off-arm movement; and follow-through.
- Separate labels for measured observations, visible patterns to keep, review prompts and missing evidence. No universal form score or fabricated fault diagnosis.
- Manual reachback, plant, arm-loading, release and finish markers. Automatic markers are suggestions; manual markers anchor more useful event comparisons.
- Pose Lite, Full and Heavy model choices. Full is default. More detailed models cost time and memory; they do not make every measurement reliable.
- Separate 21-point hand detection near release, using crops of actual source pixels with full-frame fallback and wrist-location matching. Ambiguous or missing matches are rejected.
- Dense source sampling near release, decoded frame timestamps where the browser exposes them, and explicit approximate timing when it does not. No generated/interpolated frames are treated as evidence.
- A local evidence-based practice-plan walkthrough, text export and optional phone voice playback. This is not a generative AI coach.
- 38 original practical lessons, 28 linked instructional/technical resources and 15 named publishers/coaches/research groups, with category and level filters.
- A 50-mold offline catalog across Innova, MVP, Axiom, Discraft, Latitude 64, Dynamic Discs and Discmania. Ratings link to manufacturer references and are dated. Plastic-specific differences are noted where relevant.
- Bag records for multiple copies of a mold, plastic, weight, condition, notes and comfortable personal field distance. JSON backup/restore and custom catalog import.
- A basic comparison of your logged bag distances with a target distance. This is a caddy foundation, not a flight prediction or a course-aware recommendation.
- IndexedDB version 2 preserves the existing session store and adds bag/catalog stores. The package name and Android asset origin remain unchanged.

## Run on a computer

Install Node 22+, Python 3, curl and a modern browser:

```sh
npm test
npm run assets
npm start
```

Open http://localhost:8080 on that computer. For phone camera access in a web install, serve dist/ over HTTPS. Directly opening index.html from a file is unsupported. Browser assets may fall back to pinned CDN downloads if not bundled. The Android build bundles the models.

## Build Android

Use JDK 21, Gradle 8.11.1 and Android SDK platform/build-tools 35. Set ANDROID_HOME to the SDK and run:

```sh
npm run assets
npm test
npm run android
```

The default command makes a debug APK for personal testing. To use your release keystore, set ANDROID_KEYSTORE, ANDROID_STORE_PASSWORD, ANDROID_KEY_ALIAS and ANDROID_KEY_PASSWORD, then run `bash scripts/build-android.sh assembleRelease`. The phone workflow manages an encrypted persistent release key automatically. Do not commit raw signing keys or passwords.

`npm run assets` bundles the pinned MediaPipe runtime, WASM, Pose Lite/Full/Heavy models and the hand model. It runs only on a machine with working internet. The source ZIP stays small because the model files are downloaded at build time. Useful offline content and model capabilities determine size; adding unused gigabytes would not improve the coach.

On CI, the Android build script runs `node scripts/browser-smoke.mjs` before Gradle. Chrome and localhost sockets are required. The GitHub Ubuntu 24.04 runner supplies Chrome and the Android SDK. No emulator is required for these browser checks. Actual Android camera, recorder and speech behavior still require phone testing.

## Interpretation and limits

The geometric calculations use source-image landmarks. Confidence gates reject hidden joints and multi-person ambiguity. A scale based on visible shoulders/hips or a visible near-side torso is used for comparison, not an actual body-length measurement in metres. Coil uses the pose model's estimated depth; it is not a calibrated 3D scan. Head position does not reveal gaze. Wrist/knuckle alignment does not reveal grip pressure, spin or disc nose angle. An ankle stopping is a plant cue, not proof of load or ground contact.

Review-prompt thresholds are documented application heuristics for visible changes, not validated biomechanical norms. The app does not measure joint forces, diagnose injury, guarantee ideal sequencing or certify competition rules. Intentional shot shape can change posture. Specialty throws and putting have limited interpretation, and backhand pocket/brace fault prompts are not transferred to them automatically.

Disc tracing remains assisted color tracking or manual timestamped points. It is not a learned universal disc detector, reliable occlusion tracker, spin measurement or 3D distance estimator. The disc catalog does not predict flight; manufacturer numbers vary by model/variant and throwing conditions.

See KNOWLEDGE-SOURCES.md for provenance and AI-COACH-ROADMAP.md for the planned generative coach and expanded caddy.

## Validation

36 direct tests pass for geometry, confidence gating, marked event timing, handedness/lead-foot mapping, near-side visibility fallback, translated-camera rejection, multi-person exclusion, missing coil/hand evidence, specialty-throw interpretation, hand ambiguity, catalog validation, personal-distance comparison, source references and source-frame timestamp handling. Synthetic coordinates/pixels are used only in tests and are never exposed as personal results in the app.

JavaScript, workflow YAML/shell commands, Android XML, local file references and HTML control IDs are checked separately. This source update still requires the GitHub browser/model checks and Android compilation to pass, followed by tests with actual throws on the phone. Passing software checks does not establish coaching accuracy.
