# Fairway Form 1.4.0 — shot selection and personal disc experience

Caddy can now recommend flat, hyzer or anhyzer releases for backhand and forehand, mirrored for the chosen throwing hand. Leave release on Let caddy compare, or select the angle you want. Choose Compare backhand & forehand to compare both styles; their distance references stay separate.

## What changed

- Each recommendation names a specific hand, throw style and release, with a practical explanation of the possible line, finish and wind exposure. Hyzer-flip and flex suggestions remain conditional on the disc and your experience.
- What happened? now records actual hand/style/angle, throw quality, release execution and observed flight, alongside result, carry, notes and conditions. It includes the requested explanation that feedback builds the disc profile. Actual angle and result start unrecorded rather than assuming success or that you followed the advice.
- Disc room → My bag → Your disc profile grows from the editable starting references and your real throw records. It shows shot-type and weather groups, measured averages/farthest, results, great throws, execution misses and flight reports for each physical disc copy.
- Repeated comparable reports can change the suggested angle and line expectation. Three consistent reports are needed for a flight tendency; carry still requires three comparable clear measured throws. Hand, backhand/forehand, angle and conditions stay separate. A pulled/slipped/early release does not redefine the disc's normal flight.
- Initial bag references can be labeled with a hand and angle. Unclassified historical releases stay unknown; they never silently become flat examples. General old measured carry can still provide an explicitly labeled reference.
- History correction now edits actual release, hand/style and quality/execution/flight along with distance. Profiles rebuild from the saved record. Bag/history backup preserves these fields and supports older files.
- The capability-based putter policy, staged long-hole plans, distinct-disc alternatives and previous Android Kotlin dependency fix remain included.

Research links, exact learning thresholds and limits are in SHOT-PROFILE-RESEARCH-1.4.0.md. Learning is local and based on your reports; it does not measure release angle automatically, diagnose why a throw missed, or promise a landing point.

## Update on your phone

Replace the root Fairway-Form-Source.zip in the SAME GitHub repository and commit it. Retain the exact filename, existing workflow, APP_SIGNING_PASSWORD and .fairway-signing.enc. When Actions succeeds, download/extract Fairway-Form-APK and install Fairway-Form.apk over the installed app. Check Version 1.4.0 in App & settings.

Package/origin, signing workflow and IndexedDB version 4 are unchanged. No new native dependency, permission or account is needed. Android local versionCode is 16; CI supplies its increasing code.

## Try it

1. Plan the same line with flat, hyzer and anhyzer. Switch hand and backhand/forehand; check the mirrored explanation. Try crosswind and headwind, and use a real landing point on a dogleg.
2. Log the actual shot even when you changed the plan. Leave uncertain details unrecorded. Record carry separately from basket remainder.
3. Open that bag copy's profile. Check its release/style/weather groups. After three comparable reports, check the recommendation's experience explanation and reported-flight expectation.
4. Correct an angle or distance in history, then reopen Caddy. Back up and restore bag/history; check that the same records remain without duplicates.

## Verification

248 automated tests and static checks pass. Full browser smoke and APK compilation still need the existing GitHub workflow: this workspace blocks the local browser server and lacks Gradle/Android SDK. The source archive is not an APK; device verification remains necessary.
