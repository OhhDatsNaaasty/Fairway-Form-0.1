# Caddy strategy references — 1.19.0

Reviewed for the dogleg/short-forehand correction. These are qualitative coaching sources, not a source of validated distance predictions or obstacle geometry. Summaries below are original paraphrases; the app links to the original articles.

- [Innova — The Best Discs for Throwing Forehand](https://www.innovadiscs.com/innova-news/best-discs-throwing-forehand/): Forehands are useful across approach, midrange and driving distances. Release angle, disc choice and conditions change the path; mirror right-handed examples for left-handed play. No single stability or driver model suits every forehand player.
- [Inside the Circle DG — When to Throw Forehand](https://www.insidethecircledg.com/post/when-to-throw-forehand-in-disc-golf): An opposite-side finish can suit a bend. A sustained turnover and a forehand fade are different routes, with different landing angles and ground-play risks. Evaluate the actual corner, slope and lie.
- [Ultiworld — Course Management, No Hard Shots](https://discgolf.ultiworld.com/2021/10/26/tuesday-tips-disc-golf-course-management-pt-1-no-hard-shots/): Use practiced shots and weigh the next lie against the cost of a miss. A shorter placement can be useful when the basket is outside dependable reach; advancing farther is not automatically the better choice.

## Application rules and limits

`dist/lib/caddy-route.js` separates a natural finish, turn-dependent line, opposed finish and uncertain line. It uses the first bend of a combo; an explicitly entered landing distance takes precedence. A dropdown does not supply the location of a corner, trees or mandatory carry.

For a natural-finish option beyond its own carry reference, Caddy may compare a shorter placement at 85% of that reference. The 1.08 reach margin, ranking weights, 35% relative-progress check and 85% target are app policy heuristics, not numbers asserted by these sources. References can be measured/entered disc distances or labeled estimates; the profile average never becomes a fake disc measurement. Wind/elevation retain separate planning margins. Power refers to the candidate's target.

Distinct disc choices remain the normal shortlist. On a bend, a relevant natural-finish option is retained even if another style using that same bag copy ranks higher. Each has a separate option key, selected-state UI, planned style/power/target and history record. This is especially useful when an experienced player's longer turnover competes with a short forehand.

A suggested placement does not claim to reach the corner or guarantee a later approach. Confirm a clear landing area and enter a known gap distance when required. Actual carry and distance remaining stay blank until measured or reported. A shorter profile average does not disqualify the style from a placement comparison. It also does not prove that an unknown forehand is dependable.
