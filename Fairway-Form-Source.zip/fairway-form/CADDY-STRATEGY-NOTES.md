# Caddy strategy evidence and policy — 1.20.0

The structured offline reference database is `dist/lib/caddy-research.js`. All fourteen records include original summaries, publishers, URLs, review date/scope and applied topics. They are included in the Technique library and Caddy source list. Full web articles and videos are not copied into the app.

| Record | Reviewed source | Application |
| --- | --- | --- |
| scienceFlight | [Giljarhus et al., Sports Engineering (2022)](https://link.springer.com/article/10.1007/s12283-022-00390-5) | Model inputs and limits |
| scienceGeometry | [Kamaruddin et al., institutional abstract](https://research-portal.uws.ac.uk/en/publications/aerodynamic-performance-of-flying-discs/) | Geometry/ratings uncertainty; abstract review only |
| scienceMetrics | [TechDisc Metrics](https://techdisc.freshdesk.com/support/solutions/articles/153000074253-techdisc-metrics) | Distinct speed, spin, pitch, bank and launch quantities |
| scienceRatings | [Innova, Understanding Flight Numbers](https://www.innovadiscs.com/tips/understanding-flight-numbers/) | Intended roles and comparison limits |
| scienceDiscraft | [Discraft, flight-number reference](https://support.discraft.com/support/solutions/articles/44001621475-what-are-these-numbers-on-my-disc-) | Personal flight and control |
| scienceWind | [Innova, wind guide](https://www.innovadiscs.com/tips/tips-for-playing-disc-golf-in-the-wind/) | Bank exposure and local conditions |
| scienceWindConvers | [Ron Convers Jr., Mastering the Wind](https://discgolf.discraft.com/res_wind06_p1.html) | Landing/ground play and changing wind |
| scienceWindPDGA | [Justin Menickelli, PDGA wind explainer](https://www.pdga.com/winds-change-how-wind-affects-throwing-distance) | Wind context; includes the author's clarification |
| scienceApproach | [Innova, Master Your Approach Game](https://www.innovadiscs.com/innova-news/master-your-approach-game/) | Touch, landing and runout |
| sciencePlacement | [Steve Andrews, No Hard Shots](https://discgolf.ultiworld.com/2021/10/26/tuesday-tips-disc-golf-course-management-pt-1-no-hard-shots/) | Dependable shots and miss cost |
| scienceNoBully | [Steve Andrews, Don't Be Bullied by the Course](https://discgolf.ultiworld.com/2021/11/09/tuesday-tips-dont-be-bullied-by-the-course/) | Alternate routes and avoiding the short-side trap |
| scienceSixShots | [Steve Andrews, Six Scoring Shots](https://discgolf.ultiworld.com/2021/11/02/tuesday-tips-disc-golf-course-management-pt-2-learn-to-score-with-these-six-shots/) | Reliable scoring tools and landing targets |
| scienceForehand | [Innova, Forehand Choices](https://www.innovadiscs.com/innova-news/best-discs-throwing-forehand/) | Mirroring, release and different disc jobs |
| scienceGlossary | [Innova, Shot Glossary](https://www.innovadiscs.com/home/disc-golf-faq/glossary-of-terms/) | Distinct release and flight-shape terms |

## Implemented planning rules

- Notes reach the engine through `layoutNotes`. Recognized constraints are returned in `plan.layout`. The original text remains available; unmatched and conflicting descriptions are disclosed. This is bounded offline phrase interpretation, not unrestricted language understanding or course mapping.
- Sources inform qualitative choices. `caddy-safety.js` uses explicit app policy margins for long misses: a shorter basket objective and at most 82% of the selected reference after existing context margins. A reported large space beyond the basket, or a hazard beyond the reachable first stage, can avoid that automatic shortening. These fractions are not measured success probabilities or values validated by the cited papers.
- Required crossings are checked against the placement and carry reference, with a policy margin. A too-short automatic water layup is rejected. An explicit near-side landing remains conditional on checking dry ground. Unknown carry distances are not invented.
- A known first corner can create a first-stage straight placement. An explicitly open straight or wider alternate route can be compared independently from the hole's nominal bend. Blocked styles are excluded for that lie. Dogleg bonuses are modest relative to carry, history and landing considerations.
- Bank, intended early turn and eventual finish are separate. Advanced/Pro options remain gated. Ground, ceiling, wind and repeatable effort affect ranking; no skip length, exact release degrees or calibrated flight path is fabricated.
- Tee distances and blocked-route assumptions are not automatically reused from a later lie. A new note edit activates current-lie context. Saved tee layout and current round context remain distinct.

## Data integrity and validation

App source filenames, package, origin, schema 5 and signing are unchanged. Planned targets stay separate from actual carry/remaining distance. Notes and the applied shot context survive throw/history export. Clear controls target only their associated text; changing current-lie notes does not overwrite a previously recorded throw.

598 JavaScript checks passed. Local real-browser execution was unavailable because socket operations were denied, and an approval-enabled test launch was interrupted. The updated browser checks remain mandatory in GitHub; no local browser pass or signed APK is claimed. See RELEASE-1.20.0.md.
