# Video review and backhand reliability — 1.29.0

The user reports side-on, normal-speed backhand clips with incorrect suggested
moments, frozen scrubbing and vague coaching. The exact failing recording was
not available locally. This release fixes identifiable pipeline defects and
adds adversarial synthetic regressions; it does not claim a measured real-video
accuracy improvement or equivalent coverage of forehands and putting.

## Scrubbing

Previously every slider event launched a seek and cancelled the previous one.
On a slow phone decoder, a stream of input could repeatedly restart work before
any image settled. Prepared-image review had the same cancellation pattern.

The new interactive queue runs one decode at a time and keeps only the latest
queued target. The slider shows the requested position while loading; marking
stays disabled until the queue settles on displayed pixels. Intermediate frames
can appear without moving the requested thumb backward. Playback, a new clip or
analysis cancels the queue explicitly. Repeated step presses use the queued
position. Browser scrubbing has a short paused-seek path and a bounded playback
recovery; prepared-image requests have bounded waits and immediate cancellation.
The final failed target reports an error and keeps the last displayed frame.

In the Android APK, Repair scrubbing prepares the current clip using the existing
native frame cache. It preserves the analysis, event markers, notes, review range
and session identity. It does not silently change the saved processing preference.
A mode/status label explains which transport is actually active. Original video
remains the default; Prepared frames remains a selectable preference. Cache
preparation can take time and unsupported codecs can still fail with an error.
This is a recovery route, not a guarantee for every recording or HDR format.

## Moment selection

The pose engine is unchanged. Event selection combines independent evidence:

- Foot-contact analysis receives the full pose timeline, rather than only frames
  whose throwing shoulder, elbow and wrist all pass visibility checks.
- A visible ankle and at least one contact landmark (toe or heel) can support a
  landing suggestion. The lower visible contact point tolerates a lifted heel;
  missing both points still prevents a contact suggestion.
- A later sustained stride invalidates an earlier walk-up contact, including
  shallow steps where a lift may be hard to see. Unseen final contact stays
  unavailable rather than becoming an earlier approach step.
- Swing candidates consider backswing, lead-foot settling, arm loading/opening
  and continuing arm motion. A robust speed reference reduces the influence of
  a very large isolated peak on candidate grouping. The app's score weights and
  thresholds are engineering heuristics, not values validated by an instructor.
- Follow-through can use visible movement after a short occlusion. Travel is
  accumulated only within observed segments; no motion is invented across the
  missing interval. A static arm plus a visibility gap still produces no finish.
- Suggested events have source-review intervals. These show frames to inspect,
  not calibrated confidence intervals. Manual corrections retain their actual
  source times, including an unusual or late plant; timing is not forced ideal.

Pose landmarks do not show disc separation. Automatic release remains a swing
cue and must not be described as a confirmed disc release. Competing throws
still require a selected range/anchor. A trained disc-golf temporal detector with
labeled plant/reachback/release/finish examples, and disc-visible release data,
would be a different next-stage approach. No such model is trained or shipped
here. More prose research alone cannot establish its accuracy.

## Coaching

Generic guide text was overwriting some clip-specific action cues. The merge
now retains the contextual instruction while keeping the topic explanation,
source-linked practice plan and outcome check. Posture, arm opening, head
movement, off-arm path and continuation use available clip metrics/times in the
plain-language explanation. What this point is based on expands the original
measurement evidence. Unknown checks stay ungraded and automatic release does
not silently turn into a confirmed fault or success.

Instructional basis remains the already registered library material: final
stride timing, backswing/plant order, arm loading, coil, posture, follow-through,
focused fieldwork and the corresponding shot-specific lessons. No new external
source was reviewed in this patch and no video-watching or model-training claim
is made. The existing research registry and access provenance remain searchable.

## Verification

17 new tests cover a 100-input scrub burst (one active decode plus the latest
queued target), cancellation/new-clip isolation, bounded prepared-image failure,
last-frame preservation, occluded-arm/heel contact cases, hidden final contact,
segmented follow-through and personalized coaching. Synthetic cases include
three-, five- and seven-step side-on backhands. They are generated coordinates,
not a held-out set of human throws or evidence of a measured accuracy percentage.

The required browser scenario additionally reopens a saved review in Original
mode, uses a test Android bridge for per-clip repair, checks analysis/marker/note
retention, rapidly scrubs to the final target and saves the result. This does not
test MediaCodec or a physical phone. The local browser run was blocked by socket
EPERM; GitHub's browser/model, native and APK gates remain required.
