# Fairway Form 1.2.2 — fix the caddy build check

The 1.2.1 GitHub run stopped in the pre-build browser check with “New caddy hole did not use personal limits.” The check could run before the saved profile and new hole finished loading: it treated the preloaded “THROW 1 · TEE” label and visible page as readiness. The input values were still blank at that point.

This update gives Caddy an explicit loading/ready/error state. Its controls remain inactive while the profile, bag and hole are opening; a brief loading message remains visible. The browser check waits for ready before checking the saved putting and disc-speed limits. The assertion is retained, with actual field values added to any failure message. Background autosaving skips the inactive controls so blank fields cannot overwrite a loading draft.

All player-profile, video, coaching, bag, caddy, sign-photo and weather features from 1.2.1 remain included. Saved holes retain their own per-lie limits. No database schema, Android permission, external dependency, signing or workflow change is required. Local versionCode is 12; GitHub still supplies its increasing code.

## Build using your phone

1. Download the 1.2.2 Fairway-Form-Source.zip and keep it zipped with that exact filename.
2. Replace the root ZIP in the SAME GitHub repository and commit the change to main. Rerunning the failed run by itself uses the old source.
3. Keep your existing workflow, APP_SIGNING_PASSWORD secret and .fairway-signing.enc signing file.
4. Open the newest Actions run. After it succeeds, download/extract Fairway-Form-APK and install Fairway-Form.apk over your current app.
5. Confirm App & settings shows Version 1.2.2. Save your profile and open Caddy; its new hole should show your putting and controlled-speed limits after loading.

This is an updated source ZIP, not an APK. GitHub builds and signs the installable APK.

## Verification

184 automated tests pass, including six new caddy UI integration checks. The tests evaluate the real app modules with delayed storage and a minimal DOM harness. They cover the misleading preloaded label, waiting through a profile read, preserving existing per-lie limits, concurrent opens creating only one hole, storage-failure recovery, and backgrounding during a pending profile read. The first version of the tests failed against 1.2.1; they pass with this fix.

JavaScript syntax/imports, referenced and duplicate controls, offline shell paths, Android XML, shell scripts, versions and package/database wiring pass static checks. The workspace still blocks local sockets with EPERM, so the full Chromium/model check cannot be run here. No local Android toolchain is available. The existing GitHub workflow runs that browser check before compiling/signing; its success and the phone installation still need verification.
