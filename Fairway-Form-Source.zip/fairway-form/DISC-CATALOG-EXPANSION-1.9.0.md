# Disc catalog expansion — 1.9.0

Checked 2026-10-22. The app now bundles 850 molds across 28 brands (previously 302 across 10). These are factual brand/model/type/rating snapshots, not a copy of product descriptions or a claim that every current or discontinued mold is available.

| Brand | Bundled molds | Primary source for added reference records |
| --- | ---: | --- |
| AGL Discs | 19 | https://discgolfdojo.com/discs/agl-discs/ |
| Axiom | 27 | https://discgolfdojo.com/discs/axiom/ |
| Clash Discs | 23 | https://discgolfdojo.com/discs/clash-discs/ |
| Climo | 7 | https://discgolfdojo.com/discs/climo/ |
| DGA | 21 | https://discgolfdojo.com/discs/dga |
| Discmania | 67 | https://discgolfdojo.com/discs/discmania/ |
| Discraft | 79 | https://discgolfdojo.com/discs/discraft/ |
| Dynamic Discs | 34 | https://discgolfdojo.com/discs/dynamic-discs/ |
| Gateway | 13 | https://discgolfdojo.com/discs/gateway |
| Infinite Discs | 17 | https://discgolfdojo.com/discs/infinite-discs/ |
| Innova | 126 | https://discgolfdojo.com/discs/innova/ |
| Kastaplast | 22 | https://discgolfdojo.com/discs/kastaplast/ |
| Latitude 64° | 72 | https://discgolfdojo.com/discs/latitude-64/ |
| Legacy Discs | 25 | https://discgolfdojo.com/discs/legacy-discs |
| Lone Star Disc | 48 | https://discgolfdojo.com/discs/lone-star-disc/ |
| Løft Discs | 5 | https://discgolfdojo.com/discs/loft-discs/ |
| MVP | 49 | https://discgolfdojo.com/discs/mvp/ |
| Millennium | 11 | https://discgolfdojo.com/discs/millennium |
| Mint Discs | 21 | https://discgolfdojo.com/discs/mint/ |
| Prodigy | 53 | https://discgolfdojo.com/discs/prodigy-discs/ |
| RPM | 12 | https://discgolfdojo.com/discs/rpm/ |
| Stokely Discs | 7 | https://discgolfdojo.com/discs/stokely-discs/ |
| Streamline | 13 | https://discgolfdojo.com/discs/streamline-discs/ |
| Thought Space Athletics | 17 | https://discgolfdojo.com/discs/thought-space/ |
| Trash Panda | 5 | https://trashpandadiscgolf.com/products/100-recycled-disc-golf-set |
| Viking | 13 | https://discgolfdojo.com/discs/viking-discs/ |
| Westside Discs | 32 | https://discgolfdojo.com/discs/westside-discs/ |
| Yikun | 12 | https://discgolfdojo.com/discs/yikun/ |

Original manufacturer records keep their IDs, numbers, version notes and photo hints. Manufacturer additions take precedence over the new reference snapshots; the new reference records are explicitly labeled **Reference catalog** in the UI. Equivalent punctuation in model names is normalized only for the merge. Roc and Roc+ remain distinct. Existing physical bag copies and all throw records continue to use their original IDs.

The reference source is Disc Golf Dojo’s per-brand flight-number chart tables. Those tables include retired molds as well as newer molds, and can have representative or older plastic/run ratings. Brand charts are snapshots, not authoritative inventories. MVP Mass had incomplete ratings in the retrieved table and was omitted rather than filling in unknown numbers. Manufacturer and reference discrepancies are not silently applied to the original 302 records. New records without a verified bundled photo show Photo unavailable. No generic image is passed off as a mold photograph.

Additional manufacturer checks: https://www.innovadiscs.com/disc/ (first directory page, including the Arachnid) and https://store.discgolf.com/collections/shop-all-dga-discs (Hurricane X, 13 / 5 / 0 / 3). DGA’s published flight chart is at https://store.discgolf.com/pages/disc-flight-chart. These checks do not establish an exhaustive manufacturer-by-manufacturer inventory.

## Updating the catalog

1. Edit reviewed factual entries in scripts/catalog-reference-snapshot.json or scripts/catalog-manufacturer-additions.json.
2. Run node scripts/build-catalog.mjs. Existing dist/lib/disc-data.js entries win; manufacturer additions are merged before reference records.
3. Run npm test. Rebuild the APK using the existing workflow.

Every record carries its source URL, source type, check date and a flight-variation note. Ratings and illustrative turn/fade paths remain reference information. Actual per-copy throwing and putting performance still comes from Caddy feedback, never from the fact that a mold was added to the catalog.
