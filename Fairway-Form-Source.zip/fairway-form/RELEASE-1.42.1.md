# Final Form - Disc Golf 1.42.1

## Reviewed-source browser gate

The APK workflow failed with “Reviewed sources are not present in the library database.” The references were present: 1.42.0 added the Open-Meteo sky reference, bringing the Caddy research collection to 15. The browser gate still rejected any collection whose count was not exactly 14. The earlier Node check had been updated separately, allowing those checks to disagree.

A shared, self-contained assertion now runs in both the Node suite and Chrome (serialized verbatim). It requires the original Caddy reference IDs and the sky reference, checks their reviewed metadata and useful previews, verifies summaries/application context and matching HTTPS library links, and accepts additional fully reviewed references. Failure messages identify the missing or invalid reference. The browser's separate phone-width check remains intact.

Regression tests run the serialized browser function against the actual registry, accept another valid source, reject missing required references in either collection, and reject incomplete review metadata or mismatched links. The full browser/model/native/APK gates remain required. No source was removed and no check was bypassed to get an APK.

## Scope and validation

This patch changes build-check code and release metadata. The 1.42.0 tilt, sky, foliage, weather parsing, disc selection and saved-data behavior remain unchanged. Test totals, source comparison, archive integrity and the fresh local browser status are in verification.json.

Local browser execution is BLOCKED by workspace socket permissions before tests run. No local real-browser or signed APK pass is claimed. The exact function sent to the browser is exercised in the Node regression tests; GitHub must still run the complete real-browser gate.

## Install

Replace repository-root Fairway-Form-Source.zip, preserving the exact filename. Run the existing workflow. After every required check passes, install its signed APK over the current app without uninstalling. Package, signing identity, origin and storage keys remain unchanged. Version name: 1.42.1. Fallback versionCode: 73; CI retains its increasing code.
