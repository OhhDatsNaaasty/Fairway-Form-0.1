# Final Form - Disc Golf 1.30.0

Uses measured pose results from the accessible uploaded McBeth clips to change
the production event rules. This goes beyond the reference-only 1.29.1 release.

On the full-speed screen recording, the old rules selected a swing cue at
2.33 s and a post-swing recovery as plant at 2.43 s. The updated rules select the
initial outward swing at 2.03 s and final contact at 1.80 s. A cropped viewport
keeps its already-correct swing/plant and now finds arm loading. A selected
review range also retains the supported preparation rather than switching to an
earlier approach motion.

Direction checks now use the velocity estimator's actual observed time pair.
A backhand helper distinguishes the initial outward stroke from a later wrap,
and a recovery cannot replace an already accepted final contact. Nearby observed
frames can confirm arm opening; manual corrections and genuinely late contacts
remain possible. Model weights, player data, video decoding and scrubbing are
unchanged in this release.

The comparison used MediaPipe Python CPU 0.10.21 with the identical bundled Full
task and settings, followed by the production JavaScript event code. It is not
phone/MediaCodec or WebView/WASM validation. These examples guided the change;
they are not held-out trials or independent coach-labeled ground truth. Release
remains a swing estimate rather than confirmed disc separation. No general
accuracy percentage or new model training is claimed.

The slowed reference remains ambiguous, and X-step is still unavailable in these
cropped/oblique cases. The Buhr link is recorded but its footage remains inaccessible
(archive transfer cap; throttled web fetch), so it has not been used for tuning.
See DETECTOR-REFERENCE-VALIDATION-1.30.0.md for exact before/after results, source
hashes, reproduction and limitations. Research provenance in the library is updated.

## Verification and update

The full JavaScript suite passed 771 tests, including seven new recorded-reference
regressions, with no failures/skips/cancellations. An initial concurrent run
hit the existing short supervisor-worker startup test under CPU inference load;
the final suite ran after extraction finished and passed. Local browser preflight
was BLOCKED by socket EPERM (run 0d00b256-44f4-4618-84db-751c4649a670). This is not
a browser/model pass. Mandatory GitHub browser/model/native/APK gates remain enabled.
No local signed APK or physical-phone pass is claimed. Static/archive results are
recorded in verification.json.

Replace the SAME private repository-root Fairway-Form-Source.zip and commit with
the existing working workflow/signing credentials. After Actions succeeds,
extract and install the APK over the existing app without uninstalling. Version
is 1.30.0; fallback versionCode is 53 (CI supplies its increasing code).

Reanalyze the same original side-on backhand recording to refresh estimates.
Existing manual markers keep priority; clear only markers you want automatically
estimated again. Saved reviews are not silently overwritten; save after checking.
Package com.fairwayform.app, WebView origin, IndexedDB schema 5, IDs, Caddy, bag,
approved intro and signing setup remain compatible. No upload or migration is added.
