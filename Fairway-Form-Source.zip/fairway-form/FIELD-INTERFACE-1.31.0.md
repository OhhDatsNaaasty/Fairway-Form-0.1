# Field interface implementation

The user's approved direction is deep forest (#101f1d) and basket gold (#dfbc72), with quieter dividers, readable controls and less information visible at once. The white-background design alternative is not part of the redesign.

## Where existing features live

| Task | Location |
|---|---|
| Current hole, par, distance and next lie | Caddy summary |
| Course suggestions / add course / manual hole setup | Course name or Layout, hazards & notes sheet |
| Saved courses, round logs, imports and backups | Caddy More, or app More → My courses |
| Wind, weather, compass and manual direction | Wind & weather in the current-lie sheet |
| GPS carry / nearby AR basket distance | Caddy Measure distance; full measurement tools remain in Throw / Result |
| Sign photo, recognition and draggable markers | Read a hole sign; saved photo opens from the summary |
| Notes-derived feature positions and corrections | Tap the hole picture |
| Shot alternatives, power, release and reasoning | Throw view; alternatives / details expand on demand |
| Result, measured carry, actual throw, release and putting feedback | Result view |
| Bag lookup and type / speed sorting | My Bag |
| Disc photos, plastics, weight, personal flight, measurements and corrections | Tap a bag row |
| Catalog, exact-speed filters, manufacturer references and imports | Disc room / catalog |
| Player / camera setup, source player, range and markers | Studio → Moments |
| Summary, detailed findings, evidence and linked sources | Studio → Coaching |
| Setup, task, outcome check, progression and drill choices | Studio → Practice |
| Session notes, measured carry, report / video exports | Review's Notes, distance & exports section; quick Save review remains above |
| Saved video reviews | More → My sessions, with search |
| Lessons and full research registry | Learn |
| Putting style / stance and personal references | Player profile; putting plan links to its preferences |
| Voice, offline files, appearance, privacy and updates | More → App & settings |

The layout moves canonical controls instead of duplicating them. Existing IndexedDB schema 5 is retained. Local source fields and cloud/model algorithms are not replaced by a visual simulation.

## Hole art and source precedence

Notes build scene objects with a kind, reference point, along-hole or basket-relative distance, side, optional lateral distance and original text. Supported descriptions include individual or flanking trees, dense tree lines, water / OB / road / fence and named landmarks. Unpositioned descriptions are kept as pending rather than silently drawn at an invented location. Unsupported wording remains in the note and can be represented with Add a feature. Corrections are independently editable and original note text remains intact. Visual-only corrections do not silently rewrite shot-planning notes; the editor explains that planning changes belong in notes / setup.

The base route is one of the eight actual fairway selections, including slight bends and the narrow wooded route. Coordinates are illustrative along that route. Icon sizes, tree spread, water extent and fairway width are not survey measurements. The displayed water offset is a clearance cue; no surveyed pond outline is inferred.

Sign thumbnails are resized/re-encoded locally as bounded JPEG data, removing source metadata. The original current-round sign stays available for OCR and marker editing. Saved course art is keyed by saved hole number or mapped route ID, so multiple routes of the same hole remain separate. Images / corrections round-trip in course JSON; course backups now allow up to 60 MB. The existing Android file-export limit still applies to very large backups.

New holes are created from a clean round, or their own saved layout. Returning to a hole restores its own notes and picture. Later lies keep the tee's scale and static layout; updating remaining distance does not replace tee distance. Explicitly edited hole notes and art can be saved while playing, alongside the existing current-lie data.

## Validation limits

The default sandbox blocks local browser sockets. The optional visual capture request was interrupted before running. No visual browser pass, actual-app screenshot set, signed APK or physical-phone compass result is claimed. The required GitHub browser gate still tests real models and media and now includes canonical-control / navigation and compact-profile assertions. Saved source fixtures and synthetic checks are development evidence, not general biomechanical or mapping accuracy.
