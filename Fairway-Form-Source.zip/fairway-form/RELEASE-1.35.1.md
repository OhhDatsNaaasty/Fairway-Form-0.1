# Final Form - Disc Golf 1.35.1

The terrain camera now looks diagonally across the hole from a lower angle. Level ground is foreshortened horizontally rather than stretching almost vertically toward the basket, which made ordinary flat fairways look uphill. Visual height exaggeration is reduced, and the terrain frame, base thickness and shadow are adjusted to suit the new view.

The note-derived heights remain intact. Actual uphill/downhill sections, elevated tees and basket mounds still change the surface. Home and landing views use the same revised projection, including trees, hazards, tee, basket and selected target. This changes presentation only: the terrain parser, disc ranking, carry allowances, stored distances, sign photos, feature editing and throw-analysis engine are unchanged.

## Verification

All 965 automated tests passed. The existing terrain, layout, landing, notes, backup, history, UI, native and workflow checks remain enabled. Syntax checks cover 115 runtime/script files; all 109 offline paths exist and all 409 static controls remain unique and retained.

Production-renderer previews compare the previous and revised camera on the same flat hole, show level/uphill/downhill versions under the same camera, and cover all eight selectable layouts on level ground. These SVGs were rasterized with Inkscape and visually inspected; they are not browser or Android screenshots. Archive CRC, exact workspace equality and unchanged files against version 1.35.0 are checked.

Fresh local browser run 615731cc-ba9f-40ef-a906-0e8dfd8e465a stopped immediately with socket EPERM before Chrome started. No browser or phone pass is claimed. The required GitHub browser/model gate stays enabled. No APK was compiled or signed locally.

## Update

Replace repository-root Fairway-Form-Source.zip and run the existing GitHub workflow. After every required gate passes, install its signed APK over the current app without uninstalling. Version name is 1.35.1; fallback versionCode is 62 and CI retains its increasing code. Signing identity, package/origin, storage schema and approved intro remain unchanged.
