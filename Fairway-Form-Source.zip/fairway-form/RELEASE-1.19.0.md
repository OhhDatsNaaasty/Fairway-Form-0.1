# Final Form - Disc Golf 1.19.0 — Forehand placement options on doglegs

## Fix

A shorter forehand was penalized against a long basket target, while several longer backhands filled the shortlist. The one-option-per-disc rule could also hide a useful alternative style using the same physical disc.

Caddy now compares a reachable placement using that style's own distance reference. On a right-handed right dogleg, a suitable forehand can remain useful before the basket is reachable; the directions mirror for left-handed players. Lower-skill recommendations no longer treat an understable flat backhand as a simple guaranteed right-turning route. Advanced/Pro can still compare practiced turnovers, with explicit guidance about the different flight and landing angle.

A relevant bend-matching option stays available even when another style with the same disc ranks higher. The buttons now say Use this shot / Choose this shot and select a unique shot option. The selected-shot summary shows the style and placement distance; exactly one option is selected. Logging preserves that option's planned style, effort, target and selection key rather than silently taking the first plan for the mold.

## Practical limits

The app does not know the corner's location from the total hole distance or dogleg dropdown. Placement distances are approximate guides, not promises to clear trees, reach the corner or leave a calculated approach. Use a visible landing area. The existing optional distance field is now labeled **Distance to a visible gap / corner**; entering it overrides automatic shortening.

Measured/entered distances and labeled estimated windows remain separate. Broad effort guidance uses the chosen option's target. Suggested targets do not populate actual carry or distance remaining. Saved target context is retained through bag-history backups. Putting, courses, measured distances, per-copy photos, intro and themes remain included.

The source review and app-specific heuristic limits are documented in CADDY-STRATEGY-NOTES.md. New source links and a short strategy explanation appear in Caddy's guide and source list. Ranking margins are app policy, not a validated flight simulator.

## Validation

558 JavaScript tests pass. Regression cases cover a long understable backhand versus a shorter forehand, each hand/bend direction, profile-only forehand estimates, explicit gap distances, straight long holes, first bends of combo holes, same-disc alternatives, selected-option recording, backup retention and actual-distance isolation.

A real mobile Chrome check reproduces the 350-foot right-dogleg example, selects and logs a shorter forehand, and verifies two styles using the same disc can be selected independently. It checks the planned versus actual distances and mobile layout. Previous skill/power/putting, palette/readability and personal-photo/JSON-backup browser checks also pass. The full browser/pose-model gate remains mandatory in GitHub. Local validation does not compile or sign an Android APK; there is no local SDK or signing key.

## Update from your phone

Replace and commit the repository-root **Fairway-Form-Source.zip** using the same workflow and signing credentials. After GitHub Actions succeeds, download **Fairway-Form-APK**, extract **Fairway-Form.apk**, and install it over the current app. Do not uninstall first.

Version 1.19.0 uses fallback versionCode 37; CI continues its increasing run-based version. Package `com.fairwayform.app`, origin, database schema 5, backup kinds, signing identity, movie and filenames remain unchanged.

Test your own bag, hand, distances and dogleg. Try choosing an alternate style with the same disc and confirm the saved planned/actual style in feedback. If the corner is farther away than the suggested placement, enter its distance or choose a clear spot before it.
