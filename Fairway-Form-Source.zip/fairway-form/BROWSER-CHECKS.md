# Browser checks without silent waits

Use `npm run test:browser`. Direct `node scripts/browser-smoke.mjs` invocations also enter the same supervisor. CI uses it through scripts/build-android.sh, so the existing phone ZIP workflow receives this protection without a workflow edit.

Each run prints a unique run ID and start time, replaces artifacts/browser-check.log, and writes artifacts/browser-check-status.json. The status begins as running and ends as passed, failed, blocked, timed-out or interrupted. Only passed with exit code zero is a passing run. Previous log contents are never reused as evidence for a new run.

## Limits after command launch

| Check | Limit |
| --- | --- |
| Local test-server startup | 3 seconds |
| Chrome startup | 45 seconds per attempt; at most 2 attempts |
| Individual browser protocol command | 150 seconds by default; short polling checks use their remaining wall-clock budget |
| No test-step progress | 3 minutes |
| Whole browser-check process | 10 minutes |
| Live heartbeat | Every 10 seconds |
| Graceful termination before force-stop | 3 seconds |

The supervisor is a separate Node process. It can stop the worker and Chrome descendants even if a browser command or the worker's JavaScript event loop hangs. Supervised Chrome remains inside the worker's process group. Status/heartbeat lines name the current test stage and protocol activity. A stream of arbitrary worker output does not reset the progress deadline. Existing browser/model assertions and the APK gate remain enabled.

The current workflow templates also upload Fairway-Form-Browser-Checks diagnostics on success or failure. Existing repository workflows still show the live stage/heartbeat output in the compile step; copying the new template is optional for the extra diagnostics artifact.

## Environment blocks and platform waits

A local socket EPERM/EACCES is reported as BLOCKED promptly, with exit code 2. Continue unit/static checks and use the mandatory browser/model check in GitHub's Ubuntu runner. Do not automatically queue another additional-permission request for this optional local check. Internet HTTP policy and a command's local socket permissions are separate controls.

Project timeouts start only after the execution service launches the command. They cannot control an approval queue, scheduling wait, client disconnect or service failure before launch. Announce checks first, use short yielding calls, and inspect the new run ID/start time when a call returns. If there is no new run, describe it as a tool-launch wait rather than a running browser test. Do not promise continued chat updates while the platform itself is unresponsive.

AGENTS.md records this workflow for future work on the project. These changes cannot repair Codex service availability or establish that an account was migrated to a new cloud experience.

## Validation for this change

Regression tests cover success/failure reporting, explicit blocks, live output/stages, inactivity and total deadlines, cancellation, launch errors, preflight errors/timeouts, supervised Chrome process grouping and per-command deadlines. A real Node child deliberately blocks its event loop; the independent supervisor terminates it and reports a timeout. The real local entry point has also been exercised in this environment and returns BLOCKED in under one second. No full local browser/model pass is claimed for this build-workflow update.

## Prepared-frame/image checks (1.24.1)

The reported GitHub run passed its H.264 fixtures, then timed out on one Runtime.evaluate command during the broad prepared-frame stage. Its log did not identify the precise substep. An unbounded image.decode() on a loading=lazy study image was found in that stage. This is a plausible cause, not a reproduced diagnosis of the original CI run.

All DOM-image checks now use the same serialized helper tested in Node. It sets loading=eager, scrolls the image into view, waits at most eight seconds and requires usable dimensions. Prepared-frame transfer, preview, scrubbing, pixels, markers, analysis, study image, lesson navigation, save and cleanup have distinct stage labels. Direct evaluations use a 15-second protocol deadline; polling retains elapsed-time limits and per-command deadlines. The cache-analysis polling budget stays 90 seconds, with individual evaluations bounded to 12 seconds. Failure diagnostics attempt to capture app/model status, toast, frame time and upload count, with a two-second diagnostic deadline.

The general 150-second protocol default remains for other existing heavyweight checks. The parent watchdog and required browser/model gate are retained. No unsafe SwiftShader option was added in response to Chrome's warning. Full browser and native-device results remain separate from helper tests.
