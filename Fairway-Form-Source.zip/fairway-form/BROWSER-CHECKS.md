# Browser checks without silent waits

Use `npm run test:browser`. Direct `node scripts/browser-smoke.mjs` invocations also enter the same supervisor. CI uses it through scripts/build-android.sh, so the existing phone ZIP workflow receives this protection without a workflow edit.

Each run prints a unique run ID and start time, replaces artifacts/browser-check.log, and writes artifacts/browser-check-status.json. The status begins as running and ends as passed, failed, blocked, timed-out or interrupted. Only passed with exit code zero is a passing run. Previous log contents are never reused as evidence for a new run.

## Limits after command launch

| Check | Limit |
| --- | --- |
| Local test-server startup | 3 seconds |
| Chrome startup | 45 seconds per attempt; at most 2 attempts |
| Individual browser protocol command | 150 seconds by default; short polling checks use their remaining wall-clock budget |
| No test-step progress | 3 minutes |
| Whole browser-check process | 10 minutes |
| Live heartbeat | Every 10 seconds |
| Graceful termination before force-stop | 3 seconds |

The supervisor is a separate Node process. It can stop the worker and Chrome descendants even if a browser command or the worker's JavaScript event loop hangs. Supervised Chrome remains inside the worker's process group. Status/heartbeat lines name the current test stage and protocol activity. A stream of arbitrary worker output does not reset the progress deadline. Existing browser/model assertions and the APK gate remain enabled.

The current workflow templates also upload Fairway-Form-Browser-Checks diagnostics on success or failure. Existing repository workflows still show the live stage/heartbeat output in the compile step; copying the new template is optional for the extra diagnostics artifact.

## Environment blocks and platform waits

A local socket EPERM/EACCES is reported as BLOCKED promptly, with exit code 2. Continue unit/static checks and use the mandatory browser/model check in GitHub's Ubuntu runner. Do not automatically queue another additional-permission request for this optional local check. Internet HTTP policy and a command's local socket permissions are separate controls.

Project timeouts start only after the execution service launches the command. They cannot control an approval queue, scheduling wait, client disconnect or service failure before launch. Announce checks first, use short yielding calls, and inspect the new run ID/start time when a call returns. If there is no new run, describe it as a tool-launch wait rather than a running browser test. Do not promise continued chat updates while the platform itself is unresponsive.

AGENTS.md records this workflow for future work on the project. These changes cannot repair Codex service availability or establish that an account was migrated to a new cloud experience.

## Validation for this change

Regression tests cover success/failure reporting, explicit blocks, live output/stages, inactivity and total deadlines, cancellation, launch errors, preflight errors/timeouts, supervised Chrome process grouping and per-command deadlines. A real Node child deliberately blocks its event loop; the independent supervisor terminates it and reports a timeout. The real local entry point has also been exercised in this environment and returns BLOCKED in under one second. No full local browser/model pass is claimed for this build-workflow update.

## Prepared-frame/image checks (1.24.1)

The reported GitHub run passed its H.264 fixtures, then timed out on one Runtime.evaluate command during the broad prepared-frame stage. Its log did not identify the precise substep. An unbounded image.decode() on a loading=lazy study image was found in that stage. This is a plausible cause, not a reproduced diagnosis of the original CI run.

All DOM-image checks now use the same serialized helper tested in Node. It sets loading=eager, scrolls the image into view, waits at most eight seconds and requires usable dimensions. Prepared-frame transfer, preview, scrubbing, pixels, markers, analysis, study image, lesson navigation, save and cleanup have distinct stage labels. Direct evaluations use a 15-second protocol deadline; polling retains elapsed-time limits and per-command deadlines. The cache-analysis polling budget stays 90 seconds, with individual evaluations bounded to 12 seconds. Failure diagnostics attempt to capture app/model status, toast, frame time and upload count, with a two-second diagnostic deadline.

The general 150-second protocol default remains for other existing heavyweight checks. The parent watchdog and required browser/model gate are retained. No unsafe SwiftShader option was added in response to Chrome's warning. Full browser and native-device results remain separate from helper tests.

## Analysis preview checks (1.25.0)

The browser gate asserts original-video mode is the default. Original-player
range selection and saved review windows must use displayed source timestamps.
The Android-bridge fixture opts into Prepared frames explicitly and observes
preview updates during body/hand analysis; source-image and observation times
must agree, with multiple source times displayed. This is a browser bridge
fixture, not a real Android codec or throw-event accuracy test. Existing real
H.264/model checks and bounded prepared-frame substeps remain required.

## Automatic sequence regression (1.26.0)

A named, bounded browser step uses the coordinate-only seven-step fixture to
check final plant, the actual crossover timestamp, automatic coaching without
mandatory release marking, the editable Coil marker and internal coil-lesson
navigation. It is explicitly synthetic; it is not pose-model/video accuracy
evidence. It adds no user records and the page reload clears its report. The
real H.264/model and prepared-frame checks remain enabled.

## Descriptive coaching and source browsing (1.27.0)

A bounded browser step verifies the default explanation, multi-step practice
task and direct source link; research pagination from 30 to 60 cards; a resource
without a linked lesson; catalog-reference filtering; and return from source
view into the exact lesson. Coordinate fixtures exercise rendering only and
are never described as human-video/model-accuracy evidence. Existing decoder,
model, source-frame and Android checks remain required.

## Hole-sign workflow in 1.28.0

The mandatory browser scenario generates its own local diagram, uses an explicitly named test OCR bridge, drags tee/basket/both bends with browser pointer input, checks that reanalysis preserves corrections, and verifies course distance/par/shape/rule-note persistence. This does not exercise real ML Kit or arbitrary user-photo recognition. Each added evaluated step retains a 15-second command limit; existing process, heartbeat and inactivity limits remain enabled. The local run for this release was blocked by socket EPERM, so this scenario requires GitHub verification.

## Marker drag failure and patch in 1.28.1

The supplied GitHub log reached the first tee drag and failed its movement assertion, after the earlier video/model checks passed. That log did not record the pointer target or marker coordinates, so it does not establish whether redraw/capture or coordinate targeting caused the miss.

The app now preserves each SVG handle while changing its attributes, rather than rewriting the overlay during pointerdown/move. The browser scenario cancels pending scroll animation with an instant scroll, waits two animation frames, verifies elementFromPoint at the marker center, and sends explicit mouse-button state. Movement is checked from the dot coordinates, together with identity/connection of the original handle. A native protocol touch gesture is checked too. Reanalysis and course persistence assertions remain. Failures include Caddy step, sign status, viewport coordinates, hit-tested target and recent pointer/capture events. There is no retry that converts a failed drag into a pass.

Local launch was blocked by EPERM on 2026-11-02 (run 4c987d57-ec61-4e09-a99d-fb6250a25c09). This is not a browser pass or proof that this exact GitHub failure is reproduced locally. Use the mandatory GitHub gate for the complete browser/model result.

## Video review in 1.29.0

The existing real model/decoder gates remain. Additional bounded steps reopen the saved test review in Original mode, apply Repair scrubbing through the test Android bridge, verify unchanged analysis/markers/notes and processing preference, burst several scrub inputs, wait for the final displayed source frame and save the retained data. Stub transport is not a MediaCodec test. Local socket EPERM prevented a browser pass in this environment; unit/static checks are recorded separately.

## Recorded-reference rules in 1.30.0

Seven Node regressions load model-generated landmark fixtures from the uploaded references and run production event logic. Python CPU extraction used the same Full task/version/settings; it is separate from the browser-model gate and does not validate WASM or Android decoding. No source video/images or Python dependencies are bundled. Existing real browser/model assertions remain required. The local browser run was blocked by EPERM; a successful research CPU run is never reported as a browser pass.
