# Disc catalog sources — 2026-10-21

The 301 bundled entries cover all ten requested brands. Ratings are manufacturer reference snapshots, not standardized measurements of a player’s flight. Each app card links its source and identifies a reference plastic/version when relevant. The catalog includes older models players may still own; it does not claim current stock or a complete worldwide mold list.

| Manufacturer | Entries |
| --- | ---: |
| Axiom | 17 |
| Discmania | 55 |
| Discraft | 30 |
| Dynamic Discs | 22 |
| Innova | 71 |
| Latitude 64° | 24 |
| MVP | 16 |
| Prodigy | 45 |
| Trash Panda | 5 |
| Westside Discs | 16 |

The original 50 mold IDs are retained so existing bag entries still resolve. Roc and Roc+ have distinct IDs. Personal plastic, wear, notes and distance stay in the bag records.

Prodigy uses the current model-menu ratings, including the revised rating system. The retooled Neutron Time-Lapse is listed separately in its version note from its original rating. Manufacturer references may show other plastics, runs or historical figures.

Product photos are downloaded during the GitHub asset step when a matching image is available. The source ZIP includes photo discovery, matching and validation, plus an initially empty photo index. The build records actual photo coverage and per-image source/credit in dist/disc-photos/index.json and artifacts/disc-photo-coverage.json. Missing, blocked or uncertain images stay unavailable. No generated or unrelated disc image is substituted.

## Axiom

| Mold | Speed / Glide / Turn / Fade | Reference |
| --- | --- | --- |
| [Pixel ](https://axiomdiscs.com/discs/pixel/) | 2 / 4 / 0 / 0.5 | Standard manufacturer reference |
| [Envy ](https://axiomdiscs.com/discs/envy/) | 3 / 3 / 0 / 2 | Standard manufacturer reference |
| [Proxy ](https://axiomdiscs.com/discs/proxy/) | 3 / 3 / -1 / 0.5 | Standard manufacturer reference |
| [Tempo ](https://axiomdiscs.com/discs/tempo/) | 4 / 4 / 0 / 2.5 | Standard manufacturer reference |
| [Hex ](https://axiomdiscs.com/discs/hex/) | 5 / 5 / -1 / 1 | Standard manufacturer reference |
| [Paradox ](https://axiomdiscs.com/discs/paradox/) | 5 / 4 / -4 / 0 | Standard manufacturer reference |
| [Pyro ](https://axiomdiscs.com/discs/pyro/) | 5 / 4 / 0 / 2.5 | Standard manufacturer reference |
| [Crave ](https://axiomdiscs.com/discs/crave/) | 6.5 / 5 / -1 / 1 | Standard manufacturer reference |
| [Rhythm ](https://axiomdiscs.com/discs/rhythm/) | 7 / 5 / -2 / 1 | Standard manufacturer reference |
| [Fireball ](https://axiomdiscs.com/discs/fireball/) | 9 / 3.5 / 0 / 3.5 | Standard manufacturer reference |
| [Insanity ](https://axiomdiscs.com/discs/insanity/) | 9 / 5 / -2 / 1.5 | Standard manufacturer reference |
| [Virus ](https://axiomdiscs.com/discs/virus/) | 9 / 5 / -3.5 / 1 | Standard manufacturer reference |
| [Wrath ](https://axiomdiscs.com/discs/wrath/) | 9 / 4.5 / -0.5 / 2 | Standard manufacturer reference |
| [Defy ](https://axiomdiscs.com/discs/defy/) | 11 / 5 / -1 / 3 | Standard manufacturer reference |
| [Time-Lapse ](https://axiomdiscs.com/discs/time-lapse/) | 12 / 5 / -1 / 2 | Retooled Neutron |
| [Mayhem ](https://axiomdiscs.com/discs/mayhem/) | 13 / 5 / -1.5 / 2 | Standard manufacturer reference |
| [Tenacity ](https://axiomdiscs.com/discs/tenacity/) | 13 / 5 / -2.5 / 2 | Standard manufacturer reference |

## Discmania

| Mold | Speed / Glide / Turn / Fade | Reference |
| --- | --- | --- |
| [Spore ](https://www.discmania.net/collections/discs) | 1 / 7 / 0 / 1 | Standard manufacturer reference |
| [Link ](https://www.discmania.net/collections/discs) | 2 / 3 / 0 / 1 | Standard manufacturer reference |
| [Notion ](https://www.discmania.net/collections/discs) | 2 / 3 / -1 / 0 | Standard manufacturer reference |
| [P1 ](https://www.discmania.net/collections/discs) | 2 / 3 / 0 / 0 | Standard manufacturer reference |
| [P1x ](https://www.discmania.net/collections/discs) | 2 / 3 / 0 / 0 | Standard manufacturer reference |
| [P2 ](https://www.discmania.net/collections/discs) | 2 / 3 / 0 / 1 | Standard manufacturer reference |
| [P2x ](https://www.discmania.net/collections/discs) | 2 / 2 / 0 / 2 | Standard manufacturer reference |
| [Shogun ](https://www.discmania.net/collections/discs) | 2 / 4 / 0 / 2 | Standard manufacturer reference |
| [Logic ](https://www.discmania.net/collections/discs) | 3 / 3 / 0 / 1 | Standard manufacturer reference |
| [P3x ](https://www.discmania.net/collections/discs) | 3 / 2 / 0 / 3 | Standard manufacturer reference |
| [Sensei ](https://www.discmania.net/collections/discs) | 3 / 3 / 0 / 1 | Standard manufacturer reference |
| [Drop ](https://www.discmania.net/collections/discs) | 4 / 3 / 0 / 3 | Standard manufacturer reference |
| [Maestro ](https://www.discmania.net/collections/discs) | 4 / 3 / 0 / 2 | Standard manufacturer reference |
| [P4 ](https://www.discmania.net/collections/discs) | 4 / 2 / 0 / 3 | Standard manufacturer reference |
| [Tactic ](https://www.discmania.net/collections/discs) | 4 / 2 / 0 / 3 | Standard manufacturer reference |
| [Tailor ](https://www.discmania.net/collections/discs) | 4 / 4 / 0 / 1 | Standard manufacturer reference |
| [Founder ](https://www.discmania.net/collections/discs) | 5 / 6 / -4 / 1 | Standard manufacturer reference |
| [Glacier ](https://www.discmania.net/collections/discs) | 5 / 5 / 0 / 2 | Standard manufacturer reference |
| [MD1 ](https://www.discmania.net/collections/discs) | 5 / 6 / 0 / 0 | Standard manufacturer reference |
| [MD3 ](https://www.discmania.net/collections/discs) | 5 / 5 / 0 / 1 | Standard manufacturer reference |
| [MD3x ](https://www.discmania.net/collections/discs) | 5 / 5 / 0 / 2 | Standard manufacturer reference |
| [MD4 ](https://www.discmania.net/collections/discs) | 5 / 4 / 0 / 3 | Standard manufacturer reference |
| [MD5 ](https://www.discmania.net/collections/discs) | 5 / 3 / 0 / 4 | Standard manufacturer reference |
| [Method ](https://www.discmania.net/collections/discs) | 5 / 5 / 0 / 3 | Standard manufacturer reference |
| [Mutant ](https://www.discmania.net/collections/discs) | 5 / 3 / 0 / 4 | Standard manufacturer reference |
| [Origin ](https://www.discmania.net/collections/discs) | 5 / 5 / -1 / 1 | Standard manufacturer reference |
| [Magician ](https://www.discmania.net/collections/discs) | 6 / 4 / 0 / 2 | Standard manufacturer reference |
| [FD ](https://www.discmania.net/collections/discs) | 7 / 6 / 0 / 1 | Standard manufacturer reference |
| [FD1 ](https://www.discmania.net/collections/discs) | 7 / 5 / 0 / 2 | Standard manufacturer reference |
| [FD2 ](https://www.discmania.net/collections/discs) | 7 / 4 / 0 / 2 | Standard manufacturer reference |
| [Genius ](https://www.discmania.net/collections/discs) | 7 / 5 / -4 / 1 | Standard manufacturer reference |
| [Instinct ](https://www.discmania.net/collections/discs) | 7 / 5 / 0 / 2 | Standard manufacturer reference |
| [Mermaid ](https://www.discmania.net/collections/discs) | 7 / 4 / -1 / 2 | Standard manufacturer reference |
| [Essence ](https://www.discmania.net/collections/discs) | 8 / 6 / -2 / 1 | Standard manufacturer reference |
| [Function ](https://www.discmania.net/collections/discs) | 8 / 6 / -4 / 1 | Standard manufacturer reference |
| [Rockstar ](https://www.discmania.net/collections/discs) | 8 / 5 / -2 / 1 | Standard manufacturer reference |
| [CD1 ](https://www.discmania.net/collections/discs) | 9 / 5 / -1 / 2 | Standard manufacturer reference |
| [FD3 ](https://www.discmania.net/collections/discs) | 9 / 4 / 0 / 3 | Standard manufacturer reference |
| [FD4 ](https://www.discmania.net/collections/discs) | 9 / 3 / 0 / 4 | Standard manufacturer reference |
| [Splice ](https://www.discmania.net/collections/discs) | 9 / 3 / 0 / 4 | Standard manufacturer reference |
| [Vanguard ](https://www.discmania.net/collections/discs) | 9 / 5 / 0 / 2 | Standard manufacturer reference |
| [PD ](https://www.discmania.net/collections/discs) | 10 / 4 / 0 / 3 | Standard manufacturer reference |
| [TD ](https://www.discmania.net/collections/discs) | 10 / 5 / -2 / 1 | Standard manufacturer reference |
| [DD ](https://www.discmania.net/collections/discs) | 11 / 6 / -3 / 2 | Standard manufacturer reference |
| [DD1 ](https://www.discmania.net/collections/discs) | 11 / 5 / -1 / 2 | Standard manufacturer reference |
| [Mentor ](https://www.discmania.net/collections/discs) | 11 / 5 / -2 / 2 | Standard manufacturer reference |
| [Astronaut ](https://www.discmania.net/collections/discs) | 12 / 6 / -4 / 1 | Standard manufacturer reference |
| [Cloud Breaker ](https://www.discmania.net/collections/discs) | 12 / 5 / -1 / 3 | Standard manufacturer reference |
| [DD2 ](https://www.discmania.net/collections/discs) | 12 / 5 / -1 / 2 | Standard manufacturer reference |
| [DD3 ](https://www.discmania.net/collections/discs) | 12 / 5 / -1 / 3 | Standard manufacturer reference |
| [Enigma ](https://www.discmania.net/collections/discs) | 12 / 5 / -1 / 2 | Standard manufacturer reference |
| [Paradigm ](https://www.discmania.net/collections/discs) | 12 / 6 / -1.5 / 2 | Standard manufacturer reference |
| [PD2 ](https://www.discmania.net/collections/discs) | 12 / 4 / 0 / 4 | Standard manufacturer reference |
| [DD4 ](https://www.discmania.net/collections/discs) | 13 / 5 / -1 / 3 | Standard manufacturer reference |
| [Majesty ](https://www.discmania.net/collections/discs) | 13 / 5 / -2 / 2 | Standard manufacturer reference |

## Discraft

| Mold | Speed / Glide / Turn / Fade | Reference |
| --- | --- | --- |
| [Challenger ](https://www.team.discraft.com/discs/challenger) | 2 / 3 / 0 / 2 | Standard manufacturer reference |
| [Roach ](https://www.team.discraft.com/discs/roach) | 2 / 4 / 0 / 1 | Standard manufacturer reference |
| [Luna ](https://www.team.discraft.com/discs/luna/) | 3 / 3 / 0 / 3 | Standard manufacturer reference |
| [Comet ](https://www.team.discraft.com/discs/comet/) | 4 / 5 / -2 / 1 | Standard manufacturer reference |
| [Ringer ](https://www.team.discraft.com/discs/ringer) | 4 / 4 / 0 / 2 | Standard manufacturer reference |
| [Sol ](https://www.team.discraft.com/discs/sol) | 4 / 5 / -3 / 0 | Standard manufacturer reference |
| [Zone ](https://www.team.discraft.com/discs/zone/) | 4 / 3 / 0 / 3 | Standard manufacturer reference |
| [Zone OS ](https://www.discraft.com/z-zone-os-zzoneos) | 4 / 2 / 1 / 5 | Z |
| [Buzzz ](https://www.team.discraft.com/discs/buzzz/) | 5 / 4 / -1 / 1 | Standard manufacturer reference |
| [Buzzz OS ](https://www.team.discraft.com/discs/buzzz-os) | 5 / 4 / 0 / 3 | Standard manufacturer reference |
| [Buzzz SS ](https://www.team.discraft.com/discs/buzzz-ss) | 5 / 4 / -2 / 1 | Standard manufacturer reference |
| [Malta ](https://www.team.discraft.com/discs/malta) | 5 / 4 / 1 / 3 | Standard manufacturer reference |
| [Meteor ](https://www.team.discraft.com/discs/meteor) | 5 / 5 / -3 / 1 | Standard manufacturer reference |
| [Wasp ](https://www.team.discraft.com/discs/wasp) | 5 / 3 / 0 / 2 | Standard manufacturer reference |
| [Archer ](https://www.team.discraft.com/discs/archer) | 7 / 4 / -3 / 1 | Standard manufacturer reference |
| [Cicada ](https://www.discraft.com/big-z-cicada-bzcicada) | 7 / 6 / -1 / 1 | Big Z |
| [Sting ](https://www.team.discraft.com/discs/sting) | 7 / 5 / -2 / 1 | Standard manufacturer reference |
| [Mantis ](https://www.team.discraft.com/discs/mantis) | 8 / 4 / -2 / 2 | Standard manufacturer reference |
| [Heat ](https://www.team.discraft.com/discs/heat/) | 9 / 6 / -3 / 1 | Standard manufacturer reference |
| [Raptor ](https://www.team.discraft.com/discs/raptor/) | 9 / 4 / 0 / 3 | Standard manufacturer reference |
| [Undertaker ](https://www.team.discraft.com/discs/undertaker/) | 9 / 5 / -1 / 2 | Standard manufacturer reference |
| [Avenger SS ](https://www.team.discraft.com/discs/avenger-ss) | 10 / 5 / -3 / 1 | Standard manufacturer reference |
| [Vulture ](https://www.team.discraft.com/discs/vulture) | 10 / 5 / 0 / 2 | Standard manufacturer reference |
| [Force ](https://www.team.discraft.com/discs/force) | 12 / 5 / 0 / 3 | Standard manufacturer reference |
| [Thrasher ](https://www.team.discraft.com/discs/thrasher) | 12 / 5 / -3 / 2 | Standard manufacturer reference |
| [Zeus ](https://www.team.discraft.com/discs/zeus) | 12 / 5 / -1 / 3 | Standard manufacturer reference |
| [Crank ](https://www.team.discraft.com/discs/crank) | 13 / 5 / -2 / 2 | Standard manufacturer reference |
| [Nuke ](https://www.team.discraft.com/discs/nuke) | 13 / 5 / -1 / 3 | Standard manufacturer reference |
| [Nuke OS ](https://www.team.discraft.com/discs/nuke-os) | 13 / 4 / 0 / 4 | Standard manufacturer reference |
| [Nuke SS ](https://www.team.discraft.com/discs/nuke-ss) | 13 / 5 / -3 / 3 | Standard manufacturer reference |

## Dynamic Discs

| Mold | Speed / Glide / Turn / Fade | Reference |
| --- | --- | --- |
| [EMAC Judge ](https://www.dynamicdiscs.com/products/classic-emac-judge) | 2 / 4 / 0 / 1 | Classic |
| [Judge ](https://www.dynamicdiscs.com/collections/judge) | 2 / 4 / 0 / 1 | Standard manufacturer reference |
| [Warden ](https://www.dynamicdiscs.com/products/classic-warden) | 2 / 4 / 0 / 0.5 | Classic |
| [Deputy ](https://www.dynamicdiscs.com/products/classic-deputy) | 3 / 4 / -1.5 / 0 | Classic |
| [Bounty ](https://www.dynamicdiscs.com/products/lucid-bounty) | 4 / 5 / -1.5 / 0.5 | Lucid |
| [Culprit ](https://www.dynamicdiscs.com/products/lucid-culprit) | 4 / 2 / 0 / 3.5 | Lucid |
| [EMAC Truth ](https://www.dynamicdiscs.com/collections/emac-truth) | 5 / 5 / 0 / 2 | Standard manufacturer reference |
| [Justice ](https://www.dynamicdiscs.com/products/lucid-justice) | 5 / 1 / 0.5 / 4 | Lucid |
| [Truth ](https://www.dynamicdiscs.com/products/lucid-truth) | 5 / 5 / -1 / 1 | Lucid |
| [Verdict ](https://www.dynamicdiscs.com/products/lucid-verdict) | 5 / 4 / 0 / 3.5 | Lucid |
| [Evader ](https://www.dynamicdiscs.com/products/lucid-evader) | 7 / 4 / 0 / 2.5 | Lucid |
| [Maverick ](https://www.dynamicdiscs.com/products/lucid-maverick) | 7 / 4 / -1.5 / 2 | Lucid |
| [Contender ](https://www.dynamicdiscs.com/products/lucid-contender) | 9 / 6 / -1 / 1 | Lucid |
| [Escape ](https://www.dynamicdiscs.com/products/lucid-escape) | 9 / 5 / -1 / 2 | Lucid |
| [Felon ](https://www.dynamicdiscs.com/products/lucid-felon) | 9 / 3 / 0.5 / 4 | Lucid |
| [Getaway ](https://www.dynamicdiscs.com/products/lucid-getaway) | 9 / 5 / -0.5 / 3 | Lucid |
| [Vandal ](https://www.dynamicdiscs.com/products/lucid-vandal) | 9 / 5 / -1.5 / 2 | Lucid |
| [Trespass ](https://www.dynamicdiscs.com/products/lucid-trespass) | 12 / 5 / -0.5 / 3 | Lucid |
| [Captain ](https://www.dynamicdiscs.com/products/lucid-captain) | 13 / 5 / -2 / 2 | Lucid |
| [Defender ](https://www.dynamicdiscs.com/products/lucid-defender) | 13 / 5 / 0 / 3 | Lucid |
| [Raider ](https://www.dynamicdiscs.com/products/lucid-raider) | 13 / 5 / -0.5 / 3 | Lucid |
| [Sheriff ](https://www.dynamicdiscs.com/products/lucid-sheriff) | 13 / 5 / -1 / 2 | Lucid |

## Innova

| Mold | Speed / Glide / Turn / Fade | Reference |
| --- | --- | --- |
| [Polecat ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 1 / 3 / 0 / 0 | Standard manufacturer reference |
| [Sonic ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 1 / 2 / -4 / 0 | Standard manufacturer reference |
| [Aviar ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 2 / 3 / 0 / 1 | Standard manufacturer reference |
| [JK Aviar ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 2 / 3 / 0 / 2 | Standard manufacturer reference |
| [KC Aviar ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 2 / 3 / 0 / 2 | Standard manufacturer reference |
| [Nova ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 2 / 3 / 0 / 0 | Standard manufacturer reference |
| [Rhyno ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 2 / 1 / 0 / 3 | Standard manufacturer reference |
| [RhynoX ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 2 / 1 / 0 / 4 | Standard manufacturer reference |
| [Hydra ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 3 / 3 / 0 / 2 | Standard manufacturer reference |
| [Invader ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 3 / 2 / 0 / 1 | Standard manufacturer reference |
| [Mirage ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 3 / 4 / -3 / 0 | Standard manufacturer reference |
| [Stud ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 3 / 3 / 0 / 2 | Standard manufacturer reference |
| [Sync ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 3 / 3 / 0 / 1 | Standard manufacturer reference |
| [King Cobra ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 4 / 5 / 0 / 2 | Standard manufacturer reference |
| [Mako ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 4 / 5 / 0 / 0 | Standard manufacturer reference |
| [Pig ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 4 / 1 / 0 / 3 | Standard manufacturer reference |
| [Rat ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 4 / 2 / 0 / 2 | Standard manufacturer reference |
| [Roc ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 4 / 4 / 0 / 3 | Standard manufacturer reference |
| [Roc+ ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 4 / 5 / 0 / 2 | Standard manufacturer reference |
| [Shark ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 4 / 4 / 0 / 2 | Standard manufacturer reference |
| [Stingray ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 4 / 5 / -3 / 1 | Standard manufacturer reference |
| [Fox ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 6 / -2 / 1 | Standard manufacturer reference |
| [Foxbat ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 6 / -1 / 0 | Standard manufacturer reference |
| [Gator ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 2 / 0 / 4 | Standard manufacturer reference |
| [Jay ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 4 / 0 / 1 | Standard manufacturer reference |
| [Kite ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 6 / -3 / 1 | Standard manufacturer reference |
| [Lion ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 4 / 0 / 2 | Standard manufacturer reference |
| [Mako3 ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 5 / 0 / 0 | Standard manufacturer reference |
| [Manta ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 5 / -2 / 1 | Standard manufacturer reference |
| [Panther ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 4 / -2 / 1 | Standard manufacturer reference |
| [Roc3 ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 4 / 0 / 3 | Standard manufacturer reference |
| [RocX3 ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 4 / 0 / 3.5 | Standard manufacturer reference |
| [Rollo ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 6 / -4 / 1 | Standard manufacturer reference |
| [Shark3 ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 4 / 0 / 2 | Standard manufacturer reference |
| [Skeeter ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 5 / -1 / 1 | Standard manufacturer reference |
| [Spider ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 5 / 3 / 0 / 1 | Standard manufacturer reference |
| [Gazelle ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 6 / 4 / 0 / 2 | Standard manufacturer reference |
| [Leopard ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 6 / 5 / -2 / 1 | Standard manufacturer reference |
| [Eagle ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 7 / 4 / -1 / 3 | Standard manufacturer reference |
| [Hawkeye ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 7 / 5 / -1 / 1 | Standard manufacturer reference |
| [IT ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 7 / 6 / -2 / 1 | Standard manufacturer reference |
| [Leopard3 ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 7 / 5 / -2 / 1 | Standard manufacturer reference |
| [Lynx ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 7 / 6 / -3 / 1 | Standard manufacturer reference |
| [TeeBird ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 7 / 5 / 0 / 2 | Standard manufacturer reference |
| [TL ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 7 / 5 / -1 / 1 | Standard manufacturer reference |
| [TeeBird3 ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 8 / 4 / 0 / 2 | Standard manufacturer reference |
| [TL3 ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 8 / 4 / -1 / 1 | Standard manufacturer reference |
| [Firebird ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 9 / 3 / 0 / 4 | Standard manufacturer reference |
| [FL ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 9 / 3 / 0 / 2 | Standard manufacturer reference |
| [Roadrunner ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 9 / 5 / -4 / 1 | Standard manufacturer reference |
| [Savant ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 9 / 5 / -1 / 2 | Standard manufacturer reference |
| [Sidewinder ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 9 / 5 / -3 / 1 | Standard manufacturer reference |
| [Thunderbird ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 9 / 5 / 0 / 2 | Standard manufacturer reference |
| [Valkyrie ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 9 / 4 / -2 / 2 | Standard manufacturer reference |
| [Gorgon ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 10 / 6 / -2 / 1 | Standard manufacturer reference |
| [Invictus ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 10 / 4 / 0 / 3 | Standard manufacturer reference |
| [Monarch ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 10 / 5 / -4 / 1 | Standard manufacturer reference |
| [Monster ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 10 / 3 / 0 / 5 | Standard manufacturer reference |
| [Orc ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 10 / 4 / -1 / 3 | Standard manufacturer reference |
| [Starfire ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 10 / 4 / 0 / 3 | Standard manufacturer reference |
| [Krait ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 11 / 5 / -1 / 2 | Standard manufacturer reference |
| [Mamba ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 11 / 6 / -5 / 1 | Standard manufacturer reference |
| [Max ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 11 / 3 / 0 / 5 | Standard manufacturer reference |
| [Mystere ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 11 / 6 / -2 / 2 | Standard manufacturer reference |
| [Wraith ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 11 / 5 / -1 / 3 | Standard manufacturer reference |
| [Destroyer ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 12 / 5 / -1 / 3 | Standard manufacturer reference |
| [Racer ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 12 / 6 / -1 / 2 | Standard manufacturer reference |
| [Tern ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 12 / 6 / -3 / 2 | Standard manufacturer reference |
| [Groove ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 13 / 6 / -2 / 2 | Standard manufacturer reference |
| [Katana ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 13 / 5 / -3 / 3 | Standard manufacturer reference |
| [Shryke ](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/) | 13 / 6 / -2 / 2 | Standard manufacturer reference |

## Latitude 64°

| Mold | Speed / Glide / Turn / Fade | Reference |
| --- | --- | --- |
| [Dagger ](https://latitude64.com/products/zero-medium-dagger) | 2 / 5 / 0 / 1 | Zero Medium |
| [Faith ](https://latitude64.com/products/sense-faith) | 2 / 3 / 0 / 1 | Royal Sense |
| [Keystone ](https://latitude64.com/products/zero-medium-keystone) | 2 / 5 / -1 / 1 | Zero Medium |
| [Pure ](https://latitude64.com/collections/pure) | 3 / 3 / -1 / 1 | Standard manufacturer reference |
| [Compass ](https://latitude64.com/products/opto-compass) | 5 / 5 / 0 / 1 | Opto |
| [Fuse ](https://latitude64.com/collections/fuse) | 5 / 6 / -1 / 0 | Standard manufacturer reference |
| [Trust ](https://latitude64.com/products/grand-trust) | 5 / 5 / 0 / 2 | Royal Grand |
| [Brave ](https://latitude64.com/products/grand-brave) | 7 / 6 / -1 / 2 | Royal Grand |
| [Explorer ](https://latitude64.com/collections/explorer) | 7 / 5 / 0 / 2 | Standard manufacturer reference |
| [Glory ](https://latitude64.com/products/grand-glory) | 7 / 5 / 0 / 3 | Royal Grand |
| [Maul ](https://latitude64.com/products/opto-maul) | 7 / 7 / -2 / 1 | Opto |
| [River ](https://latitude64.com/collections/river) | 7 / 7 / -1 / 1 | Standard manufacturer reference |
| [Diamond ](https://latitude64.com/products/opto-diamond) | 8 / 6 / -3 / 1 | Opto |
| [Fury ](https://latitude64.com/products/opto-fury) | 9 / 6 / -2 / 2 | Opto |
| [Jade ](https://latitude64.com/products/opto-jade) | 9 / 6 / -2 / 1 | Opto |
| [Pioneer ](https://latitude64.com/products/opto-pioneer) | 9 / 3 / 0 / 4 | Opto |
| [Saint ](https://latitude64.com/products/opto-saint) | 9 / 7 / -1 / 2 | Opto |
| [Musket ](https://latitude64.com/products/opto-musket) | 10 / 5 / -0.5 / 2 | Opto |
| [Flow ](https://latitude64.com/products/opto-flow) | 11 / 6 / -0.5 / 2 | Opto |
| [Grace ](https://latitude64.com/collections/grace) | 11 / 6 / -1 / 2 | Standard manufacturer reference |
| [Bolt ](https://latitude64.com/products/opto-bolt) | 13 / 6 / -2 / 3 | Opto |
| [Rive ](https://latitude64.com/products/grand-rive) | 13 / 5 / 0 / 3.5 | Royal Grand |
| [Strive ](https://latitude64.com/products/grand-strive) | 13 / 5 / -1 / 3 | Royal Grand |
| [Ballista Pro ](https://latitude64.com/products/opto-ballista-pro) | 14 / 4 / 0 / 3 | Opto |

## MVP

| Mold | Speed / Glide / Turn / Fade | Reference |
| --- | --- | --- |
| [Glitch ](https://mvpdiscsports.com/discs/glitch/) | 1 / 7 / 0 / 0 | Standard manufacturer reference |
| [Nomad ](https://mvpdiscsports.com/discs/nomad/) | 2 / 4 / 0 / 1.5 | Standard manufacturer reference |
| [Watt ](https://mvpdiscsports.com/discs/watt/) | 2 / 5 / -0.5 / 0.5 | Standard manufacturer reference |
| [Anode ](https://mvpdiscsports.com/discs/anode/) | 2.5 / 3 / 0 / 0.5 | Standard manufacturer reference |
| [Ion ](https://mvpdiscsports.com/discs/ion/) | 2.5 / 3 / 0 / 1.5 | Standard manufacturer reference |
| [Spin ](https://mvpdiscsports.com/discs/spin/) | 2.5 / 4 / -2 / 0 | Standard manufacturer reference |
| [Entropy ](https://mvpdiscsports.com/discs/entropy/) | 4 / 3 / 0 / 3 | Standard manufacturer reference |
| [Detour ](https://mvpdiscsports.com/discs/detour/) | 5 / 5 / -2 / 1 | Standard manufacturer reference |
| [Matrix ](https://mvpdiscsports.com/discs/matrix/) | 5 / 4 / -1 / 2 | Standard manufacturer reference |
| [Reactor ](https://mvpdiscsports.com/discs/reactor/) | 5 / 5 / -0.5 / 1.5 | Standard manufacturer reference |
| [Uplink ](https://mvpdiscsports.com/discs/uplink/) | 5 / 5 / -3 / 0.5 | Standard manufacturer reference |
| [Resistor ](https://mvpdiscsports.com/discs/resistor/) | 6.5 / 4 / 0 / 3.5 | Standard manufacturer reference |
| [Servo ](https://mvpdiscsports.com/discs/servo/) | 6.5 / 5 / -1 / 2 | Standard manufacturer reference |
| [Tesla ](https://mvpdiscsports.com/discs/tesla/) | 9 / 5 / -1 / 2 | Standard manufacturer reference |
| [Trail ](https://mvpdiscsports.com/discs/trail/) | 10 / 5 / -1 / 1 | Standard manufacturer reference |
| [Wave ](https://mvpdiscsports.com/discs/wave/) | 11 / 5 / -2 / 2 | Standard manufacturer reference |

## Prodigy

| Mold | Speed / Glide / Turn / Fade | Reference |
| --- | --- | --- |
| [Good Boy ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 3 / 5 / 0 / 2 | Standard manufacturer reference |
| [PA-1 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 3 / 3 / 0 / 2.5 | Standard manufacturer reference |
| [PA-2 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 3 / 3 / 0 / 2 | Standard manufacturer reference |
| [PA-3 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 3 / 3 / 0 / 1 | Standard manufacturer reference |
| [PA-4 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 3 / 3 / -1 / 1 | Standard manufacturer reference |
| [PA-5 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 3 / 4 / -2 / 0.5 | Standard manufacturer reference |
| [Pivot ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 3 / 4 / 0 / 0.5 | Standard manufacturer reference |
| [PX-3 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 3 / 3 / 0 / 2 | Standard manufacturer reference |
| [Rook ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 3 / 5 / -1 / 1 | Standard manufacturer reference |
| [A1 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 4 / 2 / 0 / 5 | Standard manufacturer reference |
| [A2 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 4 / 2 / 0 / 4 | Standard manufacturer reference |
| [A3 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 4 / 3 / 0 / 3 | Standard manufacturer reference |
| [A5 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 4 / 3 / 0 / 2 | Standard manufacturer reference |
| [Distortion ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 4 / 4 / 0 / 3 | Standard manufacturer reference |
| [Archive ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 5 / 5 / 0 / 2 | Standard manufacturer reference |
| [M1 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 5 / 4 / 0 / 3 | Standard manufacturer reference |
| [M2 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 5 / 4 / 0 / 2 | Standard manufacturer reference |
| [M3 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 5 / 4 / 0 / 1 | Standard manufacturer reference |
| [M4 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 5 / 5 / -1 / 1 | Standard manufacturer reference |
| [M5 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 5 / 5 / -2 / 0.5 | Standard manufacturer reference |
| [MX-1 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 5 / 3 / 0 / 4 | Standard manufacturer reference |
| [MX-2 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 5 / 4 / 0 / 3 | Standard manufacturer reference |
| [MX-3 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 5 / 4 / 0 / 1 | Standard manufacturer reference |
| [F1 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 8 / 4 / -1 / 3 | Standard manufacturer reference |
| [F2 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 8 / 4 / -1 / 2 | Standard manufacturer reference |
| [F3 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 8 / 5 / -2 / 2 | Standard manufacturer reference |
| [F5 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 8 / 6 / -2 / 1 | Standard manufacturer reference |
| [F7 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 8 / 6 / -3 / 1 | Standard manufacturer reference |
| [F9 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 8 / 6 / -4 / 0.5 | Standard manufacturer reference |
| [Feedback ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 9 / 5 / -1 / 3 | Standard manufacturer reference |
| [FX-2 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 9 / 4 / 0 / 3 | Standard manufacturer reference |
| [FX-3 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 9 / 5 / -1 / 2 | Standard manufacturer reference |
| [FX-4 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 9 / 5 / -2 / 2 | Standard manufacturer reference |
| [H1 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 10 / 4 / 0 / 3 | Standard manufacturer reference |
| [H2 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 10 / 4 / -1 / 3 | Standard manufacturer reference |
| [H3 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 10 / 5 / -1 / 1 | Standard manufacturer reference |
| [H4 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 10 / 5 / -2 / 1 | Standard manufacturer reference |
| [H5 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 10 / 5 / -3 / 1 | Standard manufacturer reference |
| [H7 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 10 / 5 / -4 / 1 | Standard manufacturer reference |
| [H6 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 11 / 5 / -3 / 1 | Standard manufacturer reference |
| [D1 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 12 / 5 / 0 / 4 | Standard manufacturer reference |
| [D2 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 12 / 5 / 0 / 3 | Standard manufacturer reference |
| [D3 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 12 / 5 / -1 / 3 | Standard manufacturer reference |
| [D4 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 12 / 5 / -2 / 2 | Standard manufacturer reference |
| [D6 ](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) | 12 / 6 / -3 / 2 | Standard manufacturer reference |

## Trash Panda

| Mold | Speed / Glide / Turn / Fade | Reference |
| --- | --- | --- |
| [Inner Core ](https://trashpandadiscgolf.com/products/100-recycled-disc-golf-set) | 2 / 4 / -0.5 / 0 | Stock Baseline / Premium |
| [Canyon ](https://trashpandadiscgolf.com/products/canyon) | 4 / 3 / 0 / 2 | Premium |
| [Dune ](https://trashpandadiscgolf.com/products/100-recycled-disc-golf-set) | 5 / 5 / -1 / 0 | Premium |
| [Ozone ](https://trashpandadiscgolf.com/products/100-recycled-disc-golf-set) | 8 / 6 / -3 / 1 | Premium |
| [Procyon ](https://trashpandadiscgolf.com/products/procyon) | 11.5 / 4 / -1 / 2 | Premium |

## Westside Discs

| Mold | Speed / Glide / Turn / Fade | Reference |
| --- | --- | --- |
| [Maiden ](https://westsidediscs.com/products/bt-medium-maiden) | 3 / 4 / 0 / 1 | BT Medium |
| [Anvil ](https://westsidediscs.com/products/vip-anvil) | 4 / 2 / 0 / 4 | VIP |
| [Gatekeeper ](https://westsidediscs.com/products/vip-gatekeeper) | 4 / 5 / 0 / 2 | VIP |
| [Harp ](https://westsidediscs.com/products/vip-harp) | 4 / 3 / 0 / 3 | VIP |
| [Bard ](https://westsidediscs.com/products/vip-bard) | 5 / 4 / 0 / 3 | VIP |
| [Tursas ](https://westsidediscs.com/products/vip-tursas) | 5 / 5 / -2 / 1 | VIP |
| [Warship ](https://westsidediscs.com/products/vip-warship) | 5 / 6 / 0 / 1 | VIP |
| [Underworld ](https://westsidediscs.com/products/vip-underworld) | 7 / 6 / -3 / 1 | VIP |
| [Bear ](https://westsidediscs.com/products/vip-bear) | 8 / 6 / -0.5 / 2.5 | VIP |
| [Stag ](https://westsidediscs.com/products/vip-stag) | 8 / 6 / -1 / 2 | VIP |
| [Ahti ](https://westsidediscs.com/products/vip-ahti) | 9 / 3 / 0 / 4 | VIP |
| [Hatchet ](https://westsidediscs.com/products/vip-hatchet) | 9 / 6 / -2 / 1 | VIP |
| [Longbowman ](https://westsidediscs.com/products/vip-longbowman) | 9 / 4 / 0 / 3 | VIP |
| [Sword ](https://westsidediscs.com/products/vip-sword) | 12 / 5 / -0.5 / 2 | VIP |
| [Destiny ](https://westsidediscs.com/products/vip-destiny) | 14 / 6 / -2 / 3 | VIP |
| [King ](https://westsidediscs.com/products/vip-king) | 14 / 5 / -1.5 / 3 | VIP |

## Manufacturer instruction added

The library now has 50 original lessons, 41 linked resources and 22 publisher/research groups. New lessons cover manufacturer rating systems, version history, lighter discs, approach choice and landing, plastic wear, recycled blends, accuracy practice and comparing a new disc with a familiar one. Product-reference sources are labeled as such and do not validate biomechanical fault thresholds.

- [Discraft · Beginning disc golf](https://www.team.discraft.com/beginning-disc-golf) — Manufacturer learning guide.
- [Discraft · What flight numbers mean](https://support.discraft.com/support/solutions/articles/44001621475-what-are-these-numbers-on-my-disc-) — Manufacturer reference.
- [Prodigy · Understanding the naming system](https://prodigydisc.com/blogs/news/prodigy-disc-naming-system) — Manufacturer reference.
- [Prodigy · Throwing lighter discs](https://prodigydisc.com/blogs/tips-tricks/how-to-throw-lightweight-disc-golf-discs) — Manufacturer instruction.
- [Prodigy · Choosing an approach disc](https://prodigydisc.com/blogs/news/finding-the-best-disc-golf-approach-disc-a-series-by-prodigy-disc) — Manufacturer instruction.
- [Prodigy · Updated flight ratings](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) — Manufacturer rating update.
- [Prodigy · PA-3 and 300 plastic reference](https://prodigydisc.com/products/prodigy-pa3-300-plastic) — Manufacturer product reference.
- [Latitude 64° · Beginner guide](https://latitude64.com/pages/disc-golf-beginner-guide) — Manufacturer learning guide.
- [Dynamic Discs · Beginner guide](https://www.dynamicdiscs.com/pages/disc-golf-beginners-guide) — Manufacturer learning guide.
- [MVP · Classroom teaching games and practice](https://mvpdiscsports.com/documents/MVP-ClassroomCollabLessonPlan.pdf) — Manufacturer teaching handbook.
- [Axiom · Flight-rating system](https://axiomdiscs.com/flight-rating-system/) — Manufacturer reference.
- [Westside Discs · Harp approach reference](https://westsidediscs.com/products/vip-harp) — Manufacturer product reference.
- [Trash Panda · Recycled blends and stock-flight comparisons](https://trashpandadiscgolf.com/products/6th-birthday-box) — Manufacturer product reference.
