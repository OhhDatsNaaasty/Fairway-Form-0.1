# Caddy field workflow and sign reading — 1.10.0

Sources checked 2026-10-23. These inform the implementation; field performance still needs real-phone and real-sign testing.

- PDGA, Disc Golf Course Design Elements: https://www.pdga.com/course-development/design-elements . Tee signs should identify hole number, length(s), direction where needed and par for the intended skill level. Multiple tees can have different paths, not just different lengths. A sign can show multiple pin positions without establishing which basket is active today. This supports preserving candidates and asking the player rather than guessing the active setup.
- PDGA, Par Guidelines: https://www.pdga.com/documents/par-guidelines . Par belongs to the hole/layout and playing conditions; it is not inferred from a disc's speed or an OCR distance alone. The setup form accepts the user's par and retains it with the course/round.
- PDGA, Tournament Central setup: https://www.pdga.com/help/tournament-central/setup . Tee, basket, OB and rule changes describe different layouts. The current local notebook stores the confirmed layout for each hole. Use separate course names for parallel full tee/basket layouts; this release is not a public course database or a full layout/scorecard service.
- Google ML Kit Text Recognition v2: https://developers.google.com/ml-kit/vision/text-recognition/v2 . OCR returns blocks and lines with bounding boxes. The Android bridge now sends normalized line boxes so labels can help orient the diagram. Recognizing the word “Basket” is not proof that a nearby symbol is today's active basket.
- Google ML Kit Android text recognition: https://developers.google.com/ml-kit/vision/text-recognition/v2/android . Uses the existing bundled Latin OCR engine. Photos remain on-device; the existing SDK telemetry disclosure remains. No external image-generation or chat API is used.
- GPS.gov accuracy: https://www.gps.gov/gps-accuracy-0 . A phone's reported horizontal accuracy is not a guarantee of foot-level precision. Tree cover, multipath and receiver conditions still matter. Faster acceptance does not create more accurate GPS.

## Faster measurement

The old capture waited at least eight seconds at each endpoint. The default now waits two seconds after a fresh accurate fix and can finish if reported accuracy is at most 8 m and readings are consistent. A one-shot stationary provider is accepted with its original uncertainty. Poor readings are not relabeled as precise; the bounded capture now stops after 15 seconds instead of 30. Acquisition and Android permission time can still add latency. Stale, invalid, moving and very uncertain fixes remain rejected. Raw location coordinates stay in memory only.

## Saved measurements and learning

Previously, Save throw retained only a draft that the disc profile did not read. Saved measurements now include a stable throw ID, the physical bag-copy ID and snapshot, actual hand/style, source and reported uncertainty. Disc profiles include that saved measurement immediately, labeled as awaiting feedback. Completing the result reuses the ID and clears the draft so the distance is counted once.

Incomplete feedback cannot establish a learned carry baseline. GPS estimates remain separately labeled from rangefinder/tape measurements, and the existing quality gates still apply before GPS affects learned range. Correcting a distance or disc preserves its identity. Ending a hole cannot silently discard its saved measurement. No missing pin distance is fabricated from the measured carry.

## Sign diagrams

Local analysis masks recognized text boxes and finds narrow connected strokes in color/darkness groups. It rejects blank images and broad filled backgrounds, traces candidate paths and simplifies them to identify straight, gentle, full and opposite-direction bends. Tee/basket label positions can orient a nearby route. Without usable labels, the lower endpoint is only a proposed tee; the player must review/swap it before applying the diagram.

This is image processing, not a trained general-purpose vision model. Trees, legends, route discontinuities, low contrast, reflections, perspective, icons without labels and multiple overlapping paths can defeat it or produce a wrong suggestion. No map scale, safe gap, current basket installation, exact carry distance or mandatory rule is inferred from a schematic. Typed/recognized explicit route text is preferred over an automatic diagram suggestion. Manual marker correction, including a second bend, remains available.

Distances require explicit units. Multiple distances and pars remain choices. Hole/par and known fields can populate the shared setup form after confirmation. Previous confirmed tee/basket labels are suggested per course, but each new hole sign asks whether the player is still using that setup. Choosing a different tee/basket is supported for alternating layouts. Remembering a label never proves which basket is actually installed.
