# Coaching audit and research — 21 October 2026

## How coaching is produced

The on-device MediaPipe models locate general human body and hand landmarks. They were not trained by this project to judge disc-golf technique. geometry.js and phases.js turn usable landmarks into camera-plane measurements and suggested event times. analysis.js applies a small set of explicit, confidence-gated review rules. Its numerical thresholds are app heuristics, not validated boundaries between correct and incorrect biomechanics.

coaching-language.js translates those findings into readable advice. knowledge.js contains original instructional notes and publisher references. Library articles are not retrieved and reasoned over during each analysis; adding a lesson does not automatically add a detector. No language-model service is called and uploaded throws are not pooled into a training database. Session video and reports stay in local device storage.

## Why earlier advice felt repetitive

The previous planner selected a focus only from attention findings, with timing, brace, posture, arm and head given priority. Many other findings only described visible movement. When no supported issue was flagged, the plan offered little beyond repeating comfortable throws. It then highlighted an unavailable body part, which often turned the plan into filming advice. Each body part had essentially one fixed drill. Most measured event information was hidden in the technical details.

Foot placement described ankle spacing at one anchor frame. It did not analyze the full crossover sequence. A switched-off fixed-camera setting prevented an automatic plant estimate and support review, but the missing-check copy could sound like the feet were hidden. These limitations explain possible mismatches; the user's particular throw still needs its original clip and exported report for diagnosis.

## Sources actually inspected in this research pass

| Resource | Access and use |
| --- | --- |
| [Brian Earhart: reachback explanation](https://discgolf.ultiworld.com/2018/05/22/tuesday-tips-dissecting-reach-back-myth-part-1/) | Read the coach-authored article. Used for backswing-room instruction and to avoid treating greater arm reach as automatically better. |
| [Danny Lindahl / Dynamic Discs: footwork](https://blog.dynamicdiscs.com/2017/07/why-is-footwork-so-important.html) | Read the article body, excluding comments. Used for compact-crossover practice; exact suggested foot dimensions were not converted to grading thresholds. |
| [Innova: illustrated X-step](https://www.innovadiscs.com/wp-content/uploads/pdf/X-Step_how-to.pdf) | Read the public PDF text. Used as a linked sequence reference. Illustrated weight placement is not measured foot pressure. |
| [Innova: distance fundamentals](https://www.innovadiscs.com/innova-news/how-to-throw-backhands-really-far/) | Read the article. Used for event-order and intended-line practice, with no universal timing target. |
| [Overthrow: building the brace](https://www.overthrowdiscgolf.academy/lessons/building-the-brace) | Read the freely published transcript. Used for an easy settled-stance practice adaptation. Locked lessons were not accessed. |
| [Overthrow: extension](https://www.overthrowdiscgolf.academy/lessons/extension-out-of-the-pocket) | Read the freely published transcript. Used for short arm-opening practice, with comfortable effort and continuation. |
| [Innova: common errors](https://www.innovadiscs.com/innova-news/common-throwing-errors-holding-back-your-game/) | Read the article. Used for shot-plane and follow-through practice. This does not establish that the app detects disc wobble or off-axis torque. |
| [Scott Stokely / PDGA: sidearm](https://www.pdga.com/news/three-keys-better-sidearm) | Read the coach-authored text. Used to keep forehand approach guidance separate from backhand footwork. |
| [Innova: forehand](https://www.innovadiscs.com/tips/how-to-throw-forehands-accurately-far-and-without-injury/) | Read the article. Used as an additional forehand reference; the app still cannot measure grip pressure or spin. |
| [UDisc / Overthrow: backhand tutorial guide](https://udisc.com/blog/post/5-great-videos-how-to-throw-backhand-in-disc-golf) | Read the co-curated written guide and its time-indexed descriptions. Verified the linked YouTube IDs and chapter offsets for footwork, arm loading and a professional comparison. |

Direct YouTube embed fetching was throttled. No claim is made to have watched the audiovisual demonstrations or obtained their full transcripts. The app labels these links as having a written outline reviewed and includes the outline link. An additional Dynamic Discs X-step page was found by search but its full fetch returned 429; it was not used as a fully reviewed source. Search-discovered course listings and forum opinions were not treated as validated biomechanics evidence.

## What changed in 1.1.5

The library has 62 lessons, 46 linked resources and 23 named publisher/coach/research groups. Twelve new lessons cover approach rhythm, crossover sequence and compactness, backswing space, event order, arm opening, support, shot plane, finish, forehand setup, outcome comparison and the scope of X-step assessment. Eighteen original Fairway Form exercises are selectable by relevant body part, shot type and stance. They are adaptations for practice, not claimed verbatim drills or endorsements from the linked coaches.

The practice plan now uses available report timestamps and exposes replay buttons. It distinguishes flagged review prompts, optional experiments based on visible movement, and general learning. Users can choose another supported focus or an alternative relevant drill. Missing body parts cannot become a selectable personal finding. An explicitly selected X-step lesson is labeled general and has no claimed video-evidence timestamps. Missing checks remain ungraded under a collapsed group. The fixed-camera setting gets a specific explanation when it blocks support assessment.

Instruction sources sometimes disagree about how to cue the turn, plant and backswing. Their cues remain attributed practice options. No new ideal angles, force claims or millisecond thresholds were adopted, and the model was not retrained. The 1.1.4 frame-stall changes remain included.

## Remaining analysis work

Complete X-step assessment needs observable crossover and contact events, a reliable intended direction, clear foot identity and ground relationship, camera suitability checks, and evaluation against independently labeled throws. A side-on ankle crossing alone cannot prove which foot passed behind the other, toe pressure, weight transfer or an effective brace. Future personalized corrections should be evaluated against experienced coaching reviews across hands, bodies, viewpoints and recording quality before being presented as reliable fault detection.

This update improves knowledge, practice variety and traceability to existing measurements. It does not establish that the current heuristics can diagnose every throwing fault. For a reported mismatch, inspect the original clip, exported JSON, phase markers, visibility and capture settings together.
