# Fairway Form 1.12.1

## Fix for “Selected disc summary missing”

The GitHub build stopped in the browser smoke check, before Gradle compiled the APK. The app catalog's model name is **TeeBird**, but the check looked for **Teebird** with a case-sensitive comparison. That incorrectly rejected a correctly rendered recommendation.

The check now derives the expected brand/model from the catalog. A shared, self-contained guard verifies that measurement and feedback select the same expected physical bag copy and that the visible summary includes its correct model and plastic. It is serialized into the real-browser test and exercised against the actual Caddy handler fixture. It still rejects missing labels, wrong plastics and mismatched copies; the check has not been removed or reduced to accepting any text.

This is a build-check correction. The catalog's canonical spelling and the Caddy recommendation rules remain intact. All 1.12.0 features remain available, including the optional build-time open-course snapshot. Its availability still depends on a successful assets-step download and is disclosed if unavailable. No private patent-review material has been added to the app/source package.

## Update from your phone

1. Replace the repository-root **Fairway-Form-Source.zip** with this version, preserving its exact filename, workflow, encrypted signing key and APP_SIGNING_PASSWORD.
2. Commit the replacement to start a new build. Re-running the old commit will still use its broken check.
3. After Actions succeeds, download and extract **Fairway-Form-APK**, then install **Fairway-Form.apk** over the current app. Do not uninstall or clear its data.

Settings should show **Version 1.12.1**. Package com.fairwayform.app, the WebView origin, signing identity and database schema 5 are preserved. Local Android versionCode fallback is 26; CI supplies its run number. Existing bags, courses, throw histories and player profiles remain compatible.

## Verification

431 automated tests pass. The course scenario verifies the selected summary against canonical catalog facts. Additional regressions execute the same serialized guard used by the browser, accept the correct catalog name after an actual recommendation, and reject absent summaries, wrong bag copies and wrong plastics.

JavaScript/import/control/offline-shell, HTML, Android XML, shell/version and serialized-browser-expression checks also pass. Full Chrome/model checks and signed Android compilation remain GitHub Actions checks; no APK was compiled locally in this workspace. The download is editable source.
