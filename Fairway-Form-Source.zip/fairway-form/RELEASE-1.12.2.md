# Fairway Form 1.12.2

Course search no longer silently ships without a course directory. The build downloads a smaller course-name directory before optional hole geometry, uses documented providers that allow project reuse, and rejects empty or unexpectedly tiny data. A valid existing dated directory is retained during provider outages. Searching remains offline on the phone.

My Courses → Find a course now shows how many courses are available and the snapshot date when opened. Search handles accents, mapped alternate names, and common 'disc golf'/'DGC' wording. Empty searches give immediate guidance. No-match messages explain actual coverage and suggest searching by park name. City searches require mapped addresses, so they cannot cover every city. An external PlanetDG link offers another way to browse the open map.

PlanetDG uses the same underlying OpenStreetMap data. We verified that source, not a separate complete course database or a documented import API. This release does not clone PlanetDG, import UDisc content or invent missing holes, distances, OB or layouts. See COURSE-SEARCH-RESEARCH-1.12.2.md for sources, licensing and download behavior.

## Update from your Android phone

1. Replace the repository-root **Fairway-Form-Source.zip** with this download, keeping the filename, workflow, encrypted signing key and APP_SIGNING_PASSWORD.
2. Commit it to trigger a fresh build. In the assets step, look for actual bundled course counts. If both providers are unavailable and no prior dated directory exists, the build now clearly fails; retry later rather than installing an empty directory.
3. After Actions succeeds, download and extract **Fairway-Form-APK** and install **Fairway-Form.apk** over the existing app. Do not uninstall or clear data.
4. Confirm **Version 1.12.2** in Settings. Open Caddy → My Courses → Find a course. Check the count/date, search a park name, preview its mapped facts, and save it. Compare a known local course; not every course or hole is mapped in OSM.

Android package com.fairwayform.app, origin, database schema 5 and signing requirements are preserved. Default local versionCode is 27; the existing GitHub workflow supplies its run number. Bags, physical-disc histories, courses, personal edits and player profiles remain compatible. Private patent-review files are excluded.

## Verification

441 automated tests pass, including provider fallback, optional geometry failures, empty/incomplete payload rejection, dated-cache retention, packaging sanity checks, aliases/accents and actual search handlers. Static syntax/import, HTML controls, offline shell, Android XML, shell and version checks pass.

Full browser/model checks, a live dataset download and signed Android compilation must run in GitHub Actions. This workspace cannot reach its configured network proxy. The downloadable file is editable source, not a locally compiled APK. No sample course fixtures are loaded by the app.
