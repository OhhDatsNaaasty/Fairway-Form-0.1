# Putting caddy and per-putter accuracy — 1.8.0

Reviewed October 22, 2026. The feature separates a player's decision to use a putting stroke from the official putting-area rule and from the fact that a disc happens to be a putter mold. It does not infer a make percentage from flight numbers, demographics, video form or a measured landing distance.

## Sources reviewed and application

- PDGA 806.01, Putting Area: https://www.pdga.com/rules/official-rules-disc-golf/80601. The rule uses 10 meters from the front of the lie to the target's base and requires demonstrating balance before advancing from a putt inside that area. Our 50-foot prompt is only an app interaction; it does not redefine the official area. Rules guidance does not assume that a step/jump release outside it is automatically legal.
- Innova, 6 Quick Putting Tips: https://www.innovadiscs.com/tips/6-quick-putting-tips/. The written article supports a small visual target, a consistent routine/follow-through and practice across useful putting situations. Its stylistic suggestions are coaching options, not universal prescriptions. The app uses an original, short routine cue and avoids a fixed aim offset for every player.
- Innova, Make More Putts with Dave Dunipace: https://www.innovadiscs.com/disc-golf-pro-tips/make-more-putts/. The page includes a written video transcription. It emphasizes a simple repeatable action, rhythm and productive practice. This was reviewed as a transcript, not as a newly watched full video. No quoted claim about an individual's likely success becomes a default user percentage.
- Discmania, Be a Better Disc Golf Putter: Practice in Reality: https://www.discmania.net/blogs/discover/be-a-better-disc-golf-putter-practice-in-reality. The written material advocates practice from actual lies with varied winds/stances/slopes and resetting between attempts. It supports keeping real context with results instead of treating sheltered repetitions as interchangeable with every on-course putt. Its training-level percentages are not used as app predictions or thresholds.
- Dynamic Discs beginner's guide: https://www.dynamicdiscs.com/pages/disc-golf-beginners-guide. The written disc-role and flight-number sections support distinguishing putting discs from drivers and treating ratings as reference information rather than exact player outcomes. A separate 2017 Dynamic practice archive surfaced in search, but its full page returned HTTP 429; no new implementation rule relies on a claimed full review of that archive.
- Existing wind guidance remains available through the caddy's manufacturer links, including https://www.innovadiscs.com/tips/tips-for-playing-disc-golf-in-the-wind/. Relative wind still comes from the existing manually confirmed or phone-compass heading. No fixed mph-to-aim or mph-to-make-percentage formula is introduced.

## UX and measurement decisions

The near-basket threshold is 50 feet in canonical units, equivalent to 15.24 meters. A positive distance at or below it prompts a Yes/No choice before planning; it does not silently relabel the shot. Explicit putting remains available above that threshold. Declining retains the chosen throwing style. After recording, the next lie gets its own distance and mode decision rather than inheriting the prior putt classification.

The new approximate-distance card and the older distance-to-basket input share one value. They are not two competing distances. Both GPS measurement views also share one controller, unit selection, permission request, capture and pending saved result. Each is labeled with the active throw number. Save binds the carry to that hole/throw; recording clears it before the next shot. Cancellation, late callbacks, unit selection and store failures retain the protections added in 1.6.0.

Putting accuracy uses starting distance to the pin. Carry from release to first landing, remaining distance after a miss and that starting distance are independent. Short-putt GPS readings are often dominated by endpoint uncertainty; they do not replace the start-distance input or silently classify a putt into a more precise band. Approximate distances are allowed and disclosed. Measured source means the user supplied a tape or appropriately accurate rangefinder distance; the app cannot certify an external measurement.

## Canonical data

A putt entry retains all existing shot, disc snapshot, condition, result and qualitative feedback fields. It adds putting.startDistanceFt, distanceMethod (estimated/measured), intent (attempt/layup/unknown) and a small provenance label. Explicit actual throw type determines whether it is a putt; a driver-like throw with a putter does not count as putting. No result is inferred from the recommendation or from a missing remaining-distance value.

The existing outcome made/missed supplies the result, so there is no separate stored outcome that can contradict it. The putting result control synchronizes with the common result control. A made putt finishes a hole; a miss continues with the entered next distance. An unrecorded result remains unrecorded. Layups stay in the profile but not the basket-attempt denominator, even if a layup unexpectedly holes out.

Legacy logs with an explicit putting type, known run intent and made/missed result may use their estimated planned starting distance, labeled as legacy evidence. Planned layups remain layups. Older auto/unknown-intent logs remain unclassified until the user confirms their intent; an unexpected actual putt from a driving plan does not inherit the drive's planned distance. Newly entered feedback always supplies an explicit putting record, including null for a deliberately missing start distance.

Putting statistics are derived from canonical throw IDs and physical bag-copy IDs. They are not stored in a second aggregate table. Duplicate/restored IDs cannot add attempts twice. Current backup validation accepts optional putting fields, validates their units/ranges/enums and supports earlier backups. Correcting actual shot type, putting distance, source or intent rebuilds the statistics. Clearing carry does not erase independent putting start distance. The feedback editor preserves the original result/hole sequence.

## User-selected accuracy bands and learning

The user chose these non-overlapping bands: (0,10], (10,20], (20,25], and (25,infinity) feet. Positive tap-ins below a foot are supported. Metric entry converts before classification; display/unit conversions preserve the 10/20/25-foot boundaries. Tiny floating-point roundoff is tolerated, not rounded into materially different bands.

Each band reports made / confirmed attempts and the descriptive percentage. A missing sample shows no percentage, while 0 made out of known attempts correctly shows 0%. Layups, missing start distances, missing results and unknown intent are separately disclosed. Pulled/slipped/misexecuted attempts still count in accuracy; excluding them would exaggerate the player's real success rate.

For recommendation evidence, attempts must also match throwing hand, distance band and comparable wind category/direction, slope and wet conditions; known temperatures must be within 8 degrees C. At least five are required before an accuracy adjustment. The bounded score uses (makes + 2) / (attempts + 4), centered on neutral and capped at eight ranking points in either direction. This is a smoothing/ranking policy, not a validated forecast probability. Preferred putter, putting comfort, wind/grip trust and risk/line heuristics remain in the choice. A new or sparsely logged putter receives no fabricated percentage. Driving carry never becomes putting comfort, and putting percentages never create throwing power.

Overall disc-profile totals remain historical and may combine contexts; Caddy labels its current-hand profiles and uses stricter matched evidence for ranking. Course practice, terrain, execution and changing conditions limit transfer to the next putt. A larger sample does not eliminate those limits.

## Validation limits

Automated tests cover denominators, empty/zero percentages, band boundaries, metric conversions, hand/condition matching, minimum sample policy, bag-only suggestions, legacy handling, drive/putt separation, sequential missed/made putts, separate start/carry/remaining distances, backup round trips and corrected feedback. Caddy integration tests exercise the actual UI module against controlled storage and capture interfaces. Browser smoke includes real DOM/IndexedDB profile corrections with simulated GPS/compass where applicable. No simulated provider is used by the production app.

Local Android hardware and full browser/model smoke are unavailable in this workspace. GitHub must compile the signed APK, followed by phone layout, GPS/compass and real on-course putting checks. This feature is a transparent field log and rule-based recommendation aid; it is not a measured biomechanical diagnosis or guaranteed caddy outcome.
