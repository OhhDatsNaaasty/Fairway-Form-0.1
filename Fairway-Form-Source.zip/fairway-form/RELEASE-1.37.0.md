# Final Form - Disc Golf 1.37.0

Hole-sign editing now keeps vertical marker gestures inside the photo. The image fits within 60% of the viewport height, with marker coordinates and hit areas matched to the displayed image, including portrait letterboxing. Scroll outside the photo to move through the page.

## Route and tree interpretation

- A new detector looks for the pale interior fairway corridor, traces its center and rejects long green-panel borders. Existing solid/dashed-line detection remains available for other diagram styles. Multiple plausible hole routes require an active-hole choice.
- Tee, basket and intermediate handles follow the proposed interior route. Explicit endpoint anchors take priority; otherwise the proposed direction still requires confirmation. Dragging a handle makes the corrected route authoritative, and rereading retains that correction.
- Compact darker-green symbols inside the printed diagram become separate tree candidates, including touching canopies where distinguishable. Outside vegetation and the sign frame are excluded by the panel detector.
- Use confirmed sign details saves the route and tree symbols with this hole. The original photo keeps priority. View 3D hole and View 3D landing open the mapped layout with the existing orbit controls, selected landing target and feature editing.
- Caddy receives the same confirmed route/tree context. Trees beside the fairway remain beside it; symbols inside the route can inform wooded-gap advice. Tree symbols do not establish OB, measured carry requirements, tree heights or ground elevation. Printed/entered distance is separate from drawing proportions. Explicit route notes can override the diagram; tee-relative geometry is not transplanted into an unlocated next lie.

## Updating

Replace the repository-root Fairway-Form-Source.zip, commit, and run the existing GitHub workflow. After every required check passes, install the signed APK over the current app without uninstalling. Version name is 1.37.0; fallback versionCode is 64, with the existing increasing CI code retained.

For an existing sign, open Read a hole sign or map, analyze it again, check the route and printed distance, and tap Use confirmed sign details. Your manual route corrections are retained on rereading. Open the photo and choose View 3D hole to review the mapped trees.

## Verification

- Full automated suite: 1,005 tests passed; zero failures, cancellations or skips. Includes 24 new route/tree/drag/model checks and one new confirmed-photo Caddy persistence check.
- Syntax checks: 119 JavaScript modules. All 409 existing static controls retained with unique IDs; 113 offline cache paths resolve.
- Original reconstructed sign fixture covers a skewed green panel, pale corridor, dotted/solid lines, dark-green tree symbols, noisy outdoor background, explicit rotated anchors, multiple routes, manual corrections, backup/restore and hole isolation. JPEG quality 60, 88 and 95 perturbations retained the interior route, with 9–10 tree candidates. The preview was generated with the production detector and 3D renderer and visually inspected. This fixture is not the user's photograph; the supplied inline screenshots were studied visually, not processed as source pixels.
- Fresh local browser run 34b6307a-352e-4f60-a96d-d2e21ad3f9b0, started 2026-11-17T04:02:33.711Z, was BLOCKED by socket permissions (EPERM) before browser checks ran. No browser checks passed locally. The required GitHub browser/model gate remains enabled and now includes an actual vertical touch gesture, page/ancestor scroll checks, image decoding, confirmed diagram persistence, mapped 3D trees and landing targets.
- APK compilation/signing and Android phone verification remain pending. Do not treat the automated fixture results as proof of recognition on every photographed sign.

Signing identity, package, WebView origin, storage identifiers, saved course/bag data, intro and video-analysis behavior are preserved. No new research sources were introduced; the existing sign-reading lesson was updated to explain the new controls and diagram model.
