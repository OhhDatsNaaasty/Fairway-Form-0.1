# Phone compass for local weather — 1.7.0

Reviewed October 22, 2026. This release removes required degree entry from the normal local-weather workflow. It adds a bounded sensor capture and an explicit aiming confirmation rather than interpreting whichever direction the phone happened to face during a location fix as the intended throw.

## Technical sources reviewed

- Android position sensors: https://developer.android.com/develop/sensors-and-location/sensors/sensors_position. Android supplies magnetic field and orientation-related sensors. Absolute rotation vectors or accelerometer/magnetometer combinations can provide a compass reference. A game rotation vector lacks the magnetic north reference and must not be used for this feature.
- SensorEvent: https://developer.android.com/reference/android/hardware/SensorEvent. Rotation-vector axes are referenced to magnetic north. An optional estimated heading accuracy is supplied in radians, with -1 meaning unavailable. Sensor status and numeric error estimates are different signals and are not silently substituted for each other.
- SensorManager: https://developer.android.com/reference/android/hardware/SensorManager. getRotationMatrixFromVector, getRotationMatrix, remapCoordinateSystem and getOrientation support orientation calculation. Remapping to display rotation is necessary when treating the top of the current screen as the aiming edge; natural sensor axes do not automatically rotate with the UI.
- GeomagneticField: https://developer.android.com/reference/android/hardware/GeomagneticField. The platform model estimates magnetic declination for a location, altitude and date. Magnetic heading plus declination gives the true-north heading needed for the meteorological wind-from comparison. This uses the phone's installed Android model and nominal altitude of zero, not a surveyed bearing or a precision calibration service.
- Existing weather basis: https://open-meteo.com/en/docs. The app requests model wind direction and explicitly requests mph. Its existing relativeWind function compares the wind-from bearing to a true-north throw bearing and retains both head/tail and crosswind components. Forecast grid wind can differ from wind at the tee or basket.

Documentation was reviewed; no manufacturer's phone sensor accuracy or real course direction was validated in this cloud workspace.

## Native implementation

PhoneCompass.java prefers TYPE_ROTATION_VECTOR, then TYPE_GEOMAGNETIC_ROTATION_VECTOR. If unavailable, it combines accelerometer and magnetic-field readings. It does not use TYPE_GAME_ROTATION_VECTOR, deprecated orientation sensors, camera pose, a GPS course-over-ground value, or an uncorrected browser alpha angle.

The native helper runs on the activity's foreground main looper at SENSOR_DELAY_UI and publishes about five updates per second. It rejects old sensor events, remaps the rotation matrix for display rotations 0/90/180/270, reads azimuth, adds GeomagneticField declination, and normalizes to [0,360). The screen-up normal must stay within 40 degrees of vertical so the user is aiming with a reasonably flat, face-up screen. Accelerometer/magnetometer fallback requires sufficiently recent paired observations, a plausible gravity magnitude and a valid rotation matrix; it keeps the magnetometer's status.

The bridge passes corrected heading, trueNorth flag, sensor status, optional numeric error estimate, level flag, display rotation and timestamp. Raw coordinates are used to calculate declination and are not included in sensor events. Native pause/destroy unregister sensors. A native timeout also unregisters if the WebView cannot clean up. Request IDs keep a delayed Stop from cancelling a newer compass stream.

## JavaScript acceptance and interaction

Local weather's explicit request still obtains coarse location and fetches its rounded forecast grid. Successful weather loading opens the aiming dialog if Caddy is foreground and the same hole/throw remains active. An explicit compass button can re-open it while weather/location context is fresh. No new location permission is required for the magnetometer.

The app accepts only corrected headings with medium/high sensor status, acceptable tilt, valid heading/timestamp, and an estimated numeric heading error no greater than 20 degrees when supplied. A missing numeric estimate stays unknown; medium/high status alone does not invent a degree accuracy. Low quality clears the candidate window and displays calibration guidance. Screen rotation also clears the previous window.

Within a 2.5-second window, at least eight updates spanning 1.5 seconds must stay within eight degrees of their circular mean. These are app settling thresholds, not proof of physical accuracy. A cached heading expires after 1.5 seconds without updates. Invalid or repeated timestamps cannot manufacture settling. The UI previews the relative wind but applies nothing until the user chooses Use this direction & apply wind. That action checks freshness/context again, writes the heading, applies existing weather-to-relative-wind logic and stops sensors. Cancel preserves previous settings. A 30-second JavaScript deadline and 35-second native backstop bound unattended sensing.

Changing holes, leaving Caddy, backgrounding, native pause and recording a throw stop capture. Late weather results are operation/context-checked before opening a dialog. A stale dialog-close event cannot cancel a newly reopened capture. Recording clears the heading in the next draft; a caddy must re-aim when the line changes. Manual entry stays available on Android without suitable hardware and in browser builds, where this release intentionally does not assume an absolute orientation event has already been corrected to true north.

## Persistence, privacy and limits

Only the selected bearing and resulting wind controls enter the caddy draft. Raw weather coordinates stay in an in-memory context, cleared on hole switch or page unload, and are not stored in hole logs or disc profiles. The weather request still transmits rounded coordinates to Open-Meteo with the existing explanation. Compass correction is local; no heading lookup service, new SDK, background permission or continuous navigation track is introduced. A bag backup contains no compass coordinates.

A stationary GPS fix cannot tell where a person intends to throw. Walking course-over-ground is a different quantity, so a brief aim/confirm step remains necessary. Metal baskets, cars, cases, phone calibration, screen tilt, sensor quality and the Android magnetic model can bias even apparently steady headings. Field wind remains variable. This feature improves convenience and consistency of the weather comparison; it does not make a guaranteed aerodynamic prediction or a precision compass claim.

## Verification

Tests cover circular north wrap, settling versus turning, stale/duplicate/future callbacks, request correlation, missing bridge/hardware, calibration guidance, status/error gates, tilt and rotation resets, timeout/cancel cleanup, relative-wind signs, automatic aiming after weather, explicit apply, saved bearing, late weather responses, no saved coordinates and per-throw reset. Browser smoke uses explicit simulated weather/sensor providers. Static native checks cover sensor selection, declination, remapping and lifecycle wiring. Android compilation belongs to the existing signed GitHub workflow; physical hardware/portrait/landscape/calibration behavior requires phone testing.
