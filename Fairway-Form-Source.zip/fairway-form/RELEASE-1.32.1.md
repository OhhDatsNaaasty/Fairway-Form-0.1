# Final Form - Disc Golf 1.32.1

The reported notes describe a slight right turn after about 350 feet, followed by about 125 feet to a slightly downhill basket, with wooded edges and a mostly clear interior. The old parser missed “turns slightly right after about 350 feet,” then treated “the right bend” as a conflicting second direction. It also treated wooded surroundings as a tight wooded throwing line. These cases now retain one gentle right bend, its approach distance, the separate basket section and its downhill context.

Supported before/after phrases, reference nouns and metric quantities are interpreted separately. Repeated same-side references preserve the earlier slight modifier. Explicit opposing directions still produce an actionable conflict. Tree/water offsets do not become the bend distance or distance to the basket. Original notes and entered basket distance remain unchanged.

The hole picture and landing picture share route geometry. Given the two stated section lengths, their drawn lengths have the same ratio, and the bend receives the corresponding distance coordinate. Slight turns remain gentler than full doglegs. Expanded sketches label the bend and the section beyond it. Notes-derived route scale is distinct from the entered basket distance; no actual carry or remaining distance is inferred from this sketch.

Before a known distant bend, Caddy evaluates the straight first section rather than giving the short bend-matching forehand an automatic line advantage. It retains controlled power and required-carry/hazard margins. A clear interior can favor useful progress while explicit tight/narrow selections still count. A downhill section beyond the bend does not penalize a level placement before it. Distance cautions refer to the selected landing target and throw style rather than comparing the entire hole with an unrelated reference. The landing description states where the bend is and how far beyond it the basket is, using the provided notes.

## Verification

All 853 automated tests passed, with no failures, skips or cancellations. Twenty-three new route/parser/geometry regressions and one actual Caddy UI regression exercise the exact reported notes, common phrases, repeated references, metric quantities, conflicting routes, landmark offsets, wooded-edge distinctions, first-section ranking, slope scope, shared geometry, segment ratios, changed lengths and later-lie isolation. Existing water-carry, shot selection, profile, history, analysis and native tests remain in the suite.

All 409 static control IDs remain unique and retained. Syntax checks cover 114 runtime/script files and all 106 offline paths exist. ZIP integrity and file-by-file equality with the workspace are checked. The standalone bend-sketch.png beside the ZIP was rendered directly from the updated production SVG renderer with the reported notes and inspected visually; it is a renderer preview, not a WebView screenshot.

The mandatory GitHub browser gate now reproduces the exact notes through the Caddy UI, compares both route paths, checks the first placement and verifies expanded distance labels. Fresh local browser run e49f6baa-be9d-4aba-83b2-714cbfd807f9 was blocked immediately by socket EPERM before Chrome started. No local browser, APK compilation/signing or physical-phone pass is claimed. Required GitHub gates remain enabled.

No new disc-golf research or instructional sources were introduced. The existing registered placement, approach and flight sources remain linked. The throw analyzer, video decoder, Android package/origin, signing workflow, database/schema and approved intro are unchanged.

## Update

Replace repository-root Fairway-Form-Source.zip and run the existing workflow. Once every required gate passes, install its signed APK over the current app without uninstalling. Retain the signing identity. Version name is 1.32.1; fallback versionCode is 58, with CI retaining its increasing code.
