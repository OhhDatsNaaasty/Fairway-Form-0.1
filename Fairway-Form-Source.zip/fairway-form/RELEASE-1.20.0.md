# Final Form - Disc Golf 1.20.0 — Research, layout notes and better landing decisions

## What changed

Layout notes were saved with courses but never passed into the recommendation engine. They now enter the plan and the saved throw snapshot. Common English constraints are interpreted locally, with a visible **How I read your notes** explanation. Unknown wording and conflicting directions are disclosed rather than treated as understood.

Caddy now considers a landing objective before ranking a disc and power:

- Water/OB beyond the basket changes a reachable basket attempt to a controlled shorter placement, allowing for carry variation and ground play. Normal planning avoids firm effort in this situation, including headwind/uphill demand. A hazard far beyond the current stage does not force a short putter on a long open hole.
- Forehand is one option, not a command attached to a dogleg. Notes can describe a blocked style, an open straight route, a wider preferred backhand route or a known first corner. A familiar positioning shot can be better than a weak throw matching the bend.
- Required carries remain distinct from space beyond the basket. Automatic targets cannot be shortened into an acknowledged crossing. Unclear carry distances require a clearer report or an explicitly chosen dry landing point.
- Low ceilings, hard ground, soft-landing requests and green slopes influence release/ground-play risk. The planner does not calculate a skip distance or certify obstacle clearance.
- Suggested power remains a broad effort cue using the chosen target and individual disc/style references. Source information does not become fabricated release speed, spin, nose angle or a predicted make percentage.

Flat/hyzer/anhyzer planning, separate hand/style histories and the Advanced/Pro restriction for complex shots are retained. Actual carry, actual effort, distance remaining and suggested targets remain separate.

## Notes examples and clear buttons

Examples:

- Water 20 ft behind basket. Hard ground. Avoid skip.
- Straight for 200 ft then dogleg right. Forehand blocked.
- Wide backhand line open. Low ceiling.
- Must carry 180 ft over water.

Distances need explicit feet or meters; common feet shorthand is supported. Notes can override a conflicting selected shape when the description is unambiguous, with a warning explaining the choice. They add hazards conservatively and do not silently erase selected trouble. They do not rewrite the dropdown or claim a measured map.

**Clear layout notes** empties that field, invalidates the old plan and uses the existing save path. On the tee it updates that saved course hole. On later throws it updates the round's current lie, preserving the saved tee layout. **Clear throw notes** empties only the current feedback text, leaving distances and earlier throw notes intact.

Tee route distances and blocked styles are not blindly reused as current-lie facts after advancing. Editing notes for the new lie activates them there; explicit “from here” wording also applies to that lie. Trouble beyond the basket remains relevant. Review recognized wording before following a recommendation.

## Research database

Fourteen reviewed reference records are bundled in `dist/lib/caddy-research.js`, including peer-reviewed flight research, TechDisc release-metric documentation, manufacturer flight/wind/approach guidance and authored course-management instruction. Each includes a URL, publisher, review scope, original summary, applied topics and limitations. One paper was reviewed through its institutional abstract and is labeled accordingly.

Seven new lessons appear under **Technique library → Caddy strategy**, bringing the library to 81 lessons. Caddy's source list links the same records. Summaries and lessons are available offline; opening the original websites needs internet. Existing sources remain. CADDY-STRATEGY-NOTES.md lists the reviewed references and distinguishes evidence from app-specific margins.

This is research-informed planning with explicit heuristic margins, not a calibrated aerodynamic simulator. The app lacks measured coefficients, geometry and release conditions for every bag disc; it cannot recover them from four flight numbers or ordinary notes.

## Validation

**598 JavaScript tests passed, with zero failures.** This includes sixteen notes-parser tests, eighteen strategy/research tests and six new UI regressions, alongside the existing suite. Tests cover negation, units, conflicts, current-lie scope, water carries, long-hazard power limits, alternative routes, ground context, source/lesson availability, saved-course note clearing, feedback isolation, markup escaping and history backup retention.

Static checks verify syntax/imports, unique/referenced controls, offline shell assets, XML/shell, versions and identity/schema compatibility. Native runtime and the approved intro are unchanged from 1.19.0.

**The new real-browser flow was added to the required GitHub smoke gate but could not be run locally.** The session denied localhost socket access; Chromium also failed its socket setup in a file-based attempt. The permission-enabled local test command was interrupted before execution. These are verification limits, not passing browser results. The GitHub gate still runs the actual interface/model checks and now checks notes interpretation, safe targets, clear/reload persistence, alternate routes, feedback and the research library.

No signed APK was built locally: the environment has no Android SDK/signing key. Use the GitHub build, then test on the phone before considering release to other testers.

## Phone update

Replace and commit repository-root **Fairway-Form-Source.zip**, preserving the working workflow and signing credentials. After Actions succeeds, download **Fairway-Form-APK**, extract **Fairway-Form.apk**, and install over your current app. Do not uninstall first.

Version is 1.20.0; fallback versionCode 38. CI retains its increasing run-based code. Package `com.fairwayform.app`, WebView origin, database schema 5, signing identity, backup kinds, movie and build filenames are unchanged.

On the phone, compare the same lie with/without “water just past basket”; check a blocked forehand and a known corner; clear notes and reopen the course; record a throw with cleared feedback text; try a required water carry; and confirm the research lessons appear. Check how the note interpretation matches the real hole before throwing.
