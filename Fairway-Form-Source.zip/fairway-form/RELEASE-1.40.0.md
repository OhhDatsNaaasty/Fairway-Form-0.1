# Final Form - Disc Golf 1.40.0

Confirmed marked landings now help the disc profile at one-fifth the weight of measured throws. Android throw measurement also uses a foreground GNSS session and a fresh stationary sample cluster instead of accepting a single good-looking fix after two seconds.

## Distance learning

- Computes approximate horizontal start-to-finish distance from a known starting lie and confirmed landing on the same sketch. It does not subtract distance remaining or copy a suggested landing. Unknown later starting positions supply no distance estimate.
- Shows measured averages, GPS results and marked-landings separately, with a weighted reference for planning. Matching conditions remain relevant; mixed-condition fallback is labeled.
- Keeps stronger observations in their own recent window and caps total approximate influence when stronger evidence exists. An estimate cannot become a measured record or a measured farthest throw. A real measurement and a sketch in one throw contribute once.
- Compatible marked rounds from 1.39.0 can contribute without rewriting their saved data. Clearing an estimate removes its evidence. Corrections and history backups preserve source information. Tree hits, bad execution, rollers and unfinished feedback remain excluded from normal range learning.

The relative weights are policy, not statistical confidence. See MEASUREMENT-RESEARCH-2026-11-17.md for the full table and rationale.

## GPS capture

- Uses Android's GNSS provider while the app is in the foreground. One bounded session spans Start, the walk and Stop. It requests fresh updates and uses monotonic fix age, duplicate rejection and mock-location checks. The screen stays awake during this session.
- Requires at least six fresh fixes spanning eight seconds, checks stationary drift and scatter, and rejects isolated position jumps. Reported accuracy is not reduced by assuming samples are independent.
- Aims for a combined reported uncertainty of ten feet. A stable reading that remains above the target is labeled accordingly; sufficiently large relative uncertainty still blocks Save. Retry landing keeps the throwing spot for another end capture.
- Stops the receiver when a usable result is ready, on cancellation, when paused, or after ten minutes. Raw geographic endpoints remain in memory only; saved records retain distance, reported uncertainty and aggregate diagnostics.
- Browsers retain a high-accuracy geolocation fallback. Camera walking remains a separate estimate and is not promoted into normal range evidence.

Actual accuracy within ten feet is not established by these changes. GPS hardware, sky visibility and shared position bias still matter. The new guide explains how to compare the phone with independently known baselines. Six official references and two practical lessons are available in the library; Check measurement accuracy opens the field-check lesson.

## Verification

- Full automated suite: 1,075 passed; zero failures, cancellations or skips. New tests cover evidence weights, influence caps and sample windows, legacy marked rounds, corrections/backups, noisy and drifting clusters, date-line handling, native bridge lifecycle and retrying a landing.
- Native host checks: startup 12, camera 19, video 13 and new location rules 14, all passed. The Android location rules are compiled and exercised on the host; this is not an Android sensor test.
- Syntax: 122 application/build JavaScript modules. All 411 previous static controls retained; 412 IDs are unique. All 116 offline shell paths resolve.
- Fresh local browser run 6315408f-0c11-40ac-953c-5b6b74aae755, started 2026-11-17T05:05:12.331Z, was BLOCKED by workspace socket permissions before browser checks ran. No local browser tests passed. The mandatory GitHub browser/model gate remains enabled and includes the warm receiver workflow, diagnostics, profile display and lesson link. The new native rules gate also runs before Android compilation.
- APK compilation/signing, Android integration and physical accuracy validation remain pending. The included research describes both implemented changes and alternatives that were assessed but not implemented.

Signing identity, package, WebView origin, stored course/bag data, intro, video analysis, 3D layout, marked-lie planning and smooth orbit behavior are preserved. No new background-location permission, cloud positioning service or route-upload feature was introduced.

## Updating

Replace repository-root Fairway-Form-Source.zip, commit, and run the existing GitHub workflow. After all required checks pass, install the signed APK over the current app without uninstalling. Version name is 1.40.0; fallback versionCode is 67 and CI retains its increasing code. Open a disc's profile to see marked estimates, or use Start / Stop with the phone held still for the new GPS capture. Use the measurement guide to check the ten-foot goal against a known distance.
