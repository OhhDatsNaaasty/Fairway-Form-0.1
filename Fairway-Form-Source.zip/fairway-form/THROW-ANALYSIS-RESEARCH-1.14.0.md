# Throw-analysis audit and first engine upgrade

Reviewed October 28, 2026. The user reports that coaching is too general and the app misses/misidentifies parts of a throw, primarily filmed side-on. This release changes the analysis pipeline and evidence handling, not only the wording. It remains an on-device pose-and-rules system, with no external generative-video service or newly trained disc detector.

## Findings in the previous implementation

- The body model used MediaPipe IMAGE mode independently at every sampled time. Its tracking-confidence option did not enable a chronological video tracker in that mode.
- The automatic release anchor was the peak of smoothed wrist speed relative to the throwing shoulder. It did not detect disc/finger separation. Another gesture elsewhere in the clip could supply that peak.
- There was no review-window control to exclude setup gestures or another throw. All clip frames could compete for the movement cue.
- Marked phase events could use a clear pose up to 0.12 seconds away when the desired pose was hidden. That could move a fast event enough to change timing interpretation.
- Tapping a phase chip replayed the event but did not select that event in the manual marker menu. The next Set marker could therefore apply the wrong event name.
- Several distinct causes of a brace or timing prompt shared the same short coaching text. Automatic practice selection prioritized an available crossover ahead of some more clearly anchored observations.

These are confirmed code paths. Without the user's original clips and agreed event labels, they do not prove the reason for every specific incorrect result they observed.

## Implemented in 1.14.0

Each uploaded-video body pass creates a fresh VIDEO-mode PoseLandmarker and feeds monotonically increasing, decoded source-video timestamps to detectForVideo. The detector is disposed before any backward hand close-up, and on cancellation or decoding failure. Its tracker state is not reused by another clip or by live IMAGE-mode preview. Hand review reuses a tracked pose only when both passes verify the same decoded frame time. Approximate timestamps still trigger body detection on the actual revisited pixels. This protects the earlier decoder/end-of-clip recovery behavior and avoids replacing verified tracked body observations with independent detections unnecessarily.

A new optional review window lets the player pause and set Start/End around the actual approach and finish. It leaves the original file intact and retains original video timestamps. Selecting a new window invalidates the previous analysis and removes markers outside that window. The range is saved with the session and exported review. Default behavior remains the whole clip; this is user-directed scoping, not an automatic throw classifier.

Before scoring, an isolated limb observation is excluded only when it jumps far from both nearby observations, returns near the previous position, and implies an implausibly long visible limb relative to the torso. No missing point or source frame is generated. The raw observations remain in session data; reports record how many points were excluded. This conservative filter does not fix every occlusion, body swap or blur error and is not a calibrated confidence estimate.

Marker matching now uses approximately half the observed sample spacing with a small timestamp allowance, capped at 0.05 seconds. A marked release without a nearby usable arm cannot borrow a much later pose for coaching. Tapping a suggested phase also selects that phase's marker menu entry. It still takes a deliberate Set marker action to confirm it; suggestions are never silently upgraded into user-confirmed events.

Coaching for timing, backswing timing, arm opening and brace prompts changes with the available phases and measurements. For example, continued hip movement and increased front-knee bending receive different explanations and practice cues. Short and expanded coaching share that contextual wording. Estimated markers remain conditional. Missing observations cannot create a personalized statement. Forehand/specialty handling remains separate. In automatic practice selection, clearly marked video evidence is preferred to a less-specific estimated crossover; explicit user focus choices remain available. This is deterministic, evidence-linked language, not a cloud AI coach.

## Research and what it supports

MediaPipe's official JavaScript guide distinguishes IMAGE and VIDEO modes and describes detectForVideo, tracking options, and synchronous inference. It also distinguishes image and model-estimated world landmarks. VIDEO mode is appropriate for ordered input, but does not by itself validate disc-golf biomechanics or guarantee correct joint identities. The current app still uses two pose slots to reject ambiguous multi-person detections. It does not claim expert-level skeletal reconstruction or universal smoothing of occluded limbs.

https://ai.google.dev/edge/mediapipe/solutions/vision/pose_landmarker/web_js
https://ai.google.dev/edge/mediapipe/solutions/vision/pose_landmarker
https://github.com/google-ai-edge/mediapipe

Disc-golf-specific research remains limited. The 2025 University of Jyväskylä work on lead-leg forces and knee kinematics is an example of measurements requiring lab equipment in addition to kinematics. Its existence does not validate this app's heuristic thresholds or let a single camera measure forces.

https://www.finna.fi/Record/jyx.123456789_102903?lng=en-gb

No new universal ideal elbow angle, plant delay, hip/shoulder separation target, force estimate, grip-pressure measurement or spin estimate has been introduced. Upscaling/generated intermediate frames cannot verify details missing from the original footage. Original high-frame-rate, unblurred video can preserve useful information; requesting more analysis samples than distinct source frames cannot create it. Clip timing follows file playback; an edited slow-motion export can stretch intervals without changing event order.

## Accuracy work still needed

Automatic release remains a wrist-motion suggestion. Reliable automatic disc separation needs disc/hand observations and a validated event model. X-step recognition remains a conservative side-view heuristic, not a trained disc-golf phase classifier. Single-view depth, torso rotation and contact estimates remain uncertain.

The next substantial validation step is a private, authorized set of real throws with independently marked crossover, reachback, foot contact, arm loading, disc separation and finish, plus expert-reviewed actionable observations. Compare old/new event error, missing-event rate, false correction rate and coach agreement on held-out players and recording conditions. An automatic model should be assessed separately for right/left hands, backhand/forehand, standstill/walk-up, blur and occlusion. Existing synthetic and no-person smoke tests verify software behavior; they cannot establish coaching accuracy on real golfers.

A later online vision/language coach could explain selected evidence more flexibly, with explicit video-sharing consent, protected server credentials and cost controls. It should receive verified event frames and uncertainty, rather than be allowed to invent measurements. No such service or video upload is added in this release.

## Validation scope

Unit tests exercise the actual ordered detector adapter, cleanup on success/failure/cancel, scoped timestamps, verified-versus-approximate hand-frame matching, spike rejection, marker distance, phase menu selection, contextual coaching and practice prioritization. Existing body, X-step, decoder, saved-session, Caddy and camera-range checks remain in the full suite. CI's real model/no-person video path now verifies VIDEO-mode analysis and saved range/frame provenance. Full browser/model and signed APK checks run in GitHub Actions; this workspace has no usable Android SDK or physical test footage, and its configured network proxy is unreachable. No measured improvement percentage or local APK build is claimed.
