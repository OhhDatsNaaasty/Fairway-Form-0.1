# GPS throw measurement — research and implementation, 1.6.0

Reviewed October 22, 2026. This release measures the horizontal displacement between release and first landing. It does not measure flight speed, total flight path, elevation-adjusted carry, or distance left to the basket.

## Sources and implications

- GPS.gov, GPS Accuracy: https://www.gps.gov/gps-accuracy-0 and https://www.gps.gov/gps-accuracy. Smartphone accuracy is commonly described as roughly a 4.9-meter radius under open sky and worsens around obstructions/reflections. More capable receivers and augmentation can achieve much better results; software on an unspecified phone cannot promise survey-grade or 1–2 foot accuracy. Receiver output and real-world comparisons take precedence over the number of digits displayed.
- Android, Request location permissions at runtime: https://developer.android.com/develop/sensors-and-location/location/permissions/runtime. Android 12+ distinguishes approximate and precise foreground permission. Request fine and coarse together, including when upgrading an existing approximate grant. The user can refuse precise access. The implementation checks the resulting fine permission rather than assuming the first permission result grants everything.
- Android Location.getAccuracy(): https://developer.android.com/reference/android/location/Location#getAccuracy(). The native Android accuracy radius is estimated horizontal accuracy at the 68th percentile. This does not prove that a reading is within its radius on every attempt.
- W3C Geolocation: https://www.w3.org/TR/geolocation/. The browser interface provides latitude/longitude, timestamp, accuracy and watch cancellation. High accuracy is a request, not a guarantee, and the location source is provider-dependent. The web API specifies a 95% accuracy radius, unlike the native Android API's stated convention. We therefore display **reported accuracy** without claiming a uniform confidence level across WebView implementations. A sum of endpoint radii is an uncertainty indicator, not a guaranteed two-point confidence interval.

These pages were read as technical documentation. They do not validate this app's readings or supply a model capable of converting ordinary phone hardware into an RTK receiver.

## Selection and geodesy

1. On explicit Start/Stop, request enableHighAccuracy with maximumAge: 0. Android first upgrades precise foreground permission through a correlated asynchronous bridge callback. Weather retains its separate coarse-permission request. Permission denial, request timeout and provider failures give usable instructions; manual distance remains available.
2. Reject invalid coordinates, missing/nonpositive accuracy, old/future timestamps and duplicate sample timestamps. Ignore moving fixes above 0.8 m/s and restart settling after reported movement. This speed is a practical guard, not proof that the phone is stationary.
3. After an eight-second settling window, a stable recent fix reporting at most 8 meters can finish. At the 30-second deadline, a recent stable fix up to 25 meters can be retained with its full uncertainty. Poor or stale fixes time out. Significant position spread prevents early completion. A provider that emits only one stationary fix can still finish after settling; the displayed sample count is literal, not a claim of independent observations.
4. Choose the best-accuracy fix from the last ten seconds. Do not silently average correlated readings or shrink their accuracy as 1/sqrt(N). The provider's accuracy estimate remains unchanged. This reduces obvious stale/poor captures but cannot remove multipath or common bias.
5. Compute distance using the Vincenty inverse solution on the WGS84 ellipsoid (a=6378137 m, f=1/298.257223563). Tests cover equatorial and meridional reference baselines, date-line crossing, invalid points and implausible throw lengths. Ellipsoidal math avoids spherical scale error; sensor uncertainty remains much larger in ordinary use. Convert meters to feet using exactly 0.3048 m/ft.
6. Sum the endpoint reported radii for a disclosed uncertainty indicator. A distance smaller than this indicator gets an explicit unresolved/short-throw warning. A result below one foot or over 1,500 feet is rejected by the existing carry-log limits. No altitude is used.

No continuous route is accumulated. Location watches and timers end after each endpoint, cancellation, error or pause. No background service or extra mapping dependency is required. Unfinished endpoint coordinates exist only in memory. Successful Save retains only carry, source, endpoint accuracy values, combined uncertainty and sample counts in a per-hole pendingMeasurement. Raw coordinates do not enter canonical throw logs, disc profiles or backups.

## Saved feedback and learning

Save throw binds its draft to the current hole and throw number, independently of basket distance. It survives recommendation refresh, unit changes, navigation and a restart after a successful save. Switching holes cannot attach a late result to a different lie. A failed storage write leaves the result available to retry. Recording feedback saves the canonical throw before advancing and clears the pending draft.

The source is gps, not measured. The validator allows only known numeric accuracy/sample fields and strips coordinates or extra metadata. A manually edited GPS value becomes estimated; an unchanged GPS value can retain provenance while shot feedback is corrected. Clearing or selecting a manual source clears GPS metadata. Bag-history export/restore validates and preserves the GPS source. Older application versions cannot be assumed to import new GPS source values.

Measured average/farthest, estimated average/farthest and GPS average/farthest stay distinct. For learning only, a GPS row must have reported combined uncertainty <=10 m and <=10% of the logged distance. This deliberately conservative policy excludes most short-shot GPS guesses. Eligible GPS and measured rows can establish a range only after at least three comparable clear, controlled throws; the source description discloses mixed GPS evidence. Existing angle/hand/style/effort/wind/slope/temperature/obstruction/execution rules still apply. A maximum remains a milestone, not routine carry. Reported accuracy is imperfect, so the learned range is still a field estimate.

## Alternatives

A measuring tape or calibrated measuring wheel can establish a known baseline with much finer resolution than typical phone GPS. A laser rangefinder can work when both endpoints are visible, but its stated accuracy matters; many sports units quote yard-level rather than foot-level accuracy. Survey-grade dual-frequency GNSS with augmentation/RTK needs appropriate receiver/correction hardware. This release does not advertise an unsupported RTK, Bluetooth rangefinder or camera-based surveying integration. Native phone dual-frequency capability may improve the provider's fix on supported devices but is not an app-level accuracy guarantee.

## Validation limits

Automated tests verify algorithms, fresh-fix and cancellation rules, permission-event handling, data provenance, range eligibility, UI integration, unit conversion and persistence races against controlled data. Browser smoke code uses an explicit simulated provider. Static manifest checks verify fine/coarse permission wiring and the absence of background location permission. Neither validates actual Android location hardware. A successful signed CI build and outdoor device comparisons are necessary before release to the app store or any measured-accuracy claim.
