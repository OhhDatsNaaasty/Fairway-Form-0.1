# Final Form - Disc Golf 1.41.0

## Caddy layout

The hole map now spans the main Caddy content width. Its title, description and edit link sit below the render. Par sits alongside the hole number in the same 30 px serif type. The distance retains its existing 78 px size. The whole-hole map also stays visible for subsequent lies. The page keeps the forest/gold palette and its existing features.

The main map rotates at eight degrees per second while visible, with no rotation toolbar on the main page. Tapping it opens the existing enlarged viewer and controls. Main-map animation uses retained SVG nodes, pauses behind scene/setup sheets, while offscreen, when hidden and away from Caddy, and respects reduced-motion settings. The explicit Full circle control retains its single-turn behavior in the viewer. Tee pads use a light cement gray.

## Zoom and landing placement

The enlarged 3D viewer and landing picker support a 1×–4× pinch zoom. A two-finger gesture with moving midpoint pans the crop. Terrain coordinates, notes and saved marker coordinates are unchanged. The screen crop is inverted before the ground-intersection calculation, including on hills and after rotation. One-finger placement waits for a drag or tap release; beginning a pinch restores any pending one-finger marker drag and suppresses placement until both fingers lift. Cancelling a touch cannot commit a landing. Behind tee restores angle and full view; keyboard +/−/0 provide a non-touch zoom path.

Zooming does not turn a marked landing into a measured throw. Existing lower-weight distance learning, confirmed sign layouts, next-lie geometry, GPS handling and the Practice saved-round refresh remain intact.

## Preview and validation

The conversation preview is a mockup of the requested layout using sample hole data and a bundled copy of the app's renderer/orbit code. The renderer output was checked against the source module. The PNG is a production-renderer layout illustration, not an Android or browser screenshot. Neither preview changes a saved course or bag.

All 1,096 automated tests passed. Focused orbit tests were rerun after final pointer-capture cleanup. New checks cover pinch suppression/cancellation, zoom limits and reset, continuous home rotation, reduced-motion behavior, keyboard zoom and accurate ground picks at multiple zoom levels and orbit angles on sloped terrain. All 58 native host-rule checks also passed. Syntax, retained controls, offline paths and ZIP checks are recorded in verification.json.

The required browser gate keeps its route/model/marker checks and adds full-width layout, matched Par/distance sizing, main-map animation cleanup and real two-finger pinch followed by a zoomed landing tap. Stable scene comparisons run with reduced motion; a separate stage explicitly enables and checks automatic motion. The fresh local browser attempt is BLOCKED by workspace socket permissions before browser tests run. GitHub's real browser/model/native/APK gates remain required. No local signed APK, real-phone touch/performance validation or actual ten-foot GPS accuracy pass is claimed.

## Install

Replace repository-root Fairway-Form-Source.zip, preserving the filename. Run the existing workflow. After all required checks pass, install its signed APK over the existing app without uninstalling. Package, signing identity, origin, storage keys and saved data are preserved. Version name: 1.41.0. Fallback versionCode: 71; CI retains its increasing code.
