# Final Form - Disc Golf 1.28.0

Caddy's hole-sign/map reader now proposes routes from pale, dark, colored and
dashed lines, with nearby tee/basket symbols and text as additional clues.
Straight, slight/full doglegs and two-bend shapes use the actual image aspect
ratio. Busier unanchored maps can ask for an active hole or closer crop.

Drag the tee, basket or either bend directly. Larger hit targets, pointer
capture, cancel rollback and keyboard arrows make small corrections easier.
Markers stay round, and reanalysis preserves a complete manually corrected
route. Placement buttons remain available for adding missing points.

Use confirmed sign details fills course name, hole, par, selected distance,
route shape and written OB/mando notes in the regular preparation form. That
same form saves the course hole in My Courses. Multiple hole cards and alternate
pars/distances require selection. Existing notes are retained without duplicate
rules; another named course or an in-progress different hole cannot be silently
replaced. Printed route text wins over automatic shape guesses; deliberately
corrected markers can override it, with disagreements displayed.

Seven reviewed public sources and four practical Course planning lessons are
searchable in the offline library, bringing it to 104 lessons and 84 distinct
research resources from 88 stable source records. All 1,092 dated catalog
references remain. See HOLE-SIGN-RESEARCH-1.28.0.md for source links, actual access
provenance, published-map checks and limitations.

## Verification

739 JavaScript tests passed, with zero failures/skips/cancellations. This includes
28 added tests covering parsing, route proposals, dragging, setup/course save and
reopen, and searchable research. Syntax checks passed for 85 JS/MJS files;
all 17 serialized browser checked-step expressions parsed, and all 97 offline
shell paths exist. The final reviewed browser scenario uses an original
synthetic image and a test OCR bridge, then real pointer input and course storage.

The local browser launch was BLOCKED by socket EPERM (run
cc50e07e-9e95-48fd-857e-8f249c4bc22d); no local browser/model pass is claimed.
No local signed APK or physical-phone/ML Kit verification was performed.
Mandatory GitHub browser/model, native and APK checks remain enabled.

Two publisher-hosted map images received local pixel checks: the Omaha hole-1
page produced tee/basket and slight-right proposals matching the visible route;
the Belvidere whole-course overview withheld an unanchored proposal. These do
not establish general recognition accuracy. Exact user-example transcriptions
were tested, but their embedded photos were not run end-to-end through OCR.

## Update and preservation

Replace the SAME private repository-root Fairway-Form-Source.zip and commit.
Keep the working workflow and signing credentials. After Actions succeeds,
download/extract the APK and install over the existing app without uninstalling.
Version is 1.28.0; fallback versionCode is 49 (CI supplies its increasing code).

Package com.fairwayform.app, WebView origin, IndexedDB schema 5, record IDs,
signing setup, approved intro, bag/catalog, video analysis and coaching remain
compatible. There is no database migration or new photo upload. The source ZIP
excludes vendor downloads, build artifacts, signing material, private IP-review
documents and third-party research artwork.

Automatic image suggestions still need confirmation. This is local heuristic
vision, not a trained model that understands every sign. Compass bearing,
measured scale, elevation, current pin selection, hazard side and clearance
are not inferred from pixels. Use explicit text and on-course checks for those
facts; routes with more than two important bends may need notes.
