# Fairway Form 1.7.0 — point your phone to read the wind

Local weather now opens a phone-compass aiming screen automatically. You no longer need to type compass degrees to convert the weather wind to your throwing line.

## On your phone

1. Open Caddy → Use local weather → Get weather at my location. Continue through the existing location explanation and allow location when Android asks.
2. Once weather loads, the **Point down the fairway** screen opens. Hold the phone fairly flat, screen up, and point the top edge of the displayed screen along your intended throw. This also works with the screen rotated into landscape.
3. Hold still until the reading settles. Tap **Use this direction & apply wind**. The app fills the throw heading and applies the weather wind as headwind, tailwind or crosswind relative to that line. The preview includes diagonal wind components.
4. For another line, use **Use phone compass** again. Each recorded throw clears the old heading, so the next lie gets its own direction. Manual entry is available in the collapsed **Enter direction manually** section.

Cancel stops sensing and leaves the previous heading/wind unchanged. Leaving Caddy, backgrounding, native pause, changing holes or finishing the capture stops its sensor subscription. Missing hardware, low accuracy, tilt or timeout leaves manual entry available. If accuracy is low, move away from metal baskets/magnetic cases and make a figure-eight movement, then aim again.

## How it works

The compass uses Android's magnetic-north-referenced rotation sensor, with an accelerometer/magnetometer fallback where needed. GPS/location is used for the weather position and an on-device correction from magnetic north to true north. GPS direction of travel is not used as a substitute for a stationary compass.

The native code remaps axes to the current screen orientation and applies Android's geomagnetic declination model. A short circular averaging window handles north correctly; 359° and 1° settle near 0°, not 180°. The app rejects unreliable/low-status, tilted, stale, duplicate and uncorrected readings. Captures stop automatically after 30 seconds if unfinished. A settled reading is an estimate, not a guarantee of exact aim or local wind. The user confirms their intended line before any wind settings change.

No new runtime permission, account, native dependency or background service is added. The existing weather location permission is sufficient; precise location is still used separately for GPS throw measurement. Raw weather/compass coordinates remain in memory and are not added to holes, disc profiles or backups. The selected heading and relative wind save with the caddy draft. More implementation detail and sources are in COMPASS-RESEARCH-1.7.0.md.

## Install using your existing phone workflow

Replace the repository-root **Fairway-Form-Source.zip** in the SAME GitHub repository and commit it. Keep that exact filename, existing workflow, APP_SIGNING_PASSWORD and .fairway-signing.enc. When Actions succeeds, download/extract Fairway-Form-APK and install Fairway-Form.apk over the existing app. App & settings should show Version 1.7.0.

This update includes version 1.6.0's GPS throw measurement and all previous features. It preserves package com.fairwayform.app, appassets origin, database version 4, signing identity and Kotlin BOM fix. Local versionCode is 19; CI still supplies the increasing run-based code.

## Verification

334 automated tests pass, including 19 compass-filter/bridge tests and eight new caddy-weather integration tests. Static JS/import/HTML/cache/XML/version/shell checks pass, along with native compass wiring checks. CI browser smoke now exercises the actual aiming dialog with simulated compass/weather data, automatic weather opening, applying a heading, sensor cleanup, recapture, cancellation and persistence without saving coordinates.

Full browser/model smoke and signed APK compilation still need GitHub Actions. Local Chromium is blocked by workspace socket permissions; no Android SDK/Gradle setup is configured here. This download is editable source, not a compiled APK. Physical compass behavior still needs testing on your phone.

Check portrait and landscape, aiming north across 359°/0°, an eastbound throw with wind from the east (headwind), changing line for the next throw, magnetic interference, no/denied location, Cancel, screen lock, navigating away, and saved heading after reopening. Verify against a known direction outdoors away from metal before relying on the recommendation.
