# Final Form - Disc Golf 1.29.0

Focuses on side-on, normal-speed backhand review, following the reported tests.

Scrubbing now coalesces rapid inputs instead of cancelling and restarting a
decode for every slider movement. The latest target stays visible while loading,
markers wait for displayed pixels, and failures retain the last visible frame.
Prepared-image waits are bounded. In the Android APK, Repair scrubbing prepares
just this clip without clearing your analysis, markers, notes or session.
A visible status identifies Original video versus Prepared source images.

Moment detection uses foot evidence independently of arm visibility, tolerates
one hidden foot-contact landmark, rejects earlier contacts followed by another
stride, and considers arm loading alongside wrist-motion candidates. Visible
follow-through segments can survive a short gap without inventing motion through
it. Suggested event intervals help inspect the source; corrections stay editable.

Coaching keeps clip-specific instructions instead of overwriting them with a
generic topic cue. More observations identify the measured change and source
time, with What this point is based on available to inspect the evidence. Existing
source links, practical tasks and outcome checks remain included.

## Verification and limits

764 JavaScript tests passed with zero failures/skips/cancellations, including
17 new regressions. All 23 serialized browser checked-step expressions parsed;
all 98 offline shell paths exist. See verification.json for syntax/archive checks.
The local browser check was BLOCKED by socket EPERM (run
c8f6073e-ef93-4cc8-8e4f-fa8f404e2ca4). No local browser/model, signed APK or
physical-phone pass is claimed. GitHub's required gates remain enabled.

No exact failing human clip was available. Synthetic cases establish regression
behavior, not a measured real-throw accuracy gain. The pose model is unchanged;
automatic release remains a swing estimate, not detected disc separation.
Forehand, putting, rear views and saved slow-motion clips have not received new
human-video validation. See VIDEO-RELIABILITY-1.29.0.md for the design and limits.

## Install and try

Replace the SAME private repository-root Fairway-Form-Source.zip and commit.
Keep the existing working workflow and signing credentials. After Actions
succeeds, extract and install the APK over the existing app without uninstalling.
Version is 1.29.0; fallback versionCode is 51 (CI supplies its increasing code).

Open the same original backhand clip and run Analyze again for new suggestions.
Try rapid timeline scrubbing and stepping. If the original decoder still stalls,
use Repair scrubbing beneath the player. Compare plant, backswing and finish
with the actual clip, then inspect the coaching's observation, task and result
check. Existing manual markers are retained; they take priority over estimates.

Caddy behavior, bag/catalog, package com.fairwayform.app, WebView origin,
IndexedDB schema 5, record IDs, signing identity and approved intro remain
compatible. No new upload, cloud analysis or database migration is introduced.
