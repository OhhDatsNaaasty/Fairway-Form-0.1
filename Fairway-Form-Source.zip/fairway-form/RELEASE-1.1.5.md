# Fairway Form 1.1.5 — coaching connected to the replay

The previous plan had a narrow issue-selection path and roughly one drill per body part. Unavailable checks often dominated its advice. This update makes the evidence and practice options clearer while leaving genuinely unassessed movements ungraded.

## Included

- Video-event summaries and replay buttons in the practice plan. Plant, backswing, arm-loading and release suggestions keep their marked/estimated labels.
- A Practice focus selector drawn from available findings, plus relevant Drill to try choices. There are 18 original exercises, filtered by shot type and stance.
- A labeled practice experiment when visible movement can support useful practice but no specific fault was established. General X-step learning is explicitly separate from personal findings.
- Unavailable checks grouped below assessed movements, with an explicit not-assessed label. Their filter opens the group. A disabled fixed-camera setting is explained as that setting rather than hidden feet.
- Twelve new lessons: 62 total, linked to 46 resources from 23 publisher/coach/research groups. New material covers X-step sequence, compact crossover, rhythm, backswing, event order, arm opening, support, plane, finish and forehand distinctions.
- External YouTube tutorial sections with checked time offsets and written-outline links. Direct playback was unavailable during research; that review basis is disclosed in the library. Videos and paid courses are not bundled.
- Practice-plan text exports include the selected exercise's reference links.

The coaching still uses explicit measurement rules and curated writing. No generative AI service or newly trained disc-golf model was added. The full X-step sequence, force/pressure, grip pressure, disc spin and nose angle are not automatically assessed. Instructional research does not itself create a new measurement capability. See COACHING-RESEARCH-1.1.5.md for the audit and exact research access.

## Update from an Android phone

1. Download the new Fairway-Form-Source.zip. Keep it zipped and use that exact filename.
2. Replace the existing root ZIP in the same GitHub repository and commit to main.
3. Keep the working workflow, APP_SIGNING_PASSWORD secret and .fairway-signing.enc file.
4. After the newest Actions run succeeds, download and extract Fairway-Form-APK, then install Fairway-Form.apk over the existing app.
5. Confirm App & settings shows Version 1.1.5.

The source ZIP is a build input, not an APK. GitHub builds and signs it with the existing identity. The Android package and data-storage schema remain stable; default local versionCode is 9 and CI supplies its increasing code. All earlier 1.1.4 frame fixes and the expanded disc catalog remain included.

## Verification

112 local tests pass, including all frame/decoder regressions and new checks for actual report timestamps, estimated-event labels, selectable relevant drills, unknown-evidence exclusion, general X-step labeling, forehand/standstill/specialty separation, source resolution and tutorial provenance. Scripts, local imports, offline cache entries, HTML/template controls, XML, shell syntax and versions were checked.

The browser script now exercises collapsing/filtering unavailable checks, changing focus and drill, replay anchors, and the general X-step scope. The workspace cannot open its required local server, so real browser/model checks and APK compilation still need the GitHub build. The new interface has not been tested on an actual phone here.

After installing, open a saved review or analyze a side-on throw. Try Practice focus and Drill to try, use the replay buttons, open Unavailable checks, and search X-step in the technique library. Check a linked tutorial section online. Try a forehand and a standstill to confirm their practice options stay appropriate. Test your previously failing clip as well.
