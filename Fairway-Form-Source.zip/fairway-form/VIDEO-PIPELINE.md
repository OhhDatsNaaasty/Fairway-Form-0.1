# Event sequence update (1.26.0)

Original-video and optional prepared-frame decoding are unchanged from 1.25.0.
Event interpretation now uses final-stride and movement-sequence evidence;
supported automatic sequences can produce observational coaching without a
mandatory manual release marker. See THROW-SEQUENCE-RESEARCH-1.26.0.md.

# Current behavior (1.25.0)

Original-video processing is the default. The prepared-frame pipeline described
below is now an explicit compatibility option in App & settings; changing it
applies when the clip is reopened. Both modes advance the analysis preview with
the exact source image and its measured observation. Original-video analysis
retains forward sampling; paused scrub seeks have a short fast path and bounded
playback-based recovery. Marker time uses a presented source timestamp when the
browser supplies it. See ANALYSIS-REGRESSION-1.25.0.md for verification limits.

The following describes the prepared-frame implementation introduced in 1.23.0,
not the current default.

# Video review pipeline (1.23.0)

The recurring screenshot timeout was raised by paused HTML-video seeking. The
1.21 forward analysis pass did not replace scrubbing, marker selection or the
player jump after analysis. Those actions could still wait on WebView's decoder.
The user's original problem clip has not been provided, so its codec failure
has not been reproduced or verified fixed on a phone.

## Android prepared-frame mode

On opening a clip, the new APK copies it in bounded chunks to private temporary
storage. A single background worker uses MediaExtractor and MediaCodec to read
the video track sequentially. Each retained decoded image gets its actual
presentation timestamp. The worker reads flexible YUV planes with their crop,
row and pixel strides, converts the image and applies rotation once. It saves
JPEG review images and returns the ordered timestamp index. No synthetic frames
or guessed frame times are generated.

Scrubbing, stepping and review playback then show those prepared images, without
seeking the WebView video. Native review playback has no audio. Marker buttons
are disabled during a pending image request or playback; only the timestamp of
the displayed image can be saved. Later scrubs supersede earlier requests.
Failed requests leave the previous displayed timestamp intact. The timeline
continues to show a saved marker even if that frame has no detectable pose;
coaching does not borrow an unrelated pose to fill the gap.

Body inference and the optional hand pass use the same frame files, including
when returning to release. A small LRU cache keeps at most six decoded browser
images. Reopening a saved session prepares its stored original video again;
markers, reports, bag data and courses keep the existing storage identities.

## Bounds and tradeoffs

- Clips remain limited to 20 seconds and 120 MB. Frames are resized to at most
  960 pixels on the long edge, JPEG quality 90, and retained at up to about 60
  frames/s (16 ms minimum separation). This reduces memory and I/O, but does
  not preserve all detail from a 4K/high-frame-rate original. Tiny hands may
  still need a separate close-up. The original saved/exported video is unchanged.
- Temporary frame files are limited to 128 MB and 1,300 images. The input copy
  is deleted after preparation. Frame files are deleted on replacement or
  activity destruction, and leftovers are removed on the next activity launch.
  They are not saved in reports or backups. While the activity stays alive in
  the background, its current review cache can remain available.
- Preparation has a 90-second worker deadline and an eight-second decoder-output
  stall limit. The bridge has a two-minute total and 15-second no-progress
  deadline, with progress and cancellation. Image reads have an eight-second
  deadline. These checks do not guarantee a vendor codec cannot hang inside an
  individual native API call.
- Unsupported pixel formats, some HDR/10-bit clips, incomplete output, changing
  dimensions or storage errors explain the limitation and fall back to the
  browser player. The browser/older-APK path retains forward frame sampling
  where supported; it is not equivalent to the native cache. Nothing treats a
  failed preparation or browser check as successful.
- No new Android permission, cloud video upload, account or paid service is used.

## Throw moments

Automatic release is still a motion cue, not visual detection of disc separation.
The selector now requires sustained relative hand motion. Marked reachback,
plant and finish times constrain candidate swings. Clear sideways approach
travel or an explicit throw direction helps reject backward reachback motion.
Comparable separated swing bursts require a manual release or narrower review
range; the app withholds body coaching instead of silently choosing one.
Manual release remains authoritative. These are conservative app heuristics,
not a trained, validated event model or a form score. Hidden feet, motion blur,
occlusion, multiple people and landmark mistakes can still hide throw events.

## Verification and phone check

652 JavaScript checks and 13 independently compiled Java frame-rule checks passed.
The changed Java files also passed a syntax-only parser. That parser does not
compile against Android APIs. The local browser server is permission-blocked;
no full local browser/model pass, Android API compilation, signed APK, native
codec execution or real-throw accuracy validation is claimed.

GitHub retains its required browser/model gate and Android build. A new browser
fixture exercises the actual app with a test Android bridge: distinct colored
images, pending-marker protection, source timestamps, unchanged HTML playhead,
cache-fed analysis and persistence. It is explicitly not a MediaCodec test.
The ordinary H.264/model browser checks remain intact.

After installing the successful APK over the existing app, open the same clip
that failed. Wait for “Frame review ready.” Scrub repeatedly around the failing
time and the end, step both ways, mark release/plant, analyze, save and reopen.
Check that the marker matches the visible image and that a new clip does not
show old images. If fallback is reported, retain the original clip and the exact
message; testing that original file on the target device is needed to diagnose
its codec and validate the change. Accurate event recognition also needs labeled
real throws covering different hands, cameras, frame rates and approaches.

Engineering references checked 2026-10-31:

- Android MediaCodec: https://developer.android.com/reference/android/media/MediaCodec
- Android MediaExtractor: https://developer.android.com/reference/android/media/MediaExtractor
- Android Image planes/crop: https://developer.android.com/reference/android/media/Image

These describe the platform APIs, not evidence that the user's video or this
implementation has passed an on-device codec test.
