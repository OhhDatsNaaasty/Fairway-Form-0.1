# Analysis regression review — 1.25.0

The user reports that analysis no longer visibly plays and suggested throw
moments are wrong. They clarified that “points” means suggested events, not
body dots. The original problem video is not available in this workspace.
These changes address confirmed display faults and prevent uncertain event
estimates from becoming confident corrective coaching; automatic event accuracy
is not verified improved on that throw.

## Confirmed display problems

Prepared-frame inference read new source images but did not advance the player
preview. The timeline and visible image could remain at an earlier frame during
analysis. Analysis now emits the source image and its measured observation as
one transient pair. The player copies those pixels before the sampler reuses or
closes its canvas. Body and optional hand passes both advance the preview.
Source pixels are not added to saved observation arrays.

The old overlay could borrow a nearby observation up to about 80–100 ms away.
That can visibly misalign a fast-moving throw. Decoder-timestamped frames now
use only the observation measured at that timestamp (0.5 ms numeric tolerance).
Older players without presented timestamps have an 18 ms approximate tolerance;
they are not represented as exact. Unsampled images can have no overlay.

Original phone/browser video is the default again. Prepared frames remains an
explicit Android compatibility option in App & settings, applied when opening
the next clip. Existing videos, review records and unsaved edits are not thrown
away when changing that preference. Native Java decoding code is unchanged.

Original-video analysis retains forward sampling and frozen source pixels.
Paused scrub/step seeks first get a 900 ms fast path; a stalled seek then uses
original-video playback recovery within the remaining five-second default
budget. New requests cancel previous ones. Failure is explicit, with the last
displayed frame retained. A presented-frame clock supplies source timestamps
for marker selection when supported. It does not use an arbitrary scrub target
as proof that those pixels were displayed. Only one legacy playback draw loop
can run at a time.

## Suggested throw moments

Automatic release still uses sustained hand motion relative to the shoulder.
A wrist-motion peak can precede or follow actual disc separation. Reachback,
plant, arm-loading and follow-through candidates depend on that anchor; an
incorrect anchor can move several suggestions at once. Transcript research
alone cannot resolve this for an individual clip.

The automatic event is now labeled Release check, with a short forward-swing
review window. Default coaching asks the player to replay, step to visible disc
separation and use Mark release here. Until a release is marked, personal
praise/fault judgments are reduced to observations and the default practice
summary does not prescribe a correction from that timing. Marking release
recalculates the other suggestions from that anchor. Unmarked plant contact
also cannot establish brace praise or a brace fault. Other markers remain
editable and explicitly suggested unless the player marks them.

This is an uncertainty safeguard, not a replacement trained event detector.
No pose weights or automatic event thresholds were tuned against an unseen
clip. Frame blur, occlusion, camera angle and sparse observations can still make
an event unavailable or incorrect. The next accuracy step is to label release,
foot contact and other visible events in the original failing video, compare
those intervals against the event candidates, and test any resulting change
against other labeled throws. A synthetic fixture cannot establish that gain.

## Verification and limits

- 684 automated JavaScript tests passed; zero failures, skips or cancellations.
- New tests cover exact source/observation pairing, advancing body/hand preview,
  original-mode default, native presentation without another seek, bounded
  original-playback recovery, superseded scrubs, cancellation, presented-frame
  clock lifecycle, and confirmed versus provisional release coaching.
- Changed JavaScript passed syntax checks. Eleven embedded browser checked-step
  expressions were expanded and parsed.
- Fresh local browser run 76f891c2-e86e-4b73-80d9-67da33f9ba1a on
  2026-10-31T19:58:27Z returned BLOCKED in 114 ms: localhost sockets denied
  with EPERM. No local browser/model pass is claimed. Required GitHub browser
  assertions remain enabled, including explicit prepared-mode opt-in and
  advancing source/observation timestamps. The Android bridge there is a test
  fixture, not MediaCodec or a physical-phone test.
- No local Android SDK/signing identity, compiled APK or original phone clip
  was available. Physical-device decoding, event accuracy and responsiveness
  still need validation. No background model upload/service is introduced.

Package com.fairwayform.app, appassets origin, IndexedDB schema 5, saved record
IDs, bag/catalog data, signing flow and the approved intro are preserved.
