# Fairway Form 1.2.3 — Android Kotlin dependency alignment

Your 1.2.2 screenshots confirm the full browser/model checks passed. The remaining failure occurs in Android's checkReleaseDuplicateClasses task. The dependency graph contains kotlin-stdlib 1.8.22 alongside kotlin-stdlib-jdk7 and kotlin-stdlib-jdk8 1.6.21. Kotlin 1.8 merged the old JDK-extension classes into the main standard library, so this mixture supplies the same classes twice.

The app now uses the Kotlin BOM 1.8.22 as an implementation platform. This applies compatible version constraints to the Kotlin runtime artifacts, upgrading the older JDK-extension artifacts without removing the runtime classes needed by the Android dependencies. Duplicate-class checking remains enabled. Kotlin's official guidance documents this fix: https://kotlinlang.org/docs/whatsnew18.html.

No app feature, stored-data schema, permission, signing identity or GitHub workflow changes. Player profiles, coaching, video review, bag, caddy, weather and sign-photo support remain included. The earlier caddy loading fix remains. Android local versionCode is 13; CI still supplies its increasing versionCode.

The message about being unable to strip libmlkit_google_ocr_pipeline.so is separate: Gradle says it will package that library as-is. The duplicate Kotlin classes are the build-stopping error in these screenshots.

## Build from your Android phone

1. Download the 1.2.3 Fairway-Form-Source.zip. Keep it zipped and retain that exact filename.
2. Replace the root ZIP in the SAME GitHub repository, then commit the replacement to main.
3. Keep your existing workflow, APP_SIGNING_PASSWORD secret and .fairway-signing.enc file.
4. Open the newest Actions run. Rerunning the old run uses the old ZIP.
5. After the new run succeeds, download/extract Fairway-Form-APK and install Fairway-Form.apk over your current app.
6. Confirm Version 1.2.3 in App & settings. Check your saved bag/profile and a new caddy hole.

This is a source update, not an APK. The existing workflow compiles and signs the APK.

## Validation and remaining check

184 automated app tests pass. JavaScript syntax/imports, referenced controls, offline shell, XML, shell scripts and version/package/database wiring pass static checks. The BOM declaration and removal of mixed explicit runtime declarations were reviewed against Kotlin's official guidance.

The current workspace has Java 21 but does not have Gradle or the Android SDK. Its configured network proxy is unreachable from the shell, preventing toolchain/dependency downloads. Consequently, resolved Android artifacts and successful APK compilation have not been verified locally. The new GitHub run must confirm dependency resolution and pass checkReleaseDuplicateClasses and assembleRelease. No Android-build success is claimed for this source archive.
