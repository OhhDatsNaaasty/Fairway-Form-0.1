# Final Form - Disc Golf 1.26.0

Changes automatic throw-moment selection to use the final throwing sequence,
with no fixed count of walk-up steps. Plant now checks movement and near-ground
settling on the final lead-foot stride, excluding earlier contacts and later
recovery steps. Backswing finds the last reversal into the swing; release cues
use sequence context instead of only the largest hand motion. Follow-through
comes from continuing arm motion, rather than a fixed post-release frame.

Fixes a concrete crossover timeline bug: it was choosing “Before the crossover”
instead of the actual crossover. Coil now reviews shoulder/hip heading changes
through a sequence, has an editable timeline marker and links to new instruction.
Four new sourced lessons bring the library to 92 lessons and 69 sources.

A supported automatic sequence now receives observational coaching without
mandatory manual release marking. Weak or genuinely competing sequences still
ask for a focused correction. The analyzer does not move plant onto backswing
to manufacture good timing, and does not treat a hand-speed cue as proof of
disc separation. See THROW-SEQUENCE-RESEARCH-1.26.0.md for sources, inspected
illustrations/photos, algorithm changes and limits.

## Validation

700 JavaScript tests passed, zero failures/skips/cancellations. Sixteen new
regression tests cover longer approaches, mirrored throws, sample rates,
playback tempos, late plant, unrelated hand pumps, finish occlusion, recovery
steps, standstill, coil and coaching flow. Syntax, twelve serialized browser
checked-step expressions and offline-shell paths passed static checks.

The local browser run was BLOCKED by this environment's socket permissions.
No local browser/model, signed APK or physical-phone accuracy pass is claimed.
The mandatory GitHub browser/model, Android compile and APK checks stay enabled.
Synthetic tests and instructional stills do not establish real-video detection
accuracy. The original problem clip has not been supplied.

## Install and check

Replace repository-root Fairway-Form-Source.zip in the same private repository
and commit. Keep the working workflow and signing credentials. After Actions
passes, download Fairway-Form-APK, extract the APK and install over the current
app without uninstalling. Source version 1.26.0, fallback Android versionCode 47;
CI continues to supply its increasing code. No workflow edit is needed.

Reanalyze the same original video to refresh old suggestions. Check that plant
is the final landing, crossover is the actual crossing, and follow-through
shows continuing arm motion. Use Coil / body turn for the new sequence review.
Suggestions remain editable; correct only what is off. If feet or far joints
are hidden, some checks can remain unavailable. Original video stays the
default; Prepared frames remains an optional compatibility setting.

Package com.fairwayform.app, appassets origin, IndexedDB schema 5, saved record
IDs, catalog/bag/course data, approved intro and signing flow are unchanged.
