# Fairway Form 1.3.1 — putter driving based on your carry

The fixed putter tee-distance cutoff is removed. A putter with reliable 300-foot carry can appear for a 300-foot tee. Measured comparable averages and entered per-disc distances override generic estimated windows; the windows are starting guidance, never distance caps.

- Suitable midrange/driver alternatives remain visible. If putter copies occupy the whole shortlist, a competitive and reachable midrange/driver can replace the third choice. The strongest choice stays first. Alternatives must respect any comfortable speed limit.
- Long open holes still favor controlled driving discs and staged play when appropriate. Short-game roles receive the long-open penalty only when an available controlled driving disc offers greater reference carry. A demonstrated longer putter is not penalized just for being a putter.
- A putter-only bag can plan a reachable placement shot on a long hole, with an explanation that a driving option is missing. It never invents a driver outside your bag or promises a one-shot finish.
- Updated in-app lessons and explanations describe this policy. All existing distance learning, per-copy average/farthest statistics, measured/estimated separation and history backup/correction features remain included.

See CADDY-FLIGHT-RESEARCH-1.3.1.md for the inherited manufacturer references, estimation assumptions and exact shortlist policy. Flight numbers do not establish a universal carry distance or identical flight across brands.

## Install from your phone

Replace the root Fairway-Form-Source.zip in your SAME GitHub repository and commit it. Keep the exact filename, existing workflow, APP_SIGNING_PASSWORD secret and .fairway-signing.enc. After Actions succeeds, download/extract Fairway-Form-APK and install Fairway-Form.apk over the installed app. Check Version 1.3.1 in App & settings.

Package, origin, signing workflow and database version 4 are preserved. No new permission or native dependency is required. Android default versionCode is 15; CI continues to supply its increasing code. The Kotlin BOM duplicate-class fix remains included.

## Verification

216 automated tests pass. Regression cases cover a 750-foot staged drive, no artificial 175-foot boundary, reliable entered and measured long-putter carry, visible alternatives among multiple putter copies, bag-order independence, unsuitable alternatives, and longer demonstrated putter carry. Static syntax/imports, controls, offline-cache paths, XML, scripts and versions pass.

Full browser smoke checks and Android compilation remain for the existing GitHub Actions workflow; this workspace cannot open a local browser server and has no Gradle/Android SDK. The source ZIP is not an APK. Phone verification remains necessary.
