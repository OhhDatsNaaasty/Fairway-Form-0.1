# Fairway Form 1.14.1 — course-service outage build fix

The screenshots show that the pose/hand models downloaded successfully. The assets step then stopped because overpass.private.coffee timed out and maps.mail.ru returned HTTP 504. The previous requirement for a populated optional course directory blocked the entire APK before compilation.

This patch keeps the 1.14.0 video-analysis upgrade and removes that outage blocker. It does not require a workflow replacement.

## What changed

When a valid dated course snapshot exists in the build workspace, it can still be retained during provider failures. When neither provider can supply a directory and there is no valid snapshot, the assets step now writes an explicit timestamped directory-unavailable notice and continues. It logs a GitHub warning. No placeholder/sample courses or fabricated hole facts are substituted.

The packaging check validates either a substantive dated directory or the deliberate outage notice. Missing, malformed or unexplained empty files still fail. Required offline pose/hand assets, native rule checks, browser checks, APK compilation and signature verification remain required.

When you open a valid directory in the app, it attempts to save those licensed open map facts in a separate on-phone cache. A later update can search that last valid directory when its bundled directory is unavailable. The original date and a fallback explanation remain visible. This cache excludes personal course edits, bags, player-location readings and throw history. It depends on the phone permitting local cache storage and does not retroactively recover a directory that was never saved by this version.

If neither bundled nor cached directory exists, Find a course clearly says the directory is unavailable and points to saved/manual course entry and the external PlanetDG link. It does not show invented search results or offer a fake course import. Saved courses and normal manual Caddy use remain available. Provider outages no longer prevent installing unrelated app improvements.

Browser CI now verifies both supported states: searchable/importable map data, or an explicit outage explanation with no selectable fake courses. A source archive's unexplained empty placeholder remains insufficient for packaging; the assets step must prepare the actual state.

## Update from your phone

1. Replace the private repository-root **Fairway-Form-Source.zip** with this download, preserving that exact filename, the existing workflow, encrypted signing key and APP_SIGNING_PASSWORD.
2. Commit the replacement to start a new build. Re-running the old commit will still contain the strict directory requirement.
3. If course providers remain unavailable, the assets step should print a warning and continue to Compile signed installable APK.
4. After Actions succeeds, download/extract **Fairway-Form-APK** and install **Fairway-Form.apk** over your current app. Do not uninstall or clear data.

Settings should show **Version 1.14.1**. Package com.fairwayform.app, WebView origin, signing identity requirements and database schema 5 remain compatible. Local versionCode fallback is 30; the existing workflow supplies its run number. Existing bags, courses, histories and saved videos are retained. Private IP-review files are excluded from the source package.

## Verification

482 JavaScript tests pass. New tests reproduce the timeout-plus-504 sequence, validate the generated outage file, exercise the real atomic bundle writer, check subsequent recovery, preserve original snapshot dates, and cover on-phone cache reuse/denial plus actual search handlers. They also verify that corrupt data and unexpected implementation errors are not hidden as normal outages. Test fixtures are isolated and never bundled as map courses.

Static JavaScript/import/control/offline-shell, XML, shell/version and serialized browser-expression checks pass. GitHub still needs to run full browser/model checks and compile/verify the signed APK. No local APK compilation or successful live course-data download is claimed. This source update fixes the identified course-outage failure path; unrelated build failures will still be reported.
