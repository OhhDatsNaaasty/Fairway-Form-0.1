# Fairway Form 1.5.0 — clearer coaching and a more colorful course

The form review now starts with a short, practical coaching view. Open the detailed plan or full coaching when you want the drill choices, body-by-body explanations, measurements and sources.

## Changes

- Short coaching names one visible pattern to keep when available, one useful focus and a plain-language next step. Missing evidence cannot create a guessed correction. Default voice playback reads the summary; detailed narration remains available.
- Coaching buttons open the matching technique lesson inside the app, expand it and clear filters that could hide it.
- All 62 previous lesson titles and explanations were rewritten. The library now has 74 lessons and previews for 49 resources. New material covers choosing a disc and landing area, backhand versus forehand, release angles, headwind/tailwind/crosswind, woods, bag roles and useful practice comparisons.
- Side-on backhand review can identify a suggested crossover/final-stride pattern and attach replay moments to it. Confirm in the original video that the rear foot passes behind, or set the new X-step crossover marker yourself. The app keeps unavailable or general footwork lessons separate from observed movement.
- Park day, Woodland and Ridgeline add original disc, basket and course illustrations. Choose Course graphics → Minimal for the simpler original look. All three color palettes and independent gray dark mode remain available; combinations save for next time.
- Six phase chips use a readable two-row layout on narrow phones. Artwork and lesson content are included in the offline app.

Research links, source-review basis, detection thresholds and limits are in COACHING-RESEARCH-1.5.0.md. Automatic crossover recognition is a conservative projected-pattern check, not proof of correct footwork or measured foot pressure. It still needs real-clip phone testing before an accuracy claim.

## Update on your Android phone

Replace the root Fairway-Form-Source.zip in the SAME GitHub repository and commit it. Keep the exact filename, existing workflow, APP_SIGNING_PASSWORD and .fairway-signing.enc. After Actions succeeds, download/extract Fairway-Form-APK and install Fairway-Form.apk over the current app. Check Version 1.5.0 in App & settings.

Your bag, player profile, disc experience, saved holes and sessions stay on the same package/origin/database. No new native dependency or permission is required. Local Android versionCode is 17; CI continues to supply its increasing code. Keep the Kotlin BOM fix and existing signing identity.

## Phone checks

1. Open a reviewed throw: the short coaching should be visible, while detailed practice and full body coaching start closed. Tap a replay moment and a related lesson. Try short and detailed voice playback.
2. Open the library, search “which disc,” “cross behind” or “headwind,” and read the lesson and resource previews before opening a link.
3. Film the whole backhand walk-up from a fixed side view with both feet visible. Check any suggested crossover and final stride in the original frames. Mark the crossover when needed. A one-step or unclear clip should not receive a confident automatic X-step assessment.
4. Try each course graphic and all three palettes in light/dark mode. Restart and check the saved combination. Minimal should remove the added course scenes.

## Verification

278 automated tests and static checks pass. Original SVG artwork was rendered and inspected. Full browser/model smoke checks and signed APK compilation remain for GitHub Actions; local Chromium launch is blocked by socket permissions and the workspace lacks an Android SDK/Gradle build setup. Device testing remains necessary. This download is source, not a compiled APK.
