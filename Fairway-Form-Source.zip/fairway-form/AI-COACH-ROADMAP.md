# Next stages: an evidence-led coach and personal caddy

## Foundation delivered in 1.1.0

The application produces a versioned report with source timestamps, phase markers and their origins, visibility coverage, per-check observations, uncertainties, original-frame overlays, practice cues and source-topic IDs. The local walkthrough uses only those findings. A 301-mold catalog and personal bag records provide a data model for later caddy functions.

## Generative coach

A future language model should explain this structured report using the curated lesson collection. It should not invent a new measurement or claim to have seen an unprovided frame. The response contract should reference existing check IDs and timestamps, distinguish observed evidence from a hypothesis, acknowledge unknown checks, preserve the intended throw/hand/view, and give a small practice plan with a way to test the cue. Any extra claims need a supporting source.

Keep original video processing on the phone when possible. An external model would need an explicit setup and a clear opt-in data path. API credentials belong in an appropriate secure runtime, not in a distributed APK or public repository. An on-device model has different RAM, storage, latency and licensing needs. No external generative AI service is connected in this version.

An avatar could display or narrate the same grounded response after the text coach is reliable. Voice playback alone should not be described as generative AI.

## Better measurement

- Collect consented representative clips, both hands, skill levels, camera views, lighting and throw types.
- Have experienced coaches annotate phase events and disputed movement patterns independently.
- Measure event-time error, false-positive review prompts, hand matching errors and performance across camera views.
- Calibrate confidence before labeling a movement a fault. The current visual-change thresholds are heuristics.
- Evaluate dedicated disc detection and actual disc-edge tracking. A wrist is not a disc and image interpolation is not new ground truth.
- Add calibrated multi-view capture or sensors for quantities a single camera cannot measure. Generated views or in-between frames must stay separate from measured evidence.

## Disc library and caddy

Expand catalog facts from manufacturer sources and approved, appropriately licensed datasets. Keep per-record provenance, variant/plastic, date and correction history. PDGA approval dimensions, manufacturer flight ratings and a player's actual flight are different kinds of data; they should not be merged into a false precision claim.

Personal recommendations need real player context: throwing hand/style, comfortable power, actual disc/run/weight/wear, observed lines and distances, wind, elevation, landing surface and risk preference. Course-aware help also needs location/hole data with an authorized source. Current target-distance comparison uses only the user's logged distances and never estimates range from speed ratings.

A good early caddy should present a few explainable choices with reasons and uncertainty, let the player record the outcome, and improve from those records. It should not require gigabytes of copied instructional media to look complete.


## Coaching audit, 1.1.5

The current walkthrough remains a local rule-and-template system. Source notes are not automatically retrieved or learned during analysis. It now exposes report timestamps, offers 18 relevant exercises, separates general X-step learning from personal findings, and keeps unknown checks ungraded. The library contains 62 lessons. Full X-step assessment still needs event detection and labeled-video evaluation, not just more instructional text. See COACHING-RESEARCH-1.1.5.md.


## Caddy, 1.2.0

A transparent bag-based planner, putting risk options, per-throw local history, optional model weather and native sign OCR are now implemented. This does not establish a flight simulator or general hole-image understanding. Future work should evaluate suggestions against measured outcomes, improve calibrated release/flight modeling, and validate diagram interpretation before automatically inferring clearances. A commercial deployment also needs licensed weather access and appropriate SDK/privacy disclosures. See CADDY-RESEARCH.md.


## Player context, 1.2.1

The local player profile and saved-review aggregation now connect the studio to caddy coaching. Optional demographics are stored context, not ability predictors. User-entered ranges and measured filmed throws remain distinct from camera geometry; the app does not estimate release speed, spin or real distance from a body skeleton. Self-declared skill affects practice structure, not the grading of body positions. Repeated review prompts are cautious replay/practice cues, not a validated disc-golf skill model. No generative coach backend has been added.
