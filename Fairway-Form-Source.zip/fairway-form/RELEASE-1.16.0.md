# Final Form - Disc Golf 1.16.0 — Opening animation and new name

The Android APK now plays the approved Concept 05 five-second intro while the existing app initializes beneath it. The visible name is **Final Form - Disc Golf**, with the basket/flight logo from the intro used for the launcher and header. Build and export filenames stay the same.

## Opening the Android app

- Plays on cold launch and when returning from Home or the app switcher after the app was in the background. Warm opening does not reload the WebView, clear a Caddy draft or change the current screen.
- Completing an app-launched gallery/camera picker, camera measurement, permission or external-reference/settings task returns to the workflow without another intro. A short pause without leaving the app does not restart it.
- The exact approved, silent H.264 movie is bundled in `res/raw/fairway_intro.mp4`; no video service or internet fetch is used. It does not request audio focus or interrupt other music.
- Skip intro is always available. Android's Remove animations setting shows the static end title while the UI loads. Decoder errors and a bounded playback watchdog prevent a stalled video from trapping the app.
- Interface setup signals readiness independently; normal playback finishes before revealing a ready app. If startup itself stalls, the overlay offers Try again and Open app rather than an endless loading screen.
- App setup, saved-data reads and catalog/library initialization run behind the movie. Pose/hand models remain lazy-loaded for analysis rather than downloading or allocating extra models on every launch. Optional web fonts load asynchronously so they cannot block startup offline.

The launcher label, adaptive and PNG icons, startup poster, header/footer, install metadata, permission explanations, backup prompts and owned-art titles use the new branding. The native system launch background matches the intro.

## Update from your phone

1. Download **Fairway-Form-Source.zip** for 1.16.0.
2. Replace and commit the repository-root ZIP with the **same filename**, in the same private repository. Keep your working Ubuntu 24.04 workflow, encrypted `.fairway-signing.enc` and `APP_SIGNING_PASSWORD` secret. No workflow replacement is needed.
3. After the Actions run succeeds, download **Fairway-Form-APK**, extract it, and install **Fairway-Form.apk** over the existing app. Do not uninstall first.

Android application/package `com.fairwayform.app`, WebView origin `https://appassets.androidplatform.net`, IndexedDB name `fairway-form` and schema 5, backup kinds, signing setup, source ZIP root and build filenames are unchanged. This is an update to the existing app, not a new installation identity. Local fallback versionCode is 33; the existing phone workflow supplies its increasing run-based value.

## Phone acceptance checks

- Cold launch online and in airplane mode: confirm the exact approved movie, clean title-to-app transition and new launcher name/icon.
- Enter an unsaved Caddy setup, background with Home, then reopen: intro replays and the same screen/fields remain. Repeat using the app switcher.
- Open Gallery, capture a video/photo, or run camera measurement: returning should keep the result/current workflow without replaying the intro. Check permission prompts too.
- Tap Skip during the movie; test Android Remove animations. Check that other music keeps playing. Rotate the phone and return from a short system interruption.
- Confirm old bag copies, courses, throw/disc profiles and saved video reviews still open, and old JSON backups still import.

## Validation and limits

Local checks passed: 506 JavaScript tests, 12 Android-independent startup lifecycle checks and 19 camera measurement rule checks, plus syntax/resources/identity checks, intact approved-media hashing and icon decoding. Source archive bytes are verified against the workspace. The existing real browser/model smoke checks and Android Gradle build remain required on GitHub. The build now checks that the compiled APK includes the exact approved movie.

This workspace has no Android SDK/emulator and cannot validate real Android VideoView playback or install a signed APK. A successful GitHub build plus the physical-phone checks above are still required. The opening animation is artwork, not an independently coach-validated biomechanical reference. No application publishing, subscription activation or source-repository visibility change is included.
