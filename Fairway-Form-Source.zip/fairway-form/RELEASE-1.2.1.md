# Fairway Form 1.2.1 — your player profile

This update connects personal capability context to the existing coaching and course caddy. It includes the 1.2.0 caddy, bag, sign-photo and weather features.

## Included

- Player profile in App & settings, with home/caddy shortcuts: optional gender, age, height (cm/inches), self-selected beginner/intermediate/amateur/pro level, usual hand, preferred driving throw, separate average backhand/forehand distances, comfortable putting range, highest controlled disc speed, and practice goal. Feet default; meters available.
- Local profile save, reset, JSON backup and restore. No new permission, account, API key or dependency. Demographics stay out of review/hole exports and are not used to infer power, skill or ideal body angles. Profile backups explicitly contain entered personal details.
- New holes use player defaults. An explicit button applies them to an existing lie; edits to a lie do not overwrite the main profile. Explicitly clearing a lie's putting/speed limit is respected. Changing the profile's usual hand clears its unsaved distance inputs so the old hand's references are not silently reassigned.
- General distance context and beyond-usual-range cautions in caddy advice. An average is not a maximum. Bag-copy distances remain the only disc-specific range reference; absent ranges stay unverified. Beginner selection gives a small disclosed extra preference to slower discs in a balanced plan. Other skill selections do not automatically prescribe faster discs.
- Measured carry inputs in the throw review. Save a measurement and flag whether it was a normal controlled throw on level ground in calm conditions. After three matching saved throws, their median can provide a general distance reference when no profile average was entered. Basket-distance differences never become measured carry.
- Recent saved-review patterns shared with caddy coaching: supported repeated review prompts plus visible patterns to keep. Rebuilt when needed from current saved sessions, so edits and deletions take effect. Form cues do not change throwing power, disc-distance estimates or flight ratings.
- Practice guidance uses the self-selected skill level and goal. Beginner guidance starts with one cue at easy pace; other levels get a small comparison exercise. Insufficient footage remains ungraded.
- Saved-review learning can be turned off, excluding both measured-session references and repeated-form cues. Explicit player and bag facts remain available.

## What counts as evidence

Uses the latest 12 saved sessions for the matching hand and throw style within 90 days. Distance references require at least three explicit, checked, measured carries. Manual profile averages take priority over the session median.

Form comparisons require complete reviews with at least 70% clear throwing-arm/hip samples, fixed side-on footage and a manually marked release. The most recent eligible stance determines which stance is compared. At least three comparable reviews are needed; a cue must appear in at least two-thirds. Timing and brace prompts also require a marked plant. Unknown/camera-visibility checks never count as form faults. These are cautious replay/practice prompts, not validated biomechanical diagnoses, a skill score, or proof of effective bracing. The app still cannot measure release speed, spin, real distance, forces or hidden grip from the skeleton.

Player summaries read session metadata without retaining the videos or pose-frame arrays. IndexedDB v4 adds a player store while preserving sessions, bag, catalog and caddy holes. Prior caddy limits seed the profile until it is explicitly saved. Existing signing, package and workflow remain unchanged. Local Android versionCode is 11; CI supplies its increasing code.

## Update from your Android phone

1. Download Fairway-Form-Source.zip for 1.2.1 and keep it zipped with that exact filename.
2. Replace the root ZIP in the SAME GitHub repository and commit to main.
3. Keep the working workflow, APP_SIGNING_PASSWORD secret and .fairway-signing.enc signing file.
4. Download/extract the newest successful Fairway-Form-APK artifact and install Fairway-Form.apk over the existing app.
5. Confirm App & settings shows Version 1.2.1. Fill and save Your player profile there.

This download is source, not an installable APK. The existing GitHub workflow builds and signs the APK.

## Phone checks

Confirm older sessions, bag copies and hole logs are still present. Save a profile, leave settings, reopen the app and check persistence. Switch distance units and height units; the physical values should stay the same. Try backing up/restoring the profile and leaving optional fields blank.

Start a new caddy hole and check hand, preferred throw and putting/speed limits. Edit a current lie, then apply the explicit profile-defaults button and check the fields. Try a target beyond your profile average, and a throw style without a bag distance: a caution is appropriate, a fabricated per-disc distance is not.

Save actual measured distances with three filmed throws of the same hand/style, checking the normal/level/calm box only when true. For repeated body cues, use full, clear side-on reviews with the same stance and confirmed phase markers. Compare the original replays before acting. Turn saved-review learning off and check that its cues disappear. Delete a saved review and reopen profile/caddy to check the evidence updates. The current unsaved analysis is not included in this history until saved.

## Validation

178 automated tests pass. JavaScript syntax/imports, HTML controls, offline shell paths, Android XML, shell scripts, versions and database wiring pass static checks. Browser smoke coverage now includes v1-to-v3-to-v4 preservation, profile persistence and conversions, saved-review aggregation/opt-out, caddy defaults and session carry persistence.

The browser smoke check cannot run in this workspace: its local server is blocked with listen EPERM. Android compilation is also unavailable here. The existing GitHub Actions workflow runs the browser checks and compiles/signs the APK; the new interface and device persistence still need that build and phone verification. No APK or device-validation success is claimed for this source package.
