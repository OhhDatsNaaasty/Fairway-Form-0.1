# Fairway Form 1.3.0 — a caddy that knows disc roles and learns your distances

## Changes

- Putters are excluded from tee recommendations when the basket is more than 175 ft away, as requested. The same rule applies in meters and when a short landing point is entered on a longer tee. If only putters are in the bag, the app asks for a suitable disc. Later short approaches and putts can still use putters.
- A long open hole now favors a controlled driving role and a staged plan. For a 750-foot hole, it compares a sensible first-stage drive rather than treating every bag disc as a one-shot option. A chosen landing point still takes priority; actual next-lie distance must be recorded independently.
- Every catalog mold has intended-role guidance, a broad estimated range and an original qualitative turn/fade sketch. Manufacturer chart references and exact-rated analogues are clearly distinguished. The catalog adds the researched MVP Photon, for 302 molds across all ten brands.
- Research includes 21 manufacturer-informed role summaries and 42 verified mold-specific manufacturer chart pages, plus lineup/guide references and 40 exact-four-number, same-type chart comparisons. A verified manufacturer chart was not found for every mold. Comparable ratings do not guarantee the same flight across brands or plastics. See CADDY-FLIGHT-RESEARCH-1.3.0.md for the coverage, links, formulas and limits.
- Record actual throw carry, its measured/estimated source, and whether the flight was clear. This is separate from actual distance left to the basket. Every outcome/condition record stays attached to the actual bag copy.
- Each bag copy shows its logged history, measured average and farthest throw, with separate hand/style summaries and separate estimate statistics. Three or more comparable clear-flight measurements can update its caddy range reference. Farthest throws and estimates never become routine measured carry.
- Comparisons account for throw type/hand, effort, slope, wind strength/direction, gusts, wet conditions and available weather temperature. Headwind, tailwind and crosswind guidance stays conditional. No exact weather-to-distance equation or 3D simulation is claimed.
- Correct or clear a bad distance in Disc room → My bag → Your throw history. Statistics and later caddy plans use the corrected durable record.
- Back up bag & throw history exports the bag and historical records together. Restore supports old bag backups as well as the new history. New restored histories appear as finished archived holes. Current matching entries are preserved rather than duplicated; additional imported history archives an affected current hole so you can start a fresh lie deliberately.

The numeric range windows are app estimates to improve new-disc recommendations, not manufacturer-certified distances. Your measured/entered disc distances take priority. The 175-ft putter tee rule is your requested policy; it is not a universal limit on how far a putter can fly.

## Update from your Android phone

1. Download this release's Fairway-Form-Source.zip. Keep it zipped and retain that exact filename.
2. Replace the root ZIP in the SAME GitHub repository and commit the replacement to main.
3. Keep the existing workflow, APP_SIGNING_PASSWORD secret and .fairway-signing.enc signing file.
4. After the newest Actions run succeeds, download/extract Fairway-Form-APK and install Fairway-Form.apk over the current app.
5. Confirm Version 1.3.0 in App & settings. Check your existing bag, profile, sessions and saved holes.

The Kotlin BOM fix from 1.2.3 and caddy loading fix from 1.2.2 remain included. No new native permission, SDK or account is required. Package/origin/signing remain unchanged; IndexedDB stays at version 4 because the new fields extend existing hole records. Local Android versionCode is 14; CI supplies its increasing code.

## Try it

Add the actual discs you carry. Open Caddy and plan a 750-ft straight/open tee: no putter should appear, and a controlled driver/fairway plan should lead. Try 175 ft and just over 175 ft. Enter a dogleg landing point, headwind, tailwind and wooded line; the plan should reflect those conditions.

Record actual carry and basket remainder separately. After three matching clear measured throws, inspect the bag's average/farthest and the next recommendation's range source. An estimated distance or tree hit should stay visible without establishing routine measured carry. Check feet/meters entry, left/right hand and forehand/backhand separation. Correct one measurement in bag history and reopen Caddy. Back up and restore the bag/history and verify there are no duplicate throws.

## Verification

211 automated tests pass. Static syntax/imports, controls, offline-cache paths, XML, scripts, versions, Android package and database wiring pass. New regression cases cover the 750-ft tee, exact 175-ft boundary, measured versus estimated data, per-copy/hand/style/condition learning, putting separation, correction/reentry, meters, missing distances, malformed backups and safe history restoration.

The full updated browser smoke check and Android build still require GitHub Actions; the workspace blocks the local browser server and has no Gradle/Android SDK. Phone testing is required for the new interface. The source ZIP is not an APK and does not claim completed device verification.
