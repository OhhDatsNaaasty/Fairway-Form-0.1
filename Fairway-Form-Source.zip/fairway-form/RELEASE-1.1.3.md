# Fairway Form 1.1.3 — expanded disc room and manufacturer lessons

## Disc catalog

301 entries across all ten requested brands:

- Axiom: 17
- Discmania: 55
- Discraft: 30
- Dynamic Discs: 22
- Innova: 70
- Latitude 64°: 24
- MVP: 16
- Prodigy: 45
- Trash Panda: 5
- Westside Discs: 16

Each entry has flight ratings, its manufacturer reference and a snapshot date. Relevant plastic/version notes distinguish revised ratings and retooled models. The original 50 IDs remain available for existing bag records. The catalog is a sizable reference selection, not a claim to contain every mold or reflect current store stock. Your own logged distances are still separate from manufacturer numbers.

Search accepts brand names without spaces, and the brand/type/speed filters remain available. Show more molds exposes the complete catalog without a fixed results ceiling. The full source table is in DISC-CATALOG-SOURCES.md.

## Product photos

The catalog and personal bag now support representative manufacturer photos with source credits. The hosted build downloads usable matching photos and bundles them for offline use. It reports actual coverage by brand, and the app shows the number available. A missing, blocked or uncertain match stays labeled Photo unavailable; the manufacturer link remains available. Images may show a different plastic, stamp or color from your own disc.

The source ZIP contains the photo importer and an initially empty index, not a pre-downloaded image library. Live photo availability is still pending the GitHub build. Source images are selected from matching product records/captions; generic charts, logos, related molds and known unrelated template pictures are rejected. The importer has a six-minute network budget so unavailable images do not indefinitely hold up the APK build.

## Manufacturer learning resources

The library grows to 50 original practical lessons and 41 linked resources. New material covers selecting controllable discs, lighter weights, model naming, changing rating systems, approach choices and landings, turn versus fade, plastic wear, recycled blends, accuracy games and comparing new molds. The Source filter lets you find lessons connected to a manufacturer. Product-reference material is clearly labeled and is not treated as a validated biomechanics model.

## Install from your Android phone

1. Download the new Fairway-Form-Source.zip. If Android adds (1), rename it back to that exact filename.
2. Replace the existing root ZIP in the same private GitHub repository and commit to main. Keep it zipped.
3. Keep your current working workflow, signing secret and encrypted key.
4. Wait for the newest Actions run. Photo downloading can make the asset step longer; its log reports how many photos were bundled.
5. Once the run succeeds, download and extract Fairway-Form-APK, then install Fairway-Form.apk over your current app.

Keep your current install so local sessions and bag records remain available. This source download still needs the GitHub build to produce the installable APK.

## Validation and phone checklist

79 local tests pass, including all earlier analysis/voice checks, all ten brands, preservation of original bag IDs, catalog round trips, separate Roc/Roc+ IDs, revised/fractional ratings, photo matching, source/format validation and a photo-build transport test. The transport fixture runs only in a temporary test directory and never supplies product photos to the app. Scripts, Android XML, controls, imports, offline assets and versions were checked. Controller checks exercise full catalog pagination, brand/search filters, photo gaps and manufacturer lesson filtering.

The workspace cannot download images directly or start a browser. Live image coverage, real-browser decoding and Android compilation still need the GitHub run. The browser check now exercises the expanded catalog and decodes actual bundled image files before packaging.

After installing, confirm your old bag entries and notes still open. Try each brand filter and search Trash Panda or Prodigy. Use Show more molds, add a new mold to your bag, and inspect available photos/credits. Try the library Source filter. Finally check dark mode, a saved coaching plan and your original video to confirm the earlier updates still work.
