#!/usr/bin/env bash
set -euo pipefail
CAMERA_PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$CAMERA_PROJECT_DIR"
CAMERA_TEST_DIR="$(mktemp -d)"
trap 'rm -rf "$CAMERA_TEST_DIR"' EXIT
java -m jdk.compiler/com.sun.tools.javac.Main -d "$CAMERA_TEST_DIR" android/app/src/main/java/com/fairwayform/app/CameraRangeRules.java tests/native/CameraRangeRulesTest.java
java -cp "$CAMERA_TEST_DIR" com.fairwayform.app.CameraRangeRulesTest
