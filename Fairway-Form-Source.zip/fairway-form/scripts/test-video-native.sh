#!/usr/bin/env bash
set -euo pipefail
VIDEO_PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$VIDEO_PROJECT_DIR"
VIDEO_TEST_DIR="$(mktemp -d)"
trap 'rm -rf "$VIDEO_TEST_DIR"' EXIT
java -m jdk.compiler/com.sun.tools.javac.Main -d "$VIDEO_TEST_DIR" android/app/src/main/java/com/fairwayform/app/VideoFrameRules.java tests/native/VideoFrameRulesTest.java
java -cp "$VIDEO_TEST_DIR" com.fairwayform.app.VideoFrameRulesTest
