// Offline, repeatable catalog merge. Edit reviewed snapshots, then run this script.
import fs from 'node:fs';
import {DISC_DATA} from '../dist/lib/disc-data.js';
const root=new URL('../',import.meta.url),read=name=>JSON.parse(fs.readFileSync(new URL('scripts/'+name,root)));
const key=d=>(d.brand+'|'+d.model).normalize('NFKD').replace(/\+/g,'plus').replace(/[^a-zA-Z0-9|]/g,'').toLowerCase();
const id=d=>(d.brand+'-'+d.model).toLowerCase().normalize('NFKD').replace(/\+/g,'-plus-').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
const seen=new Set(DISC_DATA.map(key)),rows=[];
for(const d of [...read('catalog-manufacturer-additions.json').discs,...read('catalog-reference-snapshot.json').discs]){
 if(seen.has(key(d)))continue;seen.add(key(d));
 rows.push({...d,id:id(d),type:d.type==='Putter'?'Putter':d.speed<=3.5?'Putter':d.speed<=5.5?'Midrange':d.speed<10?'Fairway':'Distance'});
}
fs.writeFileSync(new URL('dist/lib/disc-extra-data.js',root),'// Reviewed factual snapshots. Existing manufacturer records retain their IDs and ratings.\nexport const DISC_EXTRA='+JSON.stringify(rows,null,1)+';\n');
console.log('Catalog: '+(DISC_DATA.length+rows.length)+' molds; '+new Set([...DISC_DATA,...rows].map(d=>d.brand)).size+' brands.');
