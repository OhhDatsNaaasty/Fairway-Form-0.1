#!/usr/bin/env bash
set -euo pipefail
LOCATION_PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$LOCATION_PROJECT_DIR"
LOCATION_TEST_DIR="$(mktemp -d)"
trap 'rm -rf "$LOCATION_TEST_DIR"' EXIT
java -m jdk.compiler/com.sun.tools.javac.Main -d "$LOCATION_TEST_DIR" android/app/src/main/java/com/fairwayform/app/ThrowLocationRules.java tests/native/ThrowLocationRulesTest.java
java -cp "$LOCATION_TEST_DIR" com.fairwayform.app.ThrowLocationRulesTest
