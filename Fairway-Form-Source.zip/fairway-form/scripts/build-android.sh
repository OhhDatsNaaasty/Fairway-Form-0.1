#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"
for ASSET_FILE in vision_bundle.mjs pose_landmarker_lite.task pose_landmarker_full.task pose_landmarker_heavy.task hand_landmarker.task wasm/vision_wasm_internal.wasm; do
 if [[ ! -s "dist/vendor/$ASSET_FILE" ]]; then
  echo "Required offline asset missing: $ASSET_FILE. Run npm run assets before packaging." >&2
  exit 1
 fi
done
node scripts/check-startup-assets.mjs
bash scripts/test-startup-native.sh
bash scripts/test-camera-native.sh
if [[ "${CI:-false}" == true ]]; then
 node scripts/run-browser-checks.mjs
fi
: "${ANDROID_HOME:?Set ANDROID_HOME to an Android SDK with platform 35 and build-tools 35.0.0.}"
GRADLE_CMD="${GRADLE_CMD:-gradle}"
rm -rf android/app/src/main/assets/web
mkdir -p android/app/src/main/assets/web
cp -R dist/. android/app/src/main/assets/web/
cd android
"$GRADLE_CMD" --no-daemon "${1:-assembleDebug}"
mkdir -p ../artifacts
if [[ "${1:-assembleDebug}" == assembleDebug ]]; then
 cp app/build/outputs/apk/debug/app-debug.apk ../artifacts/Fairway-Form.apk
 node ../scripts/check-startup-assets.mjs ../artifacts/Fairway-Form.apk "$ANDROID_HOME/build-tools/35.0.0/aapt2" debug
 echo 'APK ready: artifacts/Fairway-Form.apk'
else
 if [[ -f app/build/outputs/apk/release/app-release.apk ]]; then
  cp app/build/outputs/apk/release/app-release.apk ../artifacts/Fairway-Form.apk
  node ../scripts/check-startup-assets.mjs ../artifacts/Fairway-Form.apk "$ANDROID_HOME/build-tools/35.0.0/aapt2" release
  echo 'Signed APK ready: artifacts/Fairway-Form.apk'
 fi
 echo 'Release output: android/app/build/outputs/apk/release/'
fi
