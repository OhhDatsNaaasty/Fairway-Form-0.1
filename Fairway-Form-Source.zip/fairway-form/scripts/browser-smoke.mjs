// Run on GitHub's Ubuntu runner. Real browser + bundled models; no product demo data.
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn,spawnSync} from 'node:child_process';
import os from 'node:os';
import {DISCS} from '../dist/lib/discs.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),dist=path.join(root,'dist');
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const chrome=['google-chrome','google-chrome-stable','chromium','chromium-browser'].find(bin=>spawnSync('which',[bin],{stdio:'ignore'}).status===0);
if(!chrome)throw Error('A Chrome/Chromium browser is required for the interface/model smoke check. GitHub Ubuntu 24.04 includes Chrome.');
const mime={'.html':'text/html','.js':'application/javascript','.mjs':'application/javascript','.css':'text/css','.wasm':'application/wasm','.task':'application/octet-stream','.json':'application/json','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'};
const server=http.createServer(async(req,res)=>{try{const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);if(pathname==='/qa-setup.html'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><title>Test storage setup</title>');return}const target=path.resolve(dist,'.'+(pathname==='/'?'/index.html':pathname));if(!target.startsWith(dist+path.sep)){res.writeHead(403);res.end();return}const data=await fs.readFile(target);res.setHeader('Content-Type',mime[path.extname(target)]??'application/octet-stream');res.setHeader('Cache-Control','no-store');res.end(req.method==='HEAD'?undefined:data)}catch{res.writeHead(404);res.end('Not found')}});
const profile=await fs.mkdtemp(path.join(os.tmpdir(),'fairway-qa-'));let browser,ws;
try{
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
 const origin=`http://127.0.0.1:${server.address().port}`;
 const childEnv=Object.fromEntries(Object.entries(process.env).filter(([k])=>!/PASSWORD|TOKEN|SECRET|ANDROID_KEYSTORE/.test(k)));
 let browserLog='';let resolveDebugger,rejectDebugger;const debuggerReady=new Promise((resolve,reject)=>{resolveDebugger=resolve;rejectDebugger=reject});
 browser=spawn(chrome,['--headless=new','--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--no-first-run','--disable-background-networking',`--user-data-dir=${profile}`,'--remote-debugging-port=0','about:blank'],{env:childEnv,stdio:['ignore','ignore','pipe']});
 browser.stderr.on('data',data=>{browserLog+=data.toString();const m=browserLog.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m)resolveDebugger(m[1])});browser.once('error',rejectDebugger);browser.once('exit',code=>rejectDebugger(Error(`Chrome exited before debugger was available (${code}). ${browserLog.slice(-1000)}`)));
 let timer;const debuggerUrl=await Promise.race([debuggerReady,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Chrome did not expose a debugger in time.')),20000)})]).finally(()=>clearTimeout(timer));
 const pages=await (await fetch(debuggerUrl.replace(/^ws:/,'http:').replace(/\/devtools\/browser\/.*/, '/json/list'))).json();
 ws=new WebSocket(pages.find(p=>p.type==='page').webSocketDebuggerUrl);
 await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true})});
 let nextId=0;const pending=new Map(),errors=[];
 ws.addEventListener('message',event=>{const message=JSON.parse(event.data);if(message.id){const p=pending.get(message.id);if(p){pending.delete(message.id);clearTimeout(p.timer);message.error?p.reject(Error(message.error.message)):p.resolve(message.result)}}else if(message.method==='Runtime.exceptionThrown')errors.push(message.params.exceptionDetails.exception?.description??message.params.exceptionDetails.text)});
 function send(method,params={}){return new Promise((resolve,reject)=>{const id=++nextId,timer=setTimeout(()=>{pending.delete(id);reject(Error('Browser command timed out: '+method))},150000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}))})}
 async function evaluate(expression){const r=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);return r.result.value}
 async function until(expression,message,seconds=20){for(let i=0;i<seconds*5;i++){if(await evaluate(expression))return;await wait(200)}throw Error(message)}
 await send('Runtime.enable');await send('Page.enable');await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
 await send('Page.navigate',{url:origin+'/qa-setup.html'});await until("document.title==='Test storage setup'",'Could not open storage test page.');
 await evaluate(`new Promise((resolve,reject)=>{const r=indexedDB.open('fairway-form',1);r.onupgradeneeded=()=>r.result.createObjectStore('sessions',{keyPath:'id'});r.onerror=()=>reject(r.error);r.onsuccess=()=>{const db=r.result,tx=db.transaction('sessions','readwrite');tx.objectStore('sessions').put({id:'qa-legacy-session',created:1,name:'QA only',blob:new Blob([]),frames:[],trace:[],options:{hand:'right',type:'backhand',view:'side'},notes:''});tx.oncomplete=()=>{db.close();resolve(true)}}})`);
 // Upgrade an existing v3 database, preserving the original v1 journal record.
 await evaluate(`new Promise((resolve,reject)=>{const r=indexedDB.open('fairway-form',3);r.onupgradeneeded=()=>{for(const name of ['bag','catalog','caddyHoles'])r.result.createObjectStore(name,{keyPath:'id'})};r.onerror=()=>reject(r.error);r.onsuccess=()=>{r.result.close();resolve(true)}})`);
 await send('Page.navigate',{url:origin+'/'});await until("document.querySelectorAll('#discCatalog .disc-card').length===60&&document.querySelectorAll('#library .library-item').length>=35",'The app did not initialize its interface/catalog.');
 // Appearance is independent from the palette; dark mode preserves its accents.
 await evaluate(`(()=>{
  document.querySelector('[data-page=settings]').click();const palette=document.getElementById('appTheme'),mode=document.getElementById('appMode');
  if(palette.options.length!==3||mode.options.length!==3)throw Error('Palette or light/dark dropdown incomplete');
  const accentKeys=['--forest','--trim','--water','--clay','--sun'];
  for(const value of ['forest','coast','sunset']){
   palette.value=value;palette.dispatchEvent(new Event('change'));mode.value='light';mode.dispatchEvent(new Event('change'));
   const original=accentKeys.map(key=>getComputedStyle(document.documentElement).getPropertyValue(key));
   mode.value='dark';mode.dispatchEvent(new Event('change'));
   if(document.documentElement.dataset.theme!==value||document.documentElement.dataset.mode!=='dark')throw Error('Dark mode replaced the selected palette');
   if(accentKeys.some((key,i)=>getComputedStyle(document.documentElement).getPropertyValue(key)!==original[i]))throw Error('Dark mode changed accent colors');
   if(getComputedStyle(document.body).backgroundColor!=='rgb(37, 40, 41)')throw Error('Dark background is not gray');
  }
  return true;
 })()`);
 await send('Page.navigate',{url:origin+'/#settings'});await until("document.getElementById('appTheme')?.value==='sunset'&&document.getElementById('appMode')?.value==='dark'",'Saved palette or dark mode was lost on restart.');
 await send('Emulation.setEmulatedMedia',{features:[{name:'prefers-color-scheme',value:'dark'}]});
 await evaluate(`(()=>{const select=document.getElementById('appMode');select.value='system';select.dispatchEvent(new Event('change'));if(document.documentElement.dataset.mode!=='dark'||document.documentElement.dataset.theme!=='sunset')throw Error('Automatic dark mode changed the palette');return true})()`);
 await send('Emulation.setEmulatedMedia',{features:[{name:'prefers-color-scheme',value:'light'}]});
 await until("document.documentElement.dataset.mode==='light'&&document.documentElement.dataset.theme==='sunset'",'Phone light mode did not update automatically.');
 // A test bridge exercises voice controls without requiring audio hardware.
 await evaluate(`(()=>{
  window.AndroidFiles={stopSpeaking(){},setSpeechOptions(...args){window.qaVoiceOptions=args},speak(text){window.qaVoiceText=text}};
  window.dispatchEvent(new CustomEvent('fairway-voices',{detail:{voices:[{id:'qa-offline',label:'QA offline',lang:'en-US',quality:400,network:false,installed:true},{id:'qa-online',label:'QA online',lang:'en-US',quality:500,network:true,installed:true}]}}));
  const voice=document.getElementById('coachVoice'),online=document.getElementById('onlineVoices'),rate=document.getElementById('voiceRate');
  if(voice.options.length!==2)throw Error('Internet voice offered by default');
  online.checked=true;online.dispatchEvent(new Event('change'));if(voice.options.length!==3)throw Error('Optional online voice not offered');
  online.checked=false;online.dispatchEvent(new Event('change'));voice.value='qa-offline';voice.dispatchEvent(new Event('change'));
  rate.value='1.1';rate.dispatchEvent(new Event('change'));document.getElementById('previewVoice').click();
  if(window.qaVoiceOptions[0]!=='qa-offline'||window.qaVoiceOptions[1]!==1.1||window.qaVoiceOptions[2]!==false||!window.qaVoiceText.includes('comfortable effort'))throw Error('Voice preview did not use selected options');
  voice.value='';voice.dispatchEvent(new Event('change'));rate.value='1';rate.dispatchEvent(new Event('change'));
  delete window.AndroidFiles;delete window.qaVoiceOptions;delete window.qaVoiceText;
  window.dispatchEvent(new CustomEvent('fairway-voices',{detail:{voices:[]}}));
  const palette=document.getElementById('appTheme'),mode=document.getElementById('appMode');palette.value='forest';palette.dispatchEvent(new Event('change'));mode.value='light';mode.dispatchEvent(new Event('change'));document.querySelector('[data-page=studio]').click();return true;
 })()`);
 await evaluate(`(()=>{document.getElementById('camera').click();if(!document.getElementById('accessDialog').open)throw Error('Camera prompt did not open');document.getElementById('accessCancel').click();if(document.getElementById('accessDialog').open)throw Error('Camera prompt did not close');document.getElementById('upload').click();if(!document.getElementById('accessTitle').textContent.includes('gallery'))throw Error('Gallery explanation missing');document.getElementById('accessCancel').click();return true})()`);
 await evaluate(`(async()=>{const s=await import('./lib/storage.js');if(!(await s.listSessions()).some(v=>v.id==='qa-legacy-session'))throw Error('Storage migration lost an old session');await s.deleteSession('qa-legacy-session');return true})()`);
 // Every requested brand is reachable, and pagination exposes the full catalog.
 await evaluate(`(()=>{
  document.querySelector('[data-page=discs]').click();const brand=document.getElementById('discBrand');
  const counts=${JSON.stringify(Object.fromEntries([...new Set(DISCS.map(d=>d.brand))].map(b=>[b,DISCS.filter(d=>d.brand===b).length])))};
  if(brand.options.length!==11)throw Error('Requested manufacturers are missing');
  for(const [name,count]of Object.entries(counts)){brand.value=name;brand.dispatchEvent(new Event('change'));if(document.querySelectorAll('#discCatalog .disc-card').length!==Math.min(60,count))throw Error('Brand filter failed: '+name)}
  brand.value='';brand.dispatchEvent(new Event('change'));for(let i=0;i<10&&!document.getElementById('moreMolds').hidden;i++)document.getElementById('moreMolds').click();
  if(document.querySelectorAll('#discCatalog .disc-card').length!==${DISCS.length})throw Error('Pagination did not expose the full catalog');
  const search=document.getElementById('discSearch');search.value='trashpanda';search.dispatchEvent(new Event('input'));if(document.querySelectorAll('#discCatalog .disc-card').length!==5)throw Error('Manufacturer-name search failed');search.value='';search.dispatchEvent(new Event('input'));
  document.querySelector('[data-page=learn]').click();const source=document.getElementById('knowledgePublisher');source.value='Prodigy';source.dispatchEvent(new Event('change'));
  if(document.querySelectorAll('#library .library-item').length<4)throw Error('Manufacturer lessons missing');source.value='';source.dispatchEvent(new Event('change'));return true;
 })()`);
 // Only actual bundled photos are counted. Each file must decode in the browser.
 await evaluate(`(async()=>{
  const index=await (await fetch('./disc-photos/index.json')).json();
  for(const item of Object.values(index.images??{})){const img=new Image();img.src=item.src;await img.decode();if(!img.naturalWidth||!img.naturalHeight)throw Error('A bundled photo could not decode')}
  return true;
 })()`);
 await evaluate(`(()=>{document.querySelector('[data-page=learn]').click();const input=document.getElementById('search');input.value='brace';input.dispatchEvent(new Event('input'));if(!document.querySelector('#library .library-item'))throw Error('Technique search failed');input.value='';input.dispatchEvent(new Event('input'));document.querySelector('[data-page=discs]').click();document.querySelector('#discCatalog [data-add]').click();return true})()`);
 await until("document.getElementById('bagCount').textContent==='1'",'Adding a disc to the bag did not persist.');
 await evaluate(`(()=>{document.getElementById('showBag').click();const field=document.querySelector('#myBag [data-field=distance]');field.value='180';field.dispatchEvent(new Event('change'));return true})()`);
 await until("document.querySelector('.bag-save-state').textContent.includes('Saved')",'Bag field edit did not save.');
 // Profile inputs persist independently from videos and keep units meaningful.
 await evaluate(`(()=>{document.querySelector('nav [data-page=settings]').click();return true})()`);
 await until("!document.getElementById('playerForm').inert&&document.getElementById('playerEvidence').textContent.includes('comparable')",'Player profile did not open.');
 await evaluate(`(()=>{const set=(id,value)=>{document.getElementById(id).value=value};set('player_gender','Prefer not to say');set('player_age','40');set('playerHeight','70');set('playerHeightUnit','in');document.getElementById('playerHeightUnit').dispatchEvent(new Event('change'));set('playerHeight','70');set('playerHeightUnit','cm');document.getElementById('playerHeightUnit').dispatchEvent(new Event('change'));if(Math.abs(Number(document.getElementById('playerHeight').value)-177.8)>.1)throw Error('Player height conversion changed physical height');set('player_averageBackhandFt','250');set('player_averageForehandFt','170');set('player_comfortablePuttFt','25');set('player_maxSpeed','9');set('player_skill','beginner');set('playerUnit','m');document.getElementById('playerUnit').dispatchEvent(new Event('change'));if(Math.abs(Number(document.getElementById('player_averageBackhandFt').value)-76.2)>.05)throw Error('Player distance conversion changed carry');set('playerUnit','ft');document.getElementById('playerUnit').dispatchEvent(new Event('change'));document.getElementById('playerForm').requestSubmit();return true})()`);
 await until("document.getElementById('playerStatus').textContent.includes('Profile saved')",'Player profile did not save.');
 await evaluate(`(async()=>{const s=await import('./lib/storage.js'),p=await s.getPlayer();if(p.age!==40||p.heightCm!==177.8||p.skill!=='beginner'||Math.abs(p.averageBackhandFt-250)>.05)throw Error('Player facts were not persisted correctly');const now=Date.now();for(let i=0;i<3;i++)await s.storeSession({id:'qa-player-'+i,created:now-i,options:{hand:'right',type:'backhand',view:'side',stance:'walkup',cameraStable:true},markers:{release:1,plant:.8},blob:new Blob([]),frames:[],trace:[],carryFt:220+i*10,carryReference:true,report:{coverage:.9,quality:{},findings:[{id:'brace',kind:'attention',t:.8}]}});const {renderPlayer}=await import('./lib/player-ui.js');await renderPlayer();if(!document.getElementById('playerEvidence').textContent.includes('3 of 3'))throw Error('Saved form reviews were not connected to player evidence');document.getElementById('playerUseSaved').checked=false;document.getElementById('playerForm').requestSubmit();return true})()`);
 await until("document.getElementById('playerEvidence').textContent.includes('learning is off')",'Review learning opt-out did not apply.');
 await evaluate(`(async()=>{const s=await import('./lib/storage.js');for(let i=0;i<3;i++)await s.deleteSession('qa-player-'+i);document.getElementById('playerUseSaved').checked=true;document.getElementById('playerForm').requestSubmit();return true})()`);
 await until("!document.getElementById('playerSave').disabled&&document.getElementById('playerEvidence').textContent.includes('0 comparable')",'Deleted review evidence remained in the player profile.');
 // Caddy uses the actual stored test bag, keeps next-lie distance separate,
 // and upgrades the v1 database without losing its journal/bag stores.
 await evaluate(`(()=>{document.querySelector('nav [data-page=caddy]').click();return true})()`);
 await until("document.getElementById('caddyLie').textContent.includes('THROW 1')&&!document.getElementById('caddy').hidden",'Caddy did not open from navigation.');
 await evaluate(`(()=>{if(document.getElementById('caddyMaxSpeed').value!=='9'||document.getElementById('caddyPuttRange').value!=='25')throw Error('New caddy hole did not use personal limits');return true})()`);
 await evaluate(`(()=>{const set=(id,value)=>{const el=document.getElementById(id);el.value=value;el.dispatchEvent(new Event('change'))};set('caddyDistance','190');set('caddyFairway','straight');set('caddyWindDirection','head');set('caddyWindStrength','medium');document.getElementById('caddyRecommend').click();return true})()`);
 await until("document.querySelectorAll('#caddyPlan .caddy-choice').length===1",'Caddy did not use the single actual bag copy.');
 await evaluate(`(()=>{if(!document.getElementById('caddyPlan').textContent.includes('headwind'))throw Error('Wind context missing');document.getElementById('caddyUnits').value='m';document.getElementById('caddyUnits').dispatchEvent(new Event('change'));if(Math.abs(Number(document.getElementById('caddyDistance').value)-57.9)>.2)throw Error('Caddy units changed the real distance');document.getElementById('caddyUnits').value='ft';document.getElementById('caddyUnits').dispatchEvent(new Event('change'));document.getElementById('caddySignText').value='Hole 8 Blue 320 ft Red 85 m Dogleg left Uphill';document.getElementById('caddyParseSign').click();if(document.getElementById('caddySignDistance').options.length!==3)throw Error('Sign distances were not kept as choices');document.getElementById('caddySignDistance').value='0';document.getElementById('caddyApplySign').click();if(document.getElementById('caddyDistance').value!=='320'||document.getElementById('caddyFairway').value!=='left')throw Error('Confirmed sign details did not apply');document.getElementById('caddyRecommend').click();return true})()`);
 await until("!document.getElementById('caddyLogPanel').hidden",'Updated lie did not receive a fresh caddy plan.');
 await evaluate(`(()=>{document.getElementById('caddyOutcome').value='made';document.getElementById('caddyOutcome').dispatchEvent(new Event('change'));document.getElementById('caddyOutcome').value='short';document.getElementById('caddyOutcome').dispatchEvent(new Event('change'));if(document.getElementById('caddyRemaining').value==='0')throw Error('Changed outcome retained an automatic zero distance');document.getElementById('caddyRemaining').value='60';document.getElementById('caddyRecord').click();return true})()`);
 await until("document.getElementById('caddyLie').textContent.includes('THROW 2')",'Recorded tee throw did not advance the lie.');
 await evaluate(`(()=>{if(document.getElementById('caddyDistance').value!=='60'||document.getElementById('caddyFairway').value!==''||document.getElementById('caddyWindDirection').value!=='unknown')throw Error('Next lie reused tee-line assumptions');document.getElementById('caddyWeather').click();if(!document.getElementById('caddyWeatherConsent').open)throw Error('Weather location explanation missing');document.getElementById('caddyWeatherCancel').click();document.querySelector('nav [data-page=discs]').click();return true})()`);
 // Restore the original bag-edit context for existing backup/removal checks.
 await until("document.getElementById('bagCount').textContent==='1'",'Caddy changed the bag.');
 await evaluate(`(()=>{document.getElementById('targetDistance').value='190';document.getElementById('bagSuggestion').click();if(!document.getElementById('caddyResult').textContent.includes('180 ft'))throw Error('Personal distance comparison failed');document.querySelector('#myBag [data-remove]').click();return true})()`);
 await until("document.getElementById('bagCount').textContent==='0'",'Bag removal did not persist.');
 await evaluate(`(async()=>{const pose=await import('./lib/pose.js'),canvas=document.createElement('canvas');canvas.width=640;canvas.height=480;canvas.getContext('2d').fillRect(0,0,640,480);pose.configurePose('full');const result=await pose.detectFrame(canvas);if(result.p||result.multi)throw Error('Blank image received an invented person pose');await pose.getHands();const points=Array.from({length:33},()=>({x:.5,y:.5,visibility:1}));points[11]={x:.4,y:.3,visibility:1};points[12]={x:.6,y:.3,visibility:1};points[23]={x:.45,y:.7,visibility:1};points[24]={x:.55,y:.7,visibility:1};points[14]={x:.65,y:.4,visibility:1};points[16]={x:.7,y:.5,visibility:1};const hand=await pose.detectHand(canvas,points,'right',640/480);if(hand)throw Error('Blank crop received an invented hand');return true})()`);
 await evaluate(`(async()=>{
  document.querySelector('[data-page=studio]').click();
  const c=document.createElement('canvas');c.width=320;c.height=240;const context=c.getContext('2d');context.fillRect(0,0,320,240);
  const stream=c.captureStream(15),chunks=[],recorder=new MediaRecorder(stream,{mimeType:'video/webm'});
  const done=new Promise(resolve=>{recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};recorder.onstop=resolve});
  recorder.start(100);let paints=0;const paint=setInterval(()=>{context.fillStyle=++paints%2?'#181818':'#191919';context.fillRect(0,0,320,240)},60);
  await new Promise(resolve=>setTimeout(resolve,1100));recorder.stop();await done;clearInterval(paint);stream.getTracks().forEach(t=>t.stop());
  const transfer=new DataTransfer();transfer.items.add(new File(chunks,'qa-no-person.webm',{type:'video/webm'}));
  const input=document.getElementById('file');input.files=transfer.files;input.dispatchEvent(new Event('change'));return true;
 })()`);
 await until("!document.getElementById('analyze').disabled&&!document.getElementById('player').hidden",'A real, generated no-person test video could not load.',30);
 // Real decoder, but deliberately suppress its seeked event: polling must recover.
 await evaluate(`(async()=>{
  const video=document.getElementById('video'),{seekVideoFrame}=await import('./lib/video-player.js');
  const suppress=event=>event.stopImmediatePropagation();video.addEventListener('seeked',suppress,true);
  try{await seekVideoFrame(video,.25,{timeout:3000});if(video.seeking||video.readyState<2)throw Error('Decoder not ready after recovered seek')}
  finally{video.removeEventListener('seeked',suppress,true)}
  // A real decoder with an Android-style rounded playhead must also finish.
  const descriptor=Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype,'currentTime');
  Object.defineProperty(video,'currentTime',{configurable:true,get(){return Math.floor(descriptor.get.call(this)*30)/30},set(time){descriptor.set.call(this,time)}});
  try{const actual=await seekVideoFrame(video,.58,{timeout:3000});if(Math.abs(actual-.58)>.043||video.seeking)throw Error('Rounded seek did not recover')}
  finally{delete video.currentTime}
  // Inject a decoding failure only in this test page. Partial evidence must survive.
  Object.defineProperty(video,'currentTime',{configurable:true,get(){return descriptor.get.call(this)},set(time){if(time>.3)throw Error('QA frame decode interruption');descriptor.set.call(this,time)}});
  document.getElementById('analyze').click();return true;
 })()`);
 await until("!document.getElementById('analyze').disabled&&!!document.querySelector('.review-interrupted')",'An interrupted analysis lost its partial review.',90);
 await evaluate(`(()=>{if(!document.getElementById('status').textContent.includes('Partial review kept'))throw Error('Interrupted analysis recovery instructions missing');delete document.getElementById('video').currentTime;return true})()`);
 await evaluate("document.getElementById('analyze').click()");
 await until("!document.getElementById('results').hidden&&!document.getElementById('analyze').disabled",'The no-person video analysis did not finish.',90);
 await evaluate(`(()=>{if(!document.getElementById('report').textContent.includes('Not enough clear'))throw Error('No-person footage did not receive an insufficient-evidence review');if(document.querySelectorAll('#reviewChecks .feedback').length)throw Error('No-person footage received personal coaching findings');return true})()`);
 // Measured carry uses the selected units and is saved with the actual session.
 await evaluate(`(()=>{document.getElementById('sessionCarryUnit').value='m';document.getElementById('sessionCarryUnit').dispatchEvent(new Event('change'));document.getElementById('sessionCarry').value='30';document.getElementById('sessionCarryReference').checked=true;document.getElementById('save').click();return true})()`);
 await until("!document.getElementById('save').disabled&&document.getElementById('status').textContent.includes('Saved. Find this video')",'Measured carry session did not save.');
 await evaluate(`(async()=>{const s=await import('./lib/storage.js'),rows=await s.listPlayerSessions(),saved=rows.find(r=>r.carryReference&&Math.abs(r.carryFt-30/.3048)<.01);if(!saved||'blob' in saved||'frames' in saved)throw Error('Measured carry metadata was lost or retained the full video');await s.deleteSession(saved.id);return true})()`);
 // Exercise orchestration with a real decoder and QA-only pose tokens, never
 // shown as model evidence or rendered into the app's user review.
 await evaluate(`(async()=>{
  const {analyzeVideo}=await import('./lib/video-analysis.js'),{createVideoSeeker}=await import('./lib/video-player.js');
  const video=document.getElementById('video'),descriptor=Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype,'currentTime');
  let detail=false,bodyCount=0;
  Object.defineProperty(video,'currentTime',{configurable:true,get(){return descriptor.get.call(this)},set(time){if(detail)throw Error('QA optional close-up decode failure');descriptor.set.call(this,time)}});
  try{
   const result=await analyzeVideo({video,seek:createVideoSeeker(video,{timeout:3000}),fps:15,handDetail:true,
    detectBody:async()=>({p:{qaOnly:true},world:null,multi:false}),prepareHands:async()=>{},detectHand:async()=>null,findRelease:()=>Math.min(.7,video.duration/2),
    onProgress:({phase})=>{if(phase==='hands'){detail=true}},onFrames:frames=>{if(!detail)bodyCount=frames.length}
   });
   if(!detail||!result.sampleInfo.bodyComplete||result.sampleInfo.incomplete||!result.sampleInfo.detailIncomplete||result.frames.length!==bodyCount)throw Error('Optional decode failure damaged completed body coverage');
   detail=false;
   const stopped=await analyzeVideo({video,seek:createVideoSeeker(video,{timeout:3000}),fps:15,handDetail:false,
    detectBody:async()=>({p:null,world:null,multi:false}),prepareHands:async()=>{throw Error('Unexpected hand pass')},findRelease:()=>null,
    onProgress:({phase})=>{if(phase!=='body'&&phase!=='complete')throw Error('Hand detail ran while disabled')}
   });
   if(!stopped.sampleInfo.bodyComplete)throw Error('Body-only pass did not finish');
  }finally{delete video.currentTime}
  return true;
 })()`);
 // A coordinate fixture exercises report rendering only; it is never user content or model evidence.
 await evaluate(`(async()=>{
  const {review}=await import('./lib/analysis.js'),{renderCoaching,renderPhaseStrip}=await import('./lib/report-ui.js');
  const frames=Array.from({length:20},(_,i)=>{const p=Array.from({length:33},()=>({x:.5,y:.5,visibility:1}));p[0]={x:.5,y:.1,visibility:1};p[11]={x:.4,y:.3,visibility:1};p[12]={x:.6,y:.3,visibility:1};p[23]={x:.45,y:.65,visibility:1};p[24]={x:.55,y:.65,visibility:1};p[14]={x:.65,y:.4,visibility:1};p[16]={x:.4+i*.02,y:.5,visibility:1};return {t:i/20,p}});
  const r=review(frames,{hand:'right',type:'backhand',view:'side',aspect:4/3,markers:{release:.6,plant:.4}});
  renderCoaching(r);renderPhaseStrip(r.phases);if(document.querySelectorAll('#report .feedback').length<12)throw Error('Whole-body review cards did not render');
  const missing=document.getElementById('reviewMissing');if(missing?.open)throw Error('Unavailable checks should start collapsed');
  document.querySelector('[data-filter=unknown]').click();if([...document.querySelectorAll('#report .feedback')].some(el=>!el.hidden&&el.dataset.kind!=='unknown')||missing&&!missing.open)throw Error('Unavailable-check filter failed');
  document.querySelector('[data-filter=all]').click();if(!document.getElementById('coachPlan').textContent.includes('practice plan'))throw Error('Practice walkthrough did not render');
  const focus=document.getElementById('practiceFocus');if(!focus)throw Error('Practice focus choice missing');
  focus.value='feet';focus.dispatchEvent(new Event('change'));
  const drill=document.getElementById('practiceDrill');if(!drill||drill.options.length<2)throw Error('No alternative drills for visible foot spacing');
  const firstPlan=document.getElementById('coachPlan').textContent;drill.value=drill.options[1].value;drill.dispatchEvent(new Event('change'));
  if(document.getElementById('coachPlan').textContent===firstPlan)throw Error('Changing the drill did not change the practice');
  if(!document.querySelector('#coachPlan [data-plan-seek]')||!document.querySelector('#report .video-evidence'))throw Error('Coaching did not expose video anchors');
  const select=document.getElementById('practiceFocus');select.value='xstep';select.dispatchEvent(new Event('change'));
  if(!document.getElementById('coachPlan').textContent.includes('general X-step lesson')||document.querySelector('#coachPlan [data-plan-seek]'))throw Error('General X-step lesson claimed personalized video evidence');
  if(document.querySelector('#report .review-details').open||[...document.querySelectorAll('.measurement-details')].some(el=>el.open))throw Error('Technical details should start closed');
  if(/torso lengths|Projected|°/.test(document.querySelector('#reviewChecks .feedback').innerText))throw Error('Technical measurements leaked into the primary coaching');
  if([...document.getElementById('results').children].indexOf(document.getElementById('coachPanel'))>[...document.getElementById('results').children].indexOf(document.getElementById('report')))throw Error('Practice plan should precede detailed cards');return true;
 })()`);
 // Return to a clean initial screen for the preview image: no fixture results or clips are shown.
 await send('Page.navigate',{url:origin+'/'});await until("document.querySelectorAll('#discCatalog .disc-card').length===60",'Could not return to a clean app screen.');

 const overflow=await evaluate('document.documentElement.scrollWidth>window.innerWidth+2');if(overflow)throw Error('Mobile page overflows horizontally.');
 if(errors.length)throw Error('Uncaught browser error: '+errors.join('\n'));
 await fs.mkdir(path.join(root,'artifacts'),{recursive:true});const screenshot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});await fs.writeFile(path.join(root,'artifacts/Fairway-Form-mobile.png'),Buffer.from(screenshot.data,'base64'));
 console.log('Browser checks passed: mobile startup, saved palettes with independent dark mode, voice controls and preview, human coaching with video anchors and drill choices, separately labeled X-step lessons and unavailable checks, optional measurements, missing-seeked and rounded-frame recovery, optional hand-pass failure isolation and disabling, partial-review retention, permission explanations, v1/v3 session migration, player-profile persistence, unit conversion, measured-review evidence and opt-out, personal caddy defaults, ten-brand catalog filters and pagination, manufacturer lessons, bundled-photo decoding, library search, bag edits and distance comparison, caddy bag-only recommendations and wind context, feet/meters conversion, confirmed sign text, next-lie logs and location opt-in, real bundled pose/hand-model initialization, no-person video rejection, and report rendering.');
}finally{
 ws?.close();browser?.kill('SIGTERM');server.close();for(let i=0;i<10;i++){try{await fs.rm(profile,{recursive:true,force:true});break}catch{await wait(100)}}
}
