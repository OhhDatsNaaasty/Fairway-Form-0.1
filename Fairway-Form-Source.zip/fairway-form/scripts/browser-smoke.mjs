// Run on GitHub's Ubuntu runner. Real browser + bundled models; no product demo data.
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn,spawnSync} from 'node:child_process';
import os from 'node:os';
import {DISCS} from '../dist/lib/discs.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),dist=path.join(root,'dist');
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const chrome=['google-chrome','google-chrome-stable','chromium','chromium-browser'].find(bin=>spawnSync('which',[bin],{stdio:'ignore'}).status===0);
if(!chrome)throw Error('A Chrome/Chromium browser is required for the interface/model smoke check. GitHub Ubuntu 24.04 includes Chrome.');
const mime={'.html':'text/html','.js':'application/javascript','.mjs':'application/javascript','.css':'text/css','.wasm':'application/wasm','.task':'application/octet-stream','.json':'application/json','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'};
const server=http.createServer(async(req,res)=>{try{const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);if(pathname==='/qa-setup.html'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><title>Test storage setup</title>');return}const target=path.resolve(dist,'.'+(pathname==='/'?'/index.html':pathname));if(!target.startsWith(dist+path.sep)){res.writeHead(403);res.end();return}const data=await fs.readFile(target);res.setHeader('Content-Type',mime[path.extname(target)]??'application/octet-stream');res.setHeader('Cache-Control','no-store');res.end(req.method==='HEAD'?undefined:data)}catch{res.writeHead(404);res.end('Not found')}});
const profile=await fs.mkdtemp(path.join(os.tmpdir(),'fairway-qa-'));let browser,ws;
try{
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
 const origin=`http://127.0.0.1:${server.address().port}`;
 const childEnv=Object.fromEntries(Object.entries(process.env).filter(([k])=>!/PASSWORD|TOKEN|SECRET|ANDROID_KEYSTORE/.test(k)));
 let browserLog='';let resolveDebugger,rejectDebugger;const debuggerReady=new Promise((resolve,reject)=>{resolveDebugger=resolve;rejectDebugger=reject});
 browser=spawn(chrome,['--headless=new','--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--no-first-run','--disable-background-networking',`--user-data-dir=${profile}`,'--remote-debugging-port=0','about:blank'],{env:childEnv,stdio:['ignore','ignore','pipe']});
 browser.stderr.on('data',data=>{browserLog+=data.toString();const m=browserLog.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m)resolveDebugger(m[1])});browser.once('error',rejectDebugger);browser.once('exit',code=>rejectDebugger(Error(`Chrome exited before debugger was available (${code}). ${browserLog.slice(-1000)}`)));
 let timer;const debuggerUrl=await Promise.race([debuggerReady,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Chrome did not expose a debugger in time.')),20000)})]).finally(()=>clearTimeout(timer));
 const pages=await (await fetch(debuggerUrl.replace(/^ws:/,'http:').replace(/\/devtools\/browser\/.*/, '/json/list'))).json();
 ws=new WebSocket(pages.find(p=>p.type==='page').webSocketDebuggerUrl);
 await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true})});
 let nextId=0;const pending=new Map(),errors=[];
 ws.addEventListener('message',event=>{const message=JSON.parse(event.data);if(message.id){const p=pending.get(message.id);if(p){pending.delete(message.id);clearTimeout(p.timer);message.error?p.reject(Error(message.error.message)):p.resolve(message.result)}}else if(message.method==='Runtime.exceptionThrown')errors.push(message.params.exceptionDetails.exception?.description??message.params.exceptionDetails.text)});
 function send(method,params={}){return new Promise((resolve,reject)=>{const id=++nextId,timer=setTimeout(()=>{pending.delete(id);reject(Error('Browser command timed out: '+method))},150000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}))})}
 async function evaluate(expression){const r=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);return r.result.value}
 async function until(expression,message,seconds=20){for(let i=0;i<seconds*5;i++){if(await evaluate(expression))return;await wait(200)}throw Error(message)}
 await send('Runtime.enable');await send('Page.enable');await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
 await send('Page.navigate',{url:origin+'/qa-setup.html'});await until("document.title==='Test storage setup'",'Could not open storage test page.');
 await evaluate(`new Promise((resolve,reject)=>{const r=indexedDB.open('fairway-form',1);r.onupgradeneeded=()=>r.result.createObjectStore('sessions',{keyPath:'id'});r.onerror=()=>reject(r.error);r.onsuccess=()=>{const db=r.result,tx=db.transaction('sessions','readwrite');tx.objectStore('sessions').put({id:'qa-legacy-session',created:1,name:'QA only',blob:new Blob([]),frames:[],trace:[],options:{hand:'right',type:'backhand',view:'side'},notes:''});tx.oncomplete=()=>{db.close();resolve(true)}}})`);
 await send('Page.navigate',{url:origin+'/'});await until("document.querySelectorAll('#discCatalog .disc-card').length===60&&document.querySelectorAll('#library .library-item').length>=35",'The app did not initialize its interface/catalog.');
 // Appearance is independent from the palette; dark mode preserves its accents.
 await evaluate(`(()=>{
  document.querySelector('[data-page=settings]').click();const palette=document.getElementById('appTheme'),mode=document.getElementById('appMode');
  if(palette.options.length!==3||mode.options.length!==3)throw Error('Palette or light/dark dropdown incomplete');
  const accentKeys=['--forest','--trim','--water','--clay','--sun'];
  for(const value of ['forest','coast','sunset']){
   palette.value=value;palette.dispatchEvent(new Event('change'));mode.value='light';mode.dispatchEvent(new Event('change'));
   const original=accentKeys.map(key=>getComputedStyle(document.documentElement).getPropertyValue(key));
   mode.value='dark';mode.dispatchEvent(new Event('change'));
   if(document.documentElement.dataset.theme!==value||document.documentElement.dataset.mode!=='dark')throw Error('Dark mode replaced the selected palette');
   if(accentKeys.some((key,i)=>getComputedStyle(document.documentElement).getPropertyValue(key)!==original[i]))throw Error('Dark mode changed accent colors');
   if(getComputedStyle(document.body).backgroundColor!=='rgb(37, 40, 41)')throw Error('Dark background is not gray');
  }
  return true;
 })()`);
 await send('Page.navigate',{url:origin+'/#settings'});await until("document.getElementById('appTheme')?.value==='sunset'&&document.getElementById('appMode')?.value==='dark'",'Saved palette or dark mode was lost on restart.');
 await send('Emulation.setEmulatedMedia',{features:[{name:'prefers-color-scheme',value:'dark'}]});
 await evaluate(`(()=>{const select=document.getElementById('appMode');select.value='system';select.dispatchEvent(new Event('change'));if(document.documentElement.dataset.mode!=='dark'||document.documentElement.dataset.theme!=='sunset')throw Error('Automatic dark mode changed the palette');return true})()`);
 await send('Emulation.setEmulatedMedia',{features:[{name:'prefers-color-scheme',value:'light'}]});
 await until("document.documentElement.dataset.mode==='light'&&document.documentElement.dataset.theme==='sunset'",'Phone light mode did not update automatically.');
 // A test bridge exercises voice controls without requiring audio hardware.
 await evaluate(`(()=>{
  window.AndroidFiles={stopSpeaking(){},setSpeechOptions(...args){window.qaVoiceOptions=args},speak(text){window.qaVoiceText=text}};
  window.dispatchEvent(new CustomEvent('fairway-voices',{detail:{voices:[{id:'qa-offline',label:'QA offline',lang:'en-US',quality:400,network:false,installed:true},{id:'qa-online',label:'QA online',lang:'en-US',quality:500,network:true,installed:true}]}}));
  const voice=document.getElementById('coachVoice'),online=document.getElementById('onlineVoices'),rate=document.getElementById('voiceRate');
  if(voice.options.length!==2)throw Error('Internet voice offered by default');
  online.checked=true;online.dispatchEvent(new Event('change'));if(voice.options.length!==3)throw Error('Optional online voice not offered');
  online.checked=false;online.dispatchEvent(new Event('change'));voice.value='qa-offline';voice.dispatchEvent(new Event('change'));
  rate.value='1.1';rate.dispatchEvent(new Event('change'));document.getElementById('previewVoice').click();
  if(window.qaVoiceOptions[0]!=='qa-offline'||window.qaVoiceOptions[1]!==1.1||window.qaVoiceOptions[2]!==false||!window.qaVoiceText.includes('comfortable effort'))throw Error('Voice preview did not use selected options');
  voice.value='';voice.dispatchEvent(new Event('change'));rate.value='1';rate.dispatchEvent(new Event('change'));
  delete window.AndroidFiles;delete window.qaVoiceOptions;delete window.qaVoiceText;
  window.dispatchEvent(new CustomEvent('fairway-voices',{detail:{voices:[]}}));
  const palette=document.getElementById('appTheme'),mode=document.getElementById('appMode');palette.value='forest';palette.dispatchEvent(new Event('change'));mode.value='light';mode.dispatchEvent(new Event('change'));document.querySelector('[data-page=studio]').click();return true;
 })()`);
 await evaluate(`(()=>{document.getElementById('camera').click();if(!document.getElementById('accessDialog').open)throw Error('Camera prompt did not open');document.getElementById('accessCancel').click();if(document.getElementById('accessDialog').open)throw Error('Camera prompt did not close');document.getElementById('upload').click();if(!document.getElementById('accessTitle').textContent.includes('gallery'))throw Error('Gallery explanation missing');document.getElementById('accessCancel').click();return true})()`);
 await evaluate(`(async()=>{const s=await import('./lib/storage.js');if(!(await s.listSessions()).some(v=>v.id==='qa-legacy-session'))throw Error('Storage migration lost an old session');await s.deleteSession('qa-legacy-session');return true})()`);
 // Every requested brand is reachable, and pagination exposes the full catalog.
 await evaluate(`(()=>{
  document.querySelector('[data-page=discs]').click();const brand=document.getElementById('discBrand');
  const counts=${JSON.stringify(Object.fromEntries([...new Set(DISCS.map(d=>d.brand))].map(b=>[b,DISCS.filter(d=>d.brand===b).length])))};
  if(brand.options.length!==11)throw Error('Requested manufacturers are missing');
  for(const [name,count]of Object.entries(counts)){brand.value=name;brand.dispatchEvent(new Event('change'));if(document.querySelectorAll('#discCatalog .disc-card').length!==Math.min(60,count))throw Error('Brand filter failed: '+name)}
  brand.value='';brand.dispatchEvent(new Event('change'));for(let i=0;i<10&&!document.getElementById('moreMolds').hidden;i++)document.getElementById('moreMolds').click();
  if(document.querySelectorAll('#discCatalog .disc-card').length!==${DISCS.length})throw Error('Pagination did not expose the full catalog');
  const search=document.getElementById('discSearch');search.value='trashpanda';search.dispatchEvent(new Event('input'));if(document.querySelectorAll('#discCatalog .disc-card').length!==5)throw Error('Manufacturer-name search failed');search.value='';search.dispatchEvent(new Event('input'));
  document.querySelector('[data-page=learn]').click();const source=document.getElementById('knowledgePublisher');source.value='Prodigy';source.dispatchEvent(new Event('change'));
  if(document.querySelectorAll('#library .library-item').length<4)throw Error('Manufacturer lessons missing');source.value='';source.dispatchEvent(new Event('change'));return true;
 })()`);
 // Only actual bundled photos are counted. Each file must decode in the browser.
 await evaluate(`(async()=>{
  const index=await (await fetch('./disc-photos/index.json')).json();
  for(const item of Object.values(index.images??{})){const img=new Image();img.src=item.src;await img.decode();if(!img.naturalWidth||!img.naturalHeight)throw Error('A bundled photo could not decode')}
  return true;
 })()`);
 await evaluate(`(()=>{document.querySelector('[data-page=learn]').click();const input=document.getElementById('search');input.value='brace';input.dispatchEvent(new Event('input'));if(!document.querySelector('#library .library-item'))throw Error('Technique search failed');input.value='';input.dispatchEvent(new Event('input'));document.querySelector('[data-page=discs]').click();document.querySelector('#discCatalog [data-add]').click();return true})()`);
 await until("document.getElementById('bagCount').textContent==='1'",'Adding a disc to the bag did not persist.');
 await evaluate(`(()=>{document.getElementById('showBag').click();const field=document.querySelector('#myBag [data-field=distance]');field.value='180';field.dispatchEvent(new Event('change'));return true})()`);
 await until("document.querySelector('.bag-save-state').textContent.includes('Saved')",'Bag field edit did not save.');
 await evaluate(`(()=>{document.getElementById('targetDistance').value='190';document.getElementById('bagSuggestion').click();if(!document.getElementById('caddyResult').textContent.includes('180 ft'))throw Error('Personal distance comparison failed');document.querySelector('#myBag [data-remove]').click();return true})()`);
 await until("document.getElementById('bagCount').textContent==='0'",'Bag removal did not persist.');
 await evaluate(`(async()=>{const pose=await import('./lib/pose.js'),canvas=document.createElement('canvas');canvas.width=640;canvas.height=480;canvas.getContext('2d').fillRect(0,0,640,480);pose.configurePose('full');const result=await pose.detectFrame(canvas);if(result.p||result.multi)throw Error('Blank image received an invented person pose');await pose.getHands();const points=Array.from({length:33},()=>({x:.5,y:.5,visibility:1}));points[11]={x:.4,y:.3,visibility:1};points[12]={x:.6,y:.3,visibility:1};points[23]={x:.45,y:.7,visibility:1};points[24]={x:.55,y:.7,visibility:1};points[14]={x:.65,y:.4,visibility:1};points[16]={x:.7,y:.5,visibility:1};const hand=await pose.detectHand(canvas,points,'right',640/480);if(hand)throw Error('Blank crop received an invented hand');return true})()`);
 await evaluate(`(async()=>{
  document.querySelector('[data-page=studio]').click();
  const c=document.createElement('canvas');c.width=320;c.height=240;const context=c.getContext('2d');context.fillRect(0,0,320,240);
  const stream=c.captureStream(15),chunks=[],recorder=new MediaRecorder(stream,{mimeType:'video/webm'});
  const done=new Promise(resolve=>{recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};recorder.onstop=resolve});
  recorder.start(100);let paints=0;const paint=setInterval(()=>{context.fillStyle=++paints%2?'#181818':'#191919';context.fillRect(0,0,320,240)},60);
  await new Promise(resolve=>setTimeout(resolve,1100));recorder.stop();await done;clearInterval(paint);stream.getTracks().forEach(t=>t.stop());
  const transfer=new DataTransfer();transfer.items.add(new File(chunks,'qa-no-person.webm',{type:'video/webm'}));
  const input=document.getElementById('file');input.files=transfer.files;input.dispatchEvent(new Event('change'));return true;
 })()`);
 await until("!document.getElementById('analyze').disabled&&!document.getElementById('player').hidden",'A real, generated no-person test video could not load.',30);
 // Real decoder, but deliberately suppress its seeked event: polling must recover.
 await evaluate(`(async()=>{
  const video=document.getElementById('video'),{seekVideoFrame}=await import('./lib/video-player.js');
  const suppress=event=>event.stopImmediatePropagation();video.addEventListener('seeked',suppress,true);
  try{await seekVideoFrame(video,.25,{timeout:3000});if(video.seeking||video.readyState<2)throw Error('Decoder not ready after recovered seek')}
  finally{video.removeEventListener('seeked',suppress,true)}
  // Inject a decoding failure only in this test page. Partial evidence must survive.
  const descriptor=Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype,'currentTime');
  Object.defineProperty(video,'currentTime',{configurable:true,get(){return descriptor.get.call(this)},set(time){if(time>.3)throw Error('QA frame decode interruption');descriptor.set.call(this,time)}});
  document.getElementById('analyze').click();return true;
 })()`);
 await until("!document.getElementById('analyze').disabled&&!!document.querySelector('.review-interrupted')",'An interrupted analysis lost its partial review.',90);
 await evaluate(`(()=>{if(!document.getElementById('status').textContent.includes('Partial review kept'))throw Error('Interrupted analysis recovery instructions missing');delete document.getElementById('video').currentTime;return true})()`);
 await evaluate("document.getElementById('analyze').click()");
 await until("!document.getElementById('results').hidden&&!document.getElementById('analyze').disabled",'The no-person video analysis did not finish.',90);
 await evaluate(`(()=>{if(!document.getElementById('report').textContent.includes('Not enough clear'))throw Error('No-person footage did not receive an insufficient-evidence review');if(document.querySelectorAll('#reviewChecks .feedback').length)throw Error('No-person footage received personal coaching findings');return true})()`);
 // A coordinate fixture exercises report rendering only; it is never user content or model evidence.
 await evaluate(`(async()=>{
  const {review}=await import('./lib/analysis.js'),{renderCoaching,renderPhaseStrip}=await import('./lib/report-ui.js');
  const frames=Array.from({length:20},(_,i)=>{const p=Array.from({length:33},()=>({x:.5,y:.5,visibility:1}));p[0]={x:.5,y:.1,visibility:1};p[11]={x:.4,y:.3,visibility:1};p[12]={x:.6,y:.3,visibility:1};p[23]={x:.45,y:.65,visibility:1};p[24]={x:.55,y:.65,visibility:1};p[14]={x:.65,y:.4,visibility:1};p[16]={x:.4+i*.02,y:.5,visibility:1};return {t:i/20,p}});
  const r=review(frames,{hand:'right',type:'backhand',view:'side',aspect:4/3,markers:{release:.6,plant:.4}});
  renderCoaching(r);renderPhaseStrip(r.phases);if(document.querySelectorAll('#reviewChecks .feedback').length<12)throw Error('Whole-body review cards did not render');
  document.querySelector('[data-filter=unknown]').click();if([...document.querySelectorAll('#reviewChecks .feedback')].some(el=>!el.hidden&&el.dataset.kind!=='unknown'))throw Error('Unknown-evidence filter failed');
  document.querySelector('[data-filter=all]').click();if(!document.getElementById('coachPlan').textContent.includes('practice plan'))throw Error('Practice walkthrough did not render');
  if(document.querySelector('#report .review-details').open||[...document.querySelectorAll('.measurement-details')].some(el=>el.open))throw Error('Technical details should start closed');
  if(/torso lengths|Projected|°/.test(document.querySelector('#reviewChecks .feedback').innerText))throw Error('Technical measurements leaked into the primary coaching');
  if([...document.getElementById('results').children].indexOf(document.getElementById('coachPanel'))>[...document.getElementById('results').children].indexOf(document.getElementById('report')))throw Error('Practice plan should precede detailed cards');return true;
 })()`);
 // Return to a clean initial screen for the preview image: no fixture results or clips are shown.
 await send('Page.navigate',{url:origin+'/'});await until("document.querySelectorAll('#discCatalog .disc-card').length===60",'Could not return to a clean app screen.');

 const overflow=await evaluate('document.documentElement.scrollWidth>window.innerWidth+2');if(overflow)throw Error('Mobile page overflows horizontally.');
 if(errors.length)throw Error('Uncaught browser error: '+errors.join('\n'));
 await fs.mkdir(path.join(root,'artifacts'),{recursive:true});const screenshot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});await fs.writeFile(path.join(root,'artifacts/Fairway-Form-mobile.png'),Buffer.from(screenshot.data,'base64'));
 console.log('Browser checks passed: mobile startup, saved palettes with independent dark mode, voice controls and preview, human coaching with optional measurements, missing-seeked recovery, partial-review retention, permission explanations, v1 session migration, ten-brand catalog filters and pagination, manufacturer lessons, bundled-photo decoding, library search, bag edits and distance comparison, real bundled pose/hand-model initialization, no-person video rejection, and report rendering.');
}finally{
 ws?.close();browser?.kill('SIGTERM');server.close();for(let i=0;i<10;i++){try{await fs.rm(profile,{recursive:true,force:true});break}catch{await wait(100)}}
}
