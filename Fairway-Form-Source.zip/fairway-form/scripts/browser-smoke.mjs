// Run on GitHub's Ubuntu runner. Real browser + bundled models; no product demo data.
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {launchChrome} from './lib/chrome-runner.mjs';
import {DISCS} from '../dist/lib/discs.js';
import {assertCaddySelection} from './lib/caddy-smoke.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),dist=path.join(root,'dist');
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const chrome=[];
for(const candidate of ['google-chrome','google-chrome-stable','chromium','chromium-browser']){
 const found=spawnSync('which',[candidate],{encoding:'utf8'});if(found.status!==0)continue;
 const executable=found.stdout.trim(),canonical=await fs.realpath(executable).catch(()=>executable);
 if(!chrome.includes(canonical))chrome.push(canonical);
}
if(!chrome.length)throw Error('A Chrome/Chromium browser is required for the interface/model smoke check. GitHub Ubuntu 24.04 includes Chrome.');
const mime={'.html':'text/html','.js':'application/javascript','.mjs':'application/javascript','.css':'text/css','.wasm':'application/wasm','.task':'application/octet-stream','.json':'application/json','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'};
const server=http.createServer(async(req,res)=>{try{const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);if(pathname==='/qa-setup.html'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><title>Test storage setup</title>');return}const target=path.resolve(dist,'.'+(pathname==='/'?'/index.html':pathname));if(!target.startsWith(dist+path.sep)){res.writeHead(403);res.end();return}const data=await fs.readFile(target);res.setHeader('Content-Type',mime[path.extname(target)]??'application/octet-stream');res.setHeader('Cache-Control','no-store');res.end(req.method==='HEAD'?undefined:data)}catch{res.writeHead(404);res.end('Not found')}});
let browser;
try{
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
 const origin=`http://127.0.0.1:${server.address().port}`;
 browser=await launchChrome({binaries:chrome});
 const send=(method,params={})=>browser.send(method,params);
 async function evaluate(expression){const r=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);return r.result.value}
 async function until(expression,message,seconds=20){for(let i=0;i<seconds*5;i++){if(await evaluate(expression))return;await wait(200)}const state=await evaluate(`JSON.stringify({caddyState:document.getElementById('caddy')?.dataset.state,caddyStatus:document.getElementById('caddyStatus')?.textContent,courseStatus:document.getElementById('courseStatus')?.textContent,bagCount:document.getElementById('bagCount')?.textContent})`).catch(()=>null);throw Error(message+(state?' · '+state:''))}
 await send('Runtime.enable');await send('Page.enable');await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
 await send('Page.navigate',{url:origin+'/qa-setup.html'});await until("document.title==='Test storage setup'",'Could not open storage test page.');
 await evaluate(`new Promise((resolve,reject)=>{const r=indexedDB.open('fairway-form',1);r.onupgradeneeded=()=>r.result.createObjectStore('sessions',{keyPath:'id'});r.onerror=()=>reject(r.error);r.onsuccess=()=>{const db=r.result,tx=db.transaction('sessions','readwrite');tx.objectStore('sessions').put({id:'qa-legacy-session',created:1,name:'QA only',blob:new Blob([]),frames:[],trace:[],options:{hand:'right',type:'backhand',view:'side'},notes:''});tx.oncomplete=()=>{db.close();resolve(true)}}})`);
 // Upgrade an existing v3 database, preserving the original v1 journal record.
 await evaluate(`new Promise((resolve,reject)=>{const r=indexedDB.open('fairway-form',3);r.onupgradeneeded=()=>{for(const name of ['bag','catalog','caddyHoles'])r.result.createObjectStore(name,{keyPath:'id'})};r.onerror=()=>reject(r.error);r.onsuccess=()=>{r.result.close();resolve(true)}})`);
 // Upgrade the last shipped v4 schema before the app adds courses in v5.
 await evaluate(`new Promise((resolve,reject)=>{const r=indexedDB.open('fairway-form',4);r.onupgradeneeded=()=>r.result.createObjectStore('player',{keyPath:'id'});r.onerror=()=>reject(r.error);r.onsuccess=()=>{const db=r.result,tx=db.transaction(['bag','player'],'readwrite');tx.objectStore('bag').put({id:'qa-migrate-bag',discId:'innova-aviar',condition:'Stock'});tx.objectStore('player').put({id:'player',schemaVersion:1,unit:'ft',age:40,heightCm:177.8,hand:'right',preferredThrow:'backhand',comfortablePuttFt:25,maxSpeed:9});tx.oncomplete=()=>{db.close();resolve(true)}}})`);
 await send('Page.navigate',{url:origin+'/'});await until("document.querySelectorAll('#discCatalog .disc-card').length===60&&document.querySelectorAll('#library .library-item').length>=35",'The app did not initialize its interface/catalog.');
 // Appearance is independent from the palette; dark mode preserves its accents.
 await evaluate(`(()=>{
  document.querySelector('[data-page=settings]').click();const palette=document.getElementById('appTheme'),mode=document.getElementById('appMode');
  if(palette.options.length!==3||mode.options.length!==3||document.getElementById('appGraphics').options.length!==4)throw Error('Palette or light/dark dropdown incomplete');
  const graphics=document.getElementById('appGraphics');
  for(const value of ['minimal','park','woodland','ridgeline']){graphics.value=value;graphics.dispatchEvent(new Event('change'));if(document.documentElement.dataset.graphics!==value)throw Error('Course scene selection failed')}
  const accentKeys=['--forest','--trim','--water','--clay','--sun'];
  for(const value of ['forest','coast','sunset']){
   palette.value=value;palette.dispatchEvent(new Event('change'));mode.value='light';mode.dispatchEvent(new Event('change'));
   const original=accentKeys.map(key=>getComputedStyle(document.documentElement).getPropertyValue(key));
   mode.value='dark';mode.dispatchEvent(new Event('change'));
   if(document.documentElement.dataset.theme!==value||document.documentElement.dataset.mode!=='dark')throw Error('Dark mode replaced the selected palette');
   if(accentKeys.some((key,i)=>getComputedStyle(document.documentElement).getPropertyValue(key)!==original[i]))throw Error('Dark mode changed accent colors');
   if(getComputedStyle(document.body).backgroundColor!=='rgb(37, 40, 41)')throw Error('Dark background is not gray');
  }
  return true;
 })()`);
 await send('Page.navigate',{url:origin+'/#settings'});await until("document.getElementById('appTheme')?.value==='sunset'&&document.getElementById('appMode')?.value==='dark'&&document.getElementById('appGraphics')?.value==='ridgeline'",'Saved palette or dark mode was lost on restart.');
 await send('Emulation.setEmulatedMedia',{features:[{name:'prefers-color-scheme',value:'dark'}]});
 await evaluate(`(()=>{const select=document.getElementById('appMode');select.value='system';select.dispatchEvent(new Event('change'));if(document.documentElement.dataset.mode!=='dark'||document.documentElement.dataset.theme!=='sunset')throw Error('Automatic dark mode changed the palette');return true})()`);
 await send('Emulation.setEmulatedMedia',{features:[{name:'prefers-color-scheme',value:'light'}]});
 await until("document.documentElement.dataset.mode==='light'&&document.documentElement.dataset.theme==='sunset'",'Phone light mode did not update automatically.');
 // A test bridge exercises voice controls without requiring audio hardware.
 await evaluate(`(()=>{
  window.AndroidFiles={stopSpeaking(){},setSpeechOptions(...args){window.qaVoiceOptions=args},speak(text){window.qaVoiceText=text}};
  window.dispatchEvent(new CustomEvent('fairway-voices',{detail:{voices:[{id:'qa-offline',label:'QA offline',lang:'en-US',quality:400,network:false,installed:true},{id:'qa-online',label:'QA online',lang:'en-US',quality:500,network:true,installed:true}]}}));
  const voice=document.getElementById('coachVoice'),online=document.getElementById('onlineVoices'),rate=document.getElementById('voiceRate');
  if(voice.options.length!==2)throw Error('Internet voice offered by default');
  online.checked=true;online.dispatchEvent(new Event('change'));if(voice.options.length!==3)throw Error('Optional online voice not offered');
  online.checked=false;online.dispatchEvent(new Event('change'));voice.value='qa-offline';voice.dispatchEvent(new Event('change'));
  rate.value='1.1';rate.dispatchEvent(new Event('change'));document.getElementById('previewVoice').click();
  if(window.qaVoiceOptions[0]!=='qa-offline'||window.qaVoiceOptions[1]!==1.1||window.qaVoiceOptions[2]!==false||!window.qaVoiceText.includes('comfortable effort'))throw Error('Voice preview did not use selected options');
  voice.value='';voice.dispatchEvent(new Event('change'));rate.value='1';rate.dispatchEvent(new Event('change'));
  delete window.AndroidFiles;delete window.qaVoiceOptions;delete window.qaVoiceText;
  window.dispatchEvent(new CustomEvent('fairway-voices',{detail:{voices:[]}}));
  const palette=document.getElementById('appTheme'),mode=document.getElementById('appMode');palette.value='forest';palette.dispatchEvent(new Event('change'));mode.value='light';mode.dispatchEvent(new Event('change'));document.querySelector('[data-page=studio]').click();return true;
 })()`);
 await evaluate(`(()=>{document.getElementById('camera').click();if(!document.getElementById('accessDialog').open)throw Error('Camera prompt did not open');document.getElementById('accessCancel').click();if(document.getElementById('accessDialog').open)throw Error('Camera prompt did not close');document.getElementById('upload').click();if(!document.getElementById('accessTitle').textContent.includes('gallery'))throw Error('Gallery explanation missing');document.getElementById('accessCancel').click();return true})()`);
 await evaluate(`(async()=>{const s=await import('./lib/storage.js');if(!(await s.listSessions()).some(v=>v.id==='qa-legacy-session'))throw Error('Storage migration lost an old session');await s.deleteSession('qa-legacy-session');return true})()`);
 await evaluate(`(async()=>{const s=await import('./lib/storage.js');if(!(await s.listBag()).some(b=>b.id==='qa-migrate-bag'))throw Error('v4 migration lost a bag copy');if((await s.getPlayer())?.heightCm!==177.8)throw Error('v4 migration lost the player profile');if((await s.listCourses()).length)throw Error('New courses store was not empty');await s.deleteBagItem('qa-migrate-bag');return true})()`);
 // Every requested brand is reachable, and pagination exposes the full catalog.
 await evaluate(`(()=>{
  document.querySelector('[data-page=discs]').click();const brand=document.getElementById('discBrand');
  const counts=${JSON.stringify(Object.fromEntries([...new Set(DISCS.map(d=>d.brand))].map(b=>[b,DISCS.filter(d=>d.brand===b).length])))};
  if(brand.options.length!==${new Set(DISCS.map(d=>d.brand)).size+1})throw Error('Requested manufacturers are missing');
  for(const [name,count]of Object.entries(counts)){brand.value=name;brand.dispatchEvent(new Event('change'));if(document.querySelectorAll('#discCatalog .disc-card').length!==Math.min(60,count))throw Error('Brand filter failed: '+name)}
  brand.value='';brand.dispatchEvent(new Event('change'));for(let i=0;i<${Math.ceil(DISCS.length/60)+1}&&!document.getElementById('moreMolds').hidden;i++)document.getElementById('moreMolds').click();
  if(document.querySelectorAll('#discCatalog .disc-card').length!==${DISCS.length})throw Error('Pagination did not expose the full catalog');
  const search=document.getElementById('discSearch');search.value='trashpanda';search.dispatchEvent(new Event('input'));if(document.querySelectorAll('#discCatalog .disc-card').length!==5)throw Error('Manufacturer-name search failed');search.value='buzzsaw';search.dispatchEvent(new Event('input'));if(document.querySelectorAll('#discCatalog .disc-card').length!==1||!document.querySelector('#discCatalog [data-add=discraft-buzzz][data-version=buzzzsaw]'))throw Error('BuzzzSaw variant was not findable');if(!document.getElementById('catalogFlightCoverage').textContent.includes('${DISCS.length} of ${DISCS.length}'))throw Error('Catalog flight coverage missing');search.value='';search.dispatchEvent(new Event('input'));
  document.querySelector('[data-page=learn]').click();const source=document.getElementById('knowledgePublisher');source.value='Prodigy';source.dispatchEvent(new Event('change'));
  if(document.querySelectorAll('#library .library-item').length<4)throw Error('Manufacturer lessons missing');source.value='';source.dispatchEvent(new Event('change'));return true;
 })()`);
 // Only actual bundled photos are counted. Each file must decode in the browser.
 await evaluate(`(async()=>{
  const index=await (await fetch('./disc-photos/index.json')).json();
  for(const item of Object.values(index.images??{})){const img=new Image();img.src=item.src;await img.decode();if(!img.naturalWidth||!img.naturalHeight)throw Error('A bundled photo could not decode')}
  return true;
 })()`);
 await evaluate(`(()=>{document.querySelector('[data-page=learn]').click();const input=document.getElementById('search');input.value='brace';input.dispatchEvent(new Event('input'));if(!document.querySelector('#library .library-item'))throw Error('Technique search failed');input.value='';input.dispatchEvent(new Event('input'));document.querySelector('[data-page=discs]').click();document.querySelector('#discCatalog [data-add="axiom-crave"]').click();return true})()`);
 await until("document.getElementById('bagCount').textContent==='1'",'Adding a disc to the bag did not persist.');
 await until("document.querySelector('[data-catalog-id=axiom-crave] .disc-ownership')?.textContent.includes('1 in your bag')",'Catalog did not show the saved bag copy.');
 await evaluate(`(()=>{document.querySelector('#discCatalog [data-add=axiom-crave]').click();return true})()`);
 await until("document.querySelector('[data-catalog-id=axiom-crave] .disc-ownership')?.textContent.includes('2 in your bag')",'Second physical copy was not counted.');
 await evaluate(`(()=>{document.getElementById('showBag').click();document.querySelector('#myBag [data-remove]').click();return true})()`);
 await until("document.getElementById('bagCount').textContent==='1'&&document.querySelector('[data-catalog-id=axiom-crave] .disc-ownership')?.textContent.includes('1 in your bag')",'Removing one copy did not update catalog ownership.');

 await evaluate(`(()=>{document.getElementById('showBag').click();const field=document.querySelector('#myBag [data-field=distance]');field.value='180';field.dispatchEvent(new Event('change'));return true})()`);
 await until("document.querySelector('.bag-save-state').textContent.includes('Saved')",'Bag field edit did not save.');
 // Profile inputs persist independently from videos and keep units meaningful.
 await evaluate(`(()=>{document.querySelector('nav [data-page=settings]').click();return true})()`);
 await until("!document.getElementById('playerForm').inert&&document.getElementById('playerEvidence').textContent.includes('comparable')",'Player profile did not open.');
 await evaluate(`(()=>{const set=(id,value)=>{document.getElementById(id).value=value};set('player_gender','Prefer not to say');set('player_age','40');set('playerHeight','70');set('playerHeightUnit','in');document.getElementById('playerHeightUnit').dispatchEvent(new Event('change'));set('playerHeight','70');set('playerHeightUnit','cm');document.getElementById('playerHeightUnit').dispatchEvent(new Event('change'));if(Math.abs(Number(document.getElementById('playerHeight').value)-177.8)>.1)throw Error('Player height conversion changed physical height');set('player_averageBackhandFt','250');set('player_averageForehandFt','170');set('player_comfortablePuttFt','25');set('player_maxSpeed','9');set('player_skill','beginner');set('playerUnit','m');document.getElementById('playerUnit').dispatchEvent(new Event('change'));if(Math.abs(Number(document.getElementById('player_averageBackhandFt').value)-76.2)>.05)throw Error('Player distance conversion changed carry');set('playerUnit','ft');document.getElementById('playerUnit').dispatchEvent(new Event('change'));document.getElementById('playerForm').requestSubmit();return true})()`);
 await until("document.getElementById('playerStatus').textContent.includes('Profile saved')",'Player profile did not save.');
 await evaluate(`(async()=>{const s=await import('./lib/storage.js'),p=await s.getPlayer();if(p.age!==40||p.heightCm!==177.8||p.skill!=='beginner'||Math.abs(p.averageBackhandFt-250)>.05)throw Error('Player facts were not persisted correctly');const now=Date.now();for(let i=0;i<3;i++)await s.storeSession({id:'qa-player-'+i,created:now-i,options:{hand:'right',type:'backhand',view:'side',stance:'walkup',cameraStable:true},markers:{release:1,plant:.8},blob:new Blob([]),frames:[],trace:[],carryFt:220+i*10,carryReference:true,report:{coverage:.9,quality:{},findings:[{id:'brace',kind:'attention',t:.8}]}});const {renderPlayer}=await import('./lib/player-ui.js');await renderPlayer();if(!document.getElementById('playerEvidence').textContent.includes('3 of 3'))throw Error('Saved form reviews were not connected to player evidence');document.getElementById('playerUseSaved').checked=false;document.getElementById('playerForm').requestSubmit();return true})()`);
 await until("document.getElementById('playerEvidence').textContent.includes('learning is off')",'Review learning opt-out did not apply.');
 await evaluate(`(async()=>{const s=await import('./lib/storage.js');for(let i=0;i<3;i++)await s.deleteSession('qa-player-'+i);document.getElementById('playerUseSaved').checked=true;document.getElementById('playerForm').requestSubmit();return true})()`);
 await until("!document.getElementById('playerSave').disabled&&document.getElementById('playerEvidence').textContent.includes('0 comparable')",'Deleted review evidence remained in the player profile.');
 // Caddy uses the actual stored test bag, keeps next-lie distance separate,
 // and upgrades the v1 database without losing its journal/bag stores.
 await evaluate(`(()=>{document.querySelector('nav [data-page=caddy]').click();return true})()`);
 await until("document.getElementById('caddy').dataset.state==='ready'&&!document.getElementById('caddyWorkspace').inert&&document.getElementById('caddyLie').textContent.includes('THROW 1')&&!document.getElementById('caddy').hidden",'Caddy did not open from navigation.');
 await evaluate(`(()=>{if(document.getElementById('caddyMaxSpeed').value!=='9'||document.getElementById('caddyPuttRange').value!=='25')throw Error('Loaded caddy hole did not use personal limits: speed='+document.getElementById('caddyMaxSpeed').value+', putting='+document.getElementById('caddyPuttRange').value+', units='+document.getElementById('caddyUnits').value);return true})()`);
 await evaluate(`(()=>{const set=(id,value)=>{const el=document.getElementById(id);el.value=value;el.dispatchEvent(new Event('change'))};set('caddyDistance','190');set('caddyFairway','straight');set('caddyWindDirection','head');set('caddyWindStrength','medium');document.getElementById('caddyRecommend').click();return true})()`);
 await until("document.querySelectorAll('#caddyPlan .caddy-choice').length===1",'Caddy did not use the single actual bag copy.');
 await evaluate(`(()=>{if(!document.getElementById('caddyPlan').textContent.includes('headwind'))throw Error('Wind context missing');document.getElementById('caddyUnits').value='m';document.getElementById('caddyUnits').dispatchEvent(new Event('change'));if(Math.abs(Number(document.getElementById('caddyDistance').value)-57.9)>.2)throw Error('Caddy units changed the real distance');document.getElementById('caddyUnits').value='ft';document.getElementById('caddyUnits').dispatchEvent(new Event('change'));document.getElementById('caddySignText').value='Hole 8 Blue 320 ft Red 85 m Dogleg left Uphill';document.getElementById('caddyParseSign').click();if(document.getElementById('caddySignDistance').options.length!==3)throw Error('Sign distances were not kept as choices');document.getElementById('caddySignDistance').value='0';document.getElementById('caddyApplySign').click();if(document.getElementById('caddyDistance').value!=='320'||document.getElementById('caddyFairway').value!=='left')throw Error('Confirmed sign details did not apply');document.getElementById('caddyRecommend').click();return true})()`);
 await until("!document.getElementById('caddyLogPanel').hidden",'Updated lie did not receive a fresh caddy plan.');
 await evaluate(`(()=>{document.getElementById('caddyOutcome').value='made';document.getElementById('caddyOutcome').dispatchEvent(new Event('change'));document.getElementById('caddyOutcome').value='short';document.getElementById('caddyOutcome').dispatchEvent(new Event('change'));if(document.getElementById('caddyRemaining').value==='0')throw Error('Changed outcome retained an automatic zero distance');document.getElementById('caddyRemaining').value='60';document.getElementById('caddyActualDistance').value='250';document.getElementById('caddyActualAngle').value='hyzer';document.getElementById('caddyActualHand').value='left';document.getElementById('caddyActualType').value='forehand';document.getElementById('caddyQuality').value='great';document.getElementById('caddyExecution').value='clean';document.getElementById('caddyFlight').value='flipped-flat';document.getElementById('caddyDistanceMethod').value='measured';document.getElementById('caddyRecord').click();return true})()`);
 await until("document.getElementById('caddyLie').textContent.includes('THROW 2')",'Recorded tee throw did not advance the lie.');
 await evaluate(`(()=>{if(document.getElementById('caddyDistance').value!=='60'||document.getElementById('caddyFairway').value!==''||document.getElementById('caddyWindDirection').value!=='unknown')throw Error('Next lie reused tee-line assumptions');document.getElementById('caddyWeather').click();if(!document.getElementById('caddyWeatherConsent').open)throw Error('Weather location explanation missing');document.getElementById('caddyWeatherCancel').click();document.querySelector('nav [data-page=discs]').click();return true})()`);
 // The bag reads the same durable throw records and can correct a measurement.
 await until("document.querySelector('#myBag .disc-history')?.textContent.includes('250 ft')",'Bag did not show the caddy throw distance.');
 await evaluate(`(()=>{const profile=document.querySelector('#myBag .disc-profile');if(!profile?.textContent.includes('Hyzer')||!profile.textContent.includes('left-hand forehand'))throw Error('Actual shot did not build the disc profile');const history=document.querySelector('#myBag .disc-history');history.open=true;history.querySelector('[data-fix-distance]').click();if(!document.getElementById('discDistanceDialog').open)throw Error('Distance correction did not open');document.getElementById('discDistanceValue').value='200';if(document.getElementById('discActualAngle').value!=='hyzer')throw Error('Actual angle missing from feedback correction');document.getElementById('discActualAngle').value='flat';document.getElementById('discFlight').value='held';document.getElementById('discDistanceSave').click();return true})()`);
 await until("!document.getElementById('discDistanceDialog').open&&document.querySelector('#myBag .disc-history')?.textContent.includes('200 ft')",'Corrected throw distance did not persist in bag statistics.');
 await evaluate(`(async()=>{const s=await import('./lib/storage.js'),h=await import('./lib/disc-history.js'),c=await import('./lib/caddy.js'),holes=await s.listCaddyHoles(),records=h.historyBackup(holes);if(!records.some(t=>t.throwDistanceFt===200&&t.remainingFt===60&&t.actualShot?.releaseAngle==='flat'&&t.actualShot?.type==='forehand'&&t.feedback?.flight==='held'))throw Error('Carry was confused with remaining basket distance');const restored=h.validateHistory(records,c.normalizeShot);await s.restoreBag(await s.listBag(),[],restored);const after=h.throwRecords(await s.listCaddyHoles());if(after.length!==records.length||!after.some(t=>t.throwDistanceFt===200))throw Error('History restore duplicated or lost measurements');return true})()`);
 // Exercise the visible GPS workflow without accessing a real location.
 await evaluate(`(()=>{document.querySelector('nav [data-page=caddy]').click();return true})()`);
 await until("document.getElementById('caddy').dataset.state==='ready'",'Caddy did not reopen for GPS measurement.');
 await evaluate(`(()=>{
  window.qaGeoOriginal=Object.getOwnPropertyDescriptor(navigator,'geolocation');window.qaGeoWatch=0;window.qaGeoCleared=0;window.qaGeoTimers=new Map();
  Object.defineProperty(navigator,'geolocation',{configurable:true,value:{watchPosition(success,error,options){
   if(!options.enableHighAccuracy||options.maximumAge!==0)throw Error('GPS requested a cached or low-accuracy position');
   const id=++window.qaGeoWatch,emit=()=>success({timestamp:Date.now(),coords:{latitude:0,longitude:id===1?0:.0009,accuracy:3,speed:0}});emit();window.qaGeoTimers.set(id,setInterval(emit,1000));return id;
  },clearWatch(id){clearInterval(window.qaGeoTimers.get(id));window.qaGeoTimers.delete(id);window.qaGeoCleared++}}});
  window.AndroidFiles={requestPreciseLocation(id){window.dispatchEvent(new CustomEvent('fairway-location-permission',{detail:{id,granted:true}}))}};
  document.getElementById('caddyDistance').value='350';document.getElementById('caddyFairway').value='straight';document.getElementById('caddyRecommend').click();
  if(document.getElementById('throwMeasureUnits').value!=='ft')throw Error('GPS does not default to feet');document.getElementById('throwMeasureAction').click();return true;
 })()`);
 await until("document.getElementById('throwMeasureAction').textContent.includes('Stop')",'GPS start did not settle.');
 await evaluate("document.getElementById('feedbackMeasureAction').click()");
 await until("!document.getElementById('throwMeasureSave').disabled",'GPS landing did not settle.');
 await evaluate(`(()=>{if(window.qaGeoCleared!==2||window.qaGeoTimers.size)throw Error('GPS watch continued after endpoint capture');const units=document.getElementById('throwMeasureUnits');units.value='m';units.dispatchEvent(new Event('change'));if(!document.getElementById('throwMeasureResult').textContent.includes('100 m'))throw Error('GPS meters conversion failed');if(document.getElementById('feedbackMeasureResult').textContent!==document.getElementById('throwMeasureResult').textContent)throw Error('Measurement copies disagree');document.getElementById('feedbackMeasureSave').click();return true})()`);
 await until("document.getElementById('throwMeasureStatus').textContent.includes('Distance saved')",'GPS distance draft was not saved.');
 await evaluate(`(async()=>{const store=await import('./lib/storage.js'),holes=await store.listCaddyHoles(),pending=holes.find(h=>h.pendingMeasurement)?.pendingMeasurement;if(!pending||pending.distanceMethod!=='gps'||!pending.distanceGps)throw Error('GPS draft lost provenance');if(/latitude|longitude/.test(JSON.stringify(pending)))throw Error('GPS coordinates persisted');if(document.getElementById('caddyDistanceMethod').value!=='gps'||Number(document.getElementById('caddyActualDistance').value)<328)throw Error('GPS did not populate What happened');document.getElementById('caddyRemaining').value='20';document.getElementById('caddyRecord').click();return true})()`);
 await until("document.getElementById('caddyLie').textContent.includes('THROW 3')",'GPS throw did not advance once.');
 await evaluate(`(async()=>{const store=await import('./lib/storage.js'),h=await import('./lib/disc-history.js'),rows=h.throwRecords(await store.listCaddyHoles()),gps=rows.find(t=>t.distanceMethod==='gps');if(!gps||gps.distanceGps.uncertaintyM!==6||gps.throwDistanceFt<328)throw Error('GPS throw log lost its distance or accuracy');const restored=h.validateHistory(h.historyBackup(await store.listCaddyHoles()),(await import('./lib/caddy.js')).normalizeShot);if(!restored.some(hole=>hole.throws.some(t=>t.distanceMethod==='gps')))throw Error('Backup lost GPS provenance');if(window.qaGeoOriginal)Object.defineProperty(navigator,'geolocation',window.qaGeoOriginal);else delete navigator.geolocation;delete window.AndroidFiles;delete window.qaGeoTimers;document.querySelector('nav [data-page=discs]').click();return true})()`);
 await until("document.querySelector('#myBag .disc-history')?.textContent.includes('GPS average')",'Bag did not distinguish GPS averages.');
 // Exercise local weather's automatic aiming dialog with simulated sensors.
 await evaluate(`(()=>{
  document.querySelector('nav [data-page=caddy]').click();return true;
 })()`);
 await until("document.getElementById('caddy').dataset.state==='ready'",'Caddy did not reopen for compass weather.');
 await evaluate(`(()=>{
  window.qaCompassGeo=Object.getOwnPropertyDescriptor(navigator,'geolocation');window.qaCompassFetch=window.fetch;window.qaCompassTimers=new Map();window.qaCompassStarts=0;window.qaCompassStops=0;
  Object.defineProperty(navigator,'geolocation',{configurable:true,value:{getCurrentPosition(resolve){resolve({coords:{latitude:40.123,longitude:-75.45}})}}});
  window.fetch=(url,options)=>String(url).startsWith('https://api.open-meteo.com/')?Promise.resolve({ok:true,json:async()=>({current_units:{wind_speed_10m:'mp/h',wind_gusts_10m:'mp/h',temperature_2m:'°C',precipitation:'mm'},current:{time:new Date().toISOString().slice(0,16),wind_speed_10m:10,wind_gusts_10m:15,wind_direction_10m:90,temperature_2m:20,precipitation:0}})}):window.qaCompassFetch(url,options);
  window.AndroidFiles={startCompass(id,lat,lon){if(lat!==40.123||lon!==-75.45)throw Error('Compass did not receive location for true-north correction');window.qaCompassStarts++;const emit=()=>window.dispatchEvent(new CustomEvent('fairway-compass',{detail:{id,heading:90,trueNorth:true,accuracy:3,accuracyDegrees:4,level:true,rotation:0,timestamp:Date.now()}}));emit();window.qaCompassTimers.set(id,setInterval(emit,200))},stopCompass(id){clearInterval(window.qaCompassTimers.get(id));window.qaCompassTimers.delete(id);window.qaCompassStops++}};
  document.getElementById('caddyWeather').click();document.getElementById('caddyWeatherContinue').click();return true;
 })()`);
 await until("document.getElementById('caddyCompassDialog').open&&!document.getElementById('caddyCompassUse').disabled",'Weather did not open a settled compass reading.');
 await evaluate(`(async()=>{
  if(document.getElementById('caddyBearing').value!=='')throw Error('The next throw silently reused an old heading');document.getElementById('caddyCompassUse').click();
  if(document.getElementById('caddyCompassDialog').open||window.qaCompassTimers.size||document.getElementById('caddyBearing').value!=='90'||document.getElementById('caddyWindDirection').value!=='head')throw Error('Compass heading did not apply or sensors did not stop');
  const ui=await import('./lib/caddy-ui.js'),store=await import('./lib/storage.js');await ui.flushCaddyDraft();const hole=(await store.listCaddyHoles())[0];if(hole.draft.bearing!=='90'||/latitude|longitude/.test(JSON.stringify(hole)))throw Error('Compass draft lost heading or saved coordinates');
  document.getElementById('caddyCompass').click();return true;
 })()`);
 await until("document.getElementById('caddyCompassDialog').open&&!document.getElementById('caddyCompassUse').disabled",'Compass recapture was cancelled by a stale dialog event.');
 await evaluate(`(()=>{
  document.getElementById('caddyCompassCancel').click();if(window.qaCompassTimers.size||window.qaCompassStarts!==2||window.qaCompassStops!==2)throw Error('Cancel did not stop the compass');
  if(window.qaCompassGeo)Object.defineProperty(navigator,'geolocation',window.qaCompassGeo);else delete navigator.geolocation;window.fetch=window.qaCompassFetch;delete window.AndroidFiles;delete window.qaCompassTimers;document.querySelector('nav [data-page=discs]').click();return true;
 })()`);
 await until("document.querySelector('#myBag .disc-history')",'Bag did not reopen after compass test.');
 // A temporary physical putter verifies putting feedback and profile correction.
 await evaluate(`(async()=>{const store=await import('./lib/storage.js');await store.storeBagItem({id:'qa-putter',discId:'innova-aviar',plastic:'QA only',distance:180,puttingRange:30,condition:'Stock'});document.querySelector('nav [data-page=caddy]').click();return true})()`);
 await until("document.getElementById('caddy').dataset.state==='ready'",'Caddy did not open for putting check.');
 await evaluate("document.getElementById('caddyNew').click()");
 await until("document.getElementById('caddyLie').textContent.includes('THROW 1')",'New putting test hole did not open.');
 await evaluate(`(()=>{const pin=document.getElementById('caddyPinDistance');pin.value='20';pin.dispatchEvent(new Event('input'));if(document.getElementById('caddyPuttingPrompt').hidden)throw Error('Close lie did not ask about putting');document.getElementById('caddyPromptPutt').click();document.getElementById('caddyPuttRecommend').click();return true})()`);
 await until("!document.getElementById('caddyLogPanel').hidden&&document.getElementById('caddyActualType').value==='putt'",'Putting caddy did not produce a putter plan.');
 await evaluate(`(()=>{if(document.getElementById('caddyUsedDisc').value!=='qa-putter'||document.getElementById('caddyPuttStartDistance').value!=='20'||document.getElementById('caddyPuttFeedback').hidden)throw Error('Putting feedback did not use the current putter/start distance');if(document.getElementById('feedbackMeasureAction').disabled)throw Error('Feedback measurement is unavailable');document.getElementById('caddyPuttResult').value='missed';document.getElementById('caddyPuttResult').dispatchEvent(new Event('change'));document.getElementById('caddyRemaining').value='8';document.getElementById('caddyRecord').click();return true})()`);
 await until("document.getElementById('caddyLie').textContent.includes('THROW 2')",'Missed putt did not advance to its own next lie.');
 await evaluate(`(()=>{if(document.getElementById('caddyPuttingPrompt').hidden||!document.getElementById('feedbackMeasureTitle').textContent.includes('2'))throw Error('Next putt or measurement still uses the first throw');document.getElementById('caddyPromptPutt').click();document.getElementById('caddyPuttRecommend').click();return true})()`);
 await until("!document.getElementById('caddyLogPanel').hidden&&document.getElementById('caddyPuttStartDistance').value==='8'",'Second putt did not use eight feet.');
 await evaluate(`(()=>{document.getElementById('caddyPuttResult').value='made';document.getElementById('caddyPuttResult').dispatchEvent(new Event('change'));document.getElementById('caddyRecord').click();return true})()`);
 await until("document.getElementById('caddyLie').textContent.includes('THROW 1')&&document.getElementById('caddyHoleNumber').value==='2'",'Made putt did not finish the hole and open the next hole.');
 await evaluate(`(async()=>{const store=await import('./lib/storage.js'),history=await import('./lib/disc-history.js'),p=await import('./lib/putting.js'),rows=history.throwRecords(await store.listCaddyHoles()),stats=p.puttingStats(rows,'qa-putter');if(stats.attempts!==2||stats.makes!==1||stats.bands[0].makes!==1||stats.bands[1].attempts!==1)throw Error('Putting accuracy mixed distances or results');window.qaPuttMiss=rows.find(r=>r.usedBagId==='qa-putter'&&r.outcome==='missed').id;document.querySelector('nav [data-page=discs]').click();return true})()`);
 await until("document.querySelector('#myBag [data-bag-id=qa-putter] .putting-profile')",'Bag did not show putting accuracy.');
 await evaluate(`(()=>{const button=document.querySelector('#myBag [data-fix-distance="'+window.qaPuttMiss+'"]');button.click();if(document.getElementById('discPuttingFields').hidden||document.getElementById('discPuttingStart').value!=='20')throw Error('Putting start correction is unavailable');document.getElementById('discPuttingStart').value='10';document.getElementById('discDistanceSave').click();return true})()`);
 await until("!document.getElementById('discDistanceDialog').open",'Putting accuracy correction did not save.');
 await evaluate(`(async()=>{const store=await import('./lib/storage.js'),history=await import('./lib/disc-history.js'),p=await import('./lib/putting.js'),c=await import('./lib/caddy.js'),holes=await store.listCaddyHoles(),backup=history.historyBackup(holes),restored=history.validateHistory(backup,c.normalizeShot),stats=p.puttingStats(history.throwRecords(restored),'qa-putter');if(stats.bands[0].attempts!==2||stats.bands[0].percentage!==50||stats.bands[1].attempts!==0)throw Error('Correction or backup lost putting accuracy');document.querySelector('#myBag [data-bag-id=qa-putter] [data-remove]').click();return true})()`);
 await until("document.getElementById('bagCount').textContent==='1'",'Temporary putter did not remove cleanly.');
 // Restore the original bag-edit context for existing backup/removal checks.
 await until("document.getElementById('bagCount').textContent==='1'",'Caddy changed the bag.');
 await evaluate(`(()=>{document.getElementById('targetDistance').value='190';document.getElementById('bagSuggestion').click();if(!document.getElementById('caddyResult').textContent.includes('180 ft'))throw Error('Personal distance comparison failed');document.querySelector('#myBag [data-remove]').click();return true})()`);
 await until("document.getElementById('bagCount').textContent==='0'",'Bag removal did not persist.');
 await evaluate(`(()=>{if(document.querySelector('[data-catalog-id=axiom-crave] .disc-ownership'))throw Error('Catalog retained removed bag ownership');return true})()`);
 await evaluate(`(async()=>{const pose=await import('./lib/pose.js'),canvas=document.createElement('canvas');canvas.width=640;canvas.height=480;canvas.getContext('2d').fillRect(0,0,640,480);pose.configurePose('full');const result=await pose.detectFrame(canvas);if(result.p||result.multi)throw Error('Blank image received an invented person pose');await pose.getHands();const points=Array.from({length:33},()=>({x:.5,y:.5,visibility:1}));points[11]={x:.4,y:.3,visibility:1};points[12]={x:.6,y:.3,visibility:1};points[23]={x:.45,y:.7,visibility:1};points[24]={x:.55,y:.7,visibility:1};points[14]={x:.65,y:.4,visibility:1};points[16]={x:.7,y:.5,visibility:1};const hand=await pose.detectHand(canvas,points,'right',640/480);if(hand)throw Error('Blank crop received an invented hand');return true})()`);
 await evaluate(`(async()=>{
  document.querySelector('[data-page=studio]').click();
  const c=document.createElement('canvas');c.width=320;c.height=240;const context=c.getContext('2d');context.fillRect(0,0,320,240);
  const stream=c.captureStream(15),chunks=[],recorder=new MediaRecorder(stream,{mimeType:'video/webm'});
  const done=new Promise(resolve=>{recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};recorder.onstop=resolve});
  recorder.start(100);let paints=0;const paint=setInterval(()=>{context.fillStyle=++paints%2?'#181818':'#191919';context.fillRect(0,0,320,240)},60);
  await new Promise(resolve=>setTimeout(resolve,1100));recorder.stop();await done;clearInterval(paint);stream.getTracks().forEach(t=>t.stop());
  const transfer=new DataTransfer();transfer.items.add(new File(chunks,'qa-no-person.webm',{type:'video/webm'}));
  const input=document.getElementById('file');input.files=transfer.files;input.dispatchEvent(new Event('change'));return true;
 })()`);
 await until("!document.getElementById('analyze').disabled&&!document.getElementById('player').hidden",'A real, generated no-person test video could not load.',30);
 // Real decoder, but deliberately suppress its seeked event: polling must recover.
 await evaluate(`(async()=>{
  const video=document.getElementById('video'),{seekVideoFrame}=await import('./lib/video-player.js');
  const suppress=event=>event.stopImmediatePropagation();video.addEventListener('seeked',suppress,true);
  try{await seekVideoFrame(video,.25,{timeout:3000});if(video.seeking||video.readyState<2)throw Error('Decoder not ready after recovered seek')}
  finally{video.removeEventListener('seeked',suppress,true)}
  // A real decoder with an Android-style rounded playhead must also finish.
  const descriptor=Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype,'currentTime');
  Object.defineProperty(video,'currentTime',{configurable:true,get(){return Math.floor(descriptor.get.call(this)*30)/30},set(time){descriptor.set.call(this,time)}});
  try{const actual=await seekVideoFrame(video,.58,{timeout:3000});if(Math.abs(actual-.58)>.043||video.seeking)throw Error('Rounded seek did not recover')}
  finally{delete video.currentTime}
  // Inject a decoding failure only in this test page. Partial evidence must survive.
  Object.defineProperty(video,'currentTime',{configurable:true,get(){return descriptor.get.call(this)},set(time){if(time>.3)throw Error('QA frame decode interruption');descriptor.set.call(this,time)}});
  document.getElementById('analyze').click();return true;
 })()`);
 await until("!document.getElementById('analyze').disabled&&!!document.querySelector('.review-interrupted')",'An interrupted analysis lost its partial review.',90);
 await evaluate(`(()=>{if(!document.getElementById('status').textContent.includes('Partial review kept'))throw Error('Interrupted analysis recovery instructions missing');delete document.getElementById('video').currentTime;return true})()`);
 await evaluate(`(async()=>{const video=document.getElementById('video'),{seekVideoFrame}=await import('./lib/video-player.js');await seekVideoFrame(video,.1,{timeout:3000});document.getElementById('reviewStart').click();await seekVideoFrame(video,video.duration-.1,{timeout:3000});document.getElementById('reviewEnd').click();if(!document.getElementById('reviewWindowStatus').textContent.includes('0.10s'))throw Error('Throw window did not follow original source time');document.getElementById('analyze').click();return true})()`);
 await until("!document.getElementById('results').hidden&&!document.getElementById('analyze').disabled",'The no-person video analysis did not finish.',90);
 await evaluate(`(()=>{if(!document.getElementById('report').textContent.includes('Not enough clear'))throw Error('No-person footage did not receive an insufficient-evidence review');if(document.querySelectorAll('#reviewChecks .feedback').length)throw Error('No-person footage received personal coaching findings');return true})()`);
 // Measured carry uses the selected units and is saved with the actual session.
 await evaluate(`(()=>{document.getElementById('sessionCarryUnit').value='m';document.getElementById('sessionCarryUnit').dispatchEvent(new Event('change'));document.getElementById('sessionCarry').value='30';document.getElementById('sessionCarryReference').checked=true;document.getElementById('save').click();return true})()`);
 await until("!document.getElementById('save').disabled&&document.getElementById('status').textContent.includes('Saved. Find this video')",'Measured carry session did not save.');
 await evaluate(`(async()=>{const s=await import('./lib/storage.js'),rows=await s.listPlayerSessions(),saved=rows.find(r=>r.carryReference&&Math.abs(r.carryFt-30/.3048)<.01);if(!saved||'blob' in saved||'frames' in saved)throw Error('Measured carry metadata was lost or retained the full video');const full=(await s.listSessions()).find(r=>r.id===saved.id);if(full.sampleInfo.trackingMode!=='video'||!full.options.reviewWindow||full.frames.some(f=>f.t<full.options.reviewWindow.start-.0001||f.t>=full.options.reviewWindow.end))throw Error('Tracked throw window was not persisted with source timestamps');await s.deleteSession(saved.id);return true})()`);
 // Exercise orchestration with a real decoder and QA-only pose tokens, never
 // shown as model evidence or rendered into the app's user review.
 await evaluate(`(async()=>{
  const {analyzeVideo}=await import('./lib/video-analysis.js'),{createVideoSeeker}=await import('./lib/video-player.js');
  const video=document.getElementById('video'),descriptor=Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype,'currentTime');
  let detail=false,bodyCount=0;
  Object.defineProperty(video,'currentTime',{configurable:true,get(){return descriptor.get.call(this)},set(time){if(detail)throw Error('QA optional close-up decode failure');descriptor.set.call(this,time)}});
  try{
   const result=await analyzeVideo({video,seek:createVideoSeeker(video,{timeout:3000}),fps:15,handDetail:true,
    detectBody:async()=>({p:{qaOnly:true},world:null,multi:false}),prepareHands:async()=>{},detectHand:async()=>null,findRelease:()=>Math.min(.7,video.duration/2),
    onProgress:({phase})=>{if(phase==='hands'){detail=true}},onFrames:frames=>{if(!detail)bodyCount=frames.length}
   });
   if(!detail||!result.sampleInfo.bodyComplete||result.sampleInfo.incomplete||!result.sampleInfo.detailIncomplete||result.frames.length!==bodyCount)throw Error('Optional decode failure damaged completed body coverage');
   detail=false;
   const stopped=await analyzeVideo({video,seek:createVideoSeeker(video,{timeout:3000}),fps:15,handDetail:false,
    detectBody:async()=>({p:null,world:null,multi:false}),prepareHands:async()=>{throw Error('Unexpected hand pass')},findRelease:()=>null,
    onProgress:({phase})=>{if(phase!=='body'&&phase!=='complete')throw Error('Hand detail ran while disabled')}
   });
   if(!stopped.sampleInfo.bodyComplete)throw Error('Body-only pass did not finish');
  }finally{delete video.currentTime}
  return true;
 })()`);
 // Internal lesson navigation clears stale filters and opens the matching lesson.
 await evaluate(`(()=>{document.querySelector('nav [data-page=learn]').click();document.getElementById('search').value='no-such-lesson';document.getElementById('search').dispatchEvent(new Event('input'));return true})()`);
 await evaluate(`(async()=>{const {openLesson}=await import('./lib/knowledge-ui.js');if(!openLesson('which-release')||!document.querySelector('#lesson-which-release details').open||document.getElementById('search').value)throw Error('Internal lesson opening failed');if(!document.querySelector('#lesson-which-release .resource-preview')?.textContent.length)throw Error('Source preview missing');document.querySelector('nav [data-page=studio]').click();return true})()`);
 // A coordinate fixture exercises report rendering only; it is never user content or model evidence.
 await evaluate(`(async()=>{
  const {review}=await import('./lib/analysis.js'),{renderCoaching,renderPhaseStrip}=await import('./lib/report-ui.js');
  const frames=Array.from({length:20},(_,i)=>{const p=Array.from({length:33},()=>({x:.5,y:.5,visibility:1}));p[0]={x:.5,y:.1,visibility:1};p[11]={x:.4,y:.3,visibility:1};p[12]={x:.6,y:.3,visibility:1};p[23]={x:.45,y:.65,visibility:1};p[24]={x:.55,y:.65,visibility:1};p[14]={x:.65,y:.4,visibility:1};p[16]={x:.4+i*.02,y:.5,visibility:1};return {t:i/20,p}});
  const r=review(frames,{hand:'right',type:'backhand',view:'side',aspect:4/3,markers:{release:.6,plant:.4}});
  renderCoaching(r);renderPhaseStrip(r.phases);document.querySelector('#phaseStrip [data-phase=plant]').click();if(document.getElementById('markerName').value!=='plant')throw Error('Suggested phase selected a different manual marker');if(document.getElementById('reviewDeep').open||document.getElementById('coachMore').open)throw Error('Detailed coaching should start closed');if(!document.querySelector('#coachQuick h3'))throw Error('Short coaching did not render');if(document.querySelectorAll('#report .feedback').length<12)throw Error('Whole-body review cards did not render');
  const missing=document.getElementById('reviewMissing');if(missing?.open)throw Error('Unavailable checks should start collapsed');
  document.querySelector('[data-filter=unknown]').click();if([...document.querySelectorAll('#report .feedback')].some(el=>!el.hidden&&el.dataset.kind!=='unknown')||missing&&!missing.open)throw Error('Unavailable-check filter failed');
  document.querySelector('[data-filter=all]').click();if(!document.getElementById('coachPlan').textContent.includes('practice plan'))throw Error('Practice walkthrough did not render');
  const focus=document.getElementById('practiceFocus');if(!focus)throw Error('Practice focus choice missing');
  focus.value='feet';focus.dispatchEvent(new Event('change'));
  const drill=document.getElementById('practiceDrill');if(!drill||drill.options.length<2)throw Error('No alternative drills for visible foot spacing');
  const firstPlan=document.getElementById('coachPlan').textContent;drill.value=drill.options[1].value;drill.dispatchEvent(new Event('change'));
  if(document.getElementById('coachPlan').textContent===firstPlan)throw Error('Changing the drill did not change the practice');
  if(!document.querySelector('#coachPlan [data-plan-seek]')||!document.querySelector('#report .video-evidence'))throw Error('Coaching did not expose video anchors');
  const select=document.getElementById('practiceFocus');select.value='xstep';select.dispatchEvent(new Event('change'));
  if(!document.getElementById('coachPlan').textContent.includes('general X-step lesson')||document.querySelector('#coachPlan [data-plan-seek]'))throw Error('General X-step lesson claimed personalized video evidence');
  if(document.querySelector('#report .review-details').open||[...document.querySelectorAll('.measurement-details')].some(el=>el.open))throw Error('Technical details should start closed');
  if(/torso lengths|Projected|°/.test(document.querySelector('#reviewChecks .feedback').innerText))throw Error('Technical measurements leaked into the primary coaching');
  if([...document.getElementById('results').children].indexOf(document.getElementById('coachPanel'))>[...document.getElementById('results').children].indexOf(document.getElementById('report')))throw Error('Practice plan should precede detailed cards');const lesson=document.querySelector('#coachPlan [data-lesson]');if(!lesson)throw Error('No internal coaching lesson link');const id=lesson.dataset.lesson;lesson.click();if(document.getElementById('learn').hidden||!document.querySelector('#lesson-'+id+' details')?.open)throw Error('Coaching lesson link did not open the exact library section');document.querySelector('nav [data-page=studio]').click();return true;
 })()`);
 // Return to a clean initial screen for the preview image: no fixture results or clips are shown.
 await send('Page.navigate',{url:origin+'/'});await until("document.querySelectorAll('#discCatalog .disc-card').length===60",'Could not return to a clean app screen.');

 const overflow=await evaluate('document.documentElement.scrollWidth>window.innerWidth+2');if(overflow)throw Error('Mobile page overflows horizontally.');
 if(browser.errors.length)throw Error('Uncaught browser error: '+browser.errors.join('\n'));
 await fs.mkdir(path.join(root,'artifacts'),{recursive:true});const screenshot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});await fs.writeFile(path.join(root,'artifacts/Fairway-Form-mobile.png'),Buffer.from(screenshot.data,'base64'));
 // Earlier removal checks intentionally emptied the bag. This scenario owns its
 // own physical bag copy; a course layout alone must never invent a disc to use.
 await evaluate(`(async()=>{const s=await import('./lib/storage.js');await s.storeBagItem({id:'qa-course-driver',discId:'innova-teebird',plastic:'QA course check only',condition:'Stock',distance:280,distanceThrow:'backhand',referenceHand:'right'});await s.storeCourse({id:'qa-course',name:'QA Riverside',created:1,updated:1,holes:[{number:1,par:4,distanceFt:750,fairway:'left',elevation:'uphill',hazard:'right',wooded:true,notes:'Creek OB'},{number:2,par:3,distanceFt:290,fairway:'straight',elevation:'level',hazard:'none',wooded:false,notes:''}]});document.querySelector('nav [data-page=caddy]').click();return true})()`);
 await until("document.getElementById('caddy').dataset.state==='ready'",'Caddy was unavailable for course checks.');
 // Course restore uses the same refresh path as returning to Caddy after a restart.
 await evaluate(`(async()=>{await import('./lib/caddy-ui.js').then(m=>m.flushCaddyDraft());return true})()`);
 await send('Page.reload');await wait(250);
 await until("document.querySelectorAll('#discCatalog .disc-card').length===60",'Reload failed.');
 await evaluate(`(()=>{document.querySelector('nav [data-page=caddy]').click();return true})()`);
 await until("document.getElementById('caddy').dataset.state==='ready'&&document.querySelector('#courseSelect option[value=qa-course]')",'My Courses did not survive reload.');
 await evaluate(`(()=>{const c=document.getElementById('courseSelect');c.value='qa-course';c.dispatchEvent(new Event('change'));const h=document.getElementById('courseHoleSelect');h.value='1';h.dispatchEvent(new Event('change'));document.getElementById('coursePlay').click();return true})()`);
 await until("document.getElementById('caddyHoleTitle').value.includes('QA Riverside')&&document.getElementById('caddyDistance').value==='750'",'Saved course did not populate the tee.');
 await evaluate(`(()=>{if(document.getElementById('caddyPar').value!=='4'||document.getElementById('caddyElevation').value!=='uphill'||document.getElementById('caddyHazard').value!=='right')throw Error('Course details were lost');document.getElementById('caddyQuickRecommend').click();return true})()`);
 await until("!document.getElementById('caddyLogPanel').hidden&&document.getElementById('caddyUsedDisc').value==='qa-course-driver'",'Course tee did not receive a plan using its test bag copy.');
 await evaluate(`(()=>{const meter=document.getElementById('caddyMeasureCard'),review=document.getElementById('caddyReview'),feedback=document.getElementById('caddyLogPanel');if(meter.nextElementSibling!==review||document.getElementById('caddy').dataset.step!=='throw')throw Error('Focused throw task did not open');(${assertCaddySelection.toString()})(${JSON.stringify({bagId:'qa-course-driver',...Object.fromEntries(['brand','model'].map(key=>[key,DISCS.find(d=>d.id==='innova-teebird')[key]])),plastic:'QA course check only'})});document.getElementById('caddyLogThrow').click();if(feedback.classList.contains('workflow-off')||!document.getElementById('caddyConditions').classList.contains('workflow-off'))throw Error('Result task did not hide setup');document.getElementById('caddyRemaining').value='470';document.getElementById('caddyRecord').click();return true})()`);
 await until("document.getElementById('caddyLie').textContent.includes('THROW 2')",'Course feedback did not advance.');
 await evaluate(`(async()=>{const s=await import('./lib/storage.js'),c=(await s.listCourses()).find(c=>c.id==='qa-course');if(c.holes[0].distanceFt!==750||c.holes[0].par!==4)throw Error('Next lie overwrote the saved course');const round=(await s.listCaddyHoles()).find(h=>h.courseId==='qa-course');if(!round||round.throws.length!==1||round.draft.distanceFt!==470)throw Error('Course round was not saved');document.getElementById('caddyFinish').click();return true})()`);
 await until("!document.getElementById('courseNext').disabled",'Next course hole remained unavailable.');
 await evaluate(`(()=>{document.getElementById('courseNext').click();return true})()`);
 await until("document.getElementById('caddyDistance').value==='290'&&document.getElementById('caddyLie').textContent.includes('THROW 1')",'Next saved course hole did not start a fresh log.');
 await evaluate(`(async()=>{const s=await import('./lib/storage.js');await s.deleteBagItem('qa-course-driver');return true})()`);
 // Optional course lookup must validate a real map or clearly disclose its outage.
 await evaluate(`(async()=>{const m=await import('./lib/course-directory.js'),payload=await(await fetch('./course-data/index.json')).json(),state=m.courseBundleStatus(payload),data=m.readCourseDirectory(payload);window.qaCourseAvailable=state.state==='available';document.getElementById('caddyCoursesCard').open=true;document.getElementById('courseFinder').open=true;document.getElementById('courseSearchQuery').value=window.qaCourseAvailable?data.courses[0].name:'course';document.getElementById('courseSearchButton').click();return true})()`);
 await until("!document.getElementById('courseSearchButton').disabled",'Offline course search did not finish.');
 await evaluate(`(()=>{const button=document.querySelector('#courseSearchResults [data-map-course]');if(window.qaCourseAvailable){if(!button)throw Error('Bundled course did not appear in offline search');button.click();if(document.getElementById('courseSearchPreview').hidden||!document.getElementById('courseSearchDetails').textContent.includes('OB'))throw Error('Course review/provenance missing');document.getElementById('courseSearchSave').click();}else{if(button||!document.getElementById('courseSearchPreview').hidden)throw Error('Unavailable directory invented selectable courses');const message=document.getElementById('courseSearchStatus').textContent;if(!message.includes('unavailable')||!message.includes('saved courses')||!message.includes('manual course entry'))throw Error('Directory outage did not explain saved/manual courses');}return true})()`);
 await until("window.qaCourseAvailable?!document.getElementById('courseSearchSave').disabled:document.getElementById('courseSearchStatus').textContent.includes('unavailable')",'Course import/outage disclosure did not finish.');
 await evaluate("delete window.qaCourseAvailable;true");
 // Browser edition must explain the optional native feature without altering a lie.
 await evaluate(`(()=>{document.getElementById('caddyStepSetup').click();const button=document.getElementById('cameraPin');if(button.closest('.workflow-off'))throw Error('Nearby camera shortcut is hidden during planning');button.click();return true})()`);
 await until("document.getElementById('cameraRangeStatus').textContent.includes('updated Android APK')",'Browser camera fallback did not explain device requirements.');
 console.log('Browser checks passed: mobile startup, saved palettes and four course scenes with independent dark mode, voice controls and preview, summary-first human coaching with closed details, internal lesson navigation, expanded source previews, video anchors and drill choices, separately labeled X-step lessons and unavailable checks, optional measurements, missing-seeked and rounded-frame recovery, optional hand-pass failure isolation and disabling, partial-review retention, permission explanations, v1/v3/v4 session and bag migration, offline open-map course search with explicit availability, licensed source notices and reviewable imports, external UDisc references, saved courses with independent tee layouts and per-round logs, prominent next-throw flow, player-profile persistence, unit conversion, measured-review evidence and opt-out, personal caddy defaults, flight roles and estimated windows, release-angle and actual-shot disc-profile persistence/correction/restore, measured disc-history, 28-brand catalog filters and pagination, manufacturer lessons, bundled-photo decoding, library search, bag edits and distance comparison, caddy bag-only recommendations and wind context, feet/meters conversion, confirmed sign text, next-lie logs and location opt-in, real bundled pose/hand-model initialization, no-person video rejection, and report rendering.');
}finally{
 await browser?.close();server.close();
}
