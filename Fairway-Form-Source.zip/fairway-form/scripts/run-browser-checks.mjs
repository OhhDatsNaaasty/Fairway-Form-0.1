import {spawn} from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {superviseBrowser} from './lib/browser-supervisor.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),directory=path.join(root,'artifacts'),runId=randomUUID(),startedAt=new Date().toISOString();
await fs.mkdir(directory,{recursive:true});
const logFile=await fs.open(path.join(directory,'browser-check.log'),'w');
const statusPath=path.join(directory,'browser-check-status.json');
let writes=Promise.resolve();
function record(stream,chunk){writes=writes.then(()=>logFile.write(chunk)).catch(()=>{});(stream==='stderr'?process.stderr:process.stdout).write(chunk)}
const log=line=>record('stdout',line+'\n');
const controller=new AbortController(),abort=()=>controller.abort();process.once('SIGINT',abort);process.once('SIGTERM',abort);
await fs.writeFile(statusPath,JSON.stringify({runId,startedAt,outcome:'running'},null,2)+'\n');
log(`[browser] Run ${runId} · ${startedAt} · fresh log; previous results are not reused.`);
try{
 const result=await superviseBrowser({
  spawnWorker:()=>spawn(process.execPath,[path.join(root,'scripts/browser-smoke.mjs')],{cwd:root,env:{...process.env,FAIRWAY_BROWSER_SUPERVISED:'1'},detached:process.platform!=='win32',stdio:['ignore','pipe','pipe','ipc']}),
  signal:controller.signal,log,output:record
 });
 await fs.writeFile(statusPath,JSON.stringify({runId,startedAt,completedAt:new Date().toISOString(),...result},null,2)+'\n');
 process.exitCode=result.exitCode;
}catch(error){
 log('[browser] Supervisor failed: '+error.message);await fs.writeFile(statusPath,JSON.stringify({runId,startedAt,completedAt:new Date().toISOString(),outcome:'failed',error:error.message},null,2)+'\n');process.exitCode=1;
}finally{process.removeListener('SIGINT',abort);process.removeListener('SIGTERM',abort);await writes;await logFile.close()}
