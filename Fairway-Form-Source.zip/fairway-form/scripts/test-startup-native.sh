#!/usr/bin/env bash
set -euo pipefail
STARTUP_PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$STARTUP_PROJECT_DIR"
STARTUP_TEST_DIR="$(mktemp -d)"
trap 'rm -rf "$STARTUP_TEST_DIR"' EXIT
java -m jdk.compiler/com.sun.tools.javac.Main -d "$STARTUP_TEST_DIR" android/app/src/main/java/com/fairwayform/app/StartupPolicy.java tests/native/StartupPolicyTest.java
java -cp "$STARTUP_TEST_DIR" com.fairwayform.app.StartupPolicyTest
