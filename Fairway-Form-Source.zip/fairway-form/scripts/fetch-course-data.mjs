import {writeCourseBundle} from './lib/course-bundle.mjs';
const status=await writeCourseBundle({output:new URL('../dist/course-data/index.json',import.meta.url)});
console.log(status.state==='available'?`Course directory ready: ${status.count} courses.`:'Course directory unavailable; manual/saved courses remain available.');
