import fs from 'node:fs/promises';
import {downloadCourseSnapshot,requireCourseSnapshot} from './lib/course-download.mjs';
const output=new URL('../dist/course-data/index.json',import.meta.url);
let cached=null;try{cached=JSON.parse(await fs.readFile(output,'utf8'))}catch{}
const snapshot=await downloadCourseSnapshot({cached});
requireCourseSnapshot(snapshot);
await fs.mkdir(new URL('../dist/course-data/',import.meta.url),{recursive:true});
await fs.writeFile(new URL('../dist/course-data/index.tmp',import.meta.url),JSON.stringify(snapshot));
await fs.rename(new URL('../dist/course-data/index.tmp',import.meta.url),output);
