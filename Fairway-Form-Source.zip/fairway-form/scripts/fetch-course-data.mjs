// A build-time OSM snapshot, not public Overpass as an app backend.
import fs from 'node:fs/promises';
import {buildCourseSnapshot,QUERY} from './lib/course-snapshot.mjs';
import {readCourseDirectory} from '../dist/lib/course-directory.js';
const output=new URL('../dist/course-data/index.json',import.meta.url);let cached=null;
try{cached=readCourseDirectory(JSON.parse(await fs.readFile(output,'utf8')));if(cached.courses.length&&Date.now()-Date.parse(cached.generatedAt)<7*86400000){console.log('Offline OSM course snapshot already available:',cached.courses.length);process.exit(0)}}catch{}
try{
 const response=await fetch('https://overpass-api.de/api/interpreter',{method:'POST',body:new URLSearchParams({data:QUERY}),signal:AbortSignal.timeout(85000),headers:{'User-Agent':'FairwayForm-CourseSnapshot/1.12 (build-time open-data extract; no live client queries)'}});
 if(!response.ok)throw Error('Map extract HTTP '+response.status);const parts=[];let size=0;for await(const part of response.body){size+=part.length;if(size>32*1024*1024)throw Error('Map extract exceeded 32 MB');parts.push(part)}
 const snapshot=buildCourseSnapshot(JSON.parse(Buffer.concat(parts).toString('utf8')));if(!snapshot.courses.length)throw Error('Map extract contained no courses');await fs.mkdir(new URL('../dist/course-data/',import.meta.url),{recursive:true});await fs.writeFile(output,JSON.stringify(snapshot));console.log('Bundled OSM courses:',snapshot.courses.length,'mapped hole routes:',snapshot.courses.reduce((n,c)=>n+c.layouts.length,0));
}catch(error){console.warn('Course snapshot unavailable:',error.message,cached?.courses.length?'Keeping the previous dated map snapshot.':'Course search will report unavailable; saved/manual courses still work. No sample courses added.');}
