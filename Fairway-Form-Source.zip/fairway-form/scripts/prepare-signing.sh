#!/usr/bin/env bash
set -euo pipefail
# This password is supplied as a GitHub repository secret, never as a workflow input.
: "${APP_SIGNING_PASSWORD:?Add the APP_SIGNING_PASSWORD repository secret first.}"
: "${RUNNER_TEMP:?RUNNER_TEMP must be set to a writable temporary directory.}"
if [[ ${#APP_SIGNING_PASSWORD} -lt 12 ]]; then
 echo 'APP_SIGNING_PASSWORD must contain at least 12 characters.' >&2
 exit 1
fi
SIGNING_ARCHIVE="${1:?Pass the encrypted signing-key path.}"
SIGNING_KEY_PATH="$RUNNER_TEMP/fairway-signing.jks"
umask 077
if [[ -s "$SIGNING_ARCHIVE" ]]; then
 openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 \
  -in "$SIGNING_ARCHIVE" -out "$SIGNING_KEY_PATH" -pass env:APP_SIGNING_PASSWORD
else
 if [[ "${ALLOW_NEW_SIGNING_KEY:-false}" != true ]]; then
  echo 'No saved signing key found. Refusing to change the signing identity of an existing app.' >&2
  exit 1
 fi
 keytool -genkeypair -noprompt -storetype PKCS12 \
  -keystore "$SIGNING_KEY_PATH" -alias fairway -keyalg RSA -keysize 3072 \
  -validity 10000 -dname 'CN=Fairway Form Personal App' \
  -storepass:env APP_SIGNING_PASSWORD -keypass:env APP_SIGNING_PASSWORD
 openssl enc -aes-256-cbc -salt -pbkdf2 -iter 200000 \
  -in "$SIGNING_KEY_PATH" -out "$SIGNING_ARCHIVE" -pass env:APP_SIGNING_PASSWORD
fi
# Reject a wrong password or damaged archive before compiling anything.
keytool -list -keystore "$SIGNING_KEY_PATH" -alias fairway \
 -storepass:env APP_SIGNING_PASSWORD >/dev/null
if [[ -n "${GITHUB_ENV:-}" ]]; then
 {
  echo "ANDROID_KEYSTORE=$SIGNING_KEY_PATH"
  echo 'ANDROID_KEY_ALIAS=fairway'
 } >> "$GITHUB_ENV"
fi
echo 'Signing identity ready. Passwords and private key are not included in the APK artifact.'
