// Keep the approved intro intact in source and in the compiled APK.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const {intro}=JSON.parse(await fs.readFile(path.join(root,'android/startup-assets.json'),'utf8'));
const bytes=await fs.readFile(path.join(root,intro.path));
const hash=value=>createHash('sha256').update(value).digest('hex');
if(bytes.length!==intro.bytes||hash(bytes)!==intro.sha256)throw Error('The opening movie does not match the approved animation. Restore it, or intentionally update android/startup-assets.json when changing the intro.');
if(process.argv[2]){
 const result=spawnSync('unzip',['-p',path.resolve(process.argv[2]),intro.apkPath],{maxBuffer:16*1024*1024});
 if(result.status!==0||hash(result.stdout)!==intro.sha256)throw Error('The compiled APK does not include the intact approved opening movie.');
 console.log('APK opening movie matches the approved five-second intro.');
}else console.log('Approved opening movie is bundled locally; no network download is required.');
