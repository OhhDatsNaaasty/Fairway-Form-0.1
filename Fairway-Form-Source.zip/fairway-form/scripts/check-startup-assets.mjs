// Keep the approved intro intact in source and in the compiled APK.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {sha256,rawResourceId,verifyApkIntro,captureProcess} from './lib/startup-apk.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const {intro}=JSON.parse(await fs.readFile(path.join(root,'android/startup-assets.json'),'utf8'));
const bytes=await fs.readFile(path.join(root,intro.path));
if(bytes.length!==intro.bytes||sha256(bytes)!==intro.sha256)throw Error('The opening movie does not match the approved animation. Restore it, or intentionally update android/startup-assets.json when changing the intro.');

async function aaptExecutable(explicit){
 if(explicit)return path.resolve(explicit);
 const sdk=process.env.ANDROID_HOME??process.env.ANDROID_SDK_ROOT;
 if(!sdk)throw Error('APK verification needs aapt2. Pass its build-tools path as the third argument, or set ANDROID_HOME.');
 const versions=await fs.readdir(path.join(sdk,'build-tools'));
 versions.sort((a,b)=>b.localeCompare(a,undefined,{numeric:true}));
 for(const version of versions){const file=path.join(sdk,'build-tools',version,'aapt2');try{await fs.access(file,fs.constants.X_OK);return file}catch{}}
 throw Error('No executable aapt2 was found in the Android SDK build-tools.');
}
async function generatedResourceId(){
 // AGP emits logical-name symbols before APK resource/path optimization. The
 // resource ID still identifies R.raw.fairway_intro even if names are collapsed.
 const build=path.join(root,'android/app/build/intermediates');
 const candidates=[
  'runtime_symbol_list/release/processReleaseResources/R.txt',
  'runtime_symbol_list/debug/processDebugResources/R.txt',
  'symbol_list_with_package_name/release/processReleaseResources/package-aware-r.txt',
  'symbol_list_with_package_name/debug/processDebugResources/package-aware-r.txt'
 ];
 // Pick the variant being checked; never use a stale debug ID for a release APK.
 const variant=process.argv[4];
 const relevant=variant?candidates.filter(name=>name.split('/')[1]===variant):[];
 for(const name of relevant){
  try{const id=rawResourceId(await fs.readFile(path.join(build,name),'utf8'));if(id)return id}
  catch(error){if(error.code!=='ENOENT')throw error;}
 }
 return null; // Uncollapsed resource names can still be resolved directly.
}
if(process.argv[2]){
 const apk=path.resolve(process.argv[2]),aapt2=await aaptExecutable(process.argv[3]);
 const result=captureProcess(aapt2,['dump','resources',apk],{encoding:'utf8',maxBuffer:32*1024*1024});
 if(result.error||result.status!==0)throw Error(`Android resource-table inspection failed: ${result.error?.message??String(result.stderr).trim().slice(0,1200)}`);
 const mapping=verifyApkIntro(apk,intro,result.stdout,{resourceId:await generatedResourceId()});
 console.log(`APK opening movie verified: ${intro.resourceName} (${mapping.resourceId}) → ${mapping.files.join(', ')}. Approved bytes and SHA-256 match.`);
}else console.log('Approved opening movie is bundled locally; no network download is required.');
