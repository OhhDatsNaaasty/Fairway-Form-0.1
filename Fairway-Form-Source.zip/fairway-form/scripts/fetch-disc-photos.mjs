// Download representative manufacturer images during the existing GitHub build.
// A missing photo never substitutes an unrelated product or blocks video analysis.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {DISCS} from '../dist/lib/discs.js';
import {httpsUrl,imageCandidates,productLinks,shopifyImages,imageKind} from './lib/disc-photos.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),output=path.join(root,'dist/disc-photos');
const limit=2*1024*1024,deadline=Date.now()+6*60*1000,checked=new Date().toISOString().slice(0,10),cache=new Map(),images={},unavailable=[];
const hosts=new Set(['cdn.shopify.com','static.wixstatic.com','www.discraft.com','discraft.com','www.team.discraft.com','team.discraft.com','www.innovadiscs.com','innovadiscs.com','mvpdiscsports.com','axiomdiscs.com','www.discmania.net','discmania.net','prodigydisc.com','www.prodigydisc.com','www.dynamicdiscs.com','dynamicdiscs.com','latitude64.com','www.latitude64.com','westsidediscs.com','www.westsidediscs.com','trashpandadiscgolf.com','www.trashpandadiscgolf.com','images.squarespace-cdn.com','cdn11.bigcommerce.com']);
function permitted(url){const u=new URL(url);return u.protocol==='https:'&&!u.username&&!u.password&&hosts.has(u.hostname)}
async function request(url){
 for(let redirects=0;redirects<5;redirects++){
  if(Date.now()>=deadline)throw Error('Photo download budget reached');
  if(!permitted(url))throw Error('Unexpected photo host');
  const response=await fetch(url,{redirect:'manual',signal:AbortSignal.timeout(Math.max(1,Math.min(12000,deadline-Date.now()))),headers:{'User-Agent':'FairwayForm-PersonalCatalog/1.2 (+manufacturer source attribution)'}});
  if([301,302,303,307,308].includes(response.status)){const next=httpsUrl(response.headers.get('location'),url);await response.body?.cancel();if(!next)throw Error('Invalid redirect');url=next;continue}
  if(!response.ok){await response.body?.cancel();throw Error('HTTP '+response.status)}
  if(Number(response.headers.get('content-length'))>limit){await response.body?.cancel();throw Error('Asset exceeds size limit')}
  const chunks=[];let total=0;
  for await(const chunk of response.body){total+=chunk.length;if(total>limit){await response.body.cancel?.().catch(()=>{});throw Error('Asset exceeds size limit')}chunks.push(chunk)}
  return {data:Buffer.concat(chunks),mime:(response.headers.get('content-type')??'').split(';')[0],url};
 }
 throw Error('Too many redirects');
}
function document(url){if(!cache.has(url))cache.set(url,request(url));return cache.get(url)}
async function candidatesAt(url,model){
 const candidates=[];
 if(/\/collections\//.test(new URL(url).pathname)){
  const jsonUrl=new URL(url);jsonUrl.search='';jsonUrl.pathname=jsonUrl.pathname.replace(/\/$/,'')+'/products.json';jsonUrl.searchParams.set('limit','100');
  try{const result=await document(jsonUrl.href);candidates.push(...shopifyImages(JSON.parse(result.data.toString()),url,model))}catch{}
 }
 try{const page=await document(url);if(page.mime.includes('html'))candidates.push(...imageCandidates(page.data.toString(),page.url,model))}catch{}
 return candidates;
}
async function collect(disc){
 const candidates=[];
 if(disc.photoUrl)candidates.push({url:disc.photoUrl,page:disc.photoPage??disc.sourceUrl,kind:'Source-checked product image'});
 if(disc.photoPage)candidates.push(...await candidatesAt(disc.photoPage,disc.model));
 const hub=disc.photoHub??disc.sourceUrl;
 if(!disc.photoPage&&/\/products\/|\/discs\/[a-z0-9-]+\/?$/i.test(new URL(hub).pathname))candidates.push(...await candidatesAt(hub,disc.model));
 if(!candidates.length||disc.photoHub){
  try{const doc=await document(hub);const links=productLinks(doc.data.toString(),doc.url,disc.model);for(const page of links){candidates.push(...await candidatesAt(page,disc.model));if(candidates.length)break}}catch{}
 }
 const seen=new Set();
 for(const candidate of candidates.slice(0,8)){
  if(!candidate.url||seen.has(candidate.url))continue;seen.add(candidate.url);
  // Shopify and WordPress expose larger originals as well as tiny thumbnails.
  const url=new URL(candidate.url);if(url.hostname==='cdn.shopify.com'||url.pathname.includes('/cdn/shop/'))url.searchParams.set('width','560');
  if(/-65x65\.(?:jpg|png|webp)$/i.test(url.pathname))url.pathname=url.pathname.replace('-65x65.','.');
  for(const address of [...new Set([url.href,candidate.url])])try{
   const result=await request(address),ext=imageKind(result.data,result.mime);if(!ext)continue;
   const file=disc.id+'.'+ext;await fs.writeFile(path.join(output,file),result.data);
   images[disc.id]={src:'./disc-photos/'+file,sourcePage:candidate.page,imageUrl:result.url,credit:disc.brand,checked};return;
  }catch{}
 }
 unavailable.push(disc.id);
}
await fs.mkdir(output,{recursive:true});
let next=0;
await Promise.all(Array.from({length:4},async()=>{while(next<DISCS.length){const disc=DISCS[next++];if(Date.now()>=deadline){unavailable.push(disc.id);continue}try{await collect(disc)}catch{unavailable.push(disc.id)}if(next%40===0)console.log(`Photo lookup: ${next}/${DISCS.length} molds processed.`)}}));
const report={version:1,status:'built',total:DISCS.length,available:Object.keys(images).length,images,unavailable,byBrand:Object.fromEntries([...new Set(DISCS.map(d=>d.brand))].map(brand=>[brand,{molds:DISCS.filter(d=>d.brand===brand).length,photos:DISCS.filter(d=>d.brand===brand&&images[d.id]).length}]))};
await fs.writeFile(path.join(output,'index.json'),JSON.stringify(report,null,2)+'\n');
await fs.mkdir(path.join(root,'artifacts'),{recursive:true});await fs.writeFile(path.join(root,'artifacts/disc-photo-coverage.json'),JSON.stringify(report,null,2)+'\n');
console.log(`Disc photos: ${report.available}/${report.total} bundled. Unavailable photos use an explicit placeholder and manufacturer link.`);
for(const [brand,count]of Object.entries(report.byBrand))console.log(`${brand}: ${count.photos}/${count.molds} photos`);
