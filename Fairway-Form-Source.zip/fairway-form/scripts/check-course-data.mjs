import fs from 'node:fs/promises';
import {requireCourseSnapshot} from './lib/course-download.mjs';
const data=requireCourseSnapshot(JSON.parse(await fs.readFile(new URL('../dist/course-data/index.json',import.meta.url),'utf8')));
console.log(`Course packaging check passed: ${data.courses.length} offline courses, snapshot ${data.generatedAt}.`);
