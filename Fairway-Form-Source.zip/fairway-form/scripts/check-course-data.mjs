import fs from 'node:fs/promises';
import {courseBundleStatus} from '../dist/lib/course-directory.js';
const state=courseBundleStatus(JSON.parse(await fs.readFile(new URL('../dist/course-data/index.json',import.meta.url),'utf8')));
console.log(state.state==='available'?`Course packaging check passed: ${state.count} offline courses, snapshot ${state.generatedAt}.`:'Course packaging check passed: explicit directory-unavailable notice. Saved/manual courses work; no map courses are claimed.');
