// Development regressions from model-generated landmarks for user-provided
// references. These cases guided the change; this is not a held-out accuracy test.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {review} from '../dist/lib/analysis.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const cases=[['fullspeed-full-frame',null],['fullspeed-full-frame',{start:.8,end:4.9}],['fullspeed-video-crop',null],['slowed-displayed-orientation',null]];
const results=cases.map(([name,reviewWindow])=>{const d=JSON.parse(fs.readFileSync(path.join(root,'tests/fixtures/reference-poses',name+'.json'))),r=review(d.frames,{hand:'right',type:'backhand',view:'side',cameraStable:true,stance:'walkup',aspect:d.provenance.dimensions[0]/d.provenance.dimensions[1],...(reviewWindow?{reviewWindow}:{})});return {name,reviewWindow,sourceSha256:d.provenance.sourceSha256,modelSha256:d.provenance.modelSha256,sourceFrameCount:d.provenance.sourceFrameCount,sampledPoses:d.provenance.sampleCount,usableArmCoverage:r.coverage,events:Object.fromEntries(r.phases.map(p=>[p.id,p.t])),releaseConfirmed:r.quality.releaseConfirmed??false,ambiguousRelease:r.quality.ambiguousRelease??false}});
console.log(JSON.stringify({basis:'Same-model Python/CPU landmarks through production JavaScript event logic; no video/WASM/Android parity claim',referenceScope:'Two recordings attributed to one athlete; the crop and selected range are processing variants, not additional independent throws',results},null,2));
