"""Optional offline research extractor. Requires MediaPipe 0.10.21, OpenCV, numpy, ffprobe.
Uses local media and the bundled Full task; never uploads the recording.
This Python/CPU extraction is not WebView/WASM or Android decoder validation.
"""
import argparse,json,subprocess,hashlib,time,bisect
from pathlib import Path
import cv2,numpy as np,mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('output');p.add_argument('--crop',help='Optional x,y,width,height in displayed pixels');p.add_argument('--model',default=str(Path(__file__).resolve().parent.parent/'dist/vendor/pose_landmarker_full.task'));args=p.parse_args()
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','frame=best_effort_timestamp_time','-of','json',args.source]));ts=[float(f['best_effort_timestamp_time']) for f in meta['frames']];wanted={bisect.bisect_left(ts,max(0,i/30-.002)) for i in range(int(ts[-1]*30)+1)};wanted.discard(len(ts));cap=cv2.VideoCapture(args.source);cap.set(cv2.CAP_PROP_ORIENTATION_AUTO,1);model=args.model;crop=list(map(int,args.crop.split(','))) if args.crop else None
options=vision.PoseLandmarkerOptions(base_options=python.BaseOptions(model_asset_path=model,delegate=python.BaseOptions.Delegate.CPU),running_mode=vision.RunningMode.VIDEO,num_poses=2,min_pose_detection_confidence=.65,min_pose_presence_confidence=.65,min_tracking_confidence=.65)
frames=[];begin=time.monotonic();index=0;shape=None
with vision.PoseLandmarker.create_from_options(options) as detector:
 while True:
  ok,bgr=cap.read()
  if not ok:break
  if index in wanted:
   if crop:
    x,y,w,h=crop;bgr=bgr[y:y+h,x:x+w]
   rgb=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB);shape=[rgb.shape[1],rgb.shape[0]];result=detector.detect_for_video(mp.Image(image_format=mp.ImageFormat.SRGB,data=rgb),round(ts[index]*1000));multi=len(result.pose_landmarks)>1;raw=result.pose_landmarks[0] if result.pose_landmarks and not multi else None;world=result.pose_world_landmarks[0] if raw else None
   frames.append({'t':ts[index],'sourceIndex':index,'decodedTime':True,'p':[{'x':q.x,'y':q.y,'z':q.z,'visibility':min(q.visibility if q.visibility is not None else 0,q.presence if q.presence is not None else 1)} for q in raw] if raw else None,'world':[{'x':q.x,'y':q.y,'z':q.z} for q in world] if world else None,'multi':multi,'trackingMode':'video'})
   if len(frames)%50==0:print(json.dumps({'stage':'pose','samples':len(frames),'sourceTime':ts[index],'secondsElapsed':round(time.monotonic()-begin,1)}),flush=True)
  index+=1
cap.release()
assert index==len(ts),(index,len(ts))
output={'provenance':{'runtime':'MediaPipe Python CPU '+mp.__version__+'; production JavaScript selector tested separately','sourceSha256':hashlib.sha256(Path(args.source).read_bytes()).hexdigest(),'modelSha256':hashlib.sha256(Path(model).read_bytes()).hexdigest(),'model':'pose_landmarker_full.task','settings':{'runningMode':'VIDEO','delegate':'CPU','numPoses':2,'minPoseDetectionConfidence':.65,'minPosePresenceConfidence':.65,'minTrackingConfidence':.65},'sampleStrategy':'First decoded source timestamp at or after each 30 Hz requested time minus 2 ms, deduplicated; ffprobe PTS matched to decoded frame indices','crop':crop,'dimensions':shape,'sourceFrameCount':index,'sampleCount':len(frames),'readableSinglePersonSamples':sum(f['p'] is not None for f in frames),'secondsElapsed':round(time.monotonic()-begin,2)},'frames':frames}
Path(args.output).parent.mkdir(parents=True,exist_ok=True);Path(args.output).write_text(json.dumps(output,separators=(',',':')));print(json.dumps(output['provenance']),flush=True)
