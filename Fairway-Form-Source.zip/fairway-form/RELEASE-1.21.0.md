# Final Form - Disc Golf 1.21.0

Video review now reads decoded frames forward on supported phones, freezes each image during inference, and uses the browser's actual presented-frame timestamps. It no longer seeks individually for every body sample. Optional hand detail makes one rewind followed by a forward release-window pass. The first seek runs playback while waiting for a presented image, avoiding a paused-MP4 decoder stall reproduced during regression testing. No intermediate frames or hidden hand positions are generated.

A missing last sub-frame ends normally without repeatedly seeking the clip tail. A real early end or stall remains an explicit interruption with collected evidence kept. Cancellation removes frame callbacks/listeners, restores playback settings, and releases the reusable canvas. A failed optional hand pass keeps the completed body review. Browsers without frame callbacks retain the previous seek path. This does not establish improved biomechanical accuracy or support for every video codec; the phone's decoder still determines compatible formats.

Coaching replay buttons are gold (#dfbc72) with black text in every palette and appearance mode, including the summary's Watch review moment button. My Bag now searches model/alias, brand, plastic, condition and notes, with alphabetical and ascending/descending numeric speed sorting. Filtering and sorting do not rewrite bag records. Disc catalog Exact speed matches the selected rating, including fractional ratings present in the catalog; Any speed removes that filter.

## Validation

- 611 JavaScript checks passed, including new forward-decoder and bag/filter regressions.
- Real Chrome mobile browser checks passed with bundled pose and hand models, no-person footage rejection, interruption recovery, bag controls, and computed gold/black coaching contrast across all palettes and both modes.
- Real H.264 MP4 fixtures at 24, 30 and 60 fps completed body and near-tail hand review. Each used exactly two currentTime assignments: the body start and release-window rewind. Captured 89/112/114 distinct source timestamps and 10/12/13 hand-window samples respectively in this run. QA tokens test orchestration; they are not real-person model evidence.
- 12 native startup lifecycle rules and 19 native camera measurement rules passed. Approved intro bytes verified unchanged.
- JavaScript/import/offline-shell, control IDs, Android XML/shell syntax and version metadata checks passed.
- No local signed APK build or Pixel 10 device test is claimed. GitHub retains the mandatory browser/model gate, Android compilation and signature/content verification.

## Update from your phone

Replace repository-root Fairway-Form-Source.zip in the same private repository and commit it. Keep your working workflow and signing credentials. When Actions succeeds, download Fairway-Form-APK, extract Fairway-Form.apk and install over the existing app without uninstalling.

Retest the original failing video with hand detail enabled, then verify a saved session still opens. Search/sort My Bag and try catalog speed 5 to confirm that other speeds are excluded. Check Watch review moment in regular and dark mode.

Package com.fairwayform.app, WebView origin, IndexedDB schema 5, signing flow and existing storage identifiers are unchanged. Source version 1.21.0; default local Android versionCode 39, overridden by CI's increasing code. Video fixtures live only in tests/fixtures and are excluded from the APK's web assets.
