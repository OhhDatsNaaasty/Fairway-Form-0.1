# Final Form - Disc Golf 1.24.1

Addresses an unbounded lazy-image decode wait found in the browser validation
for the new sequence study. The reported GitHub run passed its H.264 fixtures,
then hit a 150-second Runtime.evaluate timeout within the broad prepared-frame
stage. That log does not identify the exact substep, so the lazy-image wait is
a plausible cause rather than a reproduced diagnosis of that CI run.

All DOM-image checks now use one tested helper: request loading eagerly, scroll
the image into view, wait at most eight seconds, and require usable dimensions.
Prepared-frame validation is divided into named steps for clip transfer,
preview, pending-marker protection, source pixels, release markers, analysis,
study-image decoding, lesson navigation, saving and cleanup. Direct evaluations
use a 15-second deadline. Failure diagnostics try to capture app/model status,
the frame time, toast and upload count, with a two-second diagnostic deadline.
Polling keeps its existing bounded per-command and elapsed-time deadlines.

The required browser/model gate, native frame rules and H.264 assertions remain
enabled. No unsafe SwiftShader flag was added. App behavior changes only in
version/cache labels; the tutorial research, native video pipeline, catalog,
saved records, package/origin, signing flow and approved intro are preserved.

## Validation

- 670 automated JavaScript tests passed, zero failures.
- New regression tests cover offscreen lazy images, never-resolving decodes,
  failed/empty images and the exact helper serialized into Chrome.
- Changed JavaScript syntax passed. Seven embedded prepared-frame expressions
  and four other image-check expressions were expanded and parsed.
- The local browser entry point returned BLOCKED in about 0.1 seconds because
  this environment denies localhost server sockets. No full local browser/model
  pass, Android API compilation or signed APK pass is claimed.

GitHub must still verify the complete browser/model, Android compile and APK
checks. If the prepared-frame check fails again, its log should now identify
the specific operation and capture available app state, instead of labeling
the entire sequence as one long step. This patch does not claim the original
phone-video decoding issue is verified resolved.

## Update

Replace repository-root Fairway-Form-Source.zip in the same private repository
and commit. Keep the existing workflow and signing credentials. After Actions
passes, install the extracted APK over the current app without uninstalling.
No workflow edit is required. Source version 1.24.1; fallback Android versionCode
45, with CI supplying its increasing code.
