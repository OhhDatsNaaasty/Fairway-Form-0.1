# Disc catalog audit — 1.22.0

Reviewed 2026-10-30. Added 242 models and explicitly named rated versions: **1092 total across all 28 existing brands**. All pages of the reviewed reference-brand inventories were read, then compared with available manufacturer directories and model/release pages. Directly checked manufacturer data is labeled Manufacturer; the other additions remain labeled Reference catalog with publisher and source links. No product descriptions or manufacturer images were copied into the new factual snapshots.

This is a dated coverage audit, not a guarantee of every historical prototype or cosmetic/plastic combination. Some manufacturer directories are dynamic, unavailable or image-only. Unpublished numbers are not guessed. The machine-readable inventory records every one of 995 reviewed reference rows, its resulting catalog ID or an explicit exclusion; there are no unresolved reviewed rows. It does not certify that a reference provider is exhaustive.

| Brand | Before | Added | Now |
| --- | ---: | ---: | ---: |
| AGL Discs | 19 | 1 | 20 |
| Axiom | 27 | 5 | 32 |
| Clash Discs | 23 | 0 | 23 |
| Climo | 7 | 1 | 8 |
| DGA | 21 | 11 | 32 |
| Discmania | 67 | 5 | 72 |
| Discraft | 79 | 19 | 98 |
| Dynamic Discs | 34 | 17 | 51 |
| Gateway | 13 | 32 | 45 |
| Infinite Discs | 17 | 15 | 32 |
| Innova | 126 | 15 | 141 |
| Kastaplast | 22 | 6 | 28 |
| Latitude 64° | 72 | 7 | 79 |
| Legacy Discs | 25 | 2 | 27 |
| Lone Star Disc | 48 | 3 | 51 |
| Løft Discs | 5 | 1 | 6 |
| MVP | 49 | 2 | 51 |
| Millennium | 11 | 21 | 32 |
| Mint Discs | 21 | 1 | 22 |
| Prodigy | 53 | 26 | 79 |
| RPM | 12 | 2 | 14 |
| Stokely Discs | 7 | 2 | 9 |
| Streamline | 13 | 4 | 17 |
| Thought Space Athletics | 17 | 4 | 21 |
| Trash Panda | 5 | 1 | 6 |
| Viking | 13 | 0 | 13 |
| Westside Discs | 32 | 6 | 38 |
| Yikun | 12 | 33 | 45 |

## Identity and variants

All 850 shipped records keep their IDs, names and ratings, preserving bag references and existing throw histories. Alternate names such as Aviar P&A, Firefly, The Tex/Tex, Luan/Lu, Swan/Swan 2 and Orion LF resolve to existing records. Brand aliases include Above Ground Level, MVP Disc Sports and ASCII Loft. Original/retooled Kaxe, Time-Lapse and Venom references are explicitly named when their published ratings differ. The manufacturer-confirmed Eternal GOAT run and reference Victor Penny Putter are separate rated versions. These do not rewrite an existing copy’s plastic or history.

## Data corrections and limits

Gateway Air Strike uses the manufacturer’s Platinum 13/5/-2/2 rather than a conflicting 9-speed reference listing. Ne Zha uses its dedicated manufacturer page’s 5/5/-2/1. Yikun Qi retains an explicitly uncertain 13/6/-2/2 reference because its broad manufacturer directory disagrees and the model page returned 403. MVP Mass is included with the manufacturer’s explicitly tentative 4/2/0/3 numbers. Both uncertain records generate a Caddy caution. Existing conflicting ratings are not silently replaced.

Uplink listed under Axiom was excluded because it is already an MVP mold. Black Zombie Chainsaw and Reptilian Scale/Serpent were excluded from Gateway-branded additions. The NERF Ultimate catch/ultimate product was excluded from this disc-golf inventory. Named CHING releases sold under Stokely remain explicitly labeled CHING in their model names. Missing product photos remain labeled unavailable.

## Reproduce

Edit scripts/catalog-audit-additions-1.22.0.json, then run node scripts/build-catalog.mjs and npm test. The inventory and alias decisions live beside the snapshot. tests/fixtures/catalog-1.21.0.json protects all shipped identities/ratings.

## Sources by brand

### AGL Discs

Manufacturer directory attempted: https://www.agldiscs.com/collections/all

Fact sources:

- https://discpass.com/en/discs/above-ground-level
- https://trydiscs.com/product/above-ground-level/dogwood

### Axiom

Manufacturer directory attempted: https://axiomdiscs.com/discs/

Fact sources:

- https://axiomdiscs.com/discs/inspire/
- https://axiomdiscs.com/discs/pitch/
- https://axiomdiscs.com/discs/thrill/
- https://axiomdiscs.com/discs/trance/
- https://discpass.com/en/discs/axiom-discs
- https://discpass.com/en/discs/axiom-discs/time-lapse

### Clash Discs

Manufacturer directory attempted: https://www.clashdiscs.com/products

Fact sources:

- https://discpass.com/en/discs/clash-discs

### Climo

Manufacturer directory attempted: https://climodiscgolf.com/collections/discs

Fact sources:

- https://climodiscgolf.com/products/climo-prototype-apogee
- https://discpass.com/en/discs/climo-disc-golf

### DGA

Manufacturer directory attempted: https://store.discgolf.com/pages/disc-flight-chart

Fact sources:

- https://discpass.com/en/discs/dga

### Discmania

Manufacturer directory attempted: https://www.discmania.net/collections/discs

Fact sources:

- https://discpass.com/en/discs/discmania
- https://www.discmania.net/collections/discmania-premier

### Discraft

Manufacturer directory attempted: https://www.discraft.com/disc-golf/discs/

Fact sources:

- https://discpass.com/en/discs/discraft
- https://www.team.discraft.com/post/anthony-barela-first-run-cigarra-dropping-march-21st-on-the-discraft-factory-store

### Dynamic Discs

Manufacturer directory attempted: https://www.dynamicdiscs.com/collections/discs

Fact sources:

- https://discpass.com/en/discs/dynamic-discs

### Gateway

Manufacturer directory attempted: https://gatewaydiscsports.com/pages/flight-chart

Fact sources:

- https://discpass.com/en/discs/gateway
- https://gatewaydiscsports.com/products/airstrike-platinum

### Infinite Discs

Manufacturer directory attempted: https://infinitediscs.com/brand/infinite-discs

Fact sources:

- https://discpass.com/en/discs/infinite-discs

### Innova

Manufacturer directory attempted: https://www.innovadiscs.com/disc/

Fact sources:

- https://discpass.com/en/discs/innova

### Kastaplast

Manufacturer directory attempted: https://www.kastaplast.com/collections/all-discs

Fact sources:

- https://discpass.com/en/discs/kastaplast

### Latitude 64°

Manufacturer directory attempted: https://latitude64.com/collections/discs

Fact sources:

- https://discpass.com/en/discs/latitude-64
- https://latitude64.com/collections/discs
- https://latitude64.com/collections/spike
- https://latitude64.com/products/max-wild-prototype

### Legacy Discs

Manufacturer directory attempted: https://legacydiscsproshop.com/collections/discs

Fact sources:

- https://discpass.com/en/discs/legacy

### Lone Star Disc

Manufacturer directory attempted: https://www.lonestardiscs.com/pages/downloads

Fact sources:

- https://discpass.com/en/discs/lone-star-discs

### Løft Discs

Manufacturer directory attempted: https://loftdiscs.com/collections/discs

Fact sources:

- https://discsport.se/loeft-discs-loft

### MVP

Manufacturer directory attempted: https://mvpdiscsports.com/discs/

Fact sources:

- https://discpass.com/en/discs/mvp
- https://mvpdiscsports.com/discs/stasis/
- https://mvpdiscsports.com/releases/october-2026-release/

### Millennium

Manufacturer directory attempted: https://www.golfdisc.com/discs/

Fact sources:

- https://discpass.com/en/discs/millennium
- https://www.golfdisc.com/discs/exp-x/
- https://www.golfdisc.com/discs/omega driver/
- https://www.golfdisc.com/discs/taurus/

### Mint Discs

Manufacturer directory attempted: https://mintdiscs.com/collections/discs

Fact sources:

- https://discpass.com/en/discs/mint-discs
- https://mintdiscs.com/collections/eternal-plastic/products/goat-eternal-plastic-et-gt01-23

### Prodigy

Manufacturer directory attempted: https://prodigydisc.com/collections/all-disc-golf-discs

Fact sources:

- https://discpass.com/en/discs/prodigy

### RPM

Manufacturer directory attempted: https://www.rpmdiscs.com/

Fact sources:

- https://discpass.com/en/discs/rpm

### Stokely Discs

Manufacturer directory attempted: https://stokelydiscs.com/

Fact sources:

- https://discpass.com/en/discs/stokely-discs

### Streamline

Manufacturer directory attempted: https://streamlinediscs.com/discs/

Fact sources:

- https://discpass.com/en/discs/streamline
- https://streamlinediscs.com/discs/autopilot/
- https://streamlinediscs.com/discs/engine/
- https://streamlinediscs.com/discs/parachute/
- https://streamlinediscs.com/discs/shift/

### Thought Space Athletics

Manufacturer directory attempted: https://thoughtspaceathletics.com/collections/discs

Fact sources:

- https://discpass.com/en/discs/thought-space-athletics

### Trash Panda

Manufacturer directory attempted: https://trashpandadiscgolf.com/collections/store

Fact sources:

- https://discpass.com/en/discs/trash-panda

### Viking

Manufacturer directory attempted: https://vikingdiscs.com/

Fact sources:

- https://discpass.com/en/discs/viking

### Westside Discs

Manufacturer directory attempted: https://westsidediscs.com/collections/discs

Fact sources:

- https://discpass.com/en/discs/westside-discs

### Yikun

Manufacturer directory attempted: https://en.yikunsports.com/GOLF-DISC

Fact sources:

- https://discpass.com/en/discs/yikun
- https://en.yikunsports.com/DRIVER
- https://en.yikunsports.com/GOLF-DISC
- https://en.yikunsports.com/NE-ZHA

