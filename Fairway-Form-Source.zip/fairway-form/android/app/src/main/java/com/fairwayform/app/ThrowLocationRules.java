package com.fairwayform.app;
/** Freshness checks only. A reported radius is not a measured error guarantee. */
public final class ThrowLocationRules {
 private ThrowLocationRules(){}
 public static boolean accept(double latitude,double longitude,float accuracy,long ageMs,boolean mock,long fixNs,long startedNs,long previousNs){
  return Double.isFinite(latitude)&&Double.isFinite(longitude)&&Math.abs(latitude)<=90&&Math.abs(longitude)<=180&&Float.isFinite(accuracy)&&accuracy>0&&accuracy<=200&&ageMs>=0&&ageMs<=1500&&!mock&&fixNs>=startedNs-1000000000L&&fixNs>previousNs;
 }
 public static boolean validId(String id){return id!=null&&id.matches("[a-zA-Z0-9-]{1,100}");}
}
