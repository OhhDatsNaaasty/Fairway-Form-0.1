package com.fairwayform.app;
import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.webkit.WebView;
import android.view.WindowManager;
import org.json.JSONObject;
/** Foreground GNSS session; no route/coordinate persistence or background service. */
public final class ThrowLocation implements LocationListener {
 private final Activity activity;private final WebView web;private final LocationManager manager;private final Handler handler=new Handler(Looper.getMainLooper());
 private String id;private long startedNs,previousNs;private final Runnable timeout=()->end("Location session expired. Start again at the throwing spot.");
 public ThrowLocation(Activity activity,WebView web){this.activity=activity;this.web=web;manager=(LocationManager)activity.getSystemService(Activity.LOCATION_SERVICE);}
 public void start(String request){
  if(!ThrowLocationRules.validId(request))return;if(request.equals(id))return;stop();id=request;startedNs=SystemClock.elapsedRealtimeNanos();previousNs=0;
  if(activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){end("Precise location permission is needed.");return;}
  try{if(manager==null||!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)){end("Enable GPS location, or use a marked landing or checked distance.");return;}manager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0,this,Looper.getMainLooper());activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);handler.postDelayed(timeout,600000);}
  catch(SecurityException error){end("Precise location permission is needed.");}catch(Exception error){end("GPS could not start. Try again or enter a distance.");}
 }
 @Override public void onLocationChanged(Location location){
  if(id==null)return;long fixNs=location.getElapsedRealtimeNanos(),age=(SystemClock.elapsedRealtimeNanos()-fixNs)/1000000;
  boolean mock=Build.VERSION.SDK_INT>=31?location.isMock():location.isFromMockProvider();
  if(!location.hasAccuracy()||!ThrowLocationRules.accept(location.getLatitude(),location.getLongitude(),location.getAccuracy(),age,mock,fixNs,startedNs,previousNs))return;previousNs=fixNs;
  try{JSONObject c=new JSONObject();c.put("latitude",location.getLatitude());c.put("longitude",location.getLongitude());c.put("accuracy",location.getAccuracy());c.put("speed",location.hasSpeed()?location.getSpeed():JSONObject.NULL);JSONObject e=new JSONObject();e.put("id",id);e.put("timestamp",System.currentTimeMillis()-age);e.put("monotonicMs",fixNs/1000000.0);e.put("ageMs",age);e.put("coords",c);emit(e);}catch(Exception ignored){}
 }
 private void emit(JSONObject event){web.evaluateJavascript("window.dispatchEvent(new CustomEvent('fairway-throw-location',{detail:"+event.toString()+"}))",null);}
 private void end(String error){String request=id;stop();if(request==null)return;try{JSONObject e=new JSONObject();e.put("id",request);e.put("error",error);emit(e);}catch(Exception ignored){}}
 public void stop(String request){if(request==null||request.equals(id))stop();}
 public void stop(){handler.removeCallbacks(timeout);activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(manager!=null)try{manager.removeUpdates(this);}catch(Exception ignored){}id=null;previousNs=0;}
 @Override public void onProviderDisabled(String provider){if(LocationManager.GPS_PROVIDER.equals(provider))end("GPS was disabled. Enable it and try again.");}
 @Override public void onProviderEnabled(String provider){}
 @Override public void onStatusChanged(String provider,int status,Bundle extras){}
}
