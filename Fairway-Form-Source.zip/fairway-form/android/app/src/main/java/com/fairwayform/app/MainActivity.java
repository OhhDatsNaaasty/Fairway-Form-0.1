package com.fairwayform.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.ClipData;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import androidx.core.content.FileProvider;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.view.View;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.speech.tts.UtteranceProgressListener;
import org.json.JSONArray;
import org.json.JSONObject;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import android.widget.FrameLayout;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
 private static final String ORIGIN = "https://appassets.androidplatform.net";
 private static final int PICK_VIDEO = 101, CAMERA_PERMISSION = 102, CAPTURE_PERMISSION = 103, LOCATION_PERMISSION = 104, PRECISE_LOCATION_PERMISSION = 105;
 private String pendingPreciseLocation;
 private String cameraRangeRequest;
 private static final int CAMERA_RANGE=106;
 private WebView web;
 private StartupIntro startupIntro;
 private final StartupPolicy startupPolicy=new StartupPolicy();
 private PhoneCompass phoneCompass;
 private ValueCallback<Uri[]> picker;
 private PermissionRequest pendingCamera;
 private Intent pendingCapture;
 private Uri pendingPhotoUri;
 private GeolocationPermissions.Callback pendingLocation;
 private String pendingLocationOrigin;
 private TextRecognizer signRecognizer;
 private boolean readingSign=false;
 private TextToSpeech speech;
 private boolean speechReady = false, speechInitializing = false, allowNetworkVoices = false;
 private String speechVoice = "";
 private float speechRate = 1.0f;
 private String pendingSpeech;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  web = new WebView(this);
  FrameLayout root=new FrameLayout(this);root.addView(web,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
  startupIntro=new StartupIntro(this,root,web,()->web.reload(),()->applyTheme(getPreferences(MODE_PRIVATE).getString("theme","forest")));
  phoneCompass=new PhoneCompass(this,reading->web.evaluateJavascript("window.dispatchEvent(new CustomEvent('fairway-compass',{detail:"+reading.toString()+"}))",null));
  speechVoice=getPreferences(MODE_PRIVATE).getString("speechVoice","");
  speechRate=getPreferences(MODE_PRIVATE).getFloat("speechRate",1.0f);
  allowNetworkVoices=getPreferences(MODE_PRIVATE).getBoolean("allowNetworkVoices",false);
  applyTheme(getPreferences(MODE_PRIVATE).getString("theme","forest"));
  WebSettings settings = web.getSettings();
  settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setGeolocationEnabled(true);
  settings.setMediaPlaybackRequiresUserGesture(false);
  settings.setAllowFileAccess(false); settings.setAllowContentAccess(true);
  settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  web.addJavascriptInterface(new FileBridge(), "AndroidFiles");
  web.setWebViewClient(new WebViewClient() {
   @Override public void onPageStarted(WebView view,String url,Bitmap favicon){if(startupIntro!=null)startupIntro.appLoading();}
   @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){if(request.isForMainFrame()&&startupIntro!=null)startupIntro.appFailed();}
   @Override public void onReceivedHttpError(WebView view,WebResourceRequest request,WebResourceResponse error){if(request.isForMainFrame()&&startupIntro!=null)startupIntro.appFailed();}
   @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
    Uri uri = request.getUrl();
    if (!ORIGIN.equals(uri.getScheme()+"://"+uri.getHost())) return null;
    String path = uri.getPath();
    if (path == null || path.equals("/")) path="/index.html";
    if (path.contains("..")) return response(403,"text/plain",new ByteArrayInputStream(new byte[0]));
    try {
     InputStream stream = getAssets().open("web"+path);
     String ext = path.substring(path.lastIndexOf('.')+1).toLowerCase(Locale.ROOT);
     String mime;
     switch(ext) {
      case "js": case "mjs": mime="application/javascript"; break;
      case "wasm": mime="application/wasm"; break;
      case "css": mime="text/css"; break;
      case "json": case "webmanifest": mime="application/json"; break;
      case "svg": mime="image/svg+xml"; break;
      case "png": mime="image/png"; break;
      case "jpg": case "jpeg": mime="image/jpeg"; break;
      case "webp": mime="image/webp"; break;
      case "task": mime="application/octet-stream"; break;
      default: mime="text/html";
     }
     return response(200,mime,stream);
    } catch(IOException e) { return response(404,"text/plain",new ByteArrayInputStream(new byte[0])); }
   }
   @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
    Uri uri=request.getUrl();
    if (ORIGIN.equals(uri.getScheme()+"://"+uri.getHost())) return false;
    if ("https".equals(uri.getScheme())) {
     try { openExternalActivity(new Intent(Intent.ACTION_VIEW,uri)); } catch(Exception e) { message("No browser available for this link."); }
    }
    return true;
   }
  });
  web.setWebChromeClient(new WebChromeClient() {
   @Override public void onPermissionRequest(PermissionRequest request) {
    runOnUiThread(()->{
     if(!ORIGIN.equals(request.getOrigin().toString().replaceAll("/$",""))) { request.deny(); return; }
     if(!Arrays.asList(request.getResources()).contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {request.deny();return;}
     if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
     else { if(pendingCamera!=null)pendingCamera.deny();pendingCamera=request;requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION); }
    });
   }
   @Override public void onPermissionRequestCanceled(PermissionRequest request) { if(pendingCamera==request)pendingCamera=null; }
   @Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback callback) {
    if(!ORIGIN.equals(origin.replaceAll("/$",""))){callback.invoke(origin,false,false);return;}
    if(checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){callback.invoke(origin,true,false);return;}
    if(pendingPreciseLocation!=null){callback.invoke(origin,false,false);return;}
    if(pendingLocation!=null)pendingLocation.invoke(pendingLocationOrigin,false,false);
    pendingLocation=callback;pendingLocationOrigin=origin;
    requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_PERMISSION);
   }
   @Override public void onGeolocationPermissionsHidePrompt(){if(pendingLocation!=null){GeolocationPermissions.Callback callback=pendingLocation;pendingLocation=null;callback.invoke(pendingLocationOrigin,false,false);}}
   @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params) {
    if(picker!=null)picker.onReceiveValue(null);picker=callback;pendingPhotoUri=null;
    String accepted=String.join(",",params.getAcceptTypes());
    boolean image=accepted.contains("image"),json=accepted.contains("json");
    Intent intent;
    if(params.isCaptureEnabled()) {
     if(image){
      intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
      try {
       File directory=new File(getCacheDir(),"signs");if(!directory.exists()&&!directory.mkdirs())throw new IOException("Camera cache unavailable");
       File[] old=directory.listFiles();if(old!=null)for(File f:old)if(f.lastModified()<System.currentTimeMillis()-86400000L)f.delete();
       File photo=File.createTempFile("sign-",".jpg",directory);
       pendingPhotoUri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".files",photo);
       intent.putExtra(MediaStore.EXTRA_OUTPUT,pendingPhotoUri);intent.setClipData(ClipData.newRawUri("Disc or hole-sign photo",pendingPhotoUri));
       intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
      }catch(Exception e){picker.onReceiveValue(null);picker=null;pendingPhotoUri=null;message("Could not prepare the photo. Choose a photo from Gallery instead.");return true;}
     }else{intent=new Intent(MediaStore.ACTION_VIDEO_CAPTURE);intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT,20);intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY,1);}
    }else{
     intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.setType(json?"*/*":image?"image/*":"video/*");
     if(json)intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"});
     intent.addCategory(Intent.CATEGORY_OPENABLE);
    }
    if(params.isCaptureEnabled()&&checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){pendingCapture=intent;requestPermissions(new String[]{Manifest.permission.CAMERA},CAPTURE_PERMISSION);return true;}
    try{startActivityForResult(intent,PICK_VIDEO);}catch(Exception e){picker.onReceiveValue(null);picker=null;pendingPhotoUri=null;message("Camera or file picker unavailable. Try Gallery.");}
    return true;
   }
  });
  web.loadUrl(ORIGIN+"/index.html");
 }
 private WebResourceResponse response(int code,String mime,InputStream stream) {
  Map<String,String> headers=new HashMap<>();headers.put("Access-Control-Allow-Origin",ORIGIN);headers.put("Cache-Control","no-cache");
  return new WebResourceResponse(mime,"UTF-8",code,code==200?"OK":code==404?"Not Found":"Forbidden",headers,stream);
 }
 @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results) {
  super.onRequestPermissionsResult(code,permissions,results);
  if(code==PRECISE_LOCATION_PERMISSION&&pendingPreciseLocation!=null){String id=pendingPreciseLocation;pendingPreciseLocation=null;publishLocationPermission(id,checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED);}
  if(code==LOCATION_PERMISSION&&pendingLocation!=null){pendingLocation.invoke(pendingLocationOrigin,results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED,false);pendingLocation=null;}
  if(code==CAPTURE_PERMISSION&&pendingCapture!=null) {
   if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED) {try {startActivityForResult(pendingCapture,PICK_VIDEO);}catch(Exception e){if(picker!=null)picker.onReceiveValue(null);picker=null;message("Phone camera unavailable.");}}
   else {if(picker!=null)picker.onReceiveValue(null);picker=null;}
   pendingCapture=null;
  }
  if(code==CAMERA_PERMISSION&&pendingCamera!=null) {if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)pendingCamera.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});else pendingCamera.deny();pendingCamera=null;}
 }
 @Override protected void onActivityResult(int code,int result,Intent data) {
  super.onActivityResult(code,result,data);
  if(code==CAMERA_RANGE&&cameraRangeRequest!=null){
   String id=cameraRangeRequest;cameraRangeRequest=null;
   try {JSONObject value=new JSONObject();value.put("id",id);value.put("cancelled",result!=RESULT_OK||data==null);
    if(result==RESULT_OK&&data!=null){value.put("meters",data.getDoubleExtra("meters",Double.NaN));value.put("mode",data.getStringExtra("mode"));}
    web.post(()->web.evaluateJavascript("window.dispatchEvent(new CustomEvent('fairway-camera-range',{detail:"+value.toString()+"}))",null));
   }catch(Exception e){message("Camera estimate could not be returned. Please try again.");}
  }
  if(code==PICK_VIDEO&&picker!=null){picker.onReceiveValue(result==RESULT_OK&&pendingPhotoUri!=null?new Uri[]{pendingPhotoUri}:WebChromeClient.FileChooserParams.parseResult(result,data));picker=null;pendingPhotoUri=null;}
 }
 @Override public void onBackPressed() { if(startupIntro!=null&&startupIntro.isVisible()){startupIntro.skip();return;}if(web.canGoBack())web.goBack();else super.onBackPressed(); }
 @Override public void onConfigurationChanged(Configuration config) {
  super.onConfigurationChanged(config);refreshSystemTheme();
 }
 @Override protected void onStart(){super.onStart();boolean show=startupPolicy.onStart();if(show&&startupIntro!=null)startupIntro.show();}
 @Override protected void onResume() {super.onResume();if(startupIntro!=null)startupIntro.resume();refreshSystemTheme();}
 @Override protected void onStop(){
  startupPolicy.onStop(false);
  if(startupIntro!=null)startupIntro.stop();super.onStop();
 }
 private void refreshSystemTheme() {if(web!=null)web.evaluateJavascript("window.dispatchEvent(new Event('fairway-system-theme'))",null);if(speechReady)publishVoices(null);}
 @Override protected void onPause() {if(startupIntro!=null)startupIntro.stop();if(phoneCompass!=null)phoneCompass.pause();if(speech!=null)speech.stop();pendingSpeech=null;if(web!=null)web.evaluateJavascript("window.dispatchEvent(new Event('fairway-native-pause'))",null);super.onPause();}
 @Override protected void onDestroy() {if(startupIntro!=null)startupIntro.close();if(phoneCompass!=null)phoneCompass.stop();if(picker!=null)picker.onReceiveValue(null);if(pendingCamera!=null)pendingCamera.deny();if(pendingLocation!=null)pendingLocation.invoke(pendingLocationOrigin,false,false);if(signRecognizer!=null)signRecognizer.close();if(speech!=null){speech.stop();speech.shutdown();}web.destroy();super.onDestroy();}
 private Locale preferredEnglishLocale() {Locale locale=Locale.getDefault();return "en".equals(locale.getLanguage())?locale:Locale.US;}
 private void publishLocationPermission(String id,boolean granted){
  web.evaluateJavascript("window.dispatchEvent(new CustomEvent('fairway-location-permission',{detail:{id:"+JSONObject.quote(id)+",granted:"+granted+"}}))",null);
 }
 private List<Voice> installedEnglishVoices() {
  List<Voice> voices=new ArrayList<>();
  if(speech==null||!speechReady)return voices;
  Set<Voice> available=speech.getVoices();
  if(available!=null)for(Voice voice:available) {
   if(!"en".equals(voice.getLocale().getLanguage()))continue;
   if(voice.getFeatures()!=null&&voice.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED))continue;
   voices.add(voice);
  }
  voices.sort(Comparator.comparingInt(Voice::getQuality).reversed()
   .thenComparingInt(v->v.getLocale().getCountry().equals(preferredEnglishLocale().getCountry())?0:1)
   .thenComparingInt(Voice::getLatency).thenComparing(Voice::getName));
  return voices;
 }
 private boolean applySpeechVoice() {
  List<Voice> available=installedEnglishVoices();Voice chosen=null;
  for(Voice voice:available) {
   if(!allowNetworkVoices&&voice.isNetworkConnectionRequired())continue;
   if(chosen==null)chosen=voice;
   if(voice.getName().equals(speechVoice)){chosen=voice;break;}
  }
  if(chosen==null||speech.setVoice(chosen)!=TextToSpeech.SUCCESS)return false;
  speech.setSpeechRate(speechRate);speech.setPitch(1.0f);return true;
 }
 private void publishVoices(String error) {
  try {
   JSONArray entries=new JSONArray();int index=0;
   for(Voice voice:installedEnglishVoices()) {
    JSONObject value=new JSONObject();value.put("id",voice.getName());value.put("lang",voice.getLocale().toLanguageTag());
    value.put("label",voice.getLocale().getDisplayName(Locale.US)+" · Voice "+(++index));
    value.put("quality",voice.getQuality());value.put("latency",voice.getLatency());
    value.put("network",voice.isNetworkConnectionRequired());value.put("installed",true);entries.put(value);
   }
   JSONObject payload=new JSONObject();payload.put("voices",entries);if(error!=null)payload.put("error",error);
   web.evaluateJavascript("window.dispatchEvent(new CustomEvent('fairway-voices',{detail:"+payload.toString()+"}))",null);
  }catch(Exception e){message("Could not list speech voices. Try your phone’s voice settings.");}
 }
 private boolean ensureSpeech() {
  if(speechReady)return true;
  if(speechInitializing)return false;
  speechInitializing=true;
  speech=new TextToSpeech(this,result->runOnUiThread(()->{
   if(isFinishing()||isDestroyed())return;
   speechInitializing=false;speechReady=result==TextToSpeech.SUCCESS;
   if(!speechReady){pendingSpeech=null;if(speech!=null){speech.shutdown();speech=null;}publishVoices("Speech engine unavailable");message("Speech is unavailable. You can read the plan or try your phone’s voice settings.");return;}
   speech.setOnUtteranceProgressListener(new UtteranceProgressListener(){
    @Override public void onStart(String id) {}
    @Override public void onDone(String id) {}
    @Override public void onError(String id) {message("That voice could not finish. Try another voice in App & settings.");}
   });
   publishVoices(null);
   if(pendingSpeech!=null)speakPending();
  }));
  return false;
 }
 private void speakPlan(String text) {pendingSpeech=text;if(ensureSpeech())speakPending();}
 private void speakPending() {
  String text=pendingSpeech;pendingSpeech=null;if(text==null||speech==null||!speechReady)return;
  if(!applySpeechVoice()){message("No suitable English voice is ready. Add an offline English voice in your phone’s settings, or allow internet voices in the app.");return;}
  speech.stop();boolean first=true;int counter=0,limit=Math.min(650,TextToSpeech.getMaxSpeechInputLength()-1);
  for(String paragraph:text.split("\\n\\s*\\n")) {
   String remaining=paragraph.trim();if(remaining.isEmpty())continue;
   while(!remaining.isEmpty()) {
    int length=Math.min(limit,remaining.length());
    if(length<remaining.length()){int space=remaining.lastIndexOf(' ',length);if(space>0)length=space;}
    String part=remaining.substring(0,length);remaining=remaining.substring(length).trim();
    int result=speech.speak(part,first?TextToSpeech.QUEUE_FLUSH:TextToSpeech.QUEUE_ADD,null,"fairway-plan-"+(counter++));first=false;
    if(result==TextToSpeech.ERROR){speech.stop();message("Voice playback could not start. Try another voice in App & settings.");return;}
   }
   speech.playSilentUtterance(220,TextToSpeech.QUEUE_ADD,"fairway-pause-"+counter);
  }
 }
 private void openExternalActivity(Intent intent){startActivity(intent);}
 private void message(String value) { runOnUiThread(()->Toast.makeText(this,value,Toast.LENGTH_LONG).show()); }
 private void applyTheme(String theme) {
  boolean dark=true;int bar=0xff101f1d,background=0xff101f1d;
  web.setBackgroundColor(background);
  if(startupIntro!=null&&startupIntro.isVisible()){bar=0xff101f1d;background=0xff101f1d;dark=true;}
  getWindow().setStatusBarColor(bar);getWindow().setNavigationBarColor(background);
  int flags=getWindow().getDecorView().getSystemUiVisibility();
  flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
  if(dark)flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
  else flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
  getWindow().getDecorView().setSystemUiVisibility(flags);
 }
 private void sendSignText(String id,String text,String error){sendSignText(id,text,error,null);}
 private void sendSignText(String id,String text,String error,JSONArray lines){
  if(isFinishing()||isDestroyed())return;
  try{JSONObject value=new JSONObject();value.put("id",id);if(lines!=null)value.put("lines",lines);if(text!=null)value.put("text",text);if(error!=null)value.put("error",error);
   web.evaluateJavascript("window.dispatchEvent(new CustomEvent('fairway-sign-text',{detail:"+value.toString()+"}))",null);
  }catch(Exception e){message("Could not return sign text.");}
 }
 private void readSign(String id,String encoded){
  if(readingSign){sendSignText(id,null,"Another sign is being read. Try again shortly.");return;}
  Bitmap bitmap=null;
  try{
   byte[] bytes=Base64.decode(encoded,Base64.DEFAULT);BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,bounds);
   if(bounds.outWidth<=0||bounds.outHeight<=0||(long)bounds.outWidth*bounds.outHeight>4200000L)throw new IOException("Use a smaller sign photo.");
   bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length);if(bitmap==null)throw new IOException("The sign photo could not decode.");
   if(signRecognizer==null)signRecognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
   readingSign=true;final Bitmap source=bitmap;
   signRecognizer.process(InputImage.fromBitmap(source,0))
     .addOnSuccessListener(result->{String text=result.getText();if(text.length()>16000)text=text.substring(0,16000);
     try{JSONArray lines=new JSONArray();for(com.google.mlkit.vision.text.Text.TextBlock block:result.getTextBlocks())for(com.google.mlkit.vision.text.Text.Line line:block.getLines()){
      android.graphics.Rect box=line.getBoundingBox();if(box==null||lines.length()>=256)continue;JSONObject row=new JSONObject(),boundsJson=new JSONObject();row.put("text",line.getText());
      boundsJson.put("x",Math.max(0,box.left)/(double)source.getWidth());boundsJson.put("y",Math.max(0,box.top)/(double)source.getHeight());boundsJson.put("width",Math.max(0,Math.min(source.getWidth(),box.right)-Math.max(0,box.left))/(double)source.getWidth());boundsJson.put("height",Math.max(0,Math.min(source.getHeight(),box.bottom)-Math.max(0,box.top))/(double)source.getHeight());row.put("box",boundsJson);lines.put(row);
     }sendSignText(id,text,null,lines);}catch(Exception e){sendSignText(id,text,null);}
    })
    .addOnFailureListener(error->sendSignText(id,null,"Text could not be read. Try a clearer photo or type the visible text."))
    .addOnCompleteListener(task->{readingSign=false;source.recycle();});
  }catch(Exception e){readingSign=false;if(bitmap!=null)bitmap.recycle();sendSignText(id,null,e.getMessage()==null?"The sign could not be read.":e.getMessage());}
 }
 private class FileBridge {
  @JavascriptInterface public void startupReady(){runOnUiThread(()->{if(startupIntro!=null&&!isFinishing()&&!isDestroyed())startupIntro.appReady();});}
  @JavascriptInterface public void measureWithCamera(String id,String mode,String unit){
   if(id==null||!id.matches("[a-zA-Z0-9-]{1,100}")||!Arrays.asList("target","walk").contains(mode))return;
   runOnUiThread(()->{if(cameraRangeRequest!=null)return;cameraRangeRequest=id;
    try{Intent intent=new Intent(MainActivity.this,CameraRangeActivity.class);intent.putExtra("mode",mode);intent.putExtra("unit","m".equals(unit)?"m":"ft");startActivityForResult(intent,CAMERA_RANGE);}
    catch(Exception e){cameraRangeRequest=null;web.evaluateJavascript("window.dispatchEvent(new CustomEvent('fairway-camera-range',{detail:{id:"+JSONObject.quote(id)+",error:'Camera measurement could not open.'}}))",null);}
   });
  }
  @JavascriptInterface public void startCompass(String id,double latitude,double longitude){
   if(id==null||!id.matches("[a-zA-Z0-9-]{1,100}"))return;
   runOnUiThread(()->phoneCompass.start(id,latitude,longitude));
  }
  @JavascriptInterface public void stopCompass(String id){runOnUiThread(()->phoneCompass.stop(id));}
  @JavascriptInterface public void recognizeSign(String id,String encoded){
   if(id==null||!id.matches("[a-zA-Z0-9-]{1,80}")||encoded==null||encoded.length()>3*1024*1024)return;
   runOnUiThread(()->readSign(id,encoded));
  }
  @JavascriptInterface public void requestPreciseLocation(String id){
   if(id==null||!id.matches("[a-zA-Z0-9-]{1,100}"))return;
   runOnUiThread(()->{
    if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED){publishLocationPermission(id,true);return;}
    if(pendingPreciseLocation!=null||pendingLocation!=null){publishLocationPermission(id,false);return;}
    pendingPreciseLocation=id;
    // Android 12+ requires requesting coarse and fine together, including an
    // upgrade from the weather feature's existing approximate permission.
    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},PRECISE_LOCATION_PERMISSION);
   });
  }
  @JavascriptInterface public boolean isSystemDark() {return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;}
  @JavascriptInterface public void setTheme(String theme) {
   if(!Arrays.asList("forest","forest-dark","coast","coast-dark","sunset","sunset-dark").contains(theme))return;
   runOnUiThread(()->{getPreferences(MODE_PRIVATE).edit().putString("theme",theme).apply();applyTheme(theme);});
  }
  @JavascriptInterface public void requestVoices() {runOnUiThread(()->{if(ensureSpeech())publishVoices(null);});}
  @JavascriptInterface public void setSpeechOptions(String voice,float rate,boolean online) {
   if(voice==null||voice.length()>200||!Float.isFinite(rate)||rate<0.75f||rate>1.25f)return;
   runOnUiThread(()->{speechVoice=voice;speechRate=rate;allowNetworkVoices=online;
    getPreferences(MODE_PRIVATE).edit().putString("speechVoice",voice).putFloat("speechRate",rate).putBoolean("allowNetworkVoices",online).apply();
   });
  }
  @JavascriptInterface public void openSpeechSettings() {runOnUiThread(()->{try{openExternalActivity(new Intent("com.android.settings.TTS_SETTINGS"));}catch(Exception e){message("Open your phone’s Settings and search Text-to-speech to install or change English voices.");}});}
  @JavascriptInterface public void speak(String text) {if(text!=null&&text.length()<=16000)runOnUiThread(()->speakPlan(text));}
  @JavascriptInterface public void stopSpeaking() {runOnUiThread(()->{pendingSpeech=null;if(speech!=null)speech.stop();});}
  @JavascriptInterface public void saveBase64(String name,String mime,String encoded) {
   if(encoded.length()>85*1024*1024){message("File is too large to export in this edition.");return;}
   String safe=name.replaceAll("[^a-zA-Z0-9._-]","_");
   Uri uri=null;
   try {
    ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,safe);values.put(MediaStore.Downloads.MIME_TYPE,mime);values.put(MediaStore.Downloads.IS_PENDING,1);
    uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
    if(uri==null)throw new IOException("Download folder unavailable");
    try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(Base64.decode(encoded,Base64.DEFAULT));}
    values.clear();values.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(uri,values,null,null);
    message("Saved to Downloads: "+safe);
   } catch(Exception e) {if(uri!=null)getContentResolver().delete(uri,null,null);message("Could not save file: "+e.getMessage());}
  }
 }
}
