package com.fairwayform.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
 private static final String ORIGIN = "https://appassets.androidplatform.net";
 private static final int PICK_VIDEO = 101, CAMERA_PERMISSION = 102, CAPTURE_PERMISSION = 103;
 private WebView web;
 private ValueCallback<Uri[]> picker;
 private PermissionRequest pendingCamera;
 private Intent pendingCapture;
 private TextToSpeech speech;
 private boolean speechReady = false;
 private String pendingSpeech;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  web = new WebView(this); setContentView(web);
  web.setBackgroundColor(0xfff6f7f1);
  WebSettings settings = web.getSettings();
  settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
  settings.setMediaPlaybackRequiresUserGesture(false);
  settings.setAllowFileAccess(false); settings.setAllowContentAccess(true);
  settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  web.addJavascriptInterface(new FileBridge(), "AndroidFiles");
  web.setWebViewClient(new WebViewClient() {
   @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
    Uri uri = request.getUrl();
    if (!ORIGIN.equals(uri.getScheme()+"://"+uri.getHost())) return null;
    String path = uri.getPath();
    if (path == null || path.equals("/")) path="/index.html";
    if (path.contains("..")) return response(403,"text/plain",new ByteArrayInputStream(new byte[0]));
    try {
     InputStream stream = getAssets().open("web"+path);
     String ext = path.substring(path.lastIndexOf('.')+1).toLowerCase(Locale.ROOT);
     String mime;
     switch(ext) {
      case "js": case "mjs": mime="application/javascript"; break;
      case "wasm": mime="application/wasm"; break;
      case "css": mime="text/css"; break;
      case "json": case "webmanifest": mime="application/json"; break;
      case "svg": mime="image/svg+xml"; break;
      case "png": mime="image/png"; break;
      case "task": mime="application/octet-stream"; break;
      default: mime="text/html";
     }
     return response(200,mime,stream);
    } catch(IOException e) { return response(404,"text/plain",new ByteArrayInputStream(new byte[0])); }
   }
   @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
    Uri uri=request.getUrl();
    if (ORIGIN.equals(uri.getScheme()+"://"+uri.getHost())) return false;
    if ("https".equals(uri.getScheme())) {
     try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); } catch(Exception e) { message("No browser available for this link."); }
    }
    return true;
   }
  });
  web.setWebChromeClient(new WebChromeClient() {
   @Override public void onPermissionRequest(PermissionRequest request) {
    runOnUiThread(()->{
     if(!ORIGIN.equals(request.getOrigin().toString().replaceAll("/$",""))) { request.deny(); return; }
     if(!Arrays.asList(request.getResources()).contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {request.deny();return;}
     if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
     else { if(pendingCamera!=null)pendingCamera.deny();pendingCamera=request;requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION); }
    });
   }
   @Override public void onPermissionRequestCanceled(PermissionRequest request) { if(pendingCamera==request)pendingCamera=null; }
   @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params) {
    if(picker!=null)picker.onReceiveValue(null);picker=callback;
    Intent intent;
    if(params.isCaptureEnabled()) { intent=new Intent(MediaStore.ACTION_VIDEO_CAPTURE);intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT,20);intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY,1); }
    else {
     intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
     String accepted=String.join(",",params.getAcceptTypes());
     boolean json=accepted.contains("json");
     intent.setType(json?"*/*":"video/*");
     if(json)intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"});
     intent.addCategory(Intent.CATEGORY_OPENABLE);
    }
    if(params.isCaptureEnabled() && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) { pendingCapture=intent;requestPermissions(new String[]{Manifest.permission.CAMERA},CAPTURE_PERMISSION);return true; }
    try { startActivityForResult(intent,PICK_VIDEO); } catch(Exception e) { picker.onReceiveValue(null);picker=null;message("Camera or video picker unavailable. Try Gallery."); }
    return true;
   }
  });
  web.loadUrl(ORIGIN+"/index.html");
 }
 private WebResourceResponse response(int code,String mime,InputStream stream) {
  Map<String,String> headers=new HashMap<>();headers.put("Access-Control-Allow-Origin",ORIGIN);headers.put("Cache-Control","no-cache");
  return new WebResourceResponse(mime,"UTF-8",code,code==200?"OK":code==404?"Not Found":"Forbidden",headers,stream);
 }
 @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results) {
  super.onRequestPermissionsResult(code,permissions,results);
  if(code==CAPTURE_PERMISSION&&pendingCapture!=null) {
   if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED) {try {startActivityForResult(pendingCapture,PICK_VIDEO);}catch(Exception e){if(picker!=null)picker.onReceiveValue(null);picker=null;message("Phone camera unavailable.");}}
   else {if(picker!=null)picker.onReceiveValue(null);picker=null;}
   pendingCapture=null;
  }
  if(code==CAMERA_PERMISSION&&pendingCamera!=null) {if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)pendingCamera.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});else pendingCamera.deny();pendingCamera=null;}
 }
 @Override protected void onActivityResult(int code,int result,Intent data) {
  super.onActivityResult(code,result,data);
  if(code==PICK_VIDEO&&picker!=null) {picker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));picker=null;}
 }
 @Override public void onBackPressed() { if(web.canGoBack())web.goBack();else super.onBackPressed(); }
 @Override protected void onPause() {if(speech!=null)speech.stop();pendingSpeech=null;super.onPause();}
 @Override protected void onDestroy() {if(picker!=null)picker.onReceiveValue(null);if(pendingCamera!=null)pendingCamera.deny();if(speech!=null){speech.stop();speech.shutdown();}web.destroy();super.onDestroy();}
 private void speakPlan(String text) {
  pendingSpeech=text;
  if(speech==null) {
   speech=new TextToSpeech(this,result->{
    speechReady=result==TextToSpeech.SUCCESS;
    if(speechReady) {if(speech.setLanguage(Locale.US)<0){speechReady=false;message("Install an English voice in your phone text-to-speech settings, or read the plan on screen.");return;}speech.setSpeechRate(0.92f);if(pendingSpeech!=null&&speech.speak(pendingSpeech,TextToSpeech.QUEUE_FLUSH,null,"fairway-plan")==TextToSpeech.ERROR)message("Voice playback could not start. Your plan is shown in the app.");}
    else {pendingSpeech=null;message("Voice playback is unavailable. Your plan is still shown in the app.");}
   });
  } else if(speechReady) speech.speak(text,TextToSpeech.QUEUE_FLUSH,null,"fairway-plan");
 }
 private void message(String value) { runOnUiThread(()->Toast.makeText(this,value,Toast.LENGTH_LONG).show()); }
 private class FileBridge {
  @JavascriptInterface public void speak(String text) {if(text!=null&&text.length()<=16000)runOnUiThread(()->speakPlan(text));}
  @JavascriptInterface public void stopSpeaking() {runOnUiThread(()->{pendingSpeech=null;if(speech!=null)speech.stop();});}
  @JavascriptInterface public void saveBase64(String name,String mime,String encoded) {
   if(encoded.length()>85*1024*1024){message("File is too large to export in this edition.");return;}
   String safe=name.replaceAll("[^a-zA-Z0-9._-]","_");
   Uri uri=null;
   try {
    ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,safe);values.put(MediaStore.Downloads.MIME_TYPE,mime);values.put(MediaStore.Downloads.IS_PENDING,1);
    uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
    if(uri==null)throw new IOException("Download folder unavailable");
    try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(Base64.decode(encoded,Base64.DEFAULT));}
    values.clear();values.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(uri,values,null,null);
    message("Saved to Downloads: "+safe);
   } catch(Exception e) {if(uri!=null)getContentResolver().delete(uri,null,null);message("Could not save file: "+e.getMessage());}
  }
 }
}
