package com.fairwayform.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.VideoView;

/** Local, silent launch movie. The WebView keeps loading underneath this overlay. */
final class StartupIntro {
 private static final int BACKGROUND=0xff101f1d,CREAM=0xfff1eddc;
 private final Context context;
 private final FrameLayout overlay;
 private final ImageView poster;
 private final LinearLayout loading;
 private final TextView status;
 private final Button skip,retry;
 private final View app;
 private final Runnable reload,visibilityChanged;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private VideoView video;
 private boolean ready=false,visible=false,finished=false,prepared=false,resumed=false,failed=false;
 private int generation=0;

 StartupIntro(Context context,FrameLayout root,View app,Runnable reload,Runnable visibilityChanged){
  this.context=context;this.app=app;this.reload=reload;this.visibilityChanged=visibilityChanged;
  overlay=new FrameLayout(context);overlay.setClickable(true);overlay.setFocusable(true);overlay.setBackgroundColor(BACKGROUND);overlay.setVisibility(View.GONE);
  overlay.setContentDescription("Final Form - Disc Golf opening animation");
  root.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
  poster=new ImageView(context);poster.setImageResource(R.drawable.final_form_poster);poster.setScaleType(ImageView.ScaleType.FIT_CENTER);
  poster.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
  overlay.addView(poster,new FrameLayout.LayoutParams(-1,-1));
  skip=button("Skip intro");skip.setOnClickListener(v->skip());
  FrameLayout.LayoutParams top=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.END);top.setMargins(dp(16),dp(24),dp(16),0);overlay.addView(skip,top);
  loading=new LinearLayout(context);loading.setOrientation(LinearLayout.VERTICAL);loading.setGravity(Gravity.CENTER);loading.setPadding(dp(20),dp(8),dp(20),dp(24));
  ProgressBar spinner=new ProgressBar(context);spinner.setIndeterminateTintList(ColorStateList.valueOf(0xffa9dfbf));loading.addView(spinner,new LinearLayout.LayoutParams(dp(24),dp(24)));
  status=new TextView(context);status.setText("Opening your app…");status.setTextColor(CREAM);status.setTextSize(14);status.setGravity(Gravity.CENTER);status.setPadding(0,dp(10),0,dp(8));status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);loading.addView(status);
  retry=button("Try again");retry.setVisibility(View.GONE);retry.setOnClickListener(v->{ready=false;failed=false;show();reload.run();});loading.addView(retry);
  overlay.addView(loading,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));
 }
 private int dp(int n){return Math.round(n*context.getResources().getDisplayMetrics().density);}
 private Button button(String text){Button b=new Button(context);b.setText(text);b.setAllCaps(false);b.setTextColor(CREAM);b.setTextSize(14);b.setMinHeight(dp(48));b.setBackgroundTintList(ColorStateList.valueOf(0xff244737));return b;}
 boolean isVisible(){return visible;}
 void appReady(){ready=true;failed=false;retry.setVisibility(View.GONE);finishWhenReady();}
 void appLoading(){ready=false;failed=false;}
 void appFailed(){
  ready=false;failed=true;finished=true;releaseVideo();
  if(visible)showFailure();
 }
 void show(){
  handler.removeCallbacksAndMessages(null);releaseVideo();int token=++generation;
  visible=true;finished=false;prepared=false;overlay.setAlpha(1);overlay.setVisibility(View.VISIBLE);poster.setVisibility(View.VISIBLE);
  app.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
  loading.setVisibility(View.GONE);status.setText("Opening your app…");retry.setVisibility(View.GONE);skip.setText("Skip intro");visibilityChanged.run();
  if(failed){showFailure();return;}
  // Honor Android's Remove animations accessibility setting; still show the title while loading.
  if(!ValueAnimator.areAnimatorsEnabled()){finished=true;finishWhenReady();}
  else{
   VideoView current=new VideoView(context);video=current;
   current.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);current.setKeepScreenOn(false);
   current.setAudioFocusRequest(android.media.AudioManager.AUDIOFOCUS_NONE);
   overlay.addView(current,0,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
   current.setOnPreparedListener(player->{
    if(token!=generation||!visible||video!=current)return;
    prepared=true;player.setVolume(0,0);player.setLooping(false);
    if(resumed){current.start();poster.setVisibility(View.GONE);}
   });
   current.setOnInfoListener((player,what,extra)->{
    if(token==generation&&visible&&what==android.media.MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START)poster.setVisibility(View.GONE);
    return false;
   });
   current.setOnCompletionListener(player->{if(token==generation&&visible)completeMovie();});
   current.setOnErrorListener((player,what,extra)->{if(token==generation&&visible)completeMovie();return true;});
   try{current.setVideoURI(Uri.parse("android.resource://"+context.getPackageName()+"/"+R.raw.fairway_intro));}
   catch(RuntimeException error){completeMovie();}
  }
  // A missing decoder or stalled player must never prevent opening the app.
  handler.postDelayed(()->{if(token==generation&&visible&&!finished)completeMovie();},8000);
  handler.postDelayed(()->{if(token==generation&&visible&&!ready)showFailure();},15000);
  AccessibilityManager access=(AccessibilityManager)context.getSystemService(Context.ACCESSIBILITY_SERVICE);
  if(access!=null&&access.isTouchExplorationEnabled())skip.requestFocus();
 }
 private void completeMovie(){finished=true;releaseVideo();finishWhenReady();}
 private void finishWhenReady(){
  if(!visible||!finished)return;
  if(ready){dismiss();return;}
  poster.setVisibility(View.VISIBLE);loading.setVisibility(View.VISIBLE);
 }
 private void showFailure(){
  finished=true;releaseVideo();poster.setVisibility(View.VISIBLE);loading.setVisibility(View.VISIBLE);
  status.setText("The app is taking longer to open. Try loading it again.");retry.setVisibility(View.VISIBLE);skip.setText("Open app");
 }
 void skip(){
  if(!visible)return;
  // The user can always leave the intro, including if the app is still loading.
  dismiss();
 }
 private void dismiss(){
  handler.removeCallbacksAndMessages(null);++generation;releaseVideo();visible=false;
  overlay.setVisibility(View.GONE);app.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_AUTO);visibilityChanged.run();
 }
 void pause(){resumed=false;if(video!=null&&prepared&&video.isPlaying())video.pause();}
 void resume(){resumed=true;if(video!=null&&prepared&&visible&&!finished){video.start();poster.setVisibility(View.GONE);}}
 void stop(){resumed=false;dismiss();}
 private void releaseVideo(){
  VideoView current=video;video=null;prepared=false;
  if(current!=null){current.setOnPreparedListener(null);current.setOnCompletionListener(null);current.setOnErrorListener(null);current.setOnInfoListener(null);try{current.stopPlayback();}catch(RuntimeException ignored){}overlay.removeView(current);}
 }
 void close(){handler.removeCallbacksAndMessages(null);++generation;releaseVideo();visible=false;}
}
