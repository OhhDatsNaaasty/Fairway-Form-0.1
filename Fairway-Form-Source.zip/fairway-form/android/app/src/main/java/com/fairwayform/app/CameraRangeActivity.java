package com.fairwayform.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.Image;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import com.google.ar.core.*;
import java.nio.*;
import java.util.*;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Optional on-device AR estimates. No GPS, cloud anchors, video recording or uploads. */
public class CameraRangeActivity extends Activity implements GLSurfaceView.Renderer {
 private GLSurfaceView surface;
 private TextView status,reading;
 private Button action,use;
 private CheckBox accept;
 private Session session;
 private volatile boolean resumed=false,depth=false,frozen=false,invalid=false;
 private volatile String command="";
 private String mode,unit;
 private boolean installRequested=false;
 private int retries=0,width=1,height=1,texture,program,posAttr,uvAttr,sampler;
 private Anchor start;
 private float[] lastCamera;
 private volatile double result=Double.NaN;
 private long startedAt,lastFrame,lastDepth,lastUi;
 private final ArrayDeque<Sample> samples=new ArrayDeque<>();
 private final FloatBuffer vertices=buffer(-1,-1,1,-1,-1,1,1,1),uv=buffer(0,0,0,0,0,0,0,0);
 private static class Sample { final long at;final float[] point; Sample(long t,float[] p){at=t;point=p;} }
 private static FloatBuffer buffer(float... values){FloatBuffer b=ByteBuffer.allocateDirect(values.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();b.put(values).position(0);return b;}
 @Override public void onCreate(Bundle saved){
  super.onCreate(saved);mode="walk".equals(getIntent().getStringExtra("mode"))?"walk":"target";unit="m".equals(getIntent().getStringExtra("unit"))?"m":"ft";
  getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);getWindow().setStatusBarColor(0xff173c31);getWindow().setNavigationBarColor(0xff173c31);
  FrameLayout root=new FrameLayout(this);surface=new GLSurfaceView(this);surface.setEGLContextClientVersion(2);surface.setPreserveEGLContextOnPause(true);surface.setRenderer(this);root.addView(surface);
  TextView cross=new TextView(this);cross.setText("⊕");cross.setTextColor(Color.WHITE);cross.setTextSize(38);cross.setGravity(Gravity.CENTER);root.addView(cross,new FrameLayout.LayoutParams(-1,-1));
  LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(20,12,20,12);panel.setBackgroundColor(0xec173c31);
  TextView title=label(mode.equals("walk")?"Camera walk · completed throw":"Nearby basket · camera estimate",20);panel.addView(title);
  status=label("Checking camera measurement support…",15);panel.addView(status);reading=label("",23);panel.addView(reading);
  accept=new CheckBox(this);accept.setText("I understand this is an estimate, not laser accuracy");accept.setTextColor(Color.WHITE);panel.addView(accept);
  LinearLayout buttons=new LinearLayout(this);action=new Button(this);action.setText(mode.equals("walk")?"Mark start":"Capture target");buttons.addView(action,new LinearLayout.LayoutParams(0,-2,1));use=new Button(this);use.setText("Use estimate");use.setEnabled(false);buttons.addView(use,new LinearLayout.LayoutParams(0,-2,1));panel.addView(buttons);
  LinearLayout bottom=new LinearLayout(this);Button reset=new Button(this);reset.setText("Start over");bottom.addView(reset,new LinearLayout.LayoutParams(0,-2,1));Button cancel=new Button(this);cancel.setText("Cancel");bottom.addView(cancel,new LinearLayout.LayoutParams(0,-2,1));panel.addView(bottom);
  FrameLayout.LayoutParams place=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);root.addView(panel,place);setContentView(root);
  action.setEnabled(false);action.setOnClickListener(v->command="capture");reset.setOnClickListener(v->{accept.setChecked(false);use.setEnabled(false);command="reset";});cancel.setOnClickListener(v->finish());
  accept.setOnCheckedChangeListener((b,on)->use.setEnabled(on&&Double.isFinite(result)&&!invalid));
  use.setOnClickListener(v->{if(!accept.isChecked()||!Double.isFinite(result)||invalid)return;Intent data=new Intent();data.putExtra("meters",result);data.putExtra("mode",mode);setResult(RESULT_OK,data);finish();});
 }
 private TextView label(String text,int size){TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(Color.WHITE);return v;}
 @Override protected void onResume(){super.onResume();resumed=true;open();}
 private void open(){
  if(!resumed||isFinishing())return;
  if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},1);return;}
  try{
   if(session==null){
    ArCoreApk.Availability a=ArCoreApk.getInstance().checkAvailability(this);
    if(a.isTransient()&&retries++<30){surface.postDelayed(this::open,200);return;}
    if(!a.isSupported()){failure("This phone could not enable AR measurement. GPS and manual distances still work.");return;}
    if(ArCoreApk.getInstance().requestInstall(this,!installRequested)==ArCoreApk.InstallStatus.INSTALL_REQUESTED){installRequested=true;return;}
    session=new Session(this);Config config=session.getConfig();depth=session.isDepthModeSupported(Config.DepthMode.RAW_DEPTH_ONLY);
    if(!depth){failure("Camera depth is unavailable on this device. Use GPS or enter a measured distance.");session.close();session=null;return;}
    config.setDepthMode(Config.DepthMode.RAW_DEPTH_ONLY);config.setFocusMode(Config.FocusMode.AUTO);config.setLightEstimationMode(Config.LightEstimationMode.DISABLED);config.setPlaneFindingMode(Config.PlaneFindingMode.DISABLED);session.configure(config);
   }
   session.resume();surface.onResume();message(instructions());
  }catch(Exception e){failure("Camera measurement could not start. Update Google Play Services for AR, then try again. "+e.getClass().getSimpleName());}
 }
 @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] grants){super.onRequestPermissionsResult(code,permissions,grants);if(code==1){if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)open();else failure("Camera permission was not allowed. GPS and manual measurement still work.");}}
 private String instructions(){return mode.equals("walk")?"Return to the release spot after throwing. Scan textured ground, aim at your start mark and hold still. Keep the camera uncovered while walking; do not put it in your pocket.":"Stand at your lie. Aim at the ground where the basket pole enters it, not the chains. Move gently to scan, then hold still. Nearby targets only (up to about 33 ft / 10 m).";}
 @Override protected void onPause(){resumed=false;if(start!=null&&!frozen){invalid=true;result=Double.NaN;}surface.onPause();if(session!=null)session.pause();super.onPause();}
 @Override protected void onDestroy(){if(start!=null)start.detach();if(session!=null)session.close();super.onDestroy();}
 private void failure(String text){message(text);action.setEnabled(false);use.setEnabled(false);}
 private void message(String text){runOnUiThread(()->{if(!isFinishing())status.setText(text);});}
 private void clear(){if(start!=null)start.detach();start=null;invalid=false;frozen=false;result=Double.NaN;samples.clear();lastCamera=null;lastDepth=0;lastFrame=0;runOnUiThread(()->{reading.setText("");use.setEnabled(false);action.setText(mode.equals("walk")?"Mark start":"Capture target");});}
 @Override public void onSurfaceCreated(GL10 gl,EGLConfig config){
  int[] ids=new int[1];GLES20.glGenTextures(1,ids,0);texture=ids[0];GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE);
  int vs=shader(GLES20.GL_VERTEX_SHADER,"attribute vec2 a;attribute vec2 t;varying vec2 uv;void main(){gl_Position=vec4(a,0.,1.);uv=t;}");int fs=shader(GLES20.GL_FRAGMENT_SHADER,"#extension GL_OES_EGL_image_external : require\nprecision mediump float;uniform samplerExternalOES s;varying vec2 uv;void main(){gl_FragColor=texture2D(s,uv);}");program=GLES20.glCreateProgram();GLES20.glAttachShader(program,vs);GLES20.glAttachShader(program,fs);GLES20.glLinkProgram(program);GLES20.glDeleteShader(vs);GLES20.glDeleteShader(fs);posAttr=GLES20.glGetAttribLocation(program,"a");uvAttr=GLES20.glGetAttribLocation(program,"t");sampler=GLES20.glGetUniformLocation(program,"s");
 }
 private int shader(int kind,String source){int s=GLES20.glCreateShader(kind);GLES20.glShaderSource(s,source);GLES20.glCompileShader(s);return s;}
 @Override public void onSurfaceChanged(GL10 gl,int w,int h){width=w;height=h;GLES20.glViewport(0,0,w,h);}
 private void background(Frame frame){vertices.position(0);uv.position(0);frame.transformCoordinates2d(Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,vertices,Coordinates2d.TEXTURE_NORMALIZED,uv);vertices.position(0);uv.position(0);GLES20.glDisable(GLES20.GL_DEPTH_TEST);GLES20.glUseProgram(program);GLES20.glActiveTexture(GLES20.GL_TEXTURE0);GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture);GLES20.glUniform1i(sampler,0);GLES20.glEnableVertexAttribArray(posAttr);GLES20.glEnableVertexAttribArray(uvAttr);GLES20.glVertexAttribPointer(posAttr,2,GLES20.GL_FLOAT,false,0,vertices);GLES20.glVertexAttribPointer(uvAttr,2,GLES20.GL_FLOAT,false,0,uv);GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4);GLES20.glDisableVertexAttribArray(posAttr);GLES20.glDisableVertexAttribArray(uvAttr);}
 @Override public void onDrawFrame(GL10 gl){
  GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);if(!resumed||session==null)return;
  try{
   session.setCameraTextureName(texture);session.setDisplayGeometry(getWindowManager().getDefaultDisplay().getRotation(),width,height);Frame frame=session.update();background(frame);Camera camera=frame.getCamera();long time=SystemClock.elapsedRealtime();
   String op=command;command="";if(op.equals("reset")){clear();message(instructions());}
   if(frozen)return;
   boolean tracking=camera.getTrackingState()==TrackingState.TRACKING;
   if(!tracking){samples.clear();if(start!=null)invalid=true;update("Move gently and scan textured ground. Camera tracking is not ready.",false,Double.NaN,time);return;}
   if(start!=null&&(invalid||start.getTrackingState()!=TrackingState.TRACKING||!CameraRangeRules.continuous(tracking,lastFrame>0?time-lastFrame:0,time-startedAt))){invalid=true;update("Tracking was interrupted or this walk took too long. Start over; this distance cannot be saved.",false,Double.NaN,time);return;}
   if(start!=null&&!CameraRangeRules.plausibleStep(lastCamera,camera.getPose().getTranslation(),time-lastFrame)){invalid=true;update("Camera position jumped. Start over; this walk cannot be saved.",false,Double.NaN,time);return;}
   lastCamera=camera.getPose().getTranslation();lastFrame=time;
   Sample sample=depthSample(frame,time);if(sample!=null){samples.add(sample);while(samples.size()>24)samples.removeFirst();}
   while(!samples.isEmpty()&&time-samples.peekFirst().at>1500)samples.removeFirst();
   float[] target=stablePoint();boolean valid=target!=null&&!invalid;
   double distance=Double.NaN;
   if(valid){float[] origin=start==null?camera.getPose().getTranslation():start.getPose().getTranslation();distance=CameraRangeRules.horizontalMeters(origin,target,start==null?10:150);if(!Double.isFinite(distance))valid=false;}
   String hint=start==null?instructions():"Walk carefully with the camera viewing the surroundings. At the first landing spot, aim at the disc's ground position and hold still. This is straight displacement, not your walked path.";
   if(op.equals("capture")&&valid){
    if(mode.equals("walk")&&start==null){start=session.createAnchor(Pose.makeTranslation(target));startedAt=time;samples.clear();runOnUiThread(()->action.setText("Stop · landing spot"));message("Start marked. Walk to the first landing spot with the camera tracking continuously.");}
    else{result=distance;frozen=true;final double n=distance;runOnUiThread(()->{reading.setText(format(n)+" · camera estimate");status.setText("Check this against a known distance before relying on it. Camera tracking and surface depth can drift; no 1–2 ft accuracy is guaranteed. Saved throw estimates stay separate from measured carry.");action.setEnabled(false);use.setEnabled(accept.isChecked());});}
   }else update(valid?hint:"No stable nearby surface at the crosshair. Scan textured ground, then hold still. Do not aim through basket chains.",valid,distance,time);
  }catch(Exception e){samples.clear();if(start!=null)invalid=true;update("Camera data is unavailable. Try Start over, or cancel and use another measurement method.",false,Double.NaN,SystemClock.elapsedRealtime());}
 }
 private void update(String text,boolean ready,double distance,long now){if(now-lastUi<180)return;lastUi=now;runOnUiThread(()->{if(isFinishing())return;status.setText(text);action.setEnabled(ready);use.setEnabled(false);reading.setText(Double.isFinite(distance)?format(distance)+" · preview":"Finding a stable surface…");});}
 private String format(double m){return String.format(Locale.US,"%.1f %s",unit.equals("m")?m:m/.3048,unit);}
 private float[] stablePoint(){if(samples.isEmpty())return null;return CameraRangeRules.stablePoint(samples.stream().map(s->s.point).toArray(float[][]::new),samples.peekLast().at-samples.peekFirst().at);}
 private Sample depthSample(Frame frame,long time){
  try(Image depthImage=frame.acquireRawDepthImage16Bits();Image confidence=frame.acquireRawDepthConfidenceImage()){
   if(depthImage.getTimestamp()==lastDepth)return null;lastDepth=depthImage.getTimestamp();
   FloatBuffer image=buffer(0,0);frame.transformCoordinates2d(Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,buffer(0,0),Coordinates2d.IMAGE_NORMALIZED,image);
   int w=depthImage.getWidth(),h=depthImage.getHeight(),x=Math.round(image.get(0)*(w-1)),y=Math.round(image.get(1)*(h-1));if(x<1||y<1||x>=w-1||y>=h-1||confidence.getWidth()!=w||confidence.getHeight()!=h)return null;
   Image.Plane d=depthImage.getPlanes()[0],c=confidence.getPlanes()[0];ByteBuffer db=d.getBuffer().order(ByteOrder.LITTLE_ENDIAN),cb=c.getBuffer();int[] values=new int[9],qualities=new int[9];int index=0;
   for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){int px=x+dx,py=y+dy,quality=cb.get(py*c.getRowStride()+px*c.getPixelStride())&255,mm=db.getShort(py*d.getRowStride()+px*d.getPixelStride())&65535;values[index]=mm;qualities[index++]=quality;}
   float z=CameraRangeRules.depthMeters(values,qualities);if(!Float.isFinite(z))return null;
   CameraIntrinsics k=frame.getCamera().getImageIntrinsics();float[] focal=k.getFocalLength(),principal=k.getPrincipalPoint();int[] dims=k.getImageDimensions();float px=image.get(0)*dims[0],py=image.get(1)*dims[1];float[] local={z*(px-principal[0])/focal[0],-z*(py-principal[1])/focal[1],-z};return new Sample(time,frame.getCamera().getPose().transformPoint(local));
  }catch(com.google.ar.core.exceptions.NotYetAvailableException e){return null;}
 }
}
