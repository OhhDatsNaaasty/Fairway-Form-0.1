package com.fairwayform.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.media.Image;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Decode once, off the UI thread. JPEGs and presentation timestamps stay private
 * and temporary. Neither scrubbing nor inference seeks the WebView decoder. */
final class VideoFrames implements AutoCloseable {
 interface Listener { void publish(JSONObject value); }
 private static final long MAX_INPUT=120L*1024*1024,MAX_CACHE=128L*1024*1024;
 private final File directory;
 private final Listener listener;
 private final ExecutorService worker=Executors.newSingleThreadExecutor();
 private String current;
 private long expected,written;
 private boolean submitted,closed;
 private FileOutputStream upload;
 VideoFrames(Context context,Listener listener){
  directory=new File(context.getCacheDir(),"throw-frames");this.listener=listener;
  // Files are not history. Discard a cache left by a terminated process.
  remove(directory);directory.mkdirs();
 }
 static boolean safeId(String id){return id!=null&&id.matches("[a-zA-Z0-9-]{1,80}");}
 private static void remove(File file){File[] children=file.listFiles();if(children!=null)for(File child:children)remove(child);file.delete();}
 private static String result(String error){try{return new JSONObject().put("ok",error==null).put("error",error==null?JSONObject.NULL:error).toString();}catch(Exception ignored){return "{\"ok\":false}";}}
 synchronized String begin(String id,long size){
  if(closed||!safeId(id)||size<=0||size>MAX_INPUT)return result("Choose a video under 120 MB.");
  cancel(current);current=id;expected=size;written=0;submitted=false;
  try{File session=new File(directory,id);if(!session.mkdirs()&&!session.isDirectory())throw new IOException();upload=new FileOutputStream(new File(session,"source"));return result(null);}
  catch(Exception error){cancel(id);return result("Could not prepare private video storage.");}
 }
 synchronized String append(String id,long offset,String encoded){
  if(!safeId(id)||!id.equals(current)||upload==null||submitted||offset!=written||encoded==null||encoded.length()>360000)return result("Video transfer was interrupted.");
  try{byte[] bytes=Base64.decode(encoded,Base64.NO_WRAP);if(bytes.length==0||bytes.length>256*1024||written+bytes.length>expected)throw new IOException();upload.write(bytes);written+=bytes.length;return result(null);}
  catch(Exception error){cancel(id);return result("Video transfer could not finish.");}
 }
 synchronized void finish(String id){
  if(!safeId(id)||!id.equals(current)||submitted)return;
  try{if(upload==null||written!=expected)throw new IOException();upload.close();upload=null;submitted=true;worker.submit(()->decode(id));}
  catch(Exception error){emit(id,"error",null,"Video transfer was incomplete.");cancel(id);}
 }
 synchronized void cancel(String id){
  if(id==null||!id.equals(current))return;
  current=null;try{if(upload!=null)upload.close();}catch(Exception ignored){}upload=null;
  // Deletion also runs after decoding, once that worker has released its file.
  worker.submit(()->remove(new File(directory,id)));
 }
 private synchronized boolean active(String id){return !closed&&id.equals(current);}
 synchronized InputStream frame(String id,int index)throws IOException{
  if(!safeId(id)||!id.equals(current)||index<0||index>1300)throw new FileNotFoundException();
  return new FileInputStream(new File(new File(directory,id),index+".jpg"));
 }
 private void emit(String id,String type,JSONObject data,String error){
  if(!active(id))return;
  try{JSONObject value=data==null?new JSONObject():data;value.put("id",id).put("type",type);if(error!=null)value.put("error",error);listener.publish(value);}catch(Exception ignored){}
 }
 private void decode(String id){
  MediaExtractor extractor=null;MediaCodec codec=null;
  final File session=new File(directory,id),source=new File(session,"source");
  boolean complete=false;
  try{
   if(!active(id))return;
   extractor=new MediaExtractor();extractor.setDataSource(source.getAbsolutePath());
   int track=-1;MediaFormat format=null;
   for(int i=0;i<extractor.getTrackCount();i++){MediaFormat candidate=extractor.getTrackFormat(i);String mime=candidate.getString(MediaFormat.KEY_MIME);if(mime!=null&&mime.startsWith("video/")){track=i;format=candidate;break;}}
   if(track<0||format==null)throw new IOException("No video track was found.");
   long duration=format.containsKey(MediaFormat.KEY_DURATION)?format.getLong(MediaFormat.KEY_DURATION):0;
   if(duration<=0||duration>20150000)throw new IOException("Choose a video no longer than 20 seconds.");
   int rotation=format.containsKey(MediaFormat.KEY_ROTATION)?format.getInteger(MediaFormat.KEY_ROTATION):0;
   // Rotation is applied exactly once below to the decoded image.
   format.setInteger(MediaFormat.KEY_ROTATION,0);
   format.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
   extractor.selectTrack(track);codec=MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME));codec.configure(format,null,null,0);codec.start();
   MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();JSONArray times=new JSONArray();int[] pixelBuffer=new int[960*960];
   boolean inputEnd=false,outputEnd=false;long started=System.nanoTime(),lastOutput=started,lastSaved=-1,bytes=0;int width=0,height=0;
   while(!outputEnd){
    if(!active(id))return;
    long now=System.nanoTime();if(now-started>90000000000L)throw new IOException("Preparing this clip took too long.");
    if(now-lastOutput>8000000000L)throw new IOException("The Android video decoder stopped producing images.");
    if(!inputEnd){int input=codec.dequeueInputBuffer(10000);if(input>=0){ByteBuffer buffer=codec.getInputBuffer(input);if(buffer==null)throw new IOException("No decoder input buffer.");buffer.clear();int size=extractor.readSampleData(buffer,0);if(size<0){codec.queueInputBuffer(input,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputEnd=true;}else{codec.queueInputBuffer(input,0,size,extractor.getSampleTime(),0);extractor.advance();}}}
    int output=codec.dequeueOutputBuffer(info,10000);
    if(output>=0){
     lastOutput=System.nanoTime();outputEnd=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
     try{
      long pts=info.presentationTimeUs;
      if(info.size>0&&(info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0&&pts>=0&&pts<duration&&VideoFrameRules.keep(pts,lastSaved)){
       Image image=codec.getOutputImage(output);if(image==null)throw new IOException("This codec does not expose review images. Try a standard SDR MP4.");
       Bitmap bitmap;try{bitmap=bitmap(image,rotation,codec.getOutputFormat(),pixelBuffer);}finally{image.close();}
       File file=new File(session,times.length()+".jpg");
       try{if(width>0&&(width!=bitmap.getWidth()||height!=bitmap.getHeight()))throw new IOException("This clip changes image dimensions. Export a standard MP4 copy.");width=bitmap.getWidth();height=bitmap.getHeight();try(OutputStream stream=new FileOutputStream(file)){if(!bitmap.compress(Bitmap.CompressFormat.JPEG,90,stream))throw new IOException("Frame encoding failed.");}}finally{bitmap.recycle();}
       bytes+=file.length();if(bytes>MAX_CACHE||times.length()>=1300)throw new IOException("The clip needs too much review storage. Trim the clip first.");
       times.put(pts/1000000.0);lastSaved=pts;
       if(times.length()==1||times.length()%10==0)emit(id,"progress",new JSONObject().put("progress",Math.min(.99,pts/(double)duration)).put("frames",times.length()),null);
      }
     }finally{codec.releaseOutputBuffer(output,false);}
    }
   }
   if(times.length()<2)throw new IOException("Too few frames decoded for a review.");
   if(times.getDouble(times.length()-1)<duration/1000000.0-.2)throw new IOException("The decoder ended before the clip finished.");
   complete=true;
   emit(id,"ready",new JSONObject().put("duration",duration/1000000.0).put("width",width).put("height",height).put("times",times),null);
  }catch(Exception error){emit(id,"error",null,error.getMessage()==null?"Android could not prepare this video.":error.getMessage());}
  finally{
   if(codec!=null){try{codec.stop();}catch(Exception ignored){}try{codec.release();}catch(Exception ignored){}}
   if(extractor!=null)extractor.release();source.delete();if(!complete||!active(id))remove(session);
  }
 }
 private static Bitmap bitmap(Image image,int rotation,MediaFormat format,int[] pixels)throws IOException{
  if(image.getFormat()!=ImageFormat.YUV_420_888)throw new IOException("This HDR/10-bit video needs an SDR MP4 copy for review.");
  Rect crop=image.getCropRect();int[] dimensions=VideoFrameRules.dimensions(crop.width(),crop.height());int width=dimensions[0],height=dimensions[1];
  Image.Plane[] planes=image.getPlanes();if(planes.length<3)throw new IOException("Unsupported video pixel layout.");
  ByteBuffer y=planes[0].getBuffer(),u=planes[1].getBuffer(),v=planes[2].getBuffer();int yp=y.position(),up=u.position(),vp=v.position();
  int yr=planes[0].getRowStride(),ur=planes[1].getRowStride(),vr=planes[2].getRowStride(),yx=planes[0].getPixelStride(),ux=planes[1].getPixelStride(),vx=planes[2].getPixelStride();
  boolean full=format.containsKey(MediaFormat.KEY_COLOR_RANGE)&&format.getInteger(MediaFormat.KEY_COLOR_RANGE)==MediaFormat.COLOR_RANGE_FULL;
  boolean bt709=format.containsKey(MediaFormat.KEY_COLOR_STANDARD)&&format.getInteger(MediaFormat.KEY_COLOR_STANDARD)==MediaFormat.COLOR_STANDARD_BT709;
  for(int row=0;row<height;row++){int sy=crop.top+row*crop.height()/height;for(int col=0;col<width;col++){
   int sx=crop.left+col*crop.width()/width;
   int yy=y.get(yp+sy*yr+sx*yx)&255;
   int uu=(u.get(up+(sy/2)*ur+(sx/2)*ux)&255)-128;
   int vv=(v.get(vp+(sy/2)*vr+(sx/2)*vx)&255)-128;
   pixels[row*width+col]=VideoFrameRules.rgb(yy,uu,vv,full,bt709);
  }}
  Bitmap imageBitmap=Bitmap.createBitmap(pixels,width,height,Bitmap.Config.ARGB_8888);
  if(rotation%360!=0){Matrix matrix=new Matrix();matrix.postRotate(rotation);Bitmap rotated=Bitmap.createBitmap(imageBitmap,0,0,width,height,matrix,true);if(rotated!=imageBitmap)imageBitmap.recycle();return rotated;}
  return imageBitmap;
 }
 @Override public synchronized void close(){if(closed)return;cancel(current);closed=true;worker.shutdown();}
}
