package com.fairwayform.app;
import java.util.Arrays;
/** Measurement rejection rules, independent of camera rendering and Android UI. */
public final class CameraRangeRules {
 private CameraRangeRules(){}
 public static float depthMeters(int[] millimeters,int[] confidence){
  if(millimeters.length!=confidence.length)return Float.NaN;
  int[] good=new int[millimeters.length];int count=0;
  for(int i=0;i<millimeters.length;i++)if(confidence[i]>=192&&confidence[i]<=255&&millimeters[i]>=300&&millimeters[i]<=10000)good[count++]=millimeters[i];
  if(count<6)return Float.NaN;Arrays.sort(good,0,count);float meters=good[count/2]/1000f;
  return good[count-1]-good[0]>Math.max(100,meters*100)?Float.NaN:meters;
 }
 public static float[] stablePoint(float[][] points,long spanMs){
  if(points.length<6||spanMs<500)return null;float[] middle=new float[3];
  for(float[] point:points)if(point==null||point.length!=3||!Float.isFinite(point[0])||!Float.isFinite(point[1])||!Float.isFinite(point[2]))return null;
  for(int a=0;a<3;a++){float[] values=new float[points.length];for(int i=0;i<values.length;i++)values[i]=points[i][a];Arrays.sort(values);middle[a]=values[values.length/2];}
  for(float[] point:points)if(Math.sqrt(Math.pow(point[0]-middle[0],2)+Math.pow(point[1]-middle[1],2)+Math.pow(point[2]-middle[2],2))>.12)return null;
  return middle;
 }
 public static double horizontalMeters(float[] start,float[] end,double max){
  if(start==null||end==null||start.length!=3||end.length!=3)return Double.NaN;
  for(int i=0;i<3;i++)if(!Float.isFinite(start[i])||!Float.isFinite(end[i]))return Double.NaN;
  double meters=Math.hypot(end[0]-start[0],end[2]-start[2]);return meters>=.3048&&meters<=max?meters:Double.NaN;
 }
 public static boolean plausibleStep(float[] previous,float[] current,long elapsedMs){
  if(previous==null)return true;if(elapsedMs<0||elapsedMs>1500)return false;
  double step=Math.sqrt(Math.pow(current[0]-previous[0],2)+Math.pow(current[1]-previous[1],2)+Math.pow(current[2]-previous[2],2));return Double.isFinite(step)&&step<=.5+4*elapsedMs/1000.;
 }
 public static boolean continuous(boolean tracking,long gapMs,long durationMs){return tracking&&gapMs<=1500&&durationMs<=300000&&gapMs>=0&&durationMs>=0;}
}
