package com.fairwayform.app;

/** Foreground openings replay the intro; returning from an app-launched task does not. */
final class StartupPolicy {
 private boolean firstStart=true,stopped=false,externalReturn=false;
 boolean onStart(){
  boolean play=firstStart||(stopped&&!externalReturn);
  firstStart=false;stopped=false;externalReturn=false;
  return play;
 }
 void onStop(boolean externalTask){stopped=true;externalReturn=externalTask;}
}
