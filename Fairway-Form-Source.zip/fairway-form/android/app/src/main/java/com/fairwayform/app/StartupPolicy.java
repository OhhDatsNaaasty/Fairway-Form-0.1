package com.fairwayform.app;

/** Show once for a new app activity/session, never on a foreground resume. */
final class StartupPolicy {
 private boolean firstStart=true;
 boolean onStart(){boolean play=firstStart;firstStart=false;return play;}
 // Neither ordinary backgrounding nor an external task starts a fresh session.
 void onStop(boolean externalTask){}
}
