package com.fairwayform.app;

// Pure rules are also compiled and checked independently in CI.
final class VideoFrameRules {
 static boolean keep(long pts,long previous){return pts>=0&&(previous<0||pts-previous>=16000);}
 static int[] dimensions(int width,int height){
  if(width<=0||height<=0)throw new IllegalArgumentException("Invalid image size");
  double scale=Math.min(1,960.0/Math.max(width,height));
  return new int[]{Math.max(1,(int)Math.round(width*scale)),Math.max(1,(int)Math.round(height*scale))};
 }
 private static int clamp(int value){return Math.max(0,Math.min(255,value));}
 static int rgb(int y,int u,int v,boolean full,boolean bt709){
  int yy=full?256*y:298*Math.max(0,y-16);
  int rv=bt709?(full?403:459):(full?359:409),gu=bt709?(full?48:55):(full?88:100),gv=bt709?(full?120:136):(full?183:208),bu=bt709?(full?475:541):(full?454:516);
  return 0xff000000|(clamp((yy+rv*v+128)>>8)<<16)|(clamp((yy-gu*u-gv*v+128)>>8)<<8)|clamp((yy+bu*u+128)>>8);
 }
}
