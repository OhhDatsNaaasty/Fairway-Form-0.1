package com.fairwayform.app;

import android.app.Activity;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Surface;
import org.json.JSONObject;

/** Foreground, bounded, magnetic-north-referenced compass. No location storage. */
final class PhoneCompass implements SensorEventListener {
 interface Callback { void send(JSONObject reading); }
 private final Activity activity;
 private final SensorManager sensors;
 private final Callback callback;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private String requestId;
 private float declination;
 private final float[] gravity=new float[3],magnetic=new float[3],matrix=new float[9],screenMatrix=new float[9],angles=new float[3];
 private boolean haveGravity,haveMagnetic;
 private long gravityAt,magneticAt,lastSent;
 private int magneticAccuracy=SensorManager.SENSOR_STATUS_UNRELIABLE;
 private int sensorMode=-1;
 private final Runnable timeout=()->fail("Compass capture timed out. Aim again, or enter a direction manually.");
 PhoneCompass(Activity activity,Callback callback){this.activity=activity;this.sensors=activity.getSystemService(SensorManager.class);this.callback=callback;}
 void start(String id,double latitude,double longitude){
  stop();requestId=id;
  if(!Double.isFinite(latitude)||!Double.isFinite(longitude)||Math.abs(latitude)>90||Math.abs(longitude)>180){fail("Refresh local weather to locate the compass correction.");return;}
  declination=new GeomagneticField((float)latitude,(float)longitude,0,System.currentTimeMillis()).getDeclination();
  if(!Float.isFinite(declination)){fail("The true-north correction is unavailable. Enter a direction manually.");return;}
  haveGravity=false;haveMagnetic=false;lastSent=0;magneticAccuracy=SensorManager.SENSOR_STATUS_UNRELIABLE;
  if(sensors==null){fail("This phone has no compass sensor. Enter a direction manually.");return;}
  if(!startSensors(0))return;
  handler.postDelayed(timeout,35000);
 }
 // The UI requests a different source only after a bounded period without a
 // usable reading. Never use TYPE_GAME_ROTATION_VECTOR: it has no north reference.
 void retry(String id){if(id!=null&&id.equals(requestId))startSensors(sensorMode+1);}
 private boolean startSensors(int first){
  for(int mode=first;mode<3;mode++){
   sensors.unregisterListener(this);sensorMode=mode;
   haveGravity=false;haveMagnetic=false;lastSent=0;gravityAt=0;magneticAt=0;
   magneticAccuracy=SensorManager.SENSOR_STATUS_UNRELIABLE;
   boolean registered=false;
   try{if(mode<2){
    Sensor sensor=sensors.getDefaultSensor(mode==0?Sensor.TYPE_ROTATION_VECTOR:Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR);
    if(sensor!=null)registered=sensors.registerListener(this,sensor,SensorManager.SENSOR_DELAY_UI);
   }else{
    Sensor acceleration=sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),field=sensors.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
    if(acceleration!=null&&field!=null)registered=sensors.registerListener(this,acceleration,SensorManager.SENSOR_DELAY_UI)&&sensors.registerListener(this,field,SensorManager.SENSOR_DELAY_UI);
   }
   }catch(RuntimeException unavailable){registered=false;}
   if(registered){
    try{JSONObject p=new JSONObject();p.put("id",requestId);p.put("status","switching");p.put("sensor",sensorName());p.put("message",first==0?"Reading the phone compass. Aim the top edge down your throw and hold still.":"Trying another phone compass sensor. Aim down your throw and hold still.");callback.send(p);}catch(Exception ignored){}
    return true;
   }
  }
  fail("The phone could not provide a usable compass source. Move away from metal or magnetic cases, then retry, or enter a direction manually.");return false;
 }
 private String sensorName(){return sensorMode==0?"rotation-vector":sensorMode==1?"geomagnetic-vector":"magnetic-field";}
 void stop(String id){if(id!=null&&id.equals(requestId))stop();}
 void stop(){handler.removeCallbacks(timeout);if(sensors!=null)sensors.unregisterListener(this);requestId=null;}
 void pause(){if(requestId!=null)fail("Compass paused. Return to Caddy and aim again.");}
 private void fail(String message){String id=requestId;stop();if(id==null)return;try{JSONObject p=new JSONObject();p.put("id",id);p.put("error",message);callback.send(p);}catch(Exception ignored){}}
 @Override public void onAccuracyChanged(Sensor sensor,int accuracy){if(sensor.getType()==Sensor.TYPE_MAGNETIC_FIELD)magneticAccuracy=accuracy;}
 @Override public void onSensorChanged(SensorEvent event){
  if(requestId==null)return;
  long age=SystemClock.elapsedRealtimeNanos()-event.timestamp;
  if(age<0||age>1000000000L||event.values.length<3)return;
  for(int i=0;i<3;i++)if(!Float.isFinite(event.values[i]))return;
  int type=event.sensor.getType(),accuracy=event.accuracy;Double accuracyDegrees=null;
  if(sensorMode==0&&type!=Sensor.TYPE_ROTATION_VECTOR||sensorMode==1&&type!=Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR||sensorMode==2&&type!=Sensor.TYPE_ACCELEROMETER&&type!=Sensor.TYPE_MAGNETIC_FIELD)return;
  if(type==Sensor.TYPE_ROTATION_VECTOR||type==Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR){
   SensorManager.getRotationMatrixFromVector(matrix,event.values);
   if(event.values.length>4&&Float.isFinite(event.values[4])&&event.values[4]>=0)accuracyDegrees=Math.toDegrees(event.values[4]);
  }else{
   if(type==Sensor.TYPE_ACCELEROMETER){filter(gravity,event.values,haveGravity);haveGravity=true;gravityAt=event.timestamp;}
   else if(type==Sensor.TYPE_MAGNETIC_FIELD){filter(magnetic,event.values,haveMagnetic);haveMagnetic=true;magneticAt=event.timestamp;magneticAccuracy=event.accuracy;}
   else return;
   if(!haveGravity||!haveMagnetic||Math.abs(gravityAt-magneticAt)>500000000L)return;
   if(Math.abs(Math.sqrt(gravity[0]*gravity[0]+gravity[1]*gravity[1]+gravity[2]*gravity[2])-SensorManager.GRAVITY_EARTH)>2.5)return;
   if(!SensorManager.getRotationMatrix(matrix,null,gravity,magnetic))return;
   accuracy=magneticAccuracy;
  }
  long now=SystemClock.elapsedRealtime();if(now-lastSent<180)return;lastSent=now;
  int rotation=activity.getWindowManager().getDefaultDisplay().getRotation(),x=SensorManager.AXIS_X,y=SensorManager.AXIS_Y;
  switch(rotation){
   case Surface.ROTATION_90:x=SensorManager.AXIS_Y;y=SensorManager.AXIS_MINUS_X;break;
   case Surface.ROTATION_180:x=SensorManager.AXIS_MINUS_X;y=SensorManager.AXIS_MINUS_Y;break;
   case Surface.ROTATION_270:x=SensorManager.AXIS_MINUS_Y;y=SensorManager.AXIS_X;break;
  }
  if(!SensorManager.remapCoordinateSystem(matrix,x,y,screenMatrix))return;
  SensorManager.getOrientation(screenMatrix,angles);
  double heading=(Math.toDegrees(angles[0])+declination+360)%360;
  if(!Double.isFinite(heading))return;
  try{
   JSONObject p=new JSONObject();p.put("id",requestId);p.put("heading",heading);p.put("trueNorth",true);p.put("accuracy",accuracy);p.put("accuracyDegrees",accuracyDegrees==null?JSONObject.NULL:accuracyDegrees);
   p.put("level",screenMatrix[8]>=Math.cos(Math.toRadians(40)));p.put("rotation",rotation);p.put("sensor",sensorName());p.put("timestamp",System.currentTimeMillis());callback.send(p);
  }catch(Exception ignored){}
 }
 private static void filter(float[] target,float[] values,boolean initialized){for(int i=0;i<3;i++)target[i]=initialized?target[i]*.8f+values[i]*.2f:values[i];}
}
