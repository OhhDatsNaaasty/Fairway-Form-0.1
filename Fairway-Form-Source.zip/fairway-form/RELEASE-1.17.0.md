# Final Form - Disc Golf 1.17.0 — Fresh starts, readable green/gold, personal disc photos

## Intro behavior

The approved intro remains intact and plays for a fresh app activity/session. It no longer replays on Home/app-switcher return, unlocking the screen or returning from camera/gallery/permission tasks. If interrupted partway through, it is dismissed rather than resuming on return. Fully closing/removing the app and opening it again plays it again. An Android process kill also makes the next opening a fresh start.

Normal returns keep the same WebView, current screen and Caddy draft. Skip, Remove animations, offline bundled playback and failure fallbacks remain. The 1.16.1 resource-mapping/checksum verification fix is retained.

## Green, gold and readable controls

- Page backgrounds and native bars use the exact title-screen green, **#101f1d**, in both Regular and Dark mode. Dark uses deeper panel surfaces rather than changing the page background.
- Basket gold **#dfbc72**, mint and complementary sky/rose palette options replace the pale surfaces. Existing saved palette/mode/graphics IDs remain supported.
- The header logo, cards/sections and input windows have black framing. Gold actions use dark text for contrast.
- Main text, labels, phase labels and navigation are larger. Inputs/selects use at least 16 px text and 52 px height, with larger padding; notes areas are taller.

## Your own disc photos

Open **Disc room → My bag**. Each bag copy has a **Your disc photo** area with:

- **Take photo** using the phone's camera.
- **Choose from Gallery** using scoped file selection.
- **Use catalog photo** to remove the override.

Your photo replaces that copy's main bag/profile image. Other physical copies and manufacturer catalog images remain separate. Photos are resized and re-encoded locally to JPEG (maximum edge 960 px, at most 160 KB), with original metadata removed. The app stores the resulting image bytes on the device, not a temporary gallery URI, so the photo survives restarts. It does not upload photos.

Bag backups include photos. Old backups without photo fields remain usable and retain an existing matching copy's photo. An explicit photo removal also restores correctly. Hole exports omit photo bytes. Photo and field writes merge atomically with the latest copy, preserving notes, weight and other saved fields; a removed disc cannot be recreated by a late photo save.

## Update from your Android phone

Replace and commit the repository-root **Fairway-Form-Source.zip** with this 1.17.0 ZIP, keeping the same filename, working workflow and signing key/password. After Actions succeeds, download **Fairway-Form-APK**, extract it and install **Fairway-Form.apk** over the current app. Do not uninstall first.

The Android package `com.fairwayform.app`, WebView origin, `fairway-form` database and schema 5, backup kinds and build filenames are unchanged. Version name is 1.17.0; fallback versionCode is 35, with the phone workflow continuing to supply its increasing run-based code.

## Phone checks

1. Fully close/remove the app and launch it: the intro plays. Minimize/reopen, lock/unlock and return from a picker: it does not replay. Try interrupting the intro itself.
2. Switch Regular/Dark and each palette: the outer background stays title green. Check gold actions, black outlines and readable fields on your phone's font/display scale.
3. Add two copies of the same mold. Take/choose a photo for only one. Relaunch and verify it persists on that copy while the other keeps the catalog picture.
4. Change notes/weight, replace a photo, restore the catalog image, and try cancelling camera/gallery. Confirm disc history and saved distances remain.
5. Export/restore a bag with photos and test an older photo-free backup. Backups contain the pictures, so share them only if desired.

## Validation

The JavaScript suite passes 532 tests, alongside 12 native startup-rule checks and 19 native camera-rule checks. Static checks cover syntax, resources, identity compatibility and the intact approved movie. A real mobile Chrome check exercises all three palettes in both modes, field sizing/borders and action-text contrast, actual JPEG processing, IndexedDB photo persistence/reload/removal, photo-inclusive JSON backup export/restore, concurrent edits and missing-copy rejection. The existing full browser/pose-model smoke check remains mandatory in the GitHub build and now includes the new appearance/photo flow.

There is no local Android SDK/emulator or access to your signing key, so the signed APK build and physical camera/launcher/lock-screen behavior still need the GitHub run and phone checks above. Local Chrome checks validate the actual browser photo path; they do not claim to operate a physical Android camera or validate pose accuracy.
