# Fairway Form 1.1.1 — video recovery and themes

The green message in the screenshot was a timeout from the video player. The old code used the same message for initial video loading and seeking to an analysis frame. The screenshot alone does not identify the exact decoder failure. The update addresses a specific weakness: waiting for a seeked event even when Android has already made the requested frame ready.

The player now checks readiness and seek position, with event and polling paths. A stalled decoder is still reported, rather than analyzing stale pixels. Failed analysis retains collected observations in a prominent partial-review panel. Saved reviews and narrated practice plans disclose the interruption. Opening failures and frame decoding failures have different messages, and error notices have a warm red-brown color. Failure to jump to the release after completion does not discard the finished review.

## Themes

Open App & settings → App theme. Choose Forest (original), Dark Forest (charcoal gray and forest green), Coastal (blue and teal), Sunset (warm clay), or Follow phone setting. Your choice is saved locally. Cards, controls, navigation, coaching, library and discs follow the palette. Android system bars are updated where supported. Video pixels and overlay tracking colors are unchanged.

## Update from your phone

1. Download the new Fairway-Form-Source.zip. If your phone appends (1) to its filename, rename it back to exactly Fairway-Form-Source.zip.
2. In the same private GitHub repository, use Add file → Upload files to replace the existing root ZIP, then commit to main. Keep it zipped.
3. Keep your existing working workflow, APP_SIGNING_PASSWORD secret and encrypted signing key.
4. Open Actions → newest Build Fairway Form APK run. After it succeeds, download the Fairway-Form-APK artifact.
5. Extract the artifact ZIP in Files and install Fairway-Form.apk over your existing app. Do not uninstall first; that clears app-private data.

This download contains editable source, not an already compiled APK. No workflow edit is required for the existing working build. The same CI signing identity and increasing run number allow an in-place update.

## Verification

51 local automated tests pass. They include missing seek events, actual decoder stalls, readiness without image data, cancellation, overlapping seek requests, format-specific errors and incomplete-review warnings. JavaScript syntax, Android XML, module imports, controls, linked assets, offline shell entries and shell syntax were also checked.

The real-browser script was extended to verify palette changes and persistence, automatic dark/light switching, real-video recovery without seeked events, and partial-review retention after a deliberate test-only interruption. It could not run in this workspace because binding localhost is blocked (listen EPERM). Android compilation and the browser/model checks still need to pass in GitHub. These tests do not prove that every phone codec issue is resolved.

After installing, retry the exact clip from your screenshot. Test analysis, frame stepping, scrubbing and opening a saved session. Try all palettes and restart with Dark Forest selected. If you choose Follow phone setting, toggle your phone's dark mode. Verify that an existing bag and saved sessions still open. If the clip fails again, the new inline message should identify whether opening, decoding a particular frame, or loading a model failed.
