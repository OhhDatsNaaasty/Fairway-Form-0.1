# Final Form - Disc Golf 1.16.1 — Opening-movie APK verification fix

The reported 1.16.0 run passed the real browser/model checks and Android compilation (`BUILD SUCCESSFUL`). The next step failed because the checker assumed that the packaged movie retained the source path `res/raw/fairway_intro.mp4`. Android release resource optimization can shorten file paths; resource-name collapsing is also supported by the packaging tools.

## Change

- The checker runs the SDK's `aapt2 dump resources` against the completed APK and resolves the app's logical `raw/fairway_intro` resource to its actual packaged file.
- It uses the current build variant's generated resource ID when names have been collapsed. A release check never selects stale debug symbols.
- The actual mapped ZIP entry must contain the exact approved movie: original byte count and SHA-256 remain required. Missing files, altered/truncated bytes, incorrect resource bindings and unrelated duplicate movies still fail.
- Diagnostics distinguish resource-table/tool failures, unresolved resources, extraction failures and incorrect movie bytes, and success logs show the actual resource ID/path.
- The build passes its already-installed build-tools 35.0.0 executable to the checker. No new download or runtime dependency is introduced.

The name, logo, approved Concept 05 intro, startup behavior and all coaching/Caddy features from 1.16.0 are retained. Java deprecation warnings shown in the failed run were not the failing step and have not been hidden.

## Update from your phone

Replace the repository-root **Fairway-Form-Source.zip** with this 1.16.1 ZIP, keep the same filename, and commit it. Keep the existing workflow, encrypted signing key and password. A new Actions run will build and verify the APK. Download the successful **Fairway-Form-APK** artifact and install **Fairway-Form.apk** over the existing app; do not uninstall first.

Android package `com.fairwayform.app`, origin `https://appassets.androidplatform.net`, database name/schema 5, backup kinds and build filenames are unchanged. Version name is 1.16.1; fallback versionCode is 34 and the phone workflow still supplies its increasing run-based value.

## Validation

Regression coverage includes shortened and unoptimized paths, package-qualified names, collapsed names with generated IDs, stale debug/release symbols, missing resources, wrong bytes of the same length, truncation, multiple configurations, unrelated approved decoys, paths containing spaces and tool failures. ZIP/CLI fixtures use the real approved movie for the full checker flow, with synthetic AAPT2 output; they are not Android builds. The text format was checked against AOSP's AAPT2 resource-table/file-reference printers.

The signed APK from the reported run was not attached or available in this workspace, and there is no local Android SDK/emulator. The patched checker still needs to run against the actual newly built APK on GitHub; native intro playback still needs the phone acceptance checks in RELEASE-1.16.0.md. The build gate remains enabled.
