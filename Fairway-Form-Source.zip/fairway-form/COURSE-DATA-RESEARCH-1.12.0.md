# Course data, UDisc inquiry and future commercial use

Reviewed 2026-10-23. This documents the implementation and public-source review; it is not a legal opinion or an executed license agreement.

## What can be used from UDisc now?

The implemented feature stores a normal, user-provided HTTPS UDisc course-page link and opens it in the external browser. It does not fetch, parse, embed, cache or synchronize UDisc content. A UDisc URL already published as an OSM website tag may also be retained as an external reference; its source is the licensed OSM record, and the destination is not fetched. UDisc is identified as an independent service, without its logo or an endorsement claim.

We have not identified an open commercial license or documented public course API authorizing the requested import. UDisc's published terms, last-modified September 3, 2024, describe personal/noncommercial access in section 2 and require written consent for other copying/scraping/distribution in section 9. Section 10 also addresses competitive uses, which needs explicit attention for this proposed Caddy integration. Public visibility, an ordinary subscription, attribution, user-initiated scraping, or changing the data into a different format does not by itself establish permission for our commercial reuse. Personal score exports, if available, do not automatically license course maps or the database.

A user's own independently gathered course observations can be entered locally. This is not a feature for systematically transcribing or laundering UDisc data. Course-owner material also needs suitable authorization or an applicable license before redistribution.

Sources:
- https://udisc.com/terms
- https://forum.udisc.com/t/request-public-api/375?page=3 (public requests, not proof of private licensing availability)
- https://help.udisc.com/en/ (official support channel)
- https://play.google.com/store/apps/details?id=com.regasoftware.udisc (developer support contact help@udisc.com)

## Agreement inquiry

UDISC-LICENSING-INQUIRY.txt is an unsent initial inquiry. Fill in your name/entity/reply details and send it to help@udisc.com, asking to be routed to partnerships/data licensing. The address is a verified support contact, not a claimed licensing representative. The draft clearly describes the intended paid subscription and pro Caddy. Do not send credentials, user videos or private player histories.

The first questions cover eligibility, permitted course fields, regions, prices/minimums, API/feed availability, offline cache/refresh/export/deletion rights, attribution, and rights to user-contributed maps or third-party material. An agreement should explicitly authorize this separate paid Caddy use and resolve applicable restrictions in the standard terms. A favorable support answer without a clear grant is not a substitute for the actual written license. No API availability, price, approval or response time is assumed.

No email has been sent and no charges or subscriptions have been activated. Before production distribution, have a qualified lawyer review the specific agreement and the app's actual data flows. Future API secrets and account entitlements belong on an owned backend; do not embed a shared licensing key in an APK.

## OpenStreetMap implementation

The app searches a dated, offline snapshot, which the build downloads from the official Overpass interpreter. The bounded query requests course objects (leisure=disc_golf_course), numbered hole ways (disc_golf=hole), and explicit course relations. The build extracts names, available address/location tags, reported par and length, mapped routes, object links and source/license metadata. It does not collect user scores, profiles or photos. There are no sample courses in the distributed app.

It reads both modern par/dist and legacy disc_golf:par/disc_golf:length. Bare OSM lengths are metres; explicit feet/metre values are converted. Contradictory or malformed reported lengths remain unknown. A separately labeled geometric polyline length is a map estimate, never automatically used as the hole distance or saved as a measured throw. Signed OB, mandatories, safe gaps, tree density, elevation and active pin positions are not inferred. The original route drawing is rendered from source coordinates, without commercial map tiles or imagery.

Explicit course membership is preferred, then boundaries containing a complete route. A nearby-point association is used only with a limited radius and a clear separation from the next candidate course; it is labeled proximity-only for review. Ambiguous associations and unnumbered routes are excluded rather than arbitrarily assigned. Course object duplicates and alternative tee routes remain distinct; the UI asks the player to choose when several routes exist for a hole. Imported holes open in setup with unknown fields blank. Current, player-confirmed layouts remain separate from unconfirmed map candidates and survive snapshot refreshes.

A name-only course can be saved without fabricated holes. Add a hole to this course opens the existing setup flow. Saving it retains the original course identity. Source metadata, reported values, reference links and unresolved map candidates survive backup/restore. Importing does not rewrite old rounds or personal disc histories. Course and hole observations stay local.

## Open-data license and monetization

OSM data is ODbL 1.0. Commercial use is allowed subject to its conditions, including attribution, applicable share-alike/source availability requirements, and preserving recipients' data rights. The bundled derived map dataset and its source notices are accessible through **Export open map dataset**, separate from private player/bag/throw stores and local personal annotations. Do not put that license notice/export behind a future pro entitlement. Charging for the Caddy service does not create exclusive rights over the underlying open data. The ODbL does not automatically require all independent application code to use that license. Review any future shared/combined server database separately; do not assume a particular separation avoids all obligations.

- https://www.openstreetmap.org/copyright
- https://opendatacommons.org/licenses/odbl/1-0/
- https://wiki.openstreetmap.org/wiki/Tag:disc_golf=hole
- https://wiki.openstreetmap.org/wiki/Tag:leisure=disc_golf_course

## Hosting, freshness and build limitations

Data permission is separate from hosting permission/capacity. The official public Overpass manual identifies using donated instances as a general consumer-app backend as problematic. This implementation makes a bounded build-time snapshot request and serves searches locally; it does not turn each phone search into a public-server request. Large-scale extracts/refreshes should move to an owned or paid source, with caching and an appropriate schedule. No commercial hosting agreement has been made.

- https://dev.overpass-api.de/overpass-doc/en/preface/commons.html
- https://wiki.openstreetmap.org/wiki/Overpass_API

scripts/fetch-course-data.mjs refreshes a missing/older-than-seven-days snapshot during npm run assets. It has resource/time limits and retains a previous snapshot if download fails. If none exists, it reports the failure and leaves the directory unavailable; other app functions and manually saved courses continue working. It does not fabricate a seed catalog or fail an otherwise useful APK build. Rebuilding, rather than a live phone query, refreshes this first directory version. Actual coverage/counts are printed in the GitHub build, not hard-coded in the app.

This workspace's shell could not reach the configured network proxy, so a real global extract could not be downloaded here. Actual directory population must be checked in the existing GitHub build; parser/UI/integration tests use isolated synthetic test fixtures that are never loaded into the app. This limitation is material: a successful APK build alone does not prove the optional map download succeeded. Look for “Bundled OSM courses” in the assets step and test Find a course on the phone.
