# Fairway Form 1.12.0

## Course search without a UDisc scraper

In Caddy, open **My Courses → Find a course**. Search the offline OpenStreetMap snapshot by name or an available mapped location. Review the course and its mapped routes, then save it to My Courses. Choose the appropriate hole/tee route and Play / review this hole. Imported par and reported distance populate when available. Unknown values remain blank, and line, elevation and OB require confirmation before a reusable imported layout is saved.

Route drawings are community map data, with source links, snapshot date and ODbL attribution. Reported lengths are distinguished from estimated polyline lengths. No OB, mandatory rule, clear gap, tree cover or current basket position is guessed. Nearby course/route associations are marked for review. Ambiguous routes are excluded or presented as distinct tee/basket choices, not silently merged. Multiple choices for a following hole require a selection instead of assuming your last tee type.

A course with only a mapped name can be saved, then **Add a hole to this course** uses the existing shared setup form. Reimporting the same OSM object preserves the course's identity, user-confirmed layouts, local name and external reference. Existing rounds and per-disc histories are not rewritten. Sources and incomplete map candidates survive course backup/restore. **Export open map dataset** provides the ODbL map database separately from personal stores.

## UDisc references and commercial agreement

My Courses has a **UDisc course reference** expansion. Paste a normal HTTPS UDisc course URL, save it to the selected course and open it in your browser. The app does not fetch, scrape, embed, import or synchronize UDisc course data. Ordinary UDisc subscriptions and public pages do not establish permission for a separate commercial data integration.

UDISC-LICENSING-INQUIRY.txt is a ready-to-edit, unsent inquiry addressed to the verified support contact help@udisc.com, asking for routing to commercial licensing/partnerships. It explicitly describes your planned paid subscriptions with the full Caddy as a pro feature. It asks about eligibility, API/feed access, fields, offline storage, pricing/minimums, rate limits, attribution and third-party rights. Fill in your sender details and send it yourself after review. No agreement, API key, email response or licensing cost is assumed. No billing or subscription charges have been enabled.

See COURSE-DATA-RESEARCH-1.12.0.md for sources and the implementation's commercial-use considerations. ODbL permits commercial use subject to its conditions; permission to use data is separate from the cost/policy of hosting an API. The independent open map export/license notices should remain accessible when paid features are introduced.

## Directory availability — check this in your build

The existing **npm run assets** step now calls scripts/fetch-course-data.mjs. It downloads a bounded official OSM extract and bundles the processed map snapshot for offline search. A valid snapshot less than seven days old is reused. This avoids using donated public map servers as a live backend for every app user. At scale, move extract hosting/refreshes to an owned or paid service.

If download fails, the build retains a previous snapshot. If none exists, the directory explicitly reports unavailable; the rest of the APK can still build and all existing saved/manual course features remain usable. No fake/sample courses are substituted. Look in the assets log for **Bundled OSM courses: … mapped hole routes: …** or **Offline OSM course snapshot already available**. **A green APK build alone does not establish that this optional download succeeded.**

This workspace could not reach its configured network proxy, so the real global map extract could not be downloaded here. Directory population and actual coverage still need verification through GitHub Actions and on the phone. Isolated synthetic map fixtures are used only in tests, never as app course content.

## Phone update

Replace your existing repository-root **Fairway-Form-Source.zip**, keeping the exact filename, workflow, encrypted signing key and APP_SIGNING_PASSWORD. Commit, let Actions build, download/extract **Fairway-Form-APK**, then install **Fairway-Form.apk** over the current app. Do not uninstall or clear data. Settings should show **Version 1.12.0**.

Android package com.fairwayform.app, WebView origin, signing identity and IndexedDB schema 5 remain unchanged. Existing bags, videos, player profiles, disc histories and courses are retained. The local Android versionCode fallback is 25; CI supplies its run number. Back up your bag/history, courses and profile before updating.

## Verification

429 automated tests pass. New tests cover map distance units, modern/legacy tags, missing/conflicting fields, uncertain association, explicit membership, multiple tee options, strict source/URL validation, same-course refresh, partial/empty-course backups, review before planning, course-specific hole creation, reference-only UDisc links, local search/cache, truthful unavailable/error states, map-data export separation and next-hole choice. Earlier form, playback, bag, Caddy, putting, GPS and storage regressions pass.

JS/import/HTML/control/offline-shell checks, embedded browser-expression syntax, Android XML and shell/version checks are separate. Full browser/model smoke checks and signed APK compilation run in GitHub Actions; this workspace cannot run that browser/Android SDK build. The archive is editable source, not a locally compiled APK.
