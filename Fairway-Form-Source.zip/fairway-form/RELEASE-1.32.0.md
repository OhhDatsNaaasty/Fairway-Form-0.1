# Final Form - Disc Golf 1.32.0

Plan for this lie now includes a suggested landing picture and a short description beside the recommended disc. The target uses the exact selected candidate's planned distance and the existing disc-copy range, hand/style/release, learned flight and hazard planning. Choosing another shot updates its distance, description and diagram together, including two styles for the same physical disc. Tap the picture to enlarge it.

The marker represents an intended first-landing area on the schematic, not a predicted trajectory or a probability/dispersion boundary. It uses a middle or side-center location with room away from selected side trouble and, on hard ground or near long trouble, room for the disc's expected finish. The planner's existing shorter water-hazard target and required-carry limits remain unchanged. Known first-bend distances calibrate the first sketch segment; ordinary sketches retain their schematic spacing. A point covered by a mapped obstacle asks for a clearer target rather than displaying a clear landing there.

Subsequent throws use a current-lie sketch. Basket-relative features can be rebased to remaining distance; an old tree distance from the tee cannot locate the player's new lie. Confirmed tee/basket route markers allow the target to appear on a saved sign photo. Without that registration, or from an unknown later lie, the plan uses a sketch. The original hole-sign preference remains in the hole summary. No player location or landing coordinate is invented or saved as a measurement.

Highlighted Caddy steps now explicitly pair basket gold with black text. The same readable pairing applies to active review filters and disc tabs. Routine notes-not-understood warnings, duplicated method paragraphs, sketch footer disclaimers and repeating optional-measurement reminders are removed or shortened in working screens. Original notes, source links and research/library content remain. Actionable ambiguity, required carry, blocked targets, measurement accuracy, permission explanations and analysis outcome messages remain available where they affect use.

## Verification

All 829 automated tests passed, including 17 new landing regressions and one new UI regression for quiet ordinary notes. Existing recommendation/history tests now also compare the displayed landing distance with the recorded planned target while keeping actual carry and remaining distance empty until entered. Tests cover saved-range changes, separate forehand range, water margins, known corners, side hazards, mirrored finish room, learned turnover behavior, later lies, obstacles, metric labels, photo registration, degenerate routes, escaped text and immutable inputs.

All 409 existing static control IDs remain unique and retained. Syntax checks passed for 114 runtime/script files; all 106 offline paths exist, including the new renderer. ZIP CRC and file-by-file workspace checks are recorded in verification.json.

The required GitHub browser gate now checks selected-shot landing synchronization, enlargement and all highlighted Caddy steps across palettes/modes, in addition to existing model/media/layout tests. Fresh local browser run a94a7da4-d820-4b42-abe6-d794aaf362df was blocked immediately by socket EPERM before Chrome started. No local browser, Android APK or physical-phone pass is claimed. A standalone sketch rendered from a sample plan was visually inspected; it is not an app screenshot or real course survey.

No new disc-golf research was conducted for this presentation update. Landing guidance uses the existing registered approach/placement, ground-play and flight sources already linked under Planning notes & sources. The analysis engine, video decoder, database schema, Android package, signing workflow and approved intro are retained.

## Update

Replace repository-root Fairway-Form-Source.zip and run the existing GitHub workflow. After all required gates pass, install its signed APK over the existing app without uninstalling. Keep the signing identity. Version name is 1.32.0; fallback versionCode is 57, and CI retains its increasing code.
