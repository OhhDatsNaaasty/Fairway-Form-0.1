# Final Form - Disc Golf 1.18.0 — Caddy chooses the shot and power

## What changes

The Caddy setup no longer asks for backhand/forehand, release angle or planned effort. Enter the distance, fairway, conditions and risk preference; the recommendation chooses the disc, throw style, release and power. Putting keeps its explicit Yes/No prompt and Mark as putt controls.

Both backhand and forehand use their own saved bag distances, general profile averages and qualifying measured video references. The preferred style in your player profile is a small familiarity preference, not a lock. An unverified alternate style gets a caution and a ranking penalty. Direction mirrors for left/right hand. Each successive lie starts a fresh comparison. Old unfinished drafts with a fixed style, angle or power open in automatic mode; already recorded throws remain intact.

## Shot complexity

Beginner, Intermediate, Amateur and an unset skill use flat releases and holding hyzers. Hyzer-flips, deliberate turnovers and anhyzer flexes require **Advanced** or **Pro**. Advanced is a new explicit choice under **App & settings → Player profile → Skill level**. Amateur is not silently promoted. Wind and learned flight reports cannot bypass this gate. If no suitable simple option remains, Caddy asks for a closer landing point or a more familiar disc rather than forcing an advanced release.

Advanced/Pro enables these options but does not guarantee the user can execute them. Only use throws you have practiced; flight numbers and logs do not prove obstacle clearance.

## Suggested power and real feedback

Each disc recommendation shows a short cue and a broad subjective effort band:

- Easy/touch: roughly 40–60% effort.
- Smooth controlled: roughly 65–80% effort.
- Comfortable full throw: roughly 80–90% effort.

These are app coaching starting points, not measured release speeds or a linear distance-to-power formula. They compare the target with this disc's distance reference for the chosen hand/style, or a clearly labeled role estimate when personal carry is unknown. Elevation and wind influence the existing planning margin. Long holes use the proposed reachable stage or entered landing point instead of asking for power against the whole hole. There is no all-out 100% prescription. Putting shows a familiar putting or soft lay-up pace, without a driving-power percentage.

The recommendation saves its planned style, release and effort separately. **What happened? → Shot type, release & flight details → Actual effort used** starts at Not recorded; it does not assume the user followed the recommendation. Confirm easy, normal controlled or firm. Confirmed actual effort participates in comparable history; unknown/touch effort does not become a normal-power distance baseline. All measured throws still remain in history and overall distance statistics. Old records keep their existing interpretation. Actual effort also survives bag backup/restore and can be corrected alongside a saved throw in My bag.

## Preserved

Includes all 1.17.0 changes: fresh-launch-only intro, exact title-green background in both modes, gold accents, larger framed inputs and per-copy camera/gallery photos. The approved movie is unchanged. Android package, WebView origin, schema 5, signing process, backup kinds, file names, courses and physical-copy disc histories are unchanged.

## Validation and phone update

547 JavaScript tests pass. New tests cover mirrored style selection, separate style references, lower-skill and learned-history restrictions, Advanced/Pro options, landing/staged targets, wind/elevation context, putting pace, actual effort and backup compatibility. A real mobile Chrome check exercises automatic forehand then backhand on successive lies, visible power, separate saved actual effort, putting pace and Beginner/Advanced gating. Existing palette/readability, personal-photo processing/persistence and real JSON photo-backup checks also pass. The full browser/pose-model smoke gate remains required in the GitHub build and includes the new Caddy flow.

There is no local Android SDK or signing key. A signed APK has not been compiled here; GitHub and physical phone testing remain the final validation steps. Effort guidance is a heuristic, not a new measurement of throwing biomechanics or power.

Replace and commit repository-root **Fairway-Form-Source.zip**, preserving the working workflow and signing credentials. Download the successful **Fairway-Form-APK** artifact, extract it and install **Fairway-Form.apk** over your current app without uninstalling. Source version is 1.18.0, fallback versionCode 36; GitHub continues to supply its increasing run-based version code.

After installing, test a left/right bend, each throwing hand, Beginner versus Advanced, a long staged hole and a putt. Confirm Actual effort used in feedback and verify the saved entry in My bag. Previous course, photo and distance records should remain.
