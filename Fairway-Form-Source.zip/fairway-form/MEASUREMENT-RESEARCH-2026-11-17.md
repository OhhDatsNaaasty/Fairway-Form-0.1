# Throw-distance measurement research — 17 November 2026

The implementation aims to reduce avoidable measurement error and retain useful approximate observations. A reported ten-foot uncertainty target and an actual error within ten feet are different claims. This release does not establish the latter on an Android handset.

## Official references reviewed

All six references are registered in the searchable app library with original summaries, subject-specific titles, review dates and access provenance. The linked sections, rather than every page of each documentation set, were reviewed.

- [GPS.gov: GPS accuracy](https://archive.gps.gov/systems/gps/performance/accuracy/): receiver and environmental limits, including blockage and reflected signals. The archive's smartphone example is historical; the page states it has not been updated since February 2025.
- [Android Location](https://developer.android.com/reference/android/location/Location): reported horizontal radius, monotonic timing and mock-location indicators. The accuracy radius is a 68th-percentile estimate, not an independently established distance-error bound.
- [Android LocationManager](https://developer.android.com/reference/android/location/LocationManager): framework GNSS provider and live foreground updates. This is the provider used by the new native session.
- [Android raw GNSS](https://developer.android.com/develop/sensors-and-location/sensors/gnss): raw-measurement access and optional chipset capabilities, including carrier phase and multiple frequencies. Access alone does not supply a validated high-precision positioning solution.
- [ARCore anchors](https://developers.google.com/ar/develop/anchors): changes to world-space estimates and anchor relationships. This is not a distance-error specification; camera walking remains an estimate.
- [Google Play-services location requests](https://developers.google.com/android/reference/com/google/android/gms/location/LocationRequest.Builder): freshness and initial-accuracy request controls assessed as an alternative. No Play-services location dependency was added.

## Implementation choices

The native session keeps the GNSS provider running through the start capture, the walk and the landing capture. It rejects old, duplicate and mock fixes using monotonic timing, and stops on completion, cancellation, pause or a ten-minute limit. The screen stays awake while that bounded session is active. No walked route or geographic coordinates are written to the throw history.

Each endpoint now needs at least six fresh fixes spanning eight seconds. A robust center rejects isolated jumps, checks drift and retains the larger of reported accuracy, scatter and drift. It never divides the accuracy radius by the square root of the sample count. The preferred endpoint budget is five feet, giving a combined reported budget of ten feet. A stable lower-quality result can be returned after a longer wait, still labeled an estimate; excessive relative uncertainty blocks Save. An uncertain landing can be retried without walking back to the start.

These thresholds are app choices requiring field validation. They are not accuracy figures established by the reference pages. Repeated fixes can agree while sharing a systematic error.

## Disc-profile evidence policy

| Distance evidence | Relative weight | Treatment |
| --- | ---: | --- |
| Independently measured distance | 1.00 | Retains its measured average and farthest result |
| New qualified GPS cluster meeting the reported ten-foot budget | 0.85 | GPS estimate, with diagnostics retained |
| Quality-checked GPS estimate | 0.60 | Requires acceptable absolute and relative reported uncertainty |
| Entered distance estimate | 0.25 | Approximate evidence |
| Confirmed marked landing | 0.20 | Approximate start-to-finish displacement from the sketch |
| Coarser but usable GPS estimate | 0.20 | Approximate evidence |
| Unvalidated camera walk | 0 | Retained in history, excluded from normal range learning |

These weights are relative product-policy values, not calibrated probabilities. When stronger evidence exists, total approximate weight is capped at half the stronger weight, limiting approximate influence to one-third of the combined result. Separate recent windows prevent a flood of estimates from evicting all checked observations. Entered references provide a prior when stronger samples are sparse. Recommendations retain hand, throw, release and condition comparisons; mixed-condition fallback stays labeled.

A marked landing uses the actual known starting point and confirmed finish point. Subtracting distance remaining would be wrong on doglegs and off-line shots. A missing starting position cannot generate a later throw's distance. A first-ground-contact carry and a finish after a skip are different observations, so the latter remains a lower-weight estimate. A measured distance in the same throw takes precedence rather than counting the throw twice. Obstructions, execution errors and unfinished feedback do not establish normal range.

Compatible earlier marked rounds can acquire evidence without rewriting their saved measurements. A cleared estimate remains cleared. Corrections and history backups preserve the selected source.

## Field validation still required

Use fixed, independently checked baselines on an open field, then repeat near a wooded edge. Test in both directions and record every signed error, including the worst miss. Include a short and a full-throw distance. Compare the new GPS mode against the known baseline; a small reported radius alone does not pass the check. Repeat on the user's actual phone model. Until those comparisons demonstrate the ten-foot target for that setting, retain GPS as an estimate and use the checked value where precision matters.

Raw carrier-phase processing or an external precision receiver would be a separate, device-dependent engineering project. This release does not claim RTK or survey-grade performance, and it does not silently turn camera estimates into precise measurements.

## Pixel 10 Pro XL follow-up (1.40.1)

The user identified the phone as a Google Pixel 10 Pro XL. Google's [official specifications](https://store.google.com/product/pixel_10_pro_specs?hl=en-US) list dual-band GNSS, GPS, GLONASS and Galileo. The connectivity/location specification was reviewed through the indexed official page on 2026-11-17 and registered in the searchable library as “Google Pixel 10 Pro XL · Dual-band satellite positioning hardware.” This confirms an advertised hardware capability; no handset or per-frequency observations were made. The Android framework provider selects and processes satellite signals, and this app cannot force a dual-band solution or infer actual accuracy from the model name.

The known-baseline field check remains necessary on this phone, in both open and wooded settings. No accuracy thresholds, weights or “measured” labels were relaxed for the model. The unrelated landing-picker build failure is addressed with a stable sheet layout and cancellation of pending page scrolling; the required real-browser gate remains enabled.
