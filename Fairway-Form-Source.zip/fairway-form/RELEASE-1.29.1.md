# Final Form - Disc Golf 1.29.1

Adds the two user-provided professional backhand references to Technique library:
a slowed example and a separate full-speed example. Original summaries explain
the visible crossing/stride/swing/continuation sequence, crop and blur limits,
and why screen-recording timestamps cannot become universal timing targets.
Two practical lessons cover event order and playback-time interpretation.

The library now has 106 lessons and 86 distinct research resources from 90 stable
source records. The original recordings/images are not bundled. Source URLs,
access basis and the supplied athlete identification are recorded accurately;
original public title/channel metadata could not be fetched. The study notes
and two research JSON records contain provisional visual intervals, not automated
predictions or independently verified ground truth.

This is a reference-library update. Event selection, model weights, decoding,
coaching rules, Caddy, bag/catalog and Android behavior are unchanged from 1.29.0.
No measured recognition improvement, new training or completed phone test is
claimed. See BACKHAND-REFERENCE-STUDY-2026-11-04.md for observations and limits.

Replace the same repository-root Fairway-Form-Source.zip and keep the working
workflow/signing credentials. After Actions passes, install the extracted APK
over the existing app without uninstalling. Version is 1.29.1; fallback versionCode
is 52 (CI supplies its increasing code). Required browser/model/native/APK gates
remain enabled. See the accompanying verification.json for exact check results.
