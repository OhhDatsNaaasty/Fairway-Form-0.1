# Coaching, lessons and X-step review — 1.5.0

Research updated October 22, 2026. This release improves how existing video observations become understandable practice, and adds a conservative projected-crossover recognizer. Reading more tutorials does not itself train the pose model or validate a form detector.

## Teaching sources checked for this release

| Resource | What was reviewed and used |
| --- | --- |
| [Innova illustrated X-step](https://www.innovadiscs.com/wp-content/uploads/pdf/X-Step_how-to.pdf) | Read the one-page chart. Used for the rear-foot crossover, final stride and continuation sequence. Its weight illustrations are not video-derived pressure measurements. |
| [Danny Lindahl: Why is footwork so important?](https://blog.dynamicdiscs.com/2017/07/why-is-footwork-so-important.html) | Read the coach-authored article. Used for an easy-to-manage crossover and rehearsing the feet separately. Inch measurements and foot-angle prescriptions are not universal app targets. |
| [Overthrow: Building the Brace](https://www.overthrowdiscgolf.academy/lessons/building-the-brace) | Read the public written transcript. Used for a small settled-stance practice adaptation and explaining support. No claim that a 2D hip/knee check measures force or proves a safe brace. |
| [Overthrow: Extension Out of the Pocket](https://www.overthrowdiscgolf.academy/lessons/extension-out-of-the-pocket) | Read the public written transcript. Used to explain the forearm opening, with arm room and an easy practice progression. App drills are original adaptations, not copied transcripts. |
| [Brian Earhart: Dissecting the Reach Back Myth](https://discgolf.ultiworld.com/2018/05/22/tuesday-tips-dissecting-reach-back-myth-part-1/) | Read the article and its player-example explanation. Used to distinguish body movement around the disc from stretching farther with the arm. |
| [Innova: How to Throw Backhands Really Far](https://www.innovadiscs.com/innova-news/how-to-throw-backhands-really-far/) | Read the written guidance on intended line, planting, sequence, disc choice and nose control. It informs practice ideas, not numerical ideal positions or invented release measurements. |
| [Innova: Common Throwing Errors](https://www.innovadiscs.com/innova-news/common-throwing-errors-holding-back-your-game/) | Read the discussion of torque, rounding, overpowering, nose-up and too-fast discs. These are useful teaching topics, not automatic diagnoses from a missed shot. |
| [PDGA / Scott Stokely: Three Keys to a Better Sidearm](https://www.pdga.com/news/three-keys-better-sidearm) | Reviewed the written forehand teaching. The app keeps that guidance separate from backhand crossover and timing targets. Coach-specific cues are not universal biomechanical requirements. |
| [Discmania: Five Ways to Improve Your Sidearm](https://www.discmania.net/blogs/discover/five-ways-to-improve-your-sidearm) | Read the short-to-long progression and written grip/release guidance. Used for comfortable, repeatable forehand practice rather than claiming to see grip pressure. |
| [Discmania / Bartosz Kowalewski: Grip and Approach Shots](https://www.discmania.net/blogs/discover/disc-golf-grip-tips-and-approach-shots-with-bartosz-kowalewski) | Read the brief introduction and verified the linked demonstration. The page is described as a video-led resource; no claim to have watched or transcribed that video. |
| [Discmania: Top 5 Beginner Tips](https://www.discmania.net/blogs/discover/top-5-disc-golf-beginner-tips) | Read the technique, fieldwork and small-bag advice. Used for simple controlled practice and choosing familiar disc roles. |
| [Innova: Six Quick Putting Tips](https://www.innovadiscs.com/tips/6-quick-putting-tips/) | Read the routine, aim, continuation and lower-body guidance. Putting remains separate from backhand X-step interpretation. |
| [TechDisc Metrics](https://techdisc.freshdesk.com/support/solutions/articles/153000074253-techdisc-metrics) | Read the definitions distinguishing bank, nose and launch. Sensor or simulator examples are not imported as measurements from a phone video. |
| [Innova: Field Work](https://www.innovadiscs.com/innova-news/how-field-work-can-make-you-a-better-disc-golfer/) | Read the purposeful-practice, filming and gap/distance/shape-game suggestions. The app uses its own small-set tasks and links this article from practical fieldwork lessons. |

The MVP flight-rating reference, Innova wind article and UDisc/Overthrow backhand written outlines were also revisited. Existing video links keep their written-outline review label. No inaccessible playback, paid content or unseen transcript is presented as reviewed footage. Inherited manufacturer/product/model references remain clearly distinguished from technique instruction in KNOWLEDGE-SOURCES.md.

## Coaching presentation

The default plan is a brief, finding-derived view: one actual visible pattern to keep when available, one practice focus, a concrete cue, and replay/lesson links. Attention prompts describe the observed change in plain language. Observe findings become practice ideas, not invented faults; missing evidence cannot create praise or a body correction. Partial reviews and suggested-release limits remain visible.

The detailed practice plan, drill choices, all body cards, source evidence and measurements are in closed disclosures. Missing checks remain grouped separately. Default narration reads the short version; the detailed plan has its own read-aloud button. Existing actual voice selection and offline/internet preferences remain unchanged.

Lesson buttons open the exact internal library section, clear conflicting filters and expand it. Original lesson IDs remain stable. The library now has 74 lessons, 49 linked resources and 23 publisher/coach/research groups. All 62 previous lesson titles/explanations were rewritten for clarity, with 12 additions on disc choice, landing areas, style, angles, wind, woods and structured practice. Core explanations are accompanied by practice prompts and resource previews, so readers can assess a link before leaving the app. Product and model documentation are labeled for their actual purpose.

## What X-step recognition actually does

`x-step.js` runs on source-timed body landmarks already produced by the pose engine. For a backhand walk-up with a fixed side-on camera, it looks for:

1. A sequence of sufficiently visible hips, shoulders and both ankles before release.
2. Clear sideways body travel and a side-turned torso.
3. A sustained exchange of projected lead/rear ankle positions, followed by opening into the final stride.
4. Rejection of weak evidence: cropping, large gaps, landmark jumps, a contradictory direction/lead-foot setting, insufficient approach or front-facing ordinary walking.

The automatic result is a **candidate**, with source-frame replay moments. It cannot prove whether one foot passed behind rather than in front in depth. The user confirms the original frames or sets a crossover marker. A user marker remains labeled as marked, not an automatically validated event. No X-step is expected for standstill, forehand or specialty throws.

The report adds a separate X-step observation, crossover phase, final-stride moments and optional time comparisons. There is no ideal timing target or “correct X-step” score. Recognizing the projected sequence is not measuring contact, force, pressure, balance, heel loading or injury risk. A footwork cue can now be tied to this clip when evidence is available; otherwise the general lesson remains explicitly separate.

Thresholds are application heuristics: 2.5-second look-back; at least 10 visible frames and 80% visibility in the window; at least 0.55 seconds of coverage; no visible-frame gap above 0.18 seconds; a side-turned shoulder-width check; body travel of at least 0.25 torso lengths; sustained projected foot-order states. A rapid landmark jump above 18 torso lengths/second in a short interval is rejected. These values are for conservative evidence selection, not ideal form standards. Exact rules are in the editable module.

Synthetic coordinate tests check logic, not real-world detection accuracy. The recognizer has not been calibrated on a labeled library of actual throws. Phone testing with real side-on clips, including false-positive cases, is still needed before an app-store accuracy claim. Generated frames do not supply hidden foot or hand evidence.

## Artwork, persistence and verification

Park day, Woodland and Ridgeline use original local SVG illustrations. Minimal retains the simpler original presentation. Graphics, palette and light/dark mode are independent and saved together; an older palette/mode preference remains valid. Missing graphic preferences start with Park day, and Minimal is always available. Dark mode keeps the existing gray surfaces and palette accents. No remote artwork, animation, new native permission, account or service is required.

Package, origin, signing workflow and IndexedDB version 4 remain unchanged. The crossover marker and report metadata extend existing saved sessions; opening an existing session with pose frames recalculates the new report. The source remains editable: library-editorial.js owns lesson titles/expanded notes/previews/additions, knowledge.js owns stable IDs/source relationships, coaching-language.js owns narration, and x-step.js owns the new recognition rules.

278 automated tests pass, with static JS/import/control/cache/XML/script/version checks. New cases cover mirrored crossover sequences, ordinary walking, hidden/cropped feet, gaps, jump rejection, manual markers, report/timeline integration, summary integrity, internal lesson opening, closed detail views, saved graphics and offline SVG references. Original art was rendered and inspected. A browser launch attempt was blocked by the workspace’s Chromium socket permissions; full browser/model smoke checks and signed Android compilation still require the existing GitHub workflow, followed by phone testing.
