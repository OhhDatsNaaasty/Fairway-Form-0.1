# Recorded-reference event fixes — 1.30.0

This release changes the production event selector. Version 1.29.1 only added
reference research/library entries; it did not change event detection.

## What actually ran

Both accessible McBeth uploads were decoded locally. A separate research runtime
used MediaPipe Python CPU 0.10.21 and the app's identical bundled Full task:

`5134a3aad27a58b93da0088d431f366da362b44e3ccfbe3462b3827a839011b1`

Settings matched the app body pass: VIDEO mode, CPU, two-pose maximum, and .65
pose detection/presence/tracking thresholds. Detected visibility is the minimum
of presence/visibility, matching readPose. Source presentation timestamps from
ffprobe were paired with decoded frame indices, sampled at requested 30 Hz and
deduplicated. Display rotation was enabled: the slowed recording is displayed
1078×1168, despite its 1168×1078 coded dimensions. A preliminary coded-orientation
run was discarded and is not the slowed comparison reported here.

The resulting measured landmarks were passed through the **production JavaScript
review/event code**, before and after the changes. This is real-source model
inference plus production event-rule evaluation. It is not a WebView/WASM parity
test, a phone/MediaCodec run, a hand-detail pass or a new trained model. The CPU
wrapper and sampling scheduler can differ from the phone. The model asset and
production model configuration are unchanged.

## Observed case results

Times below belong to the uploaded full-speed copy, not calibrated physical
throw time. Visual windows were chosen through assistant review of source
stills, with no independent coach labeling. Disc departure is blurred/cropped,
so the release result is a **swing cue**, not confirmed separation.

| Event in full-speed recording | 1.29.1 | 1.30.0 | Source-frame interpretation |
| --- | --- | --- | --- |
| Swing cue, full screen recording | 2.331911 s | 2.032278 s | Moves from later continuation to the initial outward swing/departure review area. |
| Plant, full screen recording | 2.432389 s | 1.804656 s | Moves from recovery to the observed final-foot-contact region. |
| Backswing reversal, full recording | 1.838856 s | 1.838856 s | Retains the prior supported estimate. |
| Arm loading, full recording | 1.939544 s | 1.939544 s | Retains the prior supported estimate. |
| Plant, selected .8–4.9 s range | unavailable | 1.804656 s | Resolves the supported initial stroke direction. |
| Backswing, selected range | 1.399144 s | 1.838856 s | Avoids selecting an earlier approach motion. |
| Swing cue, cropped video viewport | 2.001322 s | 2.001322 s | Preserves the already-correct case. |
| Arm loading, cropped viewport | unavailable | 1.939544 s | Allows nearby observed frames to confirm the opening. |

A selected range and a cropped viewport are **processing variants of the same
throw**, not additional independent athletes or held-out examples. These cases
guided the implementation; no general accuracy percentage is claimed.

The heavily retimed 31.2-second reference still yields competing swing sequences
and abstains. A last-20-second event-module check also abstained. Naive rescaling
experiments could produce a late cue/uncertain foot contact, so automatic
rescaling was not shipped. The app's 20-second import limit is unchanged; the
full long reference was evaluated directly by the research/event module. No
X-step improvement is claimed for these cropped/oblique screen recordings.

## Changes supported by the observations

1. Direction filtering previously looked for clear hand frames independently
   within ±90 ms of a sample. The velocity estimator used a different observed
   pair, allowing spans up to 300 ms. A brief hand-visibility gap around the real
   swing invalidated the direction lookup while a later recovery peak survived.
   Direction now uses the same observed pair as the velocity estimate. No points
   are interpolated, and the existing velocity gap limit remains.
2. A late peak can follow the same backswing/loading as the real outward swing.
   The new backhand-only helper follows the initial outward segment before its
   return, using visible arm opening and forward displacement. It does not impose
   a required elbow angle, reachback length, or copied professional pose. Explicit
   throw direction and user phase corrections remain authoritative.
3. An accepted final contact already passed the later-stride rejection. A later
   post-swing recovery cannot replace it merely because the ankle becomes quieter.
   A late contact remains possible when no valid pre-swing contact exists; manual
   late markers are preserved. Timing is not forced to look ideal.
4. A short observed interval after an automatic cue can confirm arm opening.
   The loading point itself must remain before the cue. This handles brief
   occlusion/low sample coverage without inventing an unobserved pocket position.

Thresholds are engineering heuristics. The references do not validate these
numbers or prove joint loads, pressure, disc spin, nose angle or ideal timing.

## Reproduction and provenance

`tests/fixtures/reference-poses/` contains measured numeric landmarks and provenance,
not video images. The normal full/cropped records have 158 distinct sampled
source times each; the slowed record has 746. Normal source SHA-256 is
`db2993086965f1b33ba29dab2512f1e4e9561f5cb479739bcd36b99ef7acc435`;
slowed source SHA-256 is
`d92138039ead5d2194134771b8b21d8f43a2130f97ba191a83df8743c650d2cc`.

Run `node scripts/check-reference-events.mjs` for the production-selector results,
and `node tests/reference-event-detection.test.mjs` for the seven regressions.
The frozen before-results, source/model hashes and limits are in
`research/reference-event-evaluation-1.30.0.json`.

Optional fresh extraction uses `scripts/extract-reference-poses.py` with local
media, ffprobe, OpenCV, numpy and MediaPipe 0.10.21 already installed. The research
run used numpy 1.26.4/OpenCV headless 4.11.0. The extractor never uploads footage;
these Python packages are not app/build dependencies and are not bundled.
Existing JavaScript fixtures run without them.

The user-supplied YouTube references remain searchable in the library. The
Gannon Buhr URL is recorded in research/gannon-buhr-reference-pending-2026-11-04.json,
but its archive exceeded the 32 MiB transfer cap and the web fetch was throttled.
Its footage/cues were not reviewed or used to tune this change. Original videos,
extracted screenshots, private working files and model/runtime downloads are
excluded from the release archive.
