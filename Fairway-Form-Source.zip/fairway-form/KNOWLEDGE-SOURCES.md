# Fairway Form knowledge library — 1.5.0

74 original app lessons and 49 linked resources. Each lesson includes a plain-language explanation, a practice task and a preview of its references. This inventory describes the bundled content; it is not a claim that every linked video was watched or every inherited resource re-reviewed this release.

New source checks, public-transcript reviews and detection limits are documented in COACHING-RESEARCH-1.5.0.md. In-app lessons are original teaching notes, not copied articles or a complete substitute for the linked instruction.

## Lesson index

- **The backhand X-step: cross behind, then take the final step** (x-step-sequence) · Footwork · [Innova · Illustrated backhand X-step](https://www.innovadiscs.com/wp-content/uploads/pdf/X-Step_how-to.pdf); [Overthrow · Disc golf footwork made simple](https://www.youtube.com/watch?v=ay54wHy9ge0).
- **X-step size: keep the crossing step easy to manage** (x-step-compact) · Footwork · [Danny Lindahl / Dynamic Discs · Why footwork matters](https://blog.dynamicdiscs.com/2017/07/why-is-footwork-so-important.html).
- **Backhand walk-up: find a rhythm before adding speed** (approach-tempo) · Footwork · [UDisc · Backhand instruction and drills](https://udisc.com/blog/post/5-great-videos-how-to-throw-backhand-in-disc-golf); [Overthrow · Disc golf footwork made simple](https://www.youtube.com/watch?v=ay54wHy9ge0).
- **Backhand backswing: turn your body instead of stretching back** (backswing-room) · Backhand · [Brian Earhart · Rethinking reachback](https://discgolf.ultiworld.com/2018/05/22/tuesday-tips-dissecting-reach-back-myth-part-1/).
- **Backhand timing: front foot down before the disc leaves** (plant-order) · Timing & sequence · [Innova · How to throw backhands really far](https://www.innovadiscs.com/innova-news/how-to-throw-backhands-really-far/); [Brian Earhart · Rethinking reachback](https://discgolf.ultiworld.com/2018/05/22/tuesday-tips-dissecting-reach-back-myth-part-1/).
- **Power pocket to release: let the forearm swing open** (extension-practice) · Backhand · [Overthrow · Extension Out of the Pocket: the forearm opening](https://www.overthrowdiscgolf.academy/lessons/extension-out-of-the-pocket); [Overthrow · Box drill for arm loading](https://www.youtube.com/watch?v=igNPpexLXlo).
- **The backhand brace: a front side you can turn from** (brace-practice) · Footwork · [Overthrow · Building the Brace: a supported base](https://www.overthrowdiscgolf.academy/lessons/building-the-brace).
- **Body tilt for flat and hyzer shots** (shot-plane-practice) · Angles & flight · [Innova · Common throwing errors](https://www.innovadiscs.com/innova-news/common-throwing-errors-holding-back-your-game/); [Innova · How to throw backhands really far](https://www.innovadiscs.com/innova-news/how-to-throw-backhands-really-far/).
- **Follow-through: give the arm and body room to keep moving** (finish-space) · Follow-through · [Innova · Common throwing errors](https://www.innovadiscs.com/innova-news/common-throwing-errors-holding-back-your-game/).
- **Forehand setup: a simple approach and a clean release** (forehand-setup) · Forehand · [PDGA / Scott Stokely · Three keys to a better sidearm](https://www.pdga.com/news/three-keys-better-sidearm); [Innova · Level up your forehand](https://www.innovadiscs.com/tips/how-to-throw-forehands-accurately-far-and-without-injury/).
- **Fieldwork: did you hit your line, or just get a lucky result?** (practice-comparison) · Fieldwork · [Innova · How to throw backhands really far](https://www.innovadiscs.com/innova-news/how-to-throw-backhands-really-far/).
- **Review your X-step: crossover, final stride and plant** (x-step-review) · Video review · [Innova · Illustrated backhand X-step](https://www.innovadiscs.com/wp-content/uploads/pdf/X-Step_how-to.pdf); [Overthrow · Disc golf footwork made simple](https://www.youtube.com/watch?v=ay54wHy9ge0).
- **Disc flight numbers: what each rating describes** (rating-language) · Disc knowledge · [Discraft · Beginning disc golf](https://www.team.discraft.com/beginning-disc-golf); [Discraft · What flight numbers mean](https://support.discraft.com/support/solutions/articles/44001621475-what-are-these-numbers-on-my-disc-).
- **Choosing a disc you can keep on the intended line** (control-first) · Fieldwork · [Latitude 64° · Beginner guide](https://latitude64.com/pages/disc-golf-beginner-guide).
- **Disc weight: when a lighter copy is worth trying** (lighter-discs) · Disc knowledge · [Prodigy · Throwing lighter discs](https://prodigydisc.com/blogs/tips-tricks/how-to-throw-lightweight-disc-golf-discs).
- **Prodigy model names: drivers, mids and approaches** (prodigy-names) · Disc knowledge · [Prodigy · Understanding the naming system](https://prodigydisc.com/blogs/news/prodigy-disc-naming-system).
- **Approach discs: straight landing versus a stronger finish** (approach-pair) · Approach play · [Prodigy · Choosing an approach disc](https://prodigydisc.com/blogs/news/finding-the-best-disc-golf-approach-disc-a-series-by-prodigy-disc).
- **Disc versions: check the plastic and current flight ratings** (rating-history) · Disc knowledge · [Prodigy · Updated flight ratings](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence).
- **Turn versus fade: the early curve and the late finish** (turn-fade-shape) · Disc knowledge · [Dynamic Discs · Beginner guide](https://www.dynamicdiscs.com/pages/disc-golf-beginners-guide).
- **Plastic and wear: track your actual bag copy** (plastic-wear) · Disc knowledge · [Prodigy · PA-3 and 300 plastic reference](https://prodigydisc.com/products/prodigy-pa3-300-plastic).
- **Recycled plastic: read the blend description, then test the flight** (recycled-blends) · Disc knowledge · [Trash Panda · Recycled blends and stock-flight comparisons](https://trashpandadiscgolf.com/products/6th-birthday-box).
- **An accuracy game for your next field session** (accuracy-game) · Fieldwork · [MVP · Classroom teaching games and practice](https://mvpdiscsports.com/documents/MVP-ClassroomCollabLessonPlan.pdf).
- **Learn a new disc by comparing it with one you know** (flight-reference) · Disc knowledge · [Axiom · Flight-rating system](https://axiomdiscs.com/flight-rating-system/).
- **Approach landing: plan for the fade, skip and next putt** (approach-finish) · Approach play · [Westside Discs · Harp approach reference](https://westsidediscs.com/products/vip-harp).
- **Head movement: let your eyes follow the backhand turn** (head) · Head & posture · [Brian Earhart · Rethinking reachback](https://discgolf.ultiworld.com/2018/05/22/tuesday-tips-dissecting-reach-back-myth-part-1/).
- **Throwing posture: keep the tilt that suits your shot** (posture) · Head & posture · [UDisc · Form vocabulary](https://udisc.com/blog/post/throw-talk-important-vocab-for-learning-disc-golf-form); [Discmania · Beginner fundamentals](https://www.discmania.net/blogs/discover/top-5-disc-golf-beginner-tips).
- **Backhand reachback: make room for a relaxed backswing** (reachback) · Backhand · [Brian Earhart · Rethinking reachback](https://discgolf.ultiworld.com/2018/05/22/tuesday-tips-dissecting-reach-back-myth-part-1/).
- **Why “reach farther back” can be unhelpful advice** (reach-myth) · Backhand · [UDisc · Backhand instruction and drills](https://udisc.com/blog/post/5-great-videos-how-to-throw-backhand-in-disc-golf).
- **Backhand coil: turn your chest without forcing extra twist** (coil) · Backhand · [Overthrow · Building the Brace: a supported base](https://www.overthrowdiscgolf.academy/lessons/building-the-brace); [Loughborough University · Biomechanical analysis of disc-golf throws](https://repository.lboro.ac.uk/articles/conference_contribution/Biomechanical_analysis_of_disc_golf_throws_to_improve_performance/27045130).
- **Arm extension: how the forearm opens into release** (extension) · Arm mechanics · [Overthrow · Extension Out of the Pocket: the forearm opening](https://www.overthrowdiscgolf.academy/lessons/extension-out-of-the-pocket).
- **Power pocket: give the upper arm room to move** (arm) · Arm mechanics · [Google · Pose landmark detection](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker); [Overthrow · Extension Out of the Pocket: the forearm opening](https://www.overthrowdiscgolf.academy/lessons/extension-out-of-the-pocket).
- **Rounding: check whether the disc gets trapped behind you** (rounding) · Arm mechanics · [UDisc · Backhand instruction and drills](https://udisc.com/blog/post/5-great-videos-how-to-throw-backhand-in-disc-golf).
- **Backhand timing: compare the plant and release** (timing) · Timing & footwork · [Innova · How to throw backhands really far](https://www.innovadiscs.com/innova-news/how-to-throw-backhands-really-far/).
- **Plant-foot placement: compare your feet with the target line** (footwork) · Timing & footwork · [Innova · How to throw backhands really far](https://www.innovadiscs.com/innova-news/how-to-throw-backhands-really-far/); [UDisc · Form vocabulary](https://udisc.com/blog/post/throw-talk-important-vocab-for-learning-disc-golf-form).
- **Front-leg brace: support the turn without locking the knee** (brace) · Timing & footwork · [Overthrow · Building the Brace: a supported base](https://www.overthrowdiscgolf.academy/lessons/building-the-brace); [Loughborough University · Biomechanical analysis of disc-golf throws](https://repository.lboro.ac.uk/articles/conference_contribution/Biomechanical_analysis_of_disc_golf_throws_to_improve_performance/27045130).
- **Standstill backhand: simplify the throw while learning** (standstill) · Timing & footwork · [UDisc · Backhand instruction and drills](https://udisc.com/blog/post/5-great-videos-how-to-throw-backhand-in-disc-golf).
- **The non-throwing arm: repeat a comfortable action** (off-arm) · Arm mechanics · [UDisc · Form vocabulary](https://udisc.com/blog/post/throw-talk-important-vocab-for-learning-disc-golf-form).
- **Follow-through: let the throw finish naturally** (finish) · Follow-through · [EDGE · Backhand throw chart](https://edgediscgolf.org/wp-content/uploads/2021/03/Backhand_Throw_Chart.pdf).
- **Backhand grip: find a secure fit for the shot** (grip) · Hand & release · [UDisc · Backhand grip guide](https://udisc.com/blog/post/5-great-videos-disc-golf-grip-backhand); [Overthrow · Front-loaded and back-loaded grip](https://www.overthrowdiscgolf.academy/blog/front-loaded-vs-back-loaded-grip).
- **Hand and wrist review: what a close-up can show** (wrist) · Hand & release · [Google · Separate hand landmark detection](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/web_js).
- **Nose angle: why a high launch and a nose-up disc differ** (nose) · Hand & release · [TechDisc · What release metrics mean](https://techdisc.freshdesk.com/support/solutions/articles/153000074253-techdisc-metrics).
- **Find the release frame: when disc and fingers separate** (release) · Hand & release · [Google · Pose landmark detection](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker).
- **Flat, hyzer and anhyzer: choose the release angle** (angles) · Shot shaping · [Innova · Disc-golf glossary](https://www.innovadiscs.com/home/disc-golf-faq/glossary-of-terms/).
- **Hyzer-flip: start tilted and let the disc stand up** (hyzer-flip) · Shot shaping · [Innova · Disc-golf glossary](https://www.innovadiscs.com/home/disc-golf-faq/glossary-of-terms/); [MVP · Understanding flight ratings](https://mvpdiscsports.com/flight-rating-system/).
- **Anhyzer flex versus a turnover: will the disc come back?** (flex) · Shot shaping · [Innova · Disc-golf glossary](https://www.innovadiscs.com/home/disc-golf-faq/glossary-of-terms/).
- **Forehand fundamentals: setup, release and a comfortable finish** (forehand) · Forehand · [PDGA / Scott Stokely · Three keys to a better sidearm](https://www.pdga.com/news/three-keys-better-sidearm).
- **Forehand wrist action: learn a clean short release** (forehand-wrist) · Forehand · [Innova · Level up your forehand](https://www.innovadiscs.com/tips/how-to-throw-forehands-accurately-far-and-without-injury/).
- **Forehand shot shaping: practice flat, hyzer and anhyzer** (forehand-angles) · Forehand · [Discmania · Five ways to improve your sidearm](https://www.discmania.net/blogs/discover/five-ways-to-improve-your-sidearm); [UDisc · Forehand instruction](https://udisc.com/blog/post/5-great-videos-how-to-forehandsidearm-in-disc-golf).
- **Putting routine: repeat your setup, aim and finish** (putt) · Putting · [Innova · Six putting tips](https://www.innovadiscs.com/tips/6-quick-putting-tips/).
- **Putting balance and the official putting-area rule** (putting-balance) · Putting · [PDGA · Putting area rule](https://www.pdga.com/rules/official-rules-disc-golf/80601).
- **Approach distance control: learn a comfortable stock shot** (approach) · Approach play · [Discmania / Bartosz Kowalewski · Grip and approaches](https://www.discmania.net/blogs/discover/disc-golf-grip-tips-and-approach-shots-with-bartosz-kowalewski).
- **Roller basics: choose the first contact and the surface** (roller) · Specialty throws · [Innova · Fundamentals of throwing rollers](https://www.innovadiscs.com/tips/get-rolling-the-fundamentals-of-throwing-rollers/).
- **Thumber basics: a short, comfortable overhand shot** (overhand) · Specialty throws · [Scott Stokely · Thumber](https://discgolfdiscovery.com/Throws/Thumber/).
- **Before fieldwork: warm up and build effort gradually** (warmup) · Fieldwork · [Disc Golf Strong · Pre-round preparation](https://www.discgolfstrong.com/).
- **A useful practice session: one cue, a small set and a comparison** (practice) · Fieldwork · [Innova · How Field Work Can Make You a Better Disc Golfer](https://www.innovadiscs.com/innova-news/how-field-work-can-make-you-a-better-disc-golfer/); [Discmania · Beginner fundamentals](https://www.discmania.net/blogs/discover/top-5-disc-golf-beginner-tips).
- **Film a throw the app can actually review** (film) · Video review · [Innova · How Field Work Can Make You a Better Disc Golfer](https://www.innovadiscs.com/innova-news/how-field-work-can-make-you-a-better-disc-golfer/); [Google · Pose landmark detection](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker).
- **Disc tracing: inspect and correct the visible trail** (tracking) · Video review · [Google · Pose landmark detection](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker).
- **What video biomechanics can and cannot measure** (research) · Video review · [Loughborough University · Biomechanical analysis of disc-golf throws](https://repository.lboro.ac.uk/articles/conference_contribution/Biomechanical_analysis_of_disc_golf_throws_to_improve_performance/27045130); [ISBS · Temporal sequence in sidearm disc throwing](https://ojs.ub.uni-konstanz.de/cpa/article/view/5613).
- **Flight numbers explained: speed, glide, turn and fade** (discs) · Disc knowledge · [MVP · Understanding flight ratings](https://mvpdiscsports.com/flight-rating-system/).
- **Which disc should I throw? Match carry, shape and landing** (selection) · Disc knowledge · [MVP · Understanding flight ratings](https://mvpdiscsports.com/flight-rating-system/).
- **Disc selection in wind: headwind, tailwind and crosswind** (wind) · Disc knowledge · [Innova · How to throw backhands really far](https://www.innovadiscs.com/innova-news/how-to-throw-backhands-really-far/).
- **Build a useful caddy: log your real throws and misses** (caddy) · Disc knowledge · [MVP · Understanding flight ratings](https://mvpdiscsports.com/flight-rating-system/).
- **Choose a landing area before choosing the disc** (choose-landing) · Shot selection · [Innova · How to throw backhands really far](https://www.innovadiscs.com/innova-news/how-to-throw-backhands-really-far/); [Discmania · Beginner fundamentals](https://www.discmania.net/blogs/discover/top-5-disc-golf-beginner-tips).
- **Backhand or forehand: choose the curve you can repeat** (backhand-or-forehand) · Shot selection · [PDGA / Scott Stokely · Three keys to a better sidearm](https://www.pdga.com/news/three-keys-better-sidearm); [Innova · Disc-golf glossary](https://www.innovadiscs.com/home/disc-golf-faq/glossary-of-terms/).
- **Flat, hyzer or anhyzer: how to choose for this line** (which-release) · Shot selection · [Innova · Disc-golf glossary](https://www.innovadiscs.com/home/disc-golf-faq/glossary-of-terms/); [Innova · Hyzer, anhyzer and handedness](https://www.innovadiscs.com/home/disc-golf-faq/).
- **Find a useful driver speed for your actual throw** (power-match) · Disc knowledge · [Innova · Common throwing errors](https://www.innovadiscs.com/innova-news/common-throwing-errors-holding-back-your-game/); [Axiom · Flight-rating system](https://axiomdiscs.com/flight-rating-system/).
- **Crosswind: which side of the disc is exposed?** (crosswind-angle) · Shot selection · [Innova · Disc selection and release in wind](https://www.innovadiscs.com/tips/tips-for-playing-disc-golf-in-the-wind/).
- **Headwind disc choice: allow for extra turn** (headwind-choice) · Shot selection · [Innova · Disc selection and release in wind](https://www.innovadiscs.com/tips/tips-for-playing-disc-golf-in-the-wind/); [Innova · How to throw backhands really far](https://www.innovadiscs.com/innova-news/how-to-throw-backhands-really-far/).
- **Tailwind: compare a slower or more glide-friendly option** (tailwind-choice) · Shot selection · [Innova · Disc selection and release in wind](https://www.innovadiscs.com/tips/tips-for-playing-disc-golf-in-the-wind/); [MVP · Understanding flight ratings](https://mvpdiscsports.com/flight-rating-system/).
- **Wooded holes: choose the gap before chasing distance** (woods-choice) · Shot selection · [Discmania · Beginner fundamentals](https://www.discmania.net/blogs/discover/top-5-disc-golf-beginner-tips); [Discmania / Bartosz Kowalewski · Grip and approaches](https://www.discmania.net/blogs/discover/disc-golf-grip-tips-and-approach-shots-with-bartosz-kowalewski).
- **A great throw versus a good outcome: log both** (great-vs-lucky) · Fieldwork · [Innova · How to throw backhands really far](https://www.innovadiscs.com/innova-news/how-to-throw-backhands-really-far/).
- **Build a useful bag around flights you know** (bag-gaps) · Disc knowledge · [Discmania · Beginner fundamentals](https://www.discmania.net/blogs/discover/top-5-disc-golf-beginner-tips); [MVP · Understanding flight ratings](https://mvpdiscsports.com/flight-rating-system/).
- **Learn the backhand in stages: standstill, one step, X-step** (one-step-progression) · Footwork · [Overthrow · Disc golf footwork made simple](https://www.youtube.com/watch?v=ay54wHy9ge0); [Danny Lindahl / Dynamic Discs · Why footwork matters](https://blog.dynamicdiscs.com/2017/07/why-is-footwork-so-important.html).
- **Turn a video observation into one useful practice change** (review-then-practice) · Video review · [Discmania · Beginner fundamentals](https://www.discmania.net/blogs/discover/top-5-disc-golf-beginner-tips); [Google · Pose landmark detection](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker).

## Source inventory and previews

### Innova · How Field Work Can Make You a Better Disc Golfer

[Manufacturer practice guide](https://www.innovadiscs.com/innova-news/how-field-work-can-make-you-a-better-disc-golfer/) · Innova · ID: fieldwork

Innova explains purposeful field sessions: choose a task, film your throws, compare older clips and favor controlled repetitions over maximum-effort volume. It also suggests games for gap hitting, distance control and shot shaping. Use the article to plan a small session with an observable result. The app’s specific repetitions and review workflow are original practice adaptations.

### Innova · Hyzer, anhyzer and handedness

[Manufacturer reference](https://www.innovadiscs.com/home/disc-golf-faq/) · Innova · ID: anglesFAQ

A reference for release bank and how the directions mirror between hands and backhand/forehand. Hyzer and anhyzer describe the initial tilt, not a guaranteed final curve. Use the definitions when recording the actual shot in Caddy.

### Innova · Disc selection and release in wind

[Manufacturer instruction](https://www.innovadiscs.com/tips/tips-for-playing-disc-golf-in-the-wind/) · Innova · ID: windPlay

A practical guide to reading local wind, choosing a familiar disc and considering how a banked flight plate meets a crosswind. It also discusses conservative play and landing a manageable next putt. Use it for shot planning rather than a fixed wind-to-distance formula.

### Innova · Illustrated backhand X-step

[Manufacturer instruction · PDF](https://www.innovadiscs.com/wp-content/uploads/pdf/X-Step_how-to.pdf) · Innova · ID: xStepChart

An illustrated backhand footwork sequence, showing the rear foot crossing behind before the final stride and the body continuing after release. It is useful for learning the order of the feet and mirroring a right-handed example for a left hand. Treat the weight drawings as teaching illustrations, not pressure measurements the app can recover.

Written chart reviewed. Its weight-distribution drawings are teaching illustrations, not measurements from your video.

### Danny Lindahl / Dynamic Discs · Why footwork matters

[Coach instruction · article](https://blog.dynamicdiscs.com/2017/07/why-is-footwork-so-important.html) · Dynamic Discs / Danny Lindahl · ID: dannyFootwork

Danny Lindahl explains how a manageable crossover sets up the last stride, then discusses the brace and weight shift. The practical theme is a balanced approach rather than a long backward walk. His specific step dimensions and foot-angle cues describe his teaching approach; use the underlying idea without treating those numbers as universal app grading targets.

Coach-authored article reviewed. Foot dimensions and angles are teaching cues, not app grading targets.

### Overthrow · Disc golf footwork made simple

[YouTube tutorial · written outline reviewed](https://www.youtube.com/watch?v=ay54wHy9ge0) · Overthrow Disc Golf · ID: walkupVideo

An Overthrow footwork tutorial organized into the crossover, last plant and a slow recap. The written UDisc outline helps you choose a useful chapter before opening YouTube. Use it to connect the order of the feet with a repeatable walk-up. The app provides a practice adaptation, not a transcript of the whole video.

Link and time-indexed UDisc outline verified. Direct playback/transcript unavailable in this research session.

### Overthrow · Box drill for arm loading

[YouTube tutorial · written outline reviewed](https://www.youtube.com/watch?v=igNPpexLXlo) · Overthrow Disc Golf · ID: boxVideo

The box drill introduces a backhand swing with a relaxed lower arm and room between the upper arm and chest. The linked written outline identifies the slow drill sequence and common mistakes to inspect. It is useful for learning the transition into arm loading; the demonstration does not establish one required elbow angle for every throw.

Link and written UDisc outline verified; direct video playback was unavailable.

### Overthrow · Simon Lizotte and Drew Gibson comparison

[YouTube analysis · written outline reviewed](https://www.youtube.com/watch?v=Hsl4PbxMX1w) · Overthrow Disc Golf · ID: comparisonVideo

A comparison of Simon Lizotte and Drew Gibson used to illustrate movement through the final stride and swing. Watch for shared ideas rather than trying to duplicate either athlete’s exact positions. A written tutorial outline is linked for context. This is an example-based learning resource, not a validated template for every player’s body.

Link and written UDisc outline verified; the footage is an example, not an ideal template for every body.

### Discraft · Beginning disc golf

[Manufacturer learning guide](https://www.team.discraft.com/beginning-disc-golf) · Discraft · ID: discraftBasics

A manufacturer introduction to starting disc golf, useful alongside the disc-selection lessons. Begin with the intended job of the disc and a throw you can repeat. Use the linked learning guide for the manufacturer’s explanation, then bring your actual distance and flight results back to My bag. It is not a personalized recommendation for your whole bag.

### Discraft · What flight numbers mean

[Manufacturer reference](https://support.discraft.com/support/solutions/articles/44001621475-what-are-these-numbers-on-my-disc-) · Discraft · ID: discraftNumbers

A Discraft reference for the numbers printed on its discs. Use it when a rating label or scale is unfamiliar before comparing it with a four-number flight description. The key is to keep the manufacturer’s reference system separate from your own carry and observed line. Published ratings do not establish how far you will throw.

### Prodigy · Understanding the naming system

[Manufacturer reference](https://prodigydisc.com/blogs/news/prodigy-disc-naming-system) · Prodigy · ID: prodigyNames

A guide to the Prodigy naming system, including the letters and numbers used to organize model families. It is useful when you want to understand a model’s intended place in the lineup before opening its product page. Treat the name as a role guide, then check the actual model, plastic and current ratings for the disc you own.

### Prodigy · Throwing lighter discs

[Manufacturer instruction](https://prodigydisc.com/blogs/tips-tricks/how-to-throw-lightweight-disc-golf-discs) · Prodigy · ID: prodigyLight

A manufacturer discussion of lighter discs and their use. Read it before testing a lighter copy, then compare the results at a familiar effort and in similar wind. Weight is one variable among several; a lighter disc does not guarantee a longer or straighter shot. Keep separate bag entries so the test does not mix two physical copies.

### Prodigy · Choosing an approach disc

[Manufacturer instruction](https://prodigydisc.com/blogs/news/finding-the-best-disc-golf-approach-disc-a-series-by-prodigy-disc) · Prodigy · ID: prodigyApproach

An overview of Prodigy’s approach-disc families and the jobs they are intended to cover. It helps frame a choice between different approach flights before you test them. The useful fieldwork question is where your copy lands and how it finishes. Manufacturer role descriptions are starting information, while your repeated throws establish a personal recommendation.

### Prodigy · Updated flight ratings

[Manufacturer rating update](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) · Prodigy · ID: prodigyUpdates

A manufacturer update used to understand the context of flight-rating changes. It is useful when older stamps, catalog entries or product descriptions disagree. Check which model version and plastic the information describes before editing your bag reference. Your logged throws remain the record of how your own disc flies; a new printed number does not change past results.

### Prodigy · PA-3 and 300 plastic reference

[Manufacturer product reference](https://prodigydisc.com/products/prodigy-pa3-300-plastic) · Prodigy · ID: prodigyPlastic

A PA-3 product and plastic reference. Use it to identify the manufacturer’s description of the particular mold and material rather than treating every plastic version as identical. This is product information, not a complete practice lesson. Keep the actual plastic, weight, condition and throwing observations beside the copy in your bag.

### Latitude 64° · Beginner guide

[Manufacturer learning guide](https://latitude64.com/pages/disc-golf-beginner-guide) · Latitude 64° · ID: latitudeBasics

A beginner learning guide from Latitude 64°. Use it as an introduction to the game and equipment, then keep your early practice focused on a few discs and a controllable line. It provides general starting context rather than a measurement of your power. Personal field distances and landing consistency are still needed for your caddy choices.

### Dynamic Discs · Beginner guide

[Manufacturer learning guide](https://www.dynamicdiscs.com/pages/disc-golf-beginners-guide) · Dynamic Discs · ID: dynamicBasics

A Dynamic Discs beginner guide for learning the game and the role of basic equipment. It is a useful starting resource before exploring more specialized shots or a large bag. Read the manufacturer’s explanations alongside your own throws; a generic recommendation cannot establish your release, carry or how a particular plastic behaves for you.

### MVP · Classroom teaching games and practice

[Manufacturer teaching handbook](https://mvpdiscsports.com/documents/MVP-ClassroomCollabLessonPlan.pdf) · MVP Disc Sports · ID: mvpGames

An MVP classroom teaching handbook with structured disc activities. It is useful for turning practice into a clear task with a target and an observable result. The app’s accuracy-zone exercise is an original adaptation of that teaching approach, not a copied lesson. Keep the challenge small enough to repeat and compare before increasing distance or difficulty.

### Axiom · Flight-rating system

[Manufacturer reference](https://axiomdiscs.com/flight-rating-system/) · Axiom · ID: axiomRatings

Axiom explains its speed, glide, turn and fade system, including how a disc’s speed requirements relate to the flight you get. Use it to understand the reference before comparing a new disc against one you know. Ratings provide a starting description, not a measured path or a personal distance guarantee for a specific bag copy.

### Westside Discs · Harp approach reference

[Manufacturer product reference](https://westsidediscs.com/products/vip-harp) · Westside Discs · ID: westsideApproach

The Westside Harp product reference describes an approach role and intended finish. Use it to understand why a player might carry that kind of disc, then test the actual landing and ground action. A dependable finish does not mean the disc cannot skip or roll. This link is a model reference, not a universal approach tutorial.

### Trash Panda · Recycled blends and stock-flight comparisons

[Manufacturer product reference](https://trashpandadiscgolf.com/products/6th-birthday-box) · Trash Panda · ID: trashBlends

A Trash Panda special-release product page used for its blend and stock-flight context. Open it when you want the manufacturer’s description of that product, rather than a general technique lesson. Material and marketing descriptions do not establish your personal flight. Test your copy and keep its condition and actual throws in the bag profile.

### EDGE · Backhand throw chart

[Instruction](https://edgediscgolf.org/wp-content/uploads/2021/03/Backhand_Throw_Chart.pdf) · EDGE · ID: edge

An EDGE backhand teaching chart that provides a compact visual reference for the throw. Use it to connect preparation, swing and continuation rather than treating any one drawing as a pose to freeze. It is particularly useful alongside a slow rehearsal. The app’s replay still needs your actual source frames to compare the movement.

### Brian Earhart · Rethinking reachback

[Coach instruction](https://discgolf.ultiworld.com/2018/05/22/tuesday-tips-dissecting-reach-back-myth-part-1/) · Ultiworld / Brian Earhart · ID: earhart

Brian Earhart questions the advice to gain distance by reaching farther back with the upper body. Using player examples, he describes moving the body relative to a positioned disc instead of making an exaggerated stretch. Read it for a different way to understand the backswing. It does not require your hand to remain perfectly stationary during every throw.

### Overthrow · Building the Brace: a supported base

[Coach instruction · public transcript](https://www.overthrowdiscgolf.academy/lessons/building-the-brace) · Overthrow Disc Golf · ID: brace

Overthrow’s free Building the Brace lesson has a public written transcript. It begins with a settled stance and explains support before adding walk-up motion. Use the small rehearsal to understand the teaching idea; the app does not turn the lesson’s cues into force measurements or require a rigid knee. The wider course contains additional paid lessons.

### Overthrow · Extension Out of the Pocket: the forearm opening

[Coach instruction · public transcript](https://www.overthrowdiscgolf.academy/lessons/extension-out-of-the-pocket) · Overthrow Disc Golf · ID: extension

Overthrow’s free Extension Out of the Pocket lesson has a public written transcript. It builds a bent-arm setup with room to open the forearm, then uses a familiar whipping action as a learning comparison. Use it to understand the motion rather than holding a perfect still pose. The app’s short-throw exercise is a separate adaptation.

### Overthrow · Front-loaded and back-loaded grip

[Coach instruction](https://www.overthrowdiscgolf.academy/blog/front-loaded-vs-back-loaded-grip) · Overthrow Disc Golf · ID: grip

An Overthrow resource on front-loaded and back-loaded backhand grip concepts. Use it to compare what different grip choices are intended to do, then test a small change at comfortable effort. A grip explanation is not a measurement of your squeeze or fingers in a distant video. Keep the disc and target consistent while comparing results.

### Innova · How to throw backhands really far

[Instruction](https://www.innovadiscs.com/innova-news/how-to-throw-backhands-really-far/) · Innova · ID: distance

Innova’s backhand-distance article connects the intended flight with planting before release, sequencing, nose control, wind and disc choice. Its useful theme is improving a repeatable throw instead of merely adding effort. Read the sections that match your current practice focus. None of the examples turn a single body-pose estimate into a measured launch speed or nose angle.

### PDGA / Scott Stokely · Three keys to a better sidearm

[Coach instruction](https://www.pdga.com/news/three-keys-better-sidearm) · PDGA / Scott Stokely · ID: forehand

Scott Stokely explains three forehand teaching ideas for setup, a throwing action and the approach. It is useful for understanding why a forehand should be taught separately from a backhand. Some cues reflect his coaching system rather than a universal position. Start with a comfortable short version and compare the complete linked explanation before changing your motion.

### Innova · Level up your forehand

[Instruction](https://www.innovadiscs.com/tips/how-to-throw-forehands-accurately-far-and-without-injury/) · Innova · ID: flick

Innova’s forehand instruction resource covers building a useful, repeatable sidearm. Use it with the forehand lessons rather than importing a backhand crossover or pocket requirement. Pay attention to the grip, release and comfortable continuation as a whole. The app does not diagnose discomfort or infer hidden wrist action from a full-body recording.

### Innova · Common throwing errors

[Instruction](https://www.innovadiscs.com/innova-news/common-throwing-errors-holding-back-your-game/) · Innova · ID: mistakes

Innova discusses common issues including off-axis torque, rounding, overpowering the throw, nose-up release and discs that are too fast. It gives useful names for problems to investigate. A missed line or early fade can have several causes, so use the article to plan a focused comparison rather than assuming the app has diagnosed the cause.

### Discmania · Five ways to improve your sidearm

[Instruction](https://www.discmania.net/blogs/discover/five-ways-to-improve-your-sidearm) · Discmania · ID: sidearm

Discmania’s sidearm article covers a secure grip, a cleaner release, hand action and beginning with short approaches before longer shots. It also discusses keeping the setup simple and facing the intended line. Use it as a progression for practice. Flutter or a miss in one throw does not by itself establish which part needs changing.

### Discmania / Bartosz Kowalewski · Grip and approaches

[Coach instruction](https://www.discmania.net/blogs/discover/disc-golf-grip-tips-and-approach-shots-with-bartosz-kowalewski) · Discmania · ID: touch

Bartosz Kowalewski’s approach resource introduces the grips he uses and links a demonstration with flight footage. It is useful for seeing how a controlled approach differs from a maximum-distance drive. The page’s written introduction is brief; the linked video provides the demonstration. The app’s landing-zone practice is original guidance, not a claim to transcribe the video.

### Discmania · Beginner fundamentals

[Instruction](https://www.discmania.net/blogs/discover/top-5-disc-golf-beginner-tips) · Discmania · ID: basics

Discmania’s beginner article covers simple technique, controlled release, a field-practice routine, learning with experienced players and beginning with a small disc selection. It is useful as a starting checklist rather than a reason to add every new cue at once. Choose one manageable practice task and compare repeated throws before moving on.

### UDisc · Form vocabulary

[Instruction guide](https://udisc.com/blog/post/throw-talk-important-vocab-for-learning-disc-golf-form) · UDisc · ID: vocab

A UDisc guide to common language used when discussing throwing form. Open it when a coaching term is unfamiliar, then return to the lesson for a practical use of that idea. Different coaches can describe a similar movement with different words. A named movement does not establish a required numeric position in your own video.

### UDisc · Backhand instruction and drills

[Instruction guide](https://udisc.com/blog/post/5-great-videos-how-to-throw-backhand-in-disc-golf) · UDisc · ID: backhandVideos

UDisc introduces five Overthrow backhand tutorials with written explanations and time-indexed outlines. Topics include arm loading, footwork and learning from player comparisons. It is useful for picking a particular segment before opening YouTube. The app’s summaries distinguish the written outline from footage that has not been independently watched or transcribed here.

### UDisc · Backhand grip guide

[Instruction guide](https://udisc.com/blog/post/5-great-videos-disc-golf-grip-backhand) · UDisc · ID: gripVideos

A UDisc collection of backhand-grip instruction. Use the written context to choose a demonstration that matches the grip question you have, then test one change at a time. There is no single finger arrangement that the full-body pose overlay can certify. Compare secure contact, comfortable release and the flight you actually produce.

### UDisc · Forehand instruction

[Instruction guide](https://udisc.com/blog/post/5-great-videos-how-to-forehandsidearm-in-disc-golf) · UDisc · ID: forehandVideos

A UDisc collection of forehand/sidearm instruction. It is useful for finding a teaching demonstration after you decide whether to work on setup, release or shot control. Keep the practice task small and use the same disc for comparison. The resource is general instruction, not evidence that the app detected a particular forehand fault.

### TechDisc · What release metrics mean

[Sensor documentation](https://techdisc.freshdesk.com/support/solutions/articles/153000074253-techdisc-metrics) · TechDisc · ID: metrics

TechDisc defines measured release variables including speed, spin, nose angle, launch angle, bank and wobble. Its diagrams distinguish nose tilt relative to travel from launch direction relative to the horizon. It is useful for understanding what a measurement means. Sensor and simulator examples are not values that Fairway Form can recover from an ordinary body video.

### Loughborough University · Biomechanical analysis of disc-golf throws

[Research](https://repository.lboro.ac.uk/articles/conference_contribution/Biomechanical_analysis_of_disc_golf_throws_to_improve_performance/27045130) · Loughborough University · ID: study

A university biomechanics research reference about disc-golf throwing performance. Use it for research context and to distinguish laboratory measurements from a camera-plane observation. A research result can inform a question without validating this app’s thresholds. The app does not treat one sample, population or instrumented setup as the ideal movement for every player.

### ISBS · Temporal sequence in sidearm disc throwing

[Research](https://ojs.ub.uni-konstanz.de/cpa/article/view/5613) · ISBS Conference Proceedings · ID: sequence

An ISBS research reference on the temporal sequence of a sidearm disc throw. It is useful when thinking about how different body movements occur in order. Keep the study’s setting and measurement method in mind before applying it. A time difference from one phone view is not automatically equivalent to a laboratory sequence measurement.

### Disc Golf Strong · Pre-round preparation

[Training](https://www.discgolfstrong.com/) · Disc Golf Strong · ID: warmup

Disc Golf Strong provides disc-golf training and preparation resources. Use the current site to choose an appropriate warm-up resource before fieldwork. This is a training hub rather than an individual assessment or rehabilitation plan. The app’s suggestion is to begin gradually with movements and throws you can perform comfortably.

### Innova · Six putting tips

[Instruction](https://www.innovadiscs.com/tips/6-quick-putting-tips/) · Innova · ID: putting

Innova’s putting article covers stance options, a specific aim, continuation, lower-body contribution, acceleration and confidence at shorter distances. It is useful for picking one part of a routine to practice. Start where you can repeat the movement, then record actual makes and misses; the lesson does not predict your putting percentage.

### PDGA · Putting area rule

[Official rule](https://www.pdga.com/rules/official-rules-disc-golf/80601) · PDGA · ID: rules

The official PDGA putting-area rule is the reference for competition stance and balance questions. Open the current rule rather than relying on a remembered summary. This link answers a rules question, not whether a throwing style is effective. The app does not locate supporting points and the lie precisely enough to make an officiating decision.

### Innova · Fundamentals of throwing rollers

[Instruction](https://www.innovadiscs.com/tips/get-rolling-the-fundamentals-of-throwing-rollers/) · Innova · ID: roller

Innova’s roller instruction resource introduces how to think about the disc meeting the ground and continuing along it. Use it when learning a roller as a separate shot, with enough clear space to inspect first contact. The app’s visible trail and body review do not model the ground or predict the distance of the roll.

### Scott Stokely · Thumber

[Coach instruction](https://discgolfdiscovery.com/Throws/Thumber/) · Disc Golf Discovery / Scott Stokely · ID: overhand

Scott Stokely’s thumber resource is a demonstration reference for an overhand shot and its grip. Use it separately from the backhand lessons and begin with a short, comfortable attempt. The app has limited interpretation for this shot. It does not apply a backhand pocket or brace target to judge an overhand release.

### Innova · Disc-golf glossary

[Reference](https://www.innovadiscs.com/home/disc-golf-faq/glossary-of-terms/) · Innova · ID: glossary

Innova’s glossary explains disc-golf terms including hand/style abbreviations, hyzer, anhyzer, flex and hyzer-flip. Use the definitions to name the shot you intend and the flight you observed. The app uses those flight concepts, not historical rules text elsewhere on the page. Modern rules questions should go to the official current PDGA source.

### MVP · Understanding flight ratings

[Manufacturer reference](https://mvpdiscsports.com/flight-rating-system/) · MVP Disc Sports · ID: flight

MVP explains speed, glide, turn and fade as descriptions of a disc’s reference flight. Use the guide to understand the four separate parts before comparing discs. Ratings can suggest a role or shape, but do not establish your own carry or a guaranteed path. Keep real results for each physical bag copy alongside those starting descriptions.

### Google · Pose landmark detection

[Model documentation](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker) · Google AI Edge · ID: google

Google documents the pose-landmarker model, its body landmark outputs and how an application uses them. It explains the foundation of the skeleton overlay rather than how to throw a disc. Visible landmark coordinates are estimates and do not automatically measure joint forces, a disc release angle or good technique. Use this reference for model behavior, alongside the coaching lessons for practice.

### Google · Separate hand landmark detection

[Model documentation](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/web_js) · Google AI Edge · ID: hand

Google documents a separate hand-landmarker model for detecting visible hand points in web applications. It explains the technology behind the optional close-up overlay, not a disc-golf grip prescription. A confident model output still cannot recover hidden fingers or establish grip pressure. Good lighting and a large visible hand help the app make a useful comparison.

