# Knowledge and disc-data sources — 1.1.5

The app contains 62 original lessons linked to 46 resources from 23 named publisher/coach/research groups. These are curated explanations and references, not a newly trained disc-golf model or a licensed archive of full instructional content. Only public text, freely available previews, abstracts or indexed excerpts were consulted; no locked lessons were accessed or bundled.

## Teaching and technical resources

- **EDGE** — [EDGE · Backhand throw chart](https://edgediscgolf.org/wp-content/uploads/2021/03/Backhand_Throw_Chart.pdf) (Instruction; source ID: edge).
- **Ultiworld / Brian Earhart** — [Brian Earhart · Rethinking reachback](https://discgolf.ultiworld.com/2018/05/22/tuesday-tips-dissecting-reach-back-myth-part-1/) (Coach instruction; source ID: earhart).
- **Overthrow Disc Golf** — [Overthrow · Building the brace (free lesson)](https://www.overthrowdiscgolf.academy/lessons/building-the-brace) (Coach instruction; source ID: brace).
- **Overthrow Disc Golf** — [Overthrow · Extension out of the pocket (free lesson)](https://www.overthrowdiscgolf.academy/lessons/extension-out-of-the-pocket) (Coach instruction; source ID: extension).
- **Overthrow Disc Golf** — [Overthrow · Front-loaded and back-loaded grip](https://www.overthrowdiscgolf.academy/blog/front-loaded-vs-back-loaded-grip) (Coach instruction; source ID: grip).
- **Innova** — [Innova · How to throw backhands really far](https://www.innovadiscs.com/innova-news/how-to-throw-backhands-really-far/) (Instruction; source ID: distance).
- **PDGA / Scott Stokely** — [PDGA / Scott Stokely · Three keys to a better sidearm](https://www.pdga.com/news/three-keys-better-sidearm) (Coach instruction; source ID: forehand).
- **Innova** — [Innova · Level up your forehand](https://www.innovadiscs.com/tips/how-to-throw-forehands-accurately-far-and-without-injury/) (Instruction; source ID: flick).
- **Innova** — [Innova · Common throwing errors](https://www.innovadiscs.com/innova-news/common-throwing-errors-holding-back-your-game/) (Instruction; source ID: mistakes).
- **Discmania** — [Discmania · Five ways to improve your sidearm](https://www.discmania.net/blogs/discover/five-ways-to-improve-your-sidearm) (Instruction; source ID: sidearm).
- **Discmania** — [Discmania / Bartosz Kowalewski · Grip and approaches](https://www.discmania.net/blogs/discover/disc-golf-grip-tips-and-approach-shots-with-bartosz-kowalewski) (Coach instruction; source ID: touch).
- **Discmania** — [Discmania · Beginner fundamentals](https://www.discmania.net/blogs/discover/top-5-disc-golf-beginner-tips) (Instruction; source ID: basics).
- **UDisc** — [UDisc · Form vocabulary](https://udisc.com/blog/post/throw-talk-important-vocab-for-learning-disc-golf-form) (Instruction guide; source ID: vocab).
- **UDisc** — [UDisc · Backhand instruction and drills](https://udisc.com/blog/post/5-great-videos-how-to-throw-backhand-in-disc-golf) (Instruction guide; source ID: backhandVideos).
- **UDisc** — [UDisc · Backhand grip guide](https://udisc.com/blog/post/5-great-videos-disc-golf-grip-backhand) (Instruction guide; source ID: gripVideos).
- **UDisc** — [UDisc · Forehand instruction](https://udisc.com/blog/post/5-great-videos-how-to-forehandsidearm-in-disc-golf) (Instruction guide; source ID: forehandVideos).
- **TechDisc** — [TechDisc · What release metrics mean](https://techdisc.freshdesk.com/support/solutions/articles/153000074253-techdisc-metrics) (Sensor documentation; source ID: metrics).
- **Loughborough University** — [Loughborough University · Biomechanical analysis of disc-golf throws](https://repository.lboro.ac.uk/articles/conference_contribution/Biomechanical_analysis_of_disc_golf_throws_to_improve_performance/27045130) (Research; source ID: study).
- **ISBS Conference Proceedings** — [ISBS · Temporal sequence in sidearm disc throwing](https://ojs.ub.uni-konstanz.de/cpa/article/view/5613) (Research; source ID: sequence).
- **Disc Golf Strong** — [Disc Golf Strong · Pre-round preparation](https://www.discgolfstrong.com/) (Training; source ID: warmup).
- **Innova** — [Innova · Six putting tips](https://www.innovadiscs.com/tips/6-quick-putting-tips/) (Instruction; source ID: putting).
- **PDGA** — [PDGA · Putting area rule](https://www.pdga.com/rules/official-rules-disc-golf/80601) (Official rule; source ID: rules).
- **Innova** — [Innova · Fundamentals of throwing rollers](https://www.innovadiscs.com/tips/get-rolling-the-fundamentals-of-throwing-rollers/) (Instruction; source ID: roller).
- **Disc Golf Discovery / Scott Stokely** — [Scott Stokely · Thumber](https://discgolfdiscovery.com/Throws/Thumber/) (Coach instruction; source ID: overhand).
- **Innova** — [Innova · Disc-golf glossary](https://www.innovadiscs.com/home/disc-golf-faq/glossary-of-terms/) (Reference; source ID: glossary).
- **MVP Disc Sports** — [MVP · Understanding flight ratings](https://mvpdiscsports.com/flight-rating-system/) (Manufacturer reference; source ID: flight).
- **Google AI Edge** — [Google · Pose landmark detection](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker) (Model documentation; source ID: google).
- **Google AI Edge** — [Google · Separate hand landmark detection](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/web_js) (Model documentation; source ID: hand).

## Manufacturer additions in 1.1.3

- **Discraft** — [Discraft · Beginning disc golf](https://www.team.discraft.com/beginning-disc-golf) (Manufacturer learning guide; source ID: discraftBasics).
- **Discraft** — [Discraft · What flight numbers mean](https://support.discraft.com/support/solutions/articles/44001621475-what-are-these-numbers-on-my-disc-) (Manufacturer reference; source ID: discraftNumbers).
- **Prodigy** — [Prodigy · Understanding the naming system](https://prodigydisc.com/blogs/news/prodigy-disc-naming-system) (Manufacturer reference; source ID: prodigyNames).
- **Prodigy** — [Prodigy · Throwing lighter discs](https://prodigydisc.com/blogs/tips-tricks/how-to-throw-lightweight-disc-golf-discs) (Manufacturer instruction; source ID: prodigyLight).
- **Prodigy** — [Prodigy · Choosing an approach disc](https://prodigydisc.com/blogs/news/finding-the-best-disc-golf-approach-disc-a-series-by-prodigy-disc) (Manufacturer instruction; source ID: prodigyApproach).
- **Prodigy** — [Prodigy · Updated flight ratings](https://prodigydisc.com/blogs/news/prodigy-disc-at-10-a-decade-of-innovation-and-excellence) (Manufacturer rating update; source ID: prodigyUpdates).
- **Prodigy** — [Prodigy · PA-3 and 300 plastic reference](https://prodigydisc.com/products/prodigy-pa3-300-plastic) (Manufacturer product reference; source ID: prodigyPlastic).
- **Latitude 64°** — [Latitude 64° · Beginner guide](https://latitude64.com/pages/disc-golf-beginner-guide) (Manufacturer learning guide; source ID: latitudeBasics).
- **Dynamic Discs** — [Dynamic Discs · Beginner guide](https://www.dynamicdiscs.com/pages/disc-golf-beginners-guide) (Manufacturer learning guide; source ID: dynamicBasics).
- **MVP Disc Sports** — [MVP · Classroom teaching games and practice](https://mvpdiscsports.com/documents/MVP-ClassroomCollabLessonPlan.pdf) (Manufacturer teaching handbook; source ID: mvpGames).
- **Axiom** — [Axiom · Flight-rating system](https://axiomdiscs.com/flight-rating-system/) (Manufacturer reference; source ID: axiomRatings).
- **Westside Discs** — [Westside Discs · Harp approach reference](https://westsidediscs.com/products/vip-harp) (Manufacturer product reference; source ID: westsideApproach).
- **Trash Panda** — [Trash Panda · Recycled blends and stock-flight comparisons](https://trashpandadiscgolf.com/products/6th-birthday-box) (Manufacturer product reference; source ID: trashBlends).

## How sources are used

Lessons explain an idea, a visible check and a short practice exercise in original wording. Per-finding source-topic IDs resolve back to these links. Different instructors may emphasize different cues, particularly around reachback, hip movement and the brace. The app does not convert one instructor’s cue into a universal numerical norm. Study abstracts establish context, not validation of app rules.

The pose and hand models are general-purpose Google MediaPipe models. No new disc-golf-specific model training has occurred. Application confidence gates, movement thresholds and phase suggestions are heuristics that need testing on representative footage. Missing evidence remains unknown. A language model has not been added; the walkthrough is assembled locally from the report.

## Disc catalog

The expanded offline catalog contains 301 entries across all ten requested brands. Each record has a manufacturer reference URL and snapshot date. DISC-CATALOG-SOURCES.md contains the complete rating/source table, version notes and photo provenance workflow. The original fifty IDs remain available for existing bags. Selected source examples:

- [Innova comparison table](https://www.innovadiscs.com/disc-golf-discs/disc-comparison/)
- [MVP Watt](https://mvpdiscsports.com/discs/watt/) — current representative rating uses -0.5 turn and 0.5 fade; ratings are not assumed from memory.
- [Axiom Hex](https://axiomdiscs.com/discs/hex/)
- [Discraft Zone](https://www.team.discraft.com/discs/zone)
- [Latitude 64 River](https://latitude64.com/collections/river)
- [Dynamic Discs EMAC Truth](https://www.dynamicdiscs.com/collections/emac-truth)
- [Discmania FD](https://www.discmania.net/collections/fd) — representative S-/C-Line numbers; Q-Line versions can differ.

Ratings are factual reference values, not precise flight predictions or standardized cross-brand measurements. App browsing categories are normalized for navigation and can differ from a manufacturer’s category. Plastics, runs, weights, wear, release and conditions matter. User-imported records are labeled user supplied and do not inherit manufacturer verification.

The source build includes MediaPipe licensing notices and Apache 2.0 text. No manufacturer product photographs, course videos, full articles or paid coaching corpus is bundled.


## Research refresh, 21 October 2026

See COACHING-RESEARCH-1.1.5.md for exactly which text and public transcripts were read. The three newly linked YouTube videos were identified through the co-curated UDisc written guide; playback was throttled. Their source records disclose that limitation and link the outline. No complete video library or locked course was acquired. Practice exercises are original adaptations, and the model has not been retrained.

New reference records:

- Innova: https://www.innovadiscs.com/wp-content/uploads/pdf/X-Step_how-to.pdf (illustrated instruction).
- Danny Lindahl / Dynamic Discs: https://blog.dynamicdiscs.com/2017/07/why-is-footwork-so-important.html (coach-authored article).
- Overthrow footwork: https://www.youtube.com/watch?v=ay54wHy9ge0 (written-outline review; chapters 2:05, 5:42, 9:01).
- Overthrow box drill: https://www.youtube.com/watch?v=igNPpexLXlo (written-outline review; slow sequence 0:30).
- Overthrow professional comparison: https://www.youtube.com/watch?v=Hsl4PbxMX1w (written-outline review; final stride 4:39).

New lesson IDs: x-step-sequence, x-step-compact, approach-tempo, backswing-room, plant-order, extension-practice, brace-practice, shot-plane-practice, finish-space, forehand-setup, practice-comparison, x-step-review.
