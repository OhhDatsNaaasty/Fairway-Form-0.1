# Keep Fairway Form editable and updateable

## Where to make changes

Current source version: 1.4.0 (Android default versionCode 16). Includes camera and gallery access explanations with Continue and Not now actions.

| File | What it controls |
| --- | --- |
| `dist/index.html` | Screens, text and camera/player controls |
| `dist/style.css` | Forest-green visual design and phone layouts |
| `dist/app.js` | Recording, video sampling, overlays, journal and export |
| `dist/lib/knowledge.js` | The editable technique/practice knowledge collection and source links |
| `dist/lib/analysis.js` | Confidence-gated geometry, evidence rules and coaching cues |
| `dist/lib/tracker.js` | Assisted color tracking; does not contain a learned disc detector |
| `dist/lib/pose.js` | Pose engine version and official model location |
| `dist/lib/storage.js` | Local session database |
| `dist/sw.js` | Web caching and app-version updates |
| `android/app/src/main/java/com/fairwayform/app/MainActivity.java` | Android camera/gallery/file integration |

Every future change can be made to this source and distributed as a new web version or APK. The source is independent of this conversation.

## A useful knowledge-entry structure

Each entry in KNOWLEDGE has an id, category, title, summary, longer explanation, practice drill and optional source title/URL. Add new entries to the array. Keep source provenance and distinguish a practice suggestion from a result measured from video. Library prose does not create a new detection capability. Add observation rules to `analysis.js` only when the observable quantity and camera constraints are clear.

A future comprehensive coach would need expert-reviewed criteria, labeled footage across throws and camera angles, disc/hand detection, accuracy evaluation and confidence calibration. Joint forces, spin and accurate 3D flight generally need additional information or sensors. The present code does not implement those capabilities.

## Web updates

Edit source, run tests, increment the shell VERSION in `dist/sw.js` and deploy `dist/` to the SAME HTTPS origin. Keep the manifest id and scope stable. In the app choose App & settings → Check app update. The worker waits to activate while the app is in use. Version changes apply the complete cached shell together. Storage remains tied to the browser and origin.

## Android updates

For the phone-only GitHub build, follow `phone-build/PHONE-INSTALL.md`: replace the source ZIP in the same private repository and keep the encrypted key and password secret. The workflow sets a monotonically increasing versionCode through the Gradle fairwayVersionCode property. Use the same workflow path so run numbers keep increasing.

Increment `versionCode` and `versionName` in `android/app/build.gradle`, rebundle assets and rebuild. Keep applicationId `com.fairwayform.app` and use the SAME signing key as the installed APK. A debug key generated on a different computer or a fresh CI runner normally cannot update the old install. Do not rely on repeated CI debug builds for updates that must preserve sessions.

For ongoing use, generate your own release keystore once, back it up securely and do not commit it. For example, using your JDK's keytool:

```sh
keytool -genkeypair -v -keystore fairway-release.jks -alias fairway -keyalg RSA -keysize 3072 -validity 10000
```

Set environment variables ANDROID_KEYSTORE (absolute path), ANDROID_STORE_PASSWORD, ANDROID_KEY_ALIAS and ANDROID_KEY_PASSWORD in your shell or CI secrets, without committing their values. Then run:

```sh
npm run assets
npm test
bash scripts/build-android.sh assembleRelease
```

Install the signed APK from `android/app/build/outputs/apk/release/`. For Play Store publication, use a signed Android App Bundle and follow the current store submission process; publication is not included in this source delivery.

## Before trusting an update

Use representative videos from both hands and multiple throw types. Check overlay alignment at pauses and during playback, release marking, poor lighting, occluded joints and no-person footage. Verify that a missing or ambiguous disc stops a trace and that an incorrect similar-color match can be cleared. Test a 20-second upload, rejection of longer clips, denied camera permission, native-camera fallback, recording interruption, saving/reopening, exports, offline start and updating the APK while preserving sessions.

## Version 1.1.0 update

See RELEASE-1.1.0.md for the phone update steps. The existing working ZIP-upload workflow can stay in place. The new source's build script runs its browser smoke check on CI before compilation, and bundles Lite, Full, Heavy and hand models. Keep the same repository, workflow path, encrypted signing key and password. Default local versionCode is 4; the existing CI run-number property overrides it for distributed updates.

The IndexedDB upgrade preserves sessions and adds bag/catalog stores. Core measurements now live in geometry.js, phases.js and analysis.js. Hand model loading and source-image cropping live in pose.js. report-ui.js builds review cards and the local walkthrough. knowledge.js contains 38 lessons and source records. discs.js contains 50 initial catalog facts and import validation; discs-ui.js handles the bag interface. scripts/browser-smoke.mjs adds real-browser and model initialization checks to CI. It is not an app demo and its fixture data is never bundled into the normal interface.


## Version 1.1.1 update

Replace the root Fairway-Form-Source.zip in the same repository and commit it. Keep the existing workflow and signing identity. Default local versionCode is 5; CI continues to override it using the workflow run number. See RELEASE-1.1.1.md for the phone checklist.

Theme choices and the early launch preference live in dist/theme-init.js; setup and native/browser appearance updates are in dist/lib/themes.js, and semantic palette colors are in dist/themes.css. Android handles automatic appearance through isSystemDark/setTheme and uiMode configuration changes. The shell cache is bumped for browser installs; APK installs load their bundled assets directly.

Frame loading and seeking now live in dist/lib/video-player.js. Never replace its readiness checks with a bare seeked listener or allow a timed-out seek to run inference on stale pixels. Partial review state is stored in sampleInfo and passed into quality metadata so saved and spoken reviews retain the warning. The GitHub browser check now also exercises saved themes, phone light/dark appearance, missing-seeked recovery on actual video, deliberate analysis interruption and retry.


## Version 1.1.2 update

Use the same ZIP replacement and signed APK update flow. Local versionCode is 6; CI continues to use its increasing run number. See RELEASE-1.1.2.md for the phone checklist.

Appearance is stored atomically as {palette, mode} in localStorage fairway-appearance, with migration from fairway-theme. Dark mode changes background/readability tokens and retains the chosen palette accents. theme-init.js handles early launch and themes.js the controls/native bridge. Native setTheme accepts the three palettes and their -dark variants.

coaching-language.js translates supported findings into plain-language observations, cues and drills. It never upgrades unknown/observed evidence into a fault or invents praise. analysis.js still owns measurements and prompt generation. report-ui.js keeps that evidence available under optional details and presents one practice focus first.

voice.js handles voice settings, preview, browser selection, chunking and cancellation. Android MainActivity lists actual English voices and filters missing/offline-only voices before choosing by quality. Native and browser speech both require the optional internet-voice setting before using a voice that needs a network. The spoken text may go to the speech provider when enabled; the app does not upload video. Add higher-quality voices through the phone’s speech engine settings, then refresh the list. No third-party speech account or new signing setup is required.


## Version 1.1.3 update

Use the same repository, root ZIP filename, signing secret and encrypted signing key. No change to the existing phone workflow is required. Local versionCode is 7; CI keeps using the increasing workflow run number. See RELEASE-1.1.3.md for the phone checklist.

The factual catalog lives in dist/lib/disc-data.js, with validation and stable ID rules in discs.js. Preserve existing IDs when correcting a rating or source, since bags refer to them. New manufacturer facts are dated and linked; DISC-CATALOG-SOURCES.md records the complete snapshot. Import data stays labeled user supplied.

npm run assets now also runs scripts/fetch-disc-photos.mjs. It looks for matching product images in manufacturer data/captions, validates formats, follows only the configured public manufacturer/CDN hosts and writes local files plus dist/disc-photos/index.json. Photo work has a six-minute network budget and continues with explicit gaps when downloads fail. The build log and artifacts/disc-photo-coverage.json report coverage. The source ZIP excludes generated photos and neural assets; the hosted build downloads them.

scripts/lib/disc-photos.mjs owns photo identity matching. dist/lib/disc-photos.js accepts only safe local photos for known IDs. discs-ui.js handles pagination, filtering, credits, missing-image recovery and bag photos. JPEG and WebP MIME handling was added to the Android asset wrapper. The browser shell caches photo files as they are viewed; APK assets already contain the downloaded photos.

knowledge.js adds original, source-informed manufacturer lessons. knowledge-ui.js filters by publisher as well as topic/level. Rebuild and sign with the same identity to deliver future changes.


## Version 1.1.4 update

Replace the root Fairway-Form-Source.zip in the same repository. Keep the working workflow, APP_SIGNING_PASSWORD and .fairway-signing.enc. CI continues to supply its increasing versionCode.

The analysis pass orchestration now lives in dist/lib/video-analysis.js. It keeps bodyComplete independent of detailIncomplete/detailCancelled, and revisits existing sampled times for hand inference. Do not restore unconditional arbitrary 60 Hz release seeks or label a failed optional hand pass as incomplete body coverage. Hand matching re-detects pose on the same source pixels. tests/video-analysis.test.mjs covers the 3.76 s / 3.58 s regression, 60/30 fps deduplication, partial body evidence, optional failures and cancellation. dist/lib/video-frames.js subscribes to compositor metadata before seeking, rejects unrelated timestamps, and cleans up on failure. Readiness tolerates bounded rounding only after seek progress/acknowledgement; the initial same-frame fast path remains strict.

The source ZIP is a build input, not an APK. See RELEASE-1.1.4.md for phone verification.


## Version 1.1.5 update

Replace the root Fairway-Form-Source.zip in the same repository and keep the signing identity. practice-library.js defines exercises with eligible findings, shot types, stances, steps, an outcome check and source lesson IDs. coaching-language.js selects only available findings, labels general learning separately and constructs video anchors from report phase timestamps. report-ui.js handles focus/drill selection, playback buttons, source exports and the collapsed unavailable-check group. Missing evidence must not become a personal fault or selectable measured finding.

knowledge.js includes checked source-access notes and external tutorial chapter times; knowledge-ui.js displays them. A library addition does not train the model or add a video detector. Preserve that distinction in future coaching changes. The source remains independently editable. See COACHING-RESEARCH-1.1.5.md for the audit and remaining X-step event-analysis work.


## Version 1.2.0 update

Caddy inputs, ranking, range/hand logic and immutable throw transitions live in dist/lib/caddy.js. The interface and serialized local saves are in caddy-ui.js. Sign text parsing, native bridge coordination and route geometry are in caddy-sign.js. caddy-weather.js contains the documented public testing endpoint, response validation and wind-heading conversion. caddy-content.js holds the source links and short explanations. Personal calibration fields are in discs-ui.js and included in bag backup/restore. Database version 3 adds caddyHoles while preserving previous stores.

Android uses ML Kit text recognition 16.0.1 and AndroidX Core FileProvider 1.13.1, with AndroidX enabled. MainActivity handles image capture/picking, origin-scoped geolocation permission and the bounded OCR bridge. res/xml/file_paths.xml exposes only the sign cache subdirectory to camera capture. Keep the Android package, origin and signing key stable.

Recommendations must stay bag-only; missing distance cannot be inferred from flight ratings, driving range cannot become putting range, and a next lie cannot reuse a stale line or heading. Sign text/distance/route suggestions need confirmation. Do not embed a private commercial weather API key in client source. See CADDY-RESEARCH.md before distributing commercially and RELEASE-1.2.0.md for phone checks.


## Version 1.2.1 update

Replace the root source ZIP as usual, keeping the existing workflow and signing identity. IndexedDB upgrades from v3 to v4 by adding a player store; sessions, bag, catalog and caddy holes remain. Earlier caddy hand/putting/speed limits seed an unsaved profile if no saved player profile exists. Saving the new profile becomes the source for future caddy-hole defaults. Editing a lie does not rewrite the player profile.

App & settings now contains Player profile. It is local, optional, editable, resettable and separately backed up/restored as JSON. Age/gender/height never determine power or an ideal pose. Skill selection changes practice structure and adds a small disclosed slower-disc preference to a beginner’s balanced caddy plan. Bag-copy distances remain the reach reference for individual discs.

Saved-session measured carry and a normal/level/calm checkbox support a median after at least three matching-hand/throw records. Repeated form prompts need at least three sufficiently clear, complete, fixed-camera, side-on reviews with the same stance and a manually marked release; brace/timing also need a marked plant. Uses the latest 12 matching saved sessions within 90 days, with the latest eligible stance for form comparisons. These cues do not alter power estimates or disc-distance scores. Turning learning off excludes both measured-session references and repeated-form cues, while explicit profile and bag facts remain usable.

See RELEASE-1.2.1.md for acceptance checks. No new Android permission, third-party dependency, API key or workflow change is required.


## Version 1.2.2 build fix

The caddy browser check must await caddy.dataset.state === ready, rather than treating the preloaded Throw 1 label as a loaded hole. Caddy now marks loading/ready/error explicitly, reports loading outside an inert workspace, and enables inputs only after its bag/profile/hole data is ready. Background autosaves skip unpopulated controls. Initial reads are shared across concurrent opens and a storage error can be retried by reopening Caddy.

The personal-limit assertion remains enabled. A real incorrect limit still fails the build, with the actual field values included in its error. Node VM integration tests load the real caddy UI, profile, and planning modules against delayed storage and a minimal DOM test harness; these run without a local browser server. Full Chromium/model smoke testing still runs in GitHub Actions before compilation. No workflow, signing, dependency or permission change is required.


## Version 1.2.3 Android dependency fix

The reported 1.2.2 run completed its browser/model checks, then failed Android checkReleaseDuplicateClasses. It mixed kotlin-stdlib 1.8.22 with kotlin-stdlib-jdk7/jdk8 1.6.21 from transitive Android-library dependencies. Kotlin 1.8 moved the older JDK-extension classes into the main standard library, so these versions overlap.

The app now imports org.jetbrains.kotlin:kotlin-bom:1.8.22 as an implementation platform. Its constraints bring the older JDK artifacts to the compatible release line. Duplicate-class checking remains enabled; no class exclusions, packaging workarounds, signing changes or workflow changes are used. Keep the BOM when changing native dependencies, and review Gradle dependencyInsight for releaseRuntimeClasspath if updating the Kotlin runtime later.

Official reference: https://kotlinlang.org/docs/whatsnew18.html


## Version 1.3.0 caddy flight/history update

Use the same root ZIP replacement and existing signing workflow. The native Kotlin BOM remains pinned at 1.8.22. Database version remains 4; throw-distance fields extend existing canonical caddy hole entries.

New source modules: disc-flight-data.js for researched references, disc-flight.js for role/estimate/analogue rules, disc-flight-ui.js for the labeled views, and disc-history.js for measured statistics, context matching and backup validation. Each is included in the service-worker offline shell.

Do not confuse the hole's basket distance, a chosen landing point, an estimated first-stage comparison, actual measured carry and actual remaining basket distance. Do not promote a record maximum or an estimated throw into a measured routine range. The initial 1.3.0 putter tee cutoff is superseded by the capability-based policy in 1.3.1. Estimated range coefficients are application assumptions; see CADDY-FLIGHT-RESEARCH-1.3.0.md. No trajectory guarantee is made.

Bag backups now include sanitized history. Restore accepts older backups and validates historical records before an atomic transaction. Current matching throw entries win over older copies. Additional imported entries archive an affected hole to avoid a stale next-lie assumption. Pending draft saves must finish before editable bag history opens; Caddy reentry must reload corrected entries.


## Version 1.3.1 putter driving and alternatives

Replace the root Fairway-Form-Source.zip in the same repository and commit it. Keep the existing workflow, encrypted key and APP_SIGNING_PASSWORD. Local versionCode is 15; CI still supplies its increasing code.

There is no fixed putter tee-distance cutoff. Measured comparable averages and entered disc-specific carry override generic role estimates. Long open holes favor driving roles when they offer greater carry; a demonstrated longer putter is not penalized merely for its role. If putter copies fill the three-choice shortlist, a competitive, reachable midrange/driver alternative can replace the third choice. It must stay within any selected comfortable speed limit and within 10 ranking points of the leader. These margins are app planning choices, not flight physics. See CADDY-FLIGHT-RESEARCH-1.3.1.md. Existing bag/history data and IndexedDB version 4 are preserved.


## Version 1.4.0 release-angle and disc-profile learning

Use the same root Fairway-Form-Source.zip replacement and signing workflow. Native dependencies and IndexedDB version 4 are unchanged. Actual-shot metadata extends existing canonical caddy hole entries; there is no duplicate learned-profile store. Local versionCode is 16; CI supplies its increasing code.

New modules shot-shape.js and disc-profile.js are in the offline shell. The caddy compares release options per physical bag copy and, when explicitly selected, both backhand and forehand. The shortlist still contains distinct bag copies. Actual hand/style/angle and structured quality/execution/flight feedback are stored separately from the chosen recommendation. Older logs retain an unknown actual angle; a planned angle never confirms an actual release.

Carry and reported-flight learning filter by actual hand, style, release and comparable conditions. Three matching reports can establish a conditional flight tendency; three comparable clear measured throws establish carry. A maximum, an estimated distance, or pulled/early/slipped/obstructed flight cannot establish normal carry. Unknown-angle historical measurements can remain a clearly labeled general reference. Initial hand/angle bag references are optional and remain editable.

Bag → Your disc profile shows initial references, actual shot groups, result/quality/execution/flight counts, weather groups and measured average/farthest. The existing history editor now corrects actual shot and feedback as well as distance. Edits rebuild the profile from the canonical record and Caddy reentry reloads it. Bag/history backup preserves actual and planned shot metadata with strict validation; old backups remain supported. See SHOT-PROFILE-RESEARCH-1.4.0.md for source support, thresholds and limits.
