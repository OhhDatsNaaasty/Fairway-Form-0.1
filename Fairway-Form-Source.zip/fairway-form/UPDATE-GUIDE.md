# Keep Final Form - Disc Golf editable and updateable

## Recorded-reference detector fixes (1.30.0)

Replace the same repository-root Fairway-Form-Source.zip and commit using your existing workflow/signing setup. After Actions passes, install the APK over the current app without uninstalling. Fallback versionCode is 53; CI supplies its increasing code.

Reanalyze the same original backhand clip. Existing source-frame markers remain authoritative; clear only the ones you want automatically estimated again. Check final plant, preparation and the initial forward swing, then save. This release changes event rules and keeps all 1.29 scrub/coaching improvements. The heavily retimed reference and X-step in the cropped/oblique examples remain unresolved. Research CPU testing is distinct from the required GitHub/browser and physical-phone checks.

## Uploaded backhand references (1.29.1)

Use the same ZIP replacement and signing workflow. After Actions succeeds, install over the existing app. Fallback versionCode is 52; CI supplies its increasing code. In Technique library, search “backhand reference”, “screen recordings” or browse Video review to find the two new lessons and public source links. This update adds reference notes; the 1.29.0 detector and scrub fixes are retained unchanged.

## Backhand review and scrub repair (1.29.0)

Replace repository-root Fairway-Form-Source.zip using the same filename and commit. Keep your working workflow and signing credentials. Install the successful APK over your existing app without uninstalling. Fallback versionCode is 51; CI supplies its increasing code.

Reanalyze the same original side-on backhand clip to refresh automatic suggestions. The mode beneath the player tells you whether Original video or Prepared source images is active. On Android, Repair scrubbing prepares just this clip while keeping the analysis, markers and notes; it does not change your preference for future clips. Watch each suggested source interval and check the practical coaching plan. Exact release remains an estimate until confirmed; the changes have synthetic regression coverage and still need physical-phone validation.

## Hole-sign drag build fix (1.28.1)

Replace repository-root Fairway-Form-Source.zip with the new 1.28.1 ZIP, using the same filename, and commit. Keep your current working workflow and signing credentials. After Actions succeeds, install the extracted APK over the existing app without uninstalling. Fallback Android versionCode is 50; CI supplies its increasing code.

Marker dragging now updates SVG nodes in place. The GitHub check explicitly finishes scrolling, verifies the pointer hits the intended marker, checks that the same handle moves, and exercises touch as well as mouse input. The full browser/model and APK gates remain required; no workflow edit or check bypass is needed.

## Editable hole signs and saved course setup (1.28.0)

Replace repository-root Fairway-Form-Source.zip and commit using the same working workflow and signing credentials. After Actions passes, extract and install the APK over the existing app without uninstalling. Fallback Android versionCode is 49; CI supplies its increasing code.

In Caddy, open Read this hole’s sign and choose a photo or screenshot. Review the proposed endpoints and route. Drag tee, basket or either bend directly; placement buttons are only needed to add a missing point. Choose the active hole, tee/basket distance or par if several are visible, then Use confirmed sign details. Course name, hole, par, distance, shape and rule notes fill the regular setup and save through its existing course autosave. Choose a matching course if a different course name is already open. Reopening the course restores confirmed hole facts. Use the compass for bearing; the picture does not establish north or measure distance.

Seven sources and four map-reading lessons are in Technique library. This is local heuristic image analysis with confirmation, not a trained guarantee for every sign or active basket. See HOLE-SIGN-RESEARCH-1.28.0.md for research and limitations.

## Descriptive coaching and searchable research (1.27.0)

Replace repository-root Fairway-Form-Source.zip and commit using the same working workflow and signing credentials. After Actions passes, extract and install the APK over the existing app without uninstalling. Fallback Android versionCode is 48; CI supplies its increasing code.

Coaching now explains what is visible, why it matters, what to do next and how to check the next set. A named practice comparison and an article/tutorial reference appear in the default view. In Technique library, Browse switches between Practical lessons, Research & sources and Disc flight references. Search and publisher/topic filters apply to the selected view; source pages load in bounded groups. Source overviews are offline, while external articles/videos need internet. See RELEASE-1.27.0.md.

## Automatic throwing sequence and coil review (1.26.0)

Replace repository-root Fairway-Form-Source.zip and commit using the same workflow and signing credentials. After Actions passes, install the extracted APK over the existing app without uninstalling. Fallback Android versionCode is 47; CI supplies its increasing code.

Reanalyze the same original clip to refresh old event estimates. Review final plant, backswing, crossover and follow-through on the timeline; Coil / body turn is also editable. A supported automatic sequence receives observational coaching without requiring manual release marking. Correct only suggestions that are off. Original video remains the default; Prepared frames remains optional. No existing session is silently rewritten until you save it. See RELEASE-1.26.0.md for research and validation limits.

## Analysis preview and throw-moment review (1.25.0)

Replace repository-root Fairway-Form-Source.zip and commit in the same private repository. Keep the existing workflow and signing credentials. After Actions passes, download Fairway-Form-APK, extract it and install over the existing app without uninstalling. Fallback Android versionCode is 46; CI supplies its increasing code.

Original video is the default again. Analysis should show the source frames advancing with their measured points. In App & settings, Prepared frames remains an explicit compatibility option; reopen the clip after changing it. Check the suggested release in replay and use Mark release here before relying on timing-based coaching. This update fixes confirmed display problems but does not claim automatic moment accuracy is validated. See RELEASE-1.25.0.md for limits and phone checks.

## Browser preview-check timeout (1.24.1)

Replace repository-root Fairway-Form-Source.zip and commit using the same workflow and signing credentials. This patch bounds the image-decode wait and splits prepared-frame UI validation into named steps. It includes every 1.24.0 feature. GitHub still must pass the full browser/model, Android compile and APK checks. See RELEASE-1.24.1.md.

## Tutorial-informed review and source stills (1.24.0)

Replace the root Fairway-Form-Source.zip in the same repository and commit. Keep the existing workflow and signing credentials. After a successful build, install over the existing app. In detailed coaching, open Read your throw as a sequence to see event checks, links to seven new review lessons, and your source stills when prepared-frame mode is available. See FORM-TUTORIAL-RESEARCH.md for source provenance and validation limits.

## Android prepared-frame review (1.23.0)

Replace the root Fairway-Form-Source.zip in the same private repository and commit. Keep the existing workflow and signing credentials. Supported APK clips are decoded once into temporary private source images; scrub, step, marker and analysis workflows reuse their presentation timestamps. Wait for Frame review ready, then test the same clip that timed out. Unsupported formats explicitly fall back to the browser player. A successful compile is not an on-device codec validation. See VIDEO-PIPELINE.md and RELEASE-1.23.0.md.

## Manufacturer-search build check (1.22.2)

Replace repository-root Fairway-Form-Source.zip and commit in the same private repository. Keep the existing workflow and signing credentials. This fixes an outdated browser-test expectation of five Trash Panda molds; the expanded catalog correctly includes six. The check now verifies current mold identities and is exercised by the UI tests. Includes all 1.22.1 watchdog protections and the complete 1.22.0 catalog. See RELEASE-1.22.2.md.

## Browser check watchdog and progress (1.22.1)

This source update includes all 1.22.0 app/catalog changes and adds a bounded, observable browser-check runner. Replace the repository-root ZIP and commit using the same working workflow and signing identity. The existing workflow automatically receives the watchdog through build-android.sh; no workflow edit is required for that protection. The included workflow templates additionally upload browser diagnostics even on failure.

Local checks: npm run test:browser. A blocked local environment is a nonzero result, not a pass. The runner writes fresh artifacts/browser-check.log and browser-check-status.json with a run ID, stage, timing and outcome. See BROWSER-CHECKS.md. Project timers cover commands after launch; they cannot stop a platform approval or scheduling wait before execution begins.


## Disc catalog audit and expansion (1.22.0)

This combined update includes the 1.21.0 forward-decoding fix, gold coaching replay buttons, bag search/sort and exact-speed filter. It adds 242 sourced catalog records across the 28 existing brands, including explicitly named rated versions. Existing bag IDs and throw histories stay intact. Use the latest 1.22.0 ZIP if you have not installed 1.21.0 yet; one update is enough.

Replace the repository-root Fairway-Form-Source.zip and commit in the same private repository. Keep the same workflow and signing credentials. After Actions succeeds, download Fairway-Form-APK, extract the APK and install over your current app without uninstalling. See RELEASE-1.22.0.md and DISC-CATALOG-AUDIT-1.22.0.md for audit scope and verification.


## Forward video decoding and disc controls (1.21.0)

Replace the repository-root Fairway-Form-Source.zip with this update and commit it. Keep the same workflow, encrypted signing key and APP_SIGNING_PASSWORD. After Actions passes, download Fairway-Form-APK, extract the APK and install over the current app without uninstalling.

Analysis reads forward through real decoded video frames on supported phones, and uses one forward release-window pass for optional hand detail. Check the same video that previously failed. In My Bag use Search my bag and Sort my bag. Catalog Exact speed selects only that rating; Any speed removes the filter. Coaching replay buttons use gold with black text in every palette/mode. See RELEASE-1.21.0.md.


## Research, layout notes and controlled landings (1.20.0)

Replace and commit the repository-root Fairway-Form-Source.zip with the existing workflow/signing credentials. Install the successful APK over the current app without uninstalling.

Notes now influence the plan. Write direct phrases such as “water 20 ft behind basket”, “forehand blocked”, or “straight for 200 ft then dogleg right”. Check How I read your notes. Long trouble changes the objective to a controlled shorter landing. Use Clear layout notes or Clear throw notes to empty just that text. Seven new Caddy strategy lessons include fourteen reviewed sources. Current-lie note edits do not replace a saved tee layout after a throw. See RELEASE-1.20.0.md for the test status and phone checks.

## Dogleg placements and same-disc shot choices (1.19.0)

Replace the repository-root Fairway-Form-Source.zip and commit with the existing workflow/key. Install the successful APK over the current app without uninstalling.

Caddy retains a shorter bend-matching forehand option, uses a separate target for it and can compare styles using the same physical disc. Choose this shot selects the actual recommendation variant. Use the optional visible-gap/corner distance when you know the required carry. Suggested placements do not become measured carry or distance remaining. See RELEASE-1.19.0.md for verification and phone checks.

## Automatic Caddy shots and power (1.18.0)

Replace the repository-root Fairway-Form-Source.zip with this ZIP and commit, keeping the existing workflow and signing credentials. Install the successful APK over your current app; do not uninstall.

Caddy now recommends style, release and broad power rather than asking those setup questions. Putting stays explicit. Choose Advanced or Pro in the player profile to enable hyzer-flips, flexes and turnovers; lower skill levels keep simpler releases. Confirm Actual effort used in feedback to keep suggested power separate from your actual throw. Saved holes/disc histories remain compatible. See RELEASE-1.18.0.md for checks and limits.

## Fresh opening, appearance and bag photos (1.17.0)

The intro plays once in a new app activity/session. Home, app switching, screen lock, permission prompts and media-pickers do not rearm it. An interruption also dismisses an unfinished intro. Fully closing/removing the app and opening it again creates a fresh session. If Android kills the app process in the background, reopening is a fresh start too. No WebView reload or draft reset is performed on a normal return.

Both Regular and Dark share the exact title green `#101f1d`; the modes change panel depth. Saved palette IDs remain compatible, now pairing basket gold with mint, sky or rose accents. `dist/themes.css` contains the colors, `dist/brand.css` the black framing/readability rules, and `theme-init.js` the palette labels. Native bars use the same green. Input text has a 16 px floor and controls are at least 52 px tall.

In Disc room → My bag, each physical disc has Take photo, Choose from Gallery and Use catalog photo controls. `dist/lib/bag-photos.js` re-encodes a photo to an at-most-960-pixel JPEG capped at 160 KB, dropping original metadata. The `personalPhoto` field stays in that copy's bag row in the existing IndexedDB store. `patchBagItem` atomically merges photo/field edits so concurrent saves do not overwrite each other or recreate a deleted copy. No photo is uploaded.

Bag JSON backups include photos and allow up to 60 MB on import, matching the native export size ceiling. Old backups without a photo retain the existing matching copy's photo; explicit `personalPhoto:null` removes it. Hole exports omit photo bytes. No database version/schema change is needed. The approved intro and resource-table verification fix from 1.16.1 are retained.

See RELEASE-1.17.0.md for phone checks and validation limits.

## Opening-movie APK check fix (1.16.1)

If Gradle reports BUILD SUCCESSFUL and then the old movie checker reports a missing/intact-movie error, replace the root source ZIP with 1.16.1 and commit it. The checker now uses SDK build-tools `aapt2 dump resources` and the current variant’s generated `R.txt` to resolve `com.fairwayform.app:raw/fairway_intro` to its actual APK path. Android resource optimization may shorten the path or collapse its name; the resource ID still selects the movie that the app uses. The checker extracts that entry and requires the original byte count and SHA-256. It does not accept an unrelated copy elsewhere in the APK or skip the check.

The existing workflow already installs build-tools 35.0.0; no workflow edit, signing-key change or app uninstall is needed. `scripts/lib/startup-apk.mjs` contains the resolver and verifier, with regression fixtures in `tests/startup-assets.test.mjs`. See RELEASE-1.16.1.md.

## Opening animation and app name (1.16.0)

The visible name is **Final Form - Disc Golf**. Continue using `Fairway-Form-Source.zip` and `Fairway-Form.apk`, the same private repository, encrypted signing key and workflow. Install over the existing app to retain your local data.

- `android/app/src/main/res/raw/fairway_intro.mp4` is the approved Concept 05 movie, bundled offline. An intentional replacement must also update its hash/metadata in `android/startup-assets.json`.
- `StartupIntro.java` controls playback, skip, accessibility, loader readiness and fallback; `StartupPolicy.java` handles foreground return rules. The WebView loads at the same time rather than waiting for the movie.
- `dist/app.js` signals `AndroidFiles.startupReady()` after interface setup. The movie ends naturally before revealing a ready interface; decoder failure and Skip never trap the app behind the intro.
- The movie replays after Home/normal background return. Completing a picker, native camera/range or permission task keeps the current workflow visible. The intro never reloads your Caddy page or clears its fields.
- `res/values/strings.xml`, Android launcher resources, `dist/icon.svg` and its PNGs, `dist/index.html` and `dist/manifest.webmanifest` control the name/logo. `drawable-nodpi/final_form_poster.png` avoids density-upscaling the portrait poster on high-resolution phones.
- Keep `com.fairwayform.app`, `https://appassets.androidplatform.net`, the `fairway-form` database name and schema 5 unchanged. Those are compatibility identifiers, not displayed branding.

See RELEASE-1.16.0.md for phone acceptance checks. Native playback and the final signed APK need the GitHub build and physical-device testing; local rule tests are not an Android media-player test.

## Where to make changes

Current source version: 1.24.1 (Android default versionCode 45; CI supplies its run number). Includes camera and gallery access explanations with Continue and Not now actions.

| File | What it controls |
| --- | --- |
| `dist/index.html` | Screens, text and camera/player controls |
| `dist/style.css` | Forest-green visual design and phone layouts |
| `dist/app.js` | Recording, video sampling, overlays, journal and export |
| `dist/lib/knowledge.js` | The editable technique/practice knowledge collection and source links |
| `dist/lib/analysis.js` | Confidence-gated geometry, evidence rules and coaching cues |
| `dist/lib/tracker.js` | Assisted color tracking; does not contain a learned disc detector |
| `dist/lib/pose.js` | Pose engine version and official model location |
| `dist/lib/storage.js` | Local database, including courses (schema 5) |
| `dist/lib/courses.js` | Course/hole layout validation and fresh-round setup |
| `dist/lib/disc-catalog.js` | Product-version aliases and physical-copy ownership counts |
| `dist/lib/caddy-ui.js` | My Courses controls and recommendation/feedback flow |
| `scripts/catalog-reference-snapshot.json` | Reviewed additional catalog facts and their reference sources |
| `scripts/catalog-manufacturer-additions.json` | Manufacturer-checked additions |
| `scripts/build-catalog.mjs` | Rebuilds the additional catalog without changing existing IDs |
| `dist/sw.js` | Web caching and app-version updates |
| `android/app/src/main/java/com/fairwayform/app/MainActivity.java` | Android camera/gallery/file integration |

Every future change can be made to this source and distributed as a new web version or APK. The source is independent of this conversation.

## A useful knowledge-entry structure

Each entry in KNOWLEDGE has an id, category, title, summary, longer explanation, practice drill and optional source title/URL. Add new entries to the array. Keep source provenance and distinguish a practice suggestion from a result measured from video. Library prose does not create a new detection capability. Add observation rules to `analysis.js` only when the observable quantity and camera constraints are clear.

A future comprehensive coach would need expert-reviewed criteria, labeled footage across throws and camera angles, disc/hand detection, accuracy evaluation and confidence calibration. Joint forces, spin and accurate 3D flight generally need additional information or sensors. The present code does not implement those capabilities.

## Web updates

Edit source, run tests, increment the shell VERSION in `dist/sw.js` and deploy `dist/` to the SAME HTTPS origin. Keep the manifest id and scope stable. In the app choose App & settings → Check app update. The worker waits to activate while the app is in use. Version changes apply the complete cached shell together. Storage remains tied to the browser and origin.

## Android updates

For the phone-only GitHub build, follow `phone-build/PHONE-INSTALL.md`: replace the source ZIP in the same private repository and keep the encrypted key and password secret. The workflow sets a monotonically increasing versionCode through the Gradle fairwayVersionCode property. Use the same workflow path so run numbers keep increasing.

Increment `versionCode` and `versionName` in `android/app/build.gradle`, rebundle assets and rebuild. Keep applicationId `com.fairwayform.app` and use the SAME signing key as the installed APK. A debug key generated on a different computer or a fresh CI runner normally cannot update the old install. Do not rely on repeated CI debug builds for updates that must preserve sessions.

For ongoing use, generate your own release keystore once, back it up securely and do not commit it. For example, using your JDK's keytool:

```sh
keytool -genkeypair -v -keystore fairway-release.jks -alias fairway -keyalg RSA -keysize 3072 -validity 10000
```

Set environment variables ANDROID_KEYSTORE (absolute path), ANDROID_STORE_PASSWORD, ANDROID_KEY_ALIAS and ANDROID_KEY_PASSWORD in your shell or CI secrets, without committing their values. Then run:

```sh
npm run assets
npm test
bash scripts/build-android.sh assembleRelease
```

Install the signed APK from `android/app/build/outputs/apk/release/`. For Play Store publication, use a signed Android App Bundle and follow the current store submission process; publication is not included in this source delivery.

## Before trusting an update

Use representative videos from both hands and multiple throw types. Check overlay alignment at pauses and during playback, release marking, poor lighting, occluded joints and no-person footage. Verify that a missing or ambiguous disc stops a trace and that an incorrect similar-color match can be cleared. Test a 20-second upload, rejection of longer clips, denied camera permission, native-camera fallback, recording interruption, saving/reopening, exports, offline start and updating the APK while preserving sessions.

## Version 1.1.0 update

See RELEASE-1.1.0.md for the phone update steps. The existing working ZIP-upload workflow can stay in place. The new source's build script runs its browser smoke check on CI before compilation, and bundles Lite, Full, Heavy and hand models. Keep the same repository, workflow path, encrypted signing key and password. Default local versionCode is 4; the existing CI run-number property overrides it for distributed updates.

The IndexedDB upgrade preserves sessions and adds bag/catalog stores. Core measurements now live in geometry.js, phases.js and analysis.js. Hand model loading and source-image cropping live in pose.js. report-ui.js builds review cards and the local walkthrough. knowledge.js contains 38 lessons and source records. discs.js contains 50 initial catalog facts and import validation; discs-ui.js handles the bag interface. scripts/browser-smoke.mjs adds real-browser and model initialization checks to CI. It is not an app demo and its fixture data is never bundled into the normal interface.


## Version 1.1.1 update

Replace the root Fairway-Form-Source.zip in the same repository and commit it. Keep the existing workflow and signing identity. Default local versionCode is 5; CI continues to override it using the workflow run number. See RELEASE-1.1.1.md for the phone checklist.

Theme choices and the early launch preference live in dist/theme-init.js; setup and native/browser appearance updates are in dist/lib/themes.js, and semantic palette colors are in dist/themes.css. Android handles automatic appearance through isSystemDark/setTheme and uiMode configuration changes. The shell cache is bumped for browser installs; APK installs load their bundled assets directly.

Frame loading and seeking now live in dist/lib/video-player.js. Never replace its readiness checks with a bare seeked listener or allow a timed-out seek to run inference on stale pixels. Partial review state is stored in sampleInfo and passed into quality metadata so saved and spoken reviews retain the warning. The GitHub browser check now also exercises saved themes, phone light/dark appearance, missing-seeked recovery on actual video, deliberate analysis interruption and retry.


## Version 1.1.2 update

Use the same ZIP replacement and signed APK update flow. Local versionCode is 6; CI continues to use its increasing run number. See RELEASE-1.1.2.md for the phone checklist.

Appearance is stored atomically as {palette, mode} in localStorage fairway-appearance, with migration from fairway-theme. Dark mode changes background/readability tokens and retains the chosen palette accents. theme-init.js handles early launch and themes.js the controls/native bridge. Native setTheme accepts the three palettes and their -dark variants.

coaching-language.js translates supported findings into plain-language observations, cues and drills. It never upgrades unknown/observed evidence into a fault or invents praise. analysis.js still owns measurements and prompt generation. report-ui.js keeps that evidence available under optional details and presents one practice focus first.

voice.js handles voice settings, preview, browser selection, chunking and cancellation. Android MainActivity lists actual English voices and filters missing/offline-only voices before choosing by quality. Native and browser speech both require the optional internet-voice setting before using a voice that needs a network. The spoken text may go to the speech provider when enabled; the app does not upload video. Add higher-quality voices through the phone’s speech engine settings, then refresh the list. No third-party speech account or new signing setup is required.


## Version 1.1.3 update

Use the same repository, root ZIP filename, signing secret and encrypted signing key. No change to the existing phone workflow is required. Local versionCode is 7; CI keeps using the increasing workflow run number. See RELEASE-1.1.3.md for the phone checklist.

The factual catalog lives in dist/lib/disc-data.js, with validation and stable ID rules in discs.js. Preserve existing IDs when correcting a rating or source, since bags refer to them. New manufacturer facts are dated and linked; DISC-CATALOG-SOURCES.md records the complete snapshot. Import data stays labeled user supplied.

npm run assets now also runs scripts/fetch-disc-photos.mjs. It looks for matching product images in manufacturer data/captions, validates formats, follows only the configured public manufacturer/CDN hosts and writes local files plus dist/disc-photos/index.json. Photo work has a six-minute network budget and continues with explicit gaps when downloads fail. The build log and artifacts/disc-photo-coverage.json report coverage. The source ZIP excludes generated photos and neural assets; the hosted build downloads them.

scripts/lib/disc-photos.mjs owns photo identity matching. dist/lib/disc-photos.js accepts only safe local photos for known IDs. discs-ui.js handles pagination, filtering, credits, missing-image recovery and bag photos. JPEG and WebP MIME handling was added to the Android asset wrapper. The browser shell caches photo files as they are viewed; APK assets already contain the downloaded photos.

knowledge.js adds original, source-informed manufacturer lessons. knowledge-ui.js filters by publisher as well as topic/level. Rebuild and sign with the same identity to deliver future changes.


## Version 1.1.4 update

Replace the root Fairway-Form-Source.zip in the same repository. Keep the working workflow, APP_SIGNING_PASSWORD and .fairway-signing.enc. CI continues to supply its increasing versionCode.

The analysis pass orchestration now lives in dist/lib/video-analysis.js. It keeps bodyComplete independent of detailIncomplete/detailCancelled, and revisits existing sampled times for hand inference. Do not restore unconditional arbitrary 60 Hz release seeks or label a failed optional hand pass as incomplete body coverage. Hand matching re-detects pose on the same source pixels. tests/video-analysis.test.mjs covers the 3.76 s / 3.58 s regression, 60/30 fps deduplication, partial body evidence, optional failures and cancellation. dist/lib/video-frames.js subscribes to compositor metadata before seeking, rejects unrelated timestamps, and cleans up on failure. Readiness tolerates bounded rounding only after seek progress/acknowledgement; the initial same-frame fast path remains strict.

The source ZIP is a build input, not an APK. See RELEASE-1.1.4.md for phone verification.


## Version 1.1.5 update

Replace the root Fairway-Form-Source.zip in the same repository and keep the signing identity. practice-library.js defines exercises with eligible findings, shot types, stances, steps, an outcome check and source lesson IDs. coaching-language.js selects only available findings, labels general learning separately and constructs video anchors from report phase timestamps. report-ui.js handles focus/drill selection, playback buttons, source exports and the collapsed unavailable-check group. Missing evidence must not become a personal fault or selectable measured finding.

knowledge.js includes checked source-access notes and external tutorial chapter times; knowledge-ui.js displays them. A library addition does not train the model or add a video detector. Preserve that distinction in future coaching changes. The source remains independently editable. See COACHING-RESEARCH-1.1.5.md for the audit and remaining X-step event-analysis work.


## Version 1.2.0 update

Caddy inputs, ranking, range/hand logic and immutable throw transitions live in dist/lib/caddy.js. The interface and serialized local saves are in caddy-ui.js. Sign text parsing, native bridge coordination and route geometry are in caddy-sign.js. caddy-weather.js contains the documented public testing endpoint, response validation and wind-heading conversion. caddy-content.js holds the source links and short explanations. Personal calibration fields are in discs-ui.js and included in bag backup/restore. Database version 3 adds caddyHoles while preserving previous stores.

Android uses ML Kit text recognition 16.0.1 and AndroidX Core FileProvider 1.13.1, with AndroidX enabled. MainActivity handles image capture/picking, origin-scoped geolocation permission and the bounded OCR bridge. res/xml/file_paths.xml exposes only the sign cache subdirectory to camera capture. Keep the Android package, origin and signing key stable.

Recommendations must stay bag-only; missing distance cannot be inferred from flight ratings, driving range cannot become putting range, and a next lie cannot reuse a stale line or heading. Sign text/distance/route suggestions need confirmation. Do not embed a private commercial weather API key in client source. See CADDY-RESEARCH.md before distributing commercially and RELEASE-1.2.0.md for phone checks.


## Version 1.2.1 update

Replace the root source ZIP as usual, keeping the existing workflow and signing identity. IndexedDB upgrades from v3 to v4 by adding a player store; sessions, bag, catalog and caddy holes remain. Earlier caddy hand/putting/speed limits seed an unsaved profile if no saved player profile exists. Saving the new profile becomes the source for future caddy-hole defaults. Editing a lie does not rewrite the player profile.

App & settings now contains Player profile. It is local, optional, editable, resettable and separately backed up/restored as JSON. Age/gender/height never determine power or an ideal pose. Skill selection changes practice structure and adds a small disclosed slower-disc preference to a beginner’s balanced caddy plan. Bag-copy distances remain the reach reference for individual discs.

Saved-session measured carry and a normal/level/calm checkbox support a median after at least three matching-hand/throw records. Repeated form prompts need at least three sufficiently clear, complete, fixed-camera, side-on reviews with the same stance and a manually marked release; brace/timing also need a marked plant. Uses the latest 12 matching saved sessions within 90 days, with the latest eligible stance for form comparisons. These cues do not alter power estimates or disc-distance scores. Turning learning off excludes both measured-session references and repeated-form cues, while explicit profile and bag facts remain usable.

See RELEASE-1.2.1.md for acceptance checks. No new Android permission, third-party dependency, API key or workflow change is required.


## Version 1.2.2 build fix

The caddy browser check must await caddy.dataset.state === ready, rather than treating the preloaded Throw 1 label as a loaded hole. Caddy now marks loading/ready/error explicitly, reports loading outside an inert workspace, and enables inputs only after its bag/profile/hole data is ready. Background autosaves skip unpopulated controls. Initial reads are shared across concurrent opens and a storage error can be retried by reopening Caddy.

The personal-limit assertion remains enabled. A real incorrect limit still fails the build, with the actual field values included in its error. Node VM integration tests load the real caddy UI, profile, and planning modules against delayed storage and a minimal DOM test harness; these run without a local browser server. Full Chromium/model smoke testing still runs in GitHub Actions before compilation. No workflow, signing, dependency or permission change is required.


## Version 1.2.3 Android dependency fix

The reported 1.2.2 run completed its browser/model checks, then failed Android checkReleaseDuplicateClasses. It mixed kotlin-stdlib 1.8.22 with kotlin-stdlib-jdk7/jdk8 1.6.21 from transitive Android-library dependencies. Kotlin 1.8 moved the older JDK-extension classes into the main standard library, so these versions overlap.

The app now imports org.jetbrains.kotlin:kotlin-bom:1.8.22 as an implementation platform. Its constraints bring the older JDK artifacts to the compatible release line. Duplicate-class checking remains enabled; no class exclusions, packaging workarounds, signing changes or workflow changes are used. Keep the BOM when changing native dependencies, and review Gradle dependencyInsight for releaseRuntimeClasspath if updating the Kotlin runtime later.

Official reference: https://kotlinlang.org/docs/whatsnew18.html


## Version 1.3.0 caddy flight/history update

Use the same root ZIP replacement and existing signing workflow. The native Kotlin BOM remains pinned at 1.8.22. Database version remains 4; throw-distance fields extend existing canonical caddy hole entries.

New source modules: disc-flight-data.js for researched references, disc-flight.js for role/estimate/analogue rules, disc-flight-ui.js for the labeled views, and disc-history.js for measured statistics, context matching and backup validation. Each is included in the service-worker offline shell.

Do not confuse the hole's basket distance, a chosen landing point, an estimated first-stage comparison, actual measured carry and actual remaining basket distance. Do not promote a record maximum or an estimated throw into a measured routine range. The initial 1.3.0 putter tee cutoff is superseded by the capability-based policy in 1.3.1. Estimated range coefficients are application assumptions; see CADDY-FLIGHT-RESEARCH-1.3.0.md. No trajectory guarantee is made.

Bag backups now include sanitized history. Restore accepts older backups and validates historical records before an atomic transaction. Current matching throw entries win over older copies. Additional imported entries archive an affected hole to avoid a stale next-lie assumption. Pending draft saves must finish before editable bag history opens; Caddy reentry must reload corrected entries.


## Version 1.3.1 putter driving and alternatives

Replace the root Fairway-Form-Source.zip in the same repository and commit it. Keep the existing workflow, encrypted key and APP_SIGNING_PASSWORD. Local versionCode is 15; CI still supplies its increasing code.

There is no fixed putter tee-distance cutoff. Measured comparable averages and entered disc-specific carry override generic role estimates. Long open holes favor driving roles when they offer greater carry; a demonstrated longer putter is not penalized merely for its role. If putter copies fill the three-choice shortlist, a competitive, reachable midrange/driver alternative can replace the third choice. It must stay within any selected comfortable speed limit and within 10 ranking points of the leader. These margins are app planning choices, not flight physics. See CADDY-FLIGHT-RESEARCH-1.3.1.md. Existing bag/history data and IndexedDB version 4 are preserved.


## Version 1.4.0 release-angle and disc-profile learning

Use the same root Fairway-Form-Source.zip replacement and signing workflow. Native dependencies and IndexedDB version 4 are unchanged. Actual-shot metadata extends existing canonical caddy hole entries; there is no duplicate learned-profile store. Local versionCode is 16; CI supplies its increasing code.

New modules shot-shape.js and disc-profile.js are in the offline shell. The caddy compares release options per physical bag copy and, when explicitly selected, both backhand and forehand. The shortlist still contains distinct bag copies. Actual hand/style/angle and structured quality/execution/flight feedback are stored separately from the chosen recommendation. Older logs retain an unknown actual angle; a planned angle never confirms an actual release.

Carry and reported-flight learning filter by actual hand, style, release and comparable conditions. Three matching reports can establish a conditional flight tendency; three comparable clear measured throws establish carry. A maximum, an estimated distance, or pulled/early/slipped/obstructed flight cannot establish normal carry. Unknown-angle historical measurements can remain a clearly labeled general reference. Initial hand/angle bag references are optional and remain editable.

Bag → Your disc profile shows initial references, actual shot groups, result/quality/execution/flight counts, weather groups and measured average/farthest. The existing history editor now corrects actual shot and feedback as well as distance. Edits rebuild the profile from the canonical record and Caddy reentry reloads it. Bag/history backup preserves actual and planned shot metadata with strict validation; old backups remain supported. See SHOT-PROFILE-RESEARCH-1.4.0.md for source support, thresholds and limits.


## Version 1.5.0 coaching, library, X-step and graphics

Use the same source ZIP replacement and signing workflow. Package/origin and IndexedDB version 4 remain unchanged. Local versionCode is 17; CI supplies its increasing code. New local resources are included in the offline shell.

Edit library-editorial.js for current lesson titles, expanded explanations, source previews and additions; knowledge.js keeps stable IDs and source relationships. coaching-language.js selects human-readable short/deep coaching from actual findings. report-ui.js renders the summary and closed detail groups. knowledge-ui.js opens an exact lesson with filters cleared. Voice defaults to the short plan.

x-step.js recognizes a conservative projected crossover pattern in a fixed, side-on backhand approach. The report preserves candidate versus user-marked status and replay times. This is not validated 3D foot order, force or ideal-form detection. The new crossover marker extends existing session metadata. Existing sessions with frames recalculate the updated review on opening. See COACHING-RESEARCH-1.5.0.md for thresholds and validation limits.

theme-init.js and themes.js add a graphics preference alongside the existing palette/mode. Missing graphics starts with Park day; Minimal restores the original simpler presentation. Existing palettes and gray dark mode remain independent. graphics.css and art/course-*.svg provide the original local artwork; no remote image or new permission is required.

## Version 1.9.0

See RELEASE-1.9.0.md for My Courses, the simpler next-throw workflow and update checks. Course layouts are stored separately from caddy round logs. Keep course tee distance and current-lie distance separate in future edits. Back up My Courses with its own JSON export; bag/throw history and player backups remain separate. After editing the reviewed catalog snapshots, run `node scripts/build-catalog.mjs` and `npm test`, then use the existing APK workflow.

## Version 1.9.1

Replace the repository-root Fairway-Form-Source.zip with the corrected package and commit. This fixes the course smoke test after earlier tests deliberately emptied the bag. Keep the existing workflow and signing identity; no new permission, database migration or catalog replacement is needed. The course check seeds and removes its own test bag copy in the temporary browser profile. See RELEASE-1.9.1.md.

## Version 1.10.0

See RELEASE-1.10.0.md. Course metadata and shot setup now use the same form. Keep reusable tee layouts separate from later lies. Saved measurements appear in disc profiles before feedback; final feedback reuses the pending measurement ID. Do not turn a pending measurement into a second completed throw. Keep GPS estimates labeled and exclude unfinished feedback from learned carry.

`dist/lib/caddy-results.js` validates multiple observations. `dist/lib/fairways.js` defines straight, slight/full doglegs and combined bends. `dist/lib/sign-diagram.js` performs bounded local pixel/label analysis; it is not a general-purpose trained vision model. Native OCR line boxes are returned in MainActivity.java. Remember the last tee/basket label per course, but ask the player on each new sign before applying the setup.

Run npm test and the existing CI workflow after edits. Native OCR and real-sign/GPS accuracy need phone checks even when software checks pass. Keep package, origin, signing identity and exact ZIP filename unchanged.


## Version 1.11.0

See RELEASE-1.11.0.md and CATALOG-FLIGHT-AUDIT-1.11.0.md. Catalog ownership counts group bag copies by the canonical mold ID; each copy still learns separately by bag ID. BuzzzSaw is a reviewed product version of Discraft Buzzz, not a duplicate mold. Its add button pre-fills Fuzed Z · BuzzzSaw; preserve existing Buzzz IDs and histories. Update aliases/product facts in dist/lib/disc-catalog.js, and keep a dated manufacturer source.

Caddy has one active task, a top-level quick-measure entry, a prominent Log this throw action, selected-copy context, concise default instructions and collapsed course/help controls. Saved pending measurements reopen directly into their unfinished result and retain the same throw ID when completed. The source package includes actual handler tests for ownership additions/removals/restores, alias search, measurement resume and empty-bag paths. CI still runs the real browser/model checks and Android build. Package, origin, signing and IndexedDB schema 5 are unchanged.


## Version 1.12.0

Course directory/search is in dist/lib/course-directory.js and course-search-ui.js. The assets command calls scripts/fetch-course-data.mjs to build dist/course-data/index.json from a bounded official OSM extract through scripts/lib/course-snapshot.mjs. Keep the ODbL attribution/metadata and open-map export. These data files and both modules are in the offline shell. Confirm the assets log reports “Bundled OSM courses” or a valid cached snapshot; the optional fetch can fail without failing the APK build, in which case course search explicitly reports unavailable.

User-confirmed course.holes remain strict, reusable layouts. Optional source and importedLayouts keep incomplete/alternate map routes separate. Do not default unknown par, distance, line, elevation or OB into imported holes. External UDisc references are HTTPS course-page links, not API access or data ingestion. Re-import by OSM object ID preserves existing saved holes and local course names. Course backups retain sources and unresolved layouts; existing schema-1 course backups still load and IndexedDB remains schema 5. See COURSE-DATA-RESEARCH-1.12.0.md and the unsent UDISC-LICENSING-INQUIRY.txt for the paid-app licensing plan.


## Version 1.12.1

The “Selected disc summary missing” build failure was a false negative: the catalog uses TeeBird, while the browser check searched case-sensitively for Teebird. scripts/lib/caddy-smoke.mjs contains a self-contained browser guard, serialized into the real browser check and also exercised against the Caddy handler fixture. Expected brand/model values come from DISCS; feedback and measurement must select the same physical copy, and the summary must show that copy’s plastic. Keep these meaningful checks instead of removing the summary assertion or accepting any nonempty label. The patch retains all app features, package/origin/signing identity and schema 5. The full browser/model check and APK compilation still run in GitHub Actions.

## Version 1.12.2

Replace the root source ZIP and commit it using the existing phone workflow. Course search now requires an actual dated, populated directory at build time. The assets step fetches a compact course list before optional hole geometry and tries a documented fallback provider. Build and browser checks reject empty data; retry a failed provider download rather than distributing an empty search. No workflow replacement is needed.

My Courses → Find a course reports its count/date and supports accent-free names, mapped aliases and common DGC wording. Start with the park name; cities require mapped address tags. The PlanetDG link opens its OSM-based directory online and does not import its website data. See RELEASE-1.12.2.md and COURSE-SEARCH-RESEARCH-1.12.2.md.

## Version 1.13.0

Use the same source-ZIP update workflow. The Android app adds an optional ARCore camera activity; GitHub resolves the pinned SDK dependency and compiles it. Camera runtime support and raw-depth availability are checked before use. Google Play Services for AR may request installation/update. The browser edition keeps GPS/manual entry. Camera estimates are not promoted to measured carry; local histories preserve their source. GPS accepts only endpoints with reported accuracy at most 8 m and blocks new saves above 20% combined relative uncertainty. See RELEASE-1.13.0.md for use and CAMERA-RANGE-RESEARCH-1.13.0.md for limits and required Pixel field testing.

## Version 1.14.0

Replace the root source ZIP using the same phone build workflow. The body pass now uses a fresh ordered VIDEO-mode pose tracker, disposed before hand-detail rewinds. Optional Start/End review windows retain original timestamps and are saved in session options. Limb spikes are conservatively excluded; phase-marker matching uses frame spacing rather than a 0.12 s allowance. Tapping a suggested phase selects its marker type. Short/expanded coaching uses actual phase order and observed motion, and automatic focus favors clearly anchored evidence. See RELEASE-1.14.0.md for use and THROW-ANALYSIS-RESEARCH-1.14.0.md for sources, remaining limitations and required real-throw validation.

## Version 1.14.1

Replace and commit the source ZIP through the existing workflow. No workflow change is required. Optional course-provider outages now create a timestamped unavailability notice and do not block the APK. The packaging validator and browser check accept that explicit state while continuing to reject corrupt/unexplained empty data. A previously loaded valid directory can be retained in a separate on-phone cache, with its original date and a fallback notice. This supersedes the mandatory directory requirement in 1.12.2–1.14.0. Pose/model, compilation and signing checks remain required. See RELEASE-1.14.1.md for the screenshot diagnosis, testing and phone steps.

## Version 1.14.2

Replace and commit the root source ZIP with the same phone workflow. The browser startup check now uses Chrome’s debugging pipe with a real version/page handshake, one bounded retry and captured stdout/stderr on failure. A real Chrome/app/model check is still mandatory. No workflow replacement or signing change is required. See RELEASE-1.14.2.md for the screenshot diagnosis and verification limits.


## Version 1.15.0

Replace and commit the source ZIP with the same phone workflow. Course entry now lives directly in Caddy’s setup. `saved-course-picker.js` searches only `listCourses()` results; it never queries a website. `caddy-ui.js` serializes automatic course/round saves, keeps incomplete layout fields in optional `draftHoles`, and protects tee distance/line from later lies. `courses.js` validates drafts separately from complete holes and round-trips both in schema-1 course backups. The device database stays at schema 5. Older complete courses and imported source notices remain compatible.

Web course search/import is removed. `npm run assets` downloads pose assets and optional disc photos only. Android packaging no longer checks or fetches a course snapshot. Historical downloader/search/cache modules remain unwired reference code; their tests exercise the old data format, not a currently shipped course-search feature. The offline shell includes the new saved-course picker, without the course-directory data, cache or search UI. This supersedes the older course-download instructions.

Phone acceptance: add a course from the visible name field, enter only part of hole 1 and reopen; finish its setup and verify autosave without requesting a recommendation; select a saved course through a close-spelling suggestion; change the hole number to recall a saved hole or add a new one; log a throw and confirm the saved tee distance stays intact; make a putt and continue to the next hole; export and restore My Courses, including unfinished holes. No workflow, package, origin, signing or database reset is required. See RELEASE-1.15.0.md.
