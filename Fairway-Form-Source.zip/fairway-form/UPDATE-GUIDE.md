# Keep Fairway Form editable and updateable

## Where to make changes

Current source version: 1.1.0 (Android default versionCode 4). Includes camera and gallery access explanations with Continue and Not now actions.

| File | What it controls |
| --- | --- |
| `dist/index.html` | Screens, text and camera/player controls |
| `dist/style.css` | Forest-green visual design and phone layouts |
| `dist/app.js` | Recording, video sampling, overlays, journal and export |
| `dist/lib/knowledge.js` | The editable technique/practice knowledge collection and source links |
| `dist/lib/analysis.js` | Confidence-gated geometry, evidence rules and coaching cues |
| `dist/lib/tracker.js` | Assisted color tracking; does not contain a learned disc detector |
| `dist/lib/pose.js` | Pose engine version and official model location |
| `dist/lib/storage.js` | Local session database |
| `dist/sw.js` | Web caching and app-version updates |
| `android/app/src/main/java/com/fairwayform/app/MainActivity.java` | Android camera/gallery/file integration |

Every future change can be made to this source and distributed as a new web version or APK. The source is independent of this conversation.

## A useful knowledge-entry structure

Each entry in KNOWLEDGE has an id, category, title, summary, longer explanation, practice drill and optional source title/URL. Add new entries to the array. Keep source provenance and distinguish a practice suggestion from a result measured from video. Library prose does not create a new detection capability. Add observation rules to `analysis.js` only when the observable quantity and camera constraints are clear.

A future comprehensive coach would need expert-reviewed criteria, labeled footage across throws and camera angles, disc/hand detection, accuracy evaluation and confidence calibration. Joint forces, spin and accurate 3D flight generally need additional information or sensors. The present code does not implement those capabilities.

## Web updates

Edit source, run tests, increment the shell VERSION in `dist/sw.js` and deploy `dist/` to the SAME HTTPS origin. Keep the manifest id and scope stable. In the app choose App & settings → Check app update. The worker waits to activate while the app is in use. Version changes apply the complete cached shell together. Storage remains tied to the browser and origin.

## Android updates

For the phone-only GitHub build, follow `phone-build/PHONE-INSTALL.md`: replace the source ZIP in the same private repository and keep the encrypted key and password secret. The workflow sets a monotonically increasing versionCode through the Gradle fairwayVersionCode property. Use the same workflow path so run numbers keep increasing.

Increment `versionCode` and `versionName` in `android/app/build.gradle`, rebundle assets and rebuild. Keep applicationId `com.fairwayform.app` and use the SAME signing key as the installed APK. A debug key generated on a different computer or a fresh CI runner normally cannot update the old install. Do not rely on repeated CI debug builds for updates that must preserve sessions.

For ongoing use, generate your own release keystore once, back it up securely and do not commit it. For example, using your JDK's keytool:

```sh
keytool -genkeypair -v -keystore fairway-release.jks -alias fairway -keyalg RSA -keysize 3072 -validity 10000
```

Set environment variables ANDROID_KEYSTORE (absolute path), ANDROID_STORE_PASSWORD, ANDROID_KEY_ALIAS and ANDROID_KEY_PASSWORD in your shell or CI secrets, without committing their values. Then run:

```sh
npm run assets
npm test
bash scripts/build-android.sh assembleRelease
```

Install the signed APK from `android/app/build/outputs/apk/release/`. For Play Store publication, use a signed Android App Bundle and follow the current store submission process; publication is not included in this source delivery.

## Before trusting an update

Use representative videos from both hands and multiple throw types. Check overlay alignment at pauses and during playback, release marking, poor lighting, occluded joints and no-person footage. Verify that a missing or ambiguous disc stops a trace and that an incorrect similar-color match can be cleared. Test a 20-second upload, rejection of longer clips, denied camera permission, native-camera fallback, recording interruption, saving/reopening, exports, offline start and updating the APK while preserving sessions.

## Version 1.1.0 update

See RELEASE-1.1.0.md for the phone update steps. The existing working ZIP-upload workflow can stay in place. The new source's build script runs its browser smoke check on CI before compilation, and bundles Lite, Full, Heavy and hand models. Keep the same repository, workflow path, encrypted signing key and password. Default local versionCode is 4; the existing CI run-number property overrides it for distributed updates.

The IndexedDB upgrade preserves sessions and adds bag/catalog stores. Core measurements now live in geometry.js, phases.js and analysis.js. Hand model loading and source-image cropping live in pose.js. report-ui.js builds review cards and the local walkthrough. knowledge.js contains 38 lessons and source records. discs.js contains 50 initial catalog facts and import validation; discs-ui.js handles the bag interface. scripts/browser-smoke.mjs adds real-browser and model initialization checks to CI. It is not an app demo and its fixture data is never bundled into the normal interface.


## Version 1.1.1 update

Replace the root Fairway-Form-Source.zip in the same repository and commit it. Keep the existing workflow and signing identity. Default local versionCode is 5; CI continues to override it using the workflow run number. See RELEASE-1.1.1.md for the phone checklist.

Theme choices and the early launch preference live in dist/theme-init.js; setup and native/browser appearance updates are in dist/lib/themes.js, and semantic palette colors are in dist/themes.css. Android handles automatic appearance through isSystemDark/setTheme and uiMode configuration changes. The shell cache is bumped for browser installs; APK installs load their bundled assets directly.

Frame loading and seeking now live in dist/lib/video-player.js. Never replace its readiness checks with a bare seeked listener or allow a timed-out seek to run inference on stale pixels. Partial review state is stored in sampleInfo and passed into quality metadata so saved and spoken reviews retain the warning. The GitHub browser check now also exercises saved themes, phone light/dark appearance, missing-seeked recovery on actual video, deliberate analysis interruption and retry.


## Version 1.1.2 update

Use the same ZIP replacement and signed APK update flow. Local versionCode is 6; CI continues to use its increasing run number. See RELEASE-1.1.2.md for the phone checklist.

Appearance is stored atomically as {palette, mode} in localStorage fairway-appearance, with migration from fairway-theme. Dark mode changes background/readability tokens and retains the chosen palette accents. theme-init.js handles early launch and themes.js the controls/native bridge. Native setTheme accepts the three palettes and their -dark variants.

coaching-language.js translates supported findings into plain-language observations, cues and drills. It never upgrades unknown/observed evidence into a fault or invents praise. analysis.js still owns measurements and prompt generation. report-ui.js keeps that evidence available under optional details and presents one practice focus first.

voice.js handles voice settings, preview, browser selection, chunking and cancellation. Android MainActivity lists actual English voices and filters missing/offline-only voices before choosing by quality. Native and browser speech both require the optional internet-voice setting before using a voice that needs a network. The spoken text may go to the speech provider when enabled; the app does not upload video. Add higher-quality voices through the phone’s speech engine settings, then refresh the list. No third-party speech account or new signing setup is required.


## Version 1.1.3 update

Use the same repository, root ZIP filename, signing secret and encrypted signing key. No change to the existing phone workflow is required. Local versionCode is 7; CI keeps using the increasing workflow run number. See RELEASE-1.1.3.md for the phone checklist.

The factual catalog lives in dist/lib/disc-data.js, with validation and stable ID rules in discs.js. Preserve existing IDs when correcting a rating or source, since bags refer to them. New manufacturer facts are dated and linked; DISC-CATALOG-SOURCES.md records the complete snapshot. Import data stays labeled user supplied.

npm run assets now also runs scripts/fetch-disc-photos.mjs. It looks for matching product images in manufacturer data/captions, validates formats, follows only the configured public manufacturer/CDN hosts and writes local files plus dist/disc-photos/index.json. Photo work has a six-minute network budget and continues with explicit gaps when downloads fail. The build log and artifacts/disc-photo-coverage.json report coverage. The source ZIP excludes generated photos and neural assets; the hosted build downloads them.

scripts/lib/disc-photos.mjs owns photo identity matching. dist/lib/disc-photos.js accepts only safe local photos for known IDs. discs-ui.js handles pagination, filtering, credits, missing-image recovery and bag photos. JPEG and WebP MIME handling was added to the Android asset wrapper. The browser shell caches photo files as they are viewed; APK assets already contain the downloaded photos.

knowledge.js adds original, source-informed manufacturer lessons. knowledge-ui.js filters by publisher as well as topic/level. Rebuild and sign with the same identity to deliver future changes.
