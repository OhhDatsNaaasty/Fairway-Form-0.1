# Keep Fairway Form editable and updateable

## Where to make changes

Current source version: 1.1.0 (Android default versionCode 4). Includes camera and gallery access explanations with Continue and Not now actions.

| File | What it controls |
| --- | --- |
| `dist/index.html` | Screens, text and camera/player controls |
| `dist/style.css` | Forest-green visual design and phone layouts |
| `dist/app.js` | Recording, video sampling, overlays, journal and export |
| `dist/lib/knowledge.js` | The editable technique/practice knowledge collection and source links |
| `dist/lib/analysis.js` | Confidence-gated geometry, evidence rules and coaching cues |
| `dist/lib/tracker.js` | Assisted color tracking; does not contain a learned disc detector |
| `dist/lib/pose.js` | Pose engine version and official model location |
| `dist/lib/storage.js` | Local session database |
| `dist/sw.js` | Web caching and app-version updates |
| `android/app/src/main/java/com/fairwayform/app/MainActivity.java` | Android camera/gallery/file integration |

Every future change can be made to this source and distributed as a new web version or APK. The source is independent of this conversation.

## A useful knowledge-entry structure

Each entry in KNOWLEDGE has an id, category, title, summary, longer explanation, practice drill and optional source title/URL. Add new entries to the array. Keep source provenance and distinguish a practice suggestion from a result measured from video. Library prose does not create a new detection capability. Add observation rules to `analysis.js` only when the observable quantity and camera constraints are clear.

A future comprehensive coach would need expert-reviewed criteria, labeled footage across throws and camera angles, disc/hand detection, accuracy evaluation and confidence calibration. Joint forces, spin and accurate 3D flight generally need additional information or sensors. The present code does not implement those capabilities.

## Web updates

Edit source, run tests, increment the shell VERSION in `dist/sw.js` and deploy `dist/` to the SAME HTTPS origin. Keep the manifest id and scope stable. In the app choose App & settings → Check app update. The worker waits to activate while the app is in use. Version changes apply the complete cached shell together. Storage remains tied to the browser and origin.

## Android updates

For the phone-only GitHub build, follow `phone-build/PHONE-INSTALL.md`: replace the source ZIP in the same private repository and keep the encrypted key and password secret. The workflow sets a monotonically increasing versionCode through the Gradle fairwayVersionCode property. Use the same workflow path so run numbers keep increasing.

Increment `versionCode` and `versionName` in `android/app/build.gradle`, rebundle assets and rebuild. Keep applicationId `com.fairwayform.app` and use the SAME signing key as the installed APK. A debug key generated on a different computer or a fresh CI runner normally cannot update the old install. Do not rely on repeated CI debug builds for updates that must preserve sessions.

For ongoing use, generate your own release keystore once, back it up securely and do not commit it. For example, using your JDK's keytool:

```sh
keytool -genkeypair -v -keystore fairway-release.jks -alias fairway -keyalg RSA -keysize 3072 -validity 10000
```

Set environment variables ANDROID_KEYSTORE (absolute path), ANDROID_STORE_PASSWORD, ANDROID_KEY_ALIAS and ANDROID_KEY_PASSWORD in your shell or CI secrets, without committing their values. Then run:

```sh
npm run assets
npm test
bash scripts/build-android.sh assembleRelease
```

Install the signed APK from `android/app/build/outputs/apk/release/`. For Play Store publication, use a signed Android App Bundle and follow the current store submission process; publication is not included in this source delivery.

## Before trusting an update

Use representative videos from both hands and multiple throw types. Check overlay alignment at pauses and during playback, release marking, poor lighting, occluded joints and no-person footage. Verify that a missing or ambiguous disc stops a trace and that an incorrect similar-color match can be cleared. Test a 20-second upload, rejection of longer clips, denied camera permission, native-camera fallback, recording interruption, saving/reopening, exports, offline start and updating the APK while preserving sessions.

## Version 1.1.0 update

See RELEASE-1.1.0.md for the phone update steps. The existing working ZIP-upload workflow can stay in place. The new source's build script runs its browser smoke check on CI before compilation, and bundles Lite, Full, Heavy and hand models. Keep the same repository, workflow path, encrypted signing key and password. Default local versionCode is 4; the existing CI run-number property overrides it for distributed updates.

The IndexedDB upgrade preserves sessions and adds bag/catalog stores. Core measurements now live in geometry.js, phases.js and analysis.js. Hand model loading and source-image cropping live in pose.js. report-ui.js builds review cards and the local walkthrough. knowledge.js contains 38 lessons and source records. discs.js contains 50 initial catalog facts and import validation; discs-ui.js handles the bag interface. scripts/browser-smoke.mjs adds real-browser and model initialization checks to CI. It is not an app demo and its fixture data is never bundled into the normal interface.
