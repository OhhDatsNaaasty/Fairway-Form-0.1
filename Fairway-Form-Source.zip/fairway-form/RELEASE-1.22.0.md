# Final Form - Disc Golf 1.22.0

This combined update contains the 1.21.0 video decoding changes, gold/black coaching replay buttons, My Bag search and alphabetical/numeric speed sorting, and exact catalog speed filtering. You can update directly from your currently installed version; installing 1.21.0 first is unnecessary.

The catalog adds 242 sourced models and explicitly named rated versions, bringing it to 1,092 entries across the existing 28 brands. The audit accounts for all 995 rows in the reviewed, fully paginated reference inventories. Manufacturer directories and individual model/release pages were checked where available. Alternate brand/retail names and ASCII Loft searches now resolve to the same canonical records. Source publishers appear on the catalog cards.

This is a dated coverage audit, not certification of every historical prototype, cosmetic stamp, plastic or undisclosed release. Manufacturer and reference sources can disagree. New manufacturer-verified values take priority; other new entries remain clearly labeled Reference catalog. The original 850 entries keep their IDs, names and ratings, preserving existing bag records and histories. Explicitly different tooling/run references have named records instead of silently changing old copies. See DISC-CATALOG-AUDIT-1.22.0.md and scripts/catalog-audit-inventory-1.22.0.json for per-brand counts, sources, exclusions and coverage limits.

Notable additions include Discraft Cigarra/Fossil/Crank SS/Challenger variants, Axiom Pitch/Trance/Inspire/Thrill, Streamline Autopilot/Engine/Parachute/Shift, MVP Stasis/Mass, Kastaplast Nord/Stig/Tuff and a retooled Kaxe, more Gateway and Millennium models, Infinite Anubis/Maya/Scepter/Glyph, and a much wider Yikun lineup. Manufacturer-confirmed reference corrections include Gateway Air Strike at 13/5/-2/2. Mass retains explicitly tentative manufacturer numbers, and Qi has an explicit source conflict; Caddy discloses those uncertainties if selected. Missing product photos remain labeled unavailable; no unrelated or generated picture substitutes for a verified photo.

## Video review changes included

On supported phones, body review reads forward through real decoded frames, freezes each image during inference, and uses browser-reported presented-frame timestamps. Optional hand detail uses one rewind followed by a forward release-window pass. The initial seek also runs the decoder, avoiding a paused-MP4 stall reproduced during testing. It does not generate intermediate frames or recover hidden hand positions. Unsupported/corrupt codecs can still fail, and original failing clips need phone validation.

## Validation

- 619 JavaScript checks passed, zero failures. Added regressions protect all 850 shipped identities/ratings, reconcile every audited brand/count, resolve all reviewed reference rows, check new flight information, test aliases/variants and disclose uncertain references in Caddy. Fractional exact-speed filtering is also covered.
- The unchanged 1.21.0 decoding pipeline and gold-button styles passed real mobile Chrome checks with bundled pose/hand models, real no-person footage, interruption recovery, bag search/sort, exact speeds and contrast across all palettes/modes.
- Real H.264 24/30/60fps fixtures completed body and near-tail hand review with two currentTime assignments per clip. The fixtures are original synthetic patterns; QA pose tokens test orchestration, not real-person coaching accuracy.
- The additional 1.22.0 real-browser catalog recheck could not complete because its launch stalled. The expanded browser/model gate remains mandatory in GitHub; no full 1.22.0 local browser pass is claimed.
- Static syntax/import/offline-shell, control IDs, Android XML/shell and version checks passed. Native lifecycle/camera rules and approved intro bytes are checked separately.
- No local signed APK compilation or Pixel device verification is claimed. GitHub compiles, signs and verifies the installable APK.

## Install from your phone

Replace repository-root Fairway-Form-Source.zip with this archive and commit in the same private repository. Keep the existing workflow and signing credentials. Once Actions succeeds, download Fairway-Form-APK, extract Fairway-Form.apk and install over your current app without uninstalling.

Retest the clip that failed, with hand detail enabled. Verify gold Watch review moment buttons, bag search/sort and Exact speed. Try newly added models and alternate names such as Above Ground Level Dogwood, Loft Neon, Yikun Yangjian and Innova Firefly. Previously saved bag copies, throw logs, photos and courses should remain available.

Package com.fairwayform.app, origin https://appassets.androidplatform.net, IndexedDB schema 5, signing flow, startup movie and storage identifiers are unchanged. Source 1.22.0; local Android versionCode 40, with CI supplying its increasing code. Regression video fixtures are outside dist and are excluded from APK web assets.
