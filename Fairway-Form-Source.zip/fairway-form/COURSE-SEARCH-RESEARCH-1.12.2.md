# PlanetDG review and course-search repair

Reviewed 2026-10-23. This supersedes the download/availability limitations described for 1.12.0; existing OSM provenance and import-review rules remain.

## What PlanetDG provides

PlanetDG describes itself as an open-source course map, with all courses derived from OpenStreetMap and its website refreshed hourly. Its Explore page reported 2,735 mapped courses across 38 countries when reviewed, including 1,405 US courses. These are website observations, not counts promised for our app. Our directory excludes unnamed course records and may differ. It is useful for browsing, but it does not give us a separate complete inventory or guaranteed hole details/OB.

- https://planetdg.com/osm/
- https://planetdg.com/explore/
- https://planetdg.com/contribute.html
- https://planetdg.com/osm/tagging/

We could verify the data source and OSM license, but did not locate a documented PlanetDG bulk-download endpoint, public repository with a verifiable code license, or a commercial API agreement. A site's statement that it is open source does not by itself specify permission to copy its code, images, styles or server service. This release therefore links to PlanetDG in the external browser; it does not scrape/clone the website, guess private API endpoints, or imply a partnership. It obtains open map facts directly through published Overpass endpoints. Opening PlanetDG does not automatically import its selected course into our app.

## Why the prior search could be empty

The source bundle starts with an empty, explicit course-data placeholder. The prior build made one large global request containing courses plus hole geometry. If that request failed, the assets step caught the error and still succeeded, leaving the search unavailable in an otherwise successful APK. The browser smoke check explicitly allowed this state. We cannot inspect the user's installed APK or prior Actions logs here, so this is a confirmed failure path, not a proven diagnosis of their particular installation.

Location searches also required mapped address tags; many course records lack those. Name search required every typed token, so adding 'DGC' to a course whose OSM name did not contain it could hide the course. Unicode normalization previously retained accent-combining marks as separators. Both name-matching problems are repaired. The UI explains the remaining location-tag and OSM coverage limitations.

## Download and packaging changes

A compact course-only request runs first, using tags, relation bodies and centers. Only after that succeeds does a separate optional request add mapped hole routes. Hole-download failure preserves a usable name directory, or keeps an existing dated snapshot with routes rather than discarding it. A second documented global provider is tried if the directory request fails. Requests are sequential, bounded by size/time, and sent only at build time. A validated snapshot less than seven days old is reused when present in the build workspace. This is not a cross-run GitHub cache; the existing phone workflow's fresh extraction may download again.

Primary provider:
https://overpass.private.coffee/
https://overpass.private.coffee/api/interpreter

Its published terms explicitly permit commercial projects, prefer POST, require fair resource use, and ask advance notice for large operations. There are at most three sequential requests per refresh: a failed first directory attempt, a successful second attempt, and one geometry request. No phone search terms, player information or GPS coordinates are sent. The fallback endpoint is published in the OSM instance directory with permission for any project:
https://maps.mail.ru/osm/tools/overpass/api/interpreter
https://wiki.openstreetmap.org/wiki/Overpass_API

The old overpass-api.de default was replaced; its current public-instance guidance recommends paid/self-hosted servers for commercial use. Before significant release/build traffic, use an owned cached extract or a suitable hosting agreement. Public data licensing does not guarantee free server capacity.

Both the downloader and APK packaging require a valid dated snapshot with at least 250 named courses. This is an intentionally conservative sanity check against an empty or accidentally tiny global extract, not a claim of complete coverage. A refresh also rejects a sudden loss of more than a quarter of the existing directory. Failure with no valid previous snapshot now stops the build with an explicit error; it cannot silently distribute an empty search. Browser CI must search an actual bundled course and open its import preview; it no longer accepts empty data as success. ODbL attribution/export and confirmation of unknown hole facts remain in place.

## License

OSM data is available under ODbL 1.0 with attribution and applicable share-alike/database-availability obligations. Commercial use is allowed; open course facts do not become our exclusive property. The map database can be exported separately from personal bags, profiles and throw history. No UDisc data is copied.

https://www.openstreetmap.org/copyright
https://opendatacommons.org/licenses/odbl/1-0/

## Verification limit

This execution workspace cannot connect to its configured network proxy. Research pages were accessible through the web research tool, but an actual bulk course download was not. Download/error/fallback tests use isolated synthetic fixtures that are never bundled as courses. GitHub Actions must run npm run assets, print actual course and route counts, pass the browser import check and compile the APK. No local APK or real worldwide dataset download is claimed.
