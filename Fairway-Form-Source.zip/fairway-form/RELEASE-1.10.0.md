# Fairway Form 1.10.0 — a focused, faster course caddy

## One task on screen

Caddy now has Set up, Throw, Result and More controls. The active task owns the page; unrelated panels are hidden and inactive. Set up keeps the core distance, par, throw and fairway fields visible. Course metadata, shot options, landing point/OB, wind and detailed profiles are expandable. Throw shows the plan and measurement; starting a measurement gives the capture the focus. Result shows the actual disc, multiple result selections and carry/remaining distance. More holds old logs, player defaults and explanatory material.

## Measurement saves to the disc

Choose the physical bag disc before starting. GPS can accept a fresh accurate stationary fix after two seconds instead of the previous eight-second minimum; the capture has a 15-second limit. Time waiting for a provider fix or permission can still vary. Reported endpoint uncertainty stays visible and GPS cannot promise 1–2 foot accuracy.

Save distance to disc now writes an entry visible in that disc's profile immediately. It retains the actual bag copy, hand/style, distance source and GPS uncertainty. Finish the Result to update that same throw, without duplicating it. An unfinished result remains labeled and cannot train a normal-carry reference. Switching screens/reopening the app retains the saved distance. Manual correction retains the record ID. The hole-finish action asks you to complete saved throw feedback rather than dropping its distance.

GPS averages/farthest estimates are more visible in the disc profile and remain separate from measured-distance statistics. Existing quality gates still apply to learned carry; the app does not turn an uncertain estimate into an exact measurement.

## Made putts and combined results

Choose Made, then **Save made shot & next hole**. The finished hole is saved before the app loads the next saved hole, or opens setup for the next unsaved hole. It also works for a holed-out approach. A prominent Next hole action remains for manually finished holes or a failed next-hole load. Storage failures leave the completed hole saved and offer a retry.

Result supports combinations such as Short + Left. Incompatible combinations are prevented; Made clears miss selections. Both observations are retained in history, backups and disc-profile result counts, while a throw still counts once.

## One setup form for courses and recommendations

Add new course, enter the course name and hole number, par, distance, fairway, elevation and OB/notes in the same setup form used for the disc recommendation. Enable Save this tee layout to My Courses. Save hole layout or request the recommendation to retain it. Partial setup fields also survive leaving/reopening Caddy.

After a made putt, the next unsaved hole opens with the same course context so you can add holes as you play. Later-lie distances do not overwrite tee distance or route. Par remains editable. Slight dogleg left/right and combos left-then-right/right-then-left are supported. Combo advice recommends choosing a reachable gap/corner and reassessing rather than treating the entire S-shaped route as one guaranteed flight.

The notebook stores the confirmed layout per hole. Use separate course names for parallel complete tee/basket layouts. This is not yet a public course database or full scorecard system.

## Hole-sign analysis

The Android OCR bridge now returns text positions as well as text. Photo selection starts analysis automatically in the APK. Recognized hole number, par, explicit-unit distances, elevation, sided OB and literal route descriptions become editable setup suggestions. Multiple distances/pars require choosing the active ones.

Local diagram analysis can propose tee/basket endpoints and trace connected sign strokes, including gentle and multiple bends. Visible tee/basket labels help orient the route. Unlabeled endpoints need review; the initial proposed tee is the lower endpoint. Swap tee/basket or correct the markers, including a second bend, when necessary. No route is synthesized into the photograph.

The last confirmed tee/basket labels are remembered per course. Each new hole sign asks whether you are still using them. Keep the same setup or change it when alternating. An uncertain diagram still needs its markers reviewed before applying. The active pin cannot be established merely because its symbol appears on a sign.

These are genuine on-device OCR and pixel-analysis operations, with limits rather than guaranteed scene understanding. Reflections, complex drawings, unlabeled icons, broken route strokes and multiple overlapping routes can fail. The result never establishes a safe gap, true map distance or current basket installation. See FIELDWORK-RESEARCH-1.10.0.md for sources and details.

## Update on your phone

Replace the repository-root Fairway-Form-Source.zip in the same GitHub repository and commit. Keep the exact filename, workflow, .fairway-signing.enc and APP_SIGNING_PASSWORD. After Actions succeeds, download/extract Fairway-Form-APK and install Fairway-Form.apk over the current app. Do not uninstall or clear app data. Settings should show Version 1.10.0.

Package com.fairwayform.app, app origin and signing identity remain unchanged. Database schema remains 5. Existing sessions, bags, per-disc histories, courses and profiles remain. The local Android versionCode default is 23; CI still supplies its run number. Back up your bag/history, courses and player profile before updating.

## Verification

396 automated tests cover the previous features and the new workflow, immediate GPS-profile visibility, same-ID finalization, actual disc/style retention, empty pin distance, multiple results and backup round trips, fast capture, made-putt advancement, shared course setup, slight/combo routes, label/pixel diagram analysis, blank-image rejection, and per-hole keep/change tee confirmation.

JS/import/control/offline-shell checks, HTML nesting, embedded browser expression syntax, Android XML and shell/version checks are separate. Full browser/model smoke checks and signed Android compilation still run in GitHub Actions; this workspace cannot run the required browser/Android SDK build. The ZIP contains editable source, not an APK built here. Real signs, GPS and native OCR still need phone verification.

## Field checks

- Start a course, add its first hole in setup, and request a disc. Confirm that only the active task is shown.
- Measure a throw, select the disc and save. Open its profile before finishing feedback: the GPS distance should already appear. Complete Result, then confirm it still appears once.
- Select Short + Left and verify both in history. Make a putt and save: verify the old hole is finished and the next hole is ready.
- Add that next hole's par/distance/route and confirm the previous tee layout is unchanged. Test feet/meters.
- Photograph a real sign. Verify hole/par/distance and proposed route markers. Try Long on one hole, keep it on the next, then change to Short. Confirm the prompt asks each time and permits the change.
