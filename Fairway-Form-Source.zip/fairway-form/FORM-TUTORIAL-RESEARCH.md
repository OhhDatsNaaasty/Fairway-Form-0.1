# Tutorial research and video review (1.24.0)

Research can improve the event definitions, checks and explanations used by the
app. Reading a transcript does not retrain MediaPipe, establish correct form for
every player, or prove a detector became more accurate. This release makes that
distinction explicit and connects the research to reviewable changes.

## What was accessible

Nine source records were reviewed on 2026-10-31. Three publisher-hosted Overthrow
transcripts were readable: Building the Brace, Extension Out of the Pocket, and
Proper Posture. UDisc's backhand and forehand articles supplied written,
time-indexed video guides. Innova's X-step PDF was read and its illustrated page
was visually inspected. The remaining material was coach/manufacturer/analysis
articles. Direct YouTube playback failed; tutorial thumbnails were unavailable.
No claim is made that complete tutorial videos were watched.

The machine-readable audit is research/form-tutorial-review-1.24.0.json. Existing
source IDs were retained, two new resources were added, and reviewed resources
now disclose their access type in the technique library. No full transcript,
third-party video or professional screenshot is bundled. The app ships original
teaching notes and links. Tutorial footage would need appropriate permission
before redistribution or inclusion in a training corpus.

The most useful research points were:

- Distinguish an isolated drill from the full throw. A fixed-base exercise is
  not a requirement to freeze the feet during every finish.
- Examine the sequence after an arm bend, rather than treating a single bent
  elbow as proof of a power pocket.
- Verify foot contact visually; slowing an ankle is not evidence of pressure.
- Match events before comparing body shapes, and account for the camera and
  intended shot. Forehand instruction needs its own context.

The numerical tolerances in the app remain engineering heuristics. The resources
do not validate those thresholds or promise injury prevention.

## Implemented in the app

Seven source-linked lessons were added, taking the library from 81 to 88 lessons
and from 63 to 65 linked resources. Original lesson IDs are preserved. New topics
cover crossover, contact, arm loading, release, posture, forehand review and
comparison by events.

Inside detailed coaching, “Read your throw as a sequence” starts collapsed. It
shows plain-language checks and links to the relevant lesson. In Android
prepared-frame mode it also shows the user's own nearby source stills, labeled
with their source times and whether the event was marked or suggested. Missing
events remain missing. Forehand cards do not use the backhand crossover or
power-pocket model. No professional-pose similarity score is calculated.

Arm-loading candidates now require visible opening afterward and follow the
suggested backswing when one is available. The automatic backhand cue is not
applied to a forehand. Foot-contact candidates require visible ankle, heel and
toe samples near the observed low foot level, alongside sustained settling.
This rejects the regression case of a raised foot pausing in the air. It still
does not prove ground contact, loading, forces or good biomechanics. User
markers remain authoritative.

## How to measure accuracy next

The source includes scripts/lib/form-benchmark.mjs and tests for an interval
scorer. It compares predicted events with independently labeled earliest/latest
times, distinguishing hits, wrong times, missed events and suggestions for
unobservable/not-applicable events. Unlabeled predictions cannot inflate its
metrics. The current tests use synthetic cases to verify software behavior;
there are no real-throw benchmark clips or accuracy results in this release.

A useful real-data evaluation should:

1. Use authorized original clips with reliable timestamps, covering both hands,
   backhand/forehand, standstill/walk-up, camera views, frame rates and player
   variation. Keep recordings from the same player together when splitting
   development and held-out evaluation sets.
2. Have a reviewer label events independently of the detector's predictions.
   Use intervals when a release falls between the last held and first separate
   frame. Mark hidden events unobservable and inapplicable events explicitly.
3. Compare the old and new detectors on the same held-out clips. Measure error,
   missed-event rate and unsupported suggestions for each event and camera view.
   Do not feed the correct manual markers into an automatic-detection benchmark.
4. Retain examples where the detector is wrong, and have disputed annotations
   reviewed. Synthetic coordinates, tutorial descriptions and passing browser
   checks are not substitutes for this evaluation.

Example annotation shape (a format example, not a real clip label):

```json
{
  "clipId": "example-only",
  "hand": "right",
  "type": "backhand",
  "view": "side",
  "permissionRecord": "required-for-real-footage",
  "events": {
    "release": {"status": "visible", "earliest": 1.0, "latest": 1.033},
    "pocket": {"status": "unobservable"},
    "crossover": {"status": "not-applicable"}
  }
}
```

No footage or user videos are uploaded for research or training by this change.
The pose-model weights and the native decoding implementation are unchanged.
Target-phone decoding and real throw-event accuracy still need verification.

## Principal links

- https://www.overthrowdiscgolf.academy/lessons/building-the-brace
- https://www.overthrowdiscgolf.academy/lessons/extension-out-of-the-pocket
- https://www.overthrowdiscgolf.academy/lessons/proper-posture
- https://udisc.com/blog/post/5-great-videos-how-to-throw-backhand-in-disc-golf
- https://udisc.com/blog/post/5-great-videos-how-to-forehandsidearm-in-disc-golf
- https://www.innovadiscs.com/wp-content/uploads/pdf/X-Step_how-to.pdf
- https://www.innovadiscs.com/tips/how-to-throw-backhands-really-far/
- https://www.pdga.com/news/three-keys-better-sidearm
- https://discgolf.ultiworld.com/2022/03/23/creating-the-form-shadow/
