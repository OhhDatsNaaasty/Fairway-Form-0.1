# Fairway Form 1.8.0 — measure every throw and track your putting

## Measurement in What happened?

The top of **What happened?** now has the same Start/Stop, Save throw, Cancel and feet/meters controls as the main measurement area. Both locations share one active capture: you can start at the top, finish from feedback, and see the same result in both places.

The title identifies the current throw. Saving fills that throw's Actual throw carry; recording it clears the measurement and prepares the next throw. It is not limited to the tee shot. A measured distance stays separate from distance left to the basket. GPS uncertainty is still shown, and saved logs retain the GPS source/accuracy details.

Start must be captured at the release point before walking to the first landing. A feedback button cannot reconstruct an unmarked release point after the throw. Save throw saves the distance draft; Record throw saves the full feedback and advances the lie.

## Putting caddy

A new **How far to the pin?** card mirrors the existing basket-distance field. Enter the approximate distance from the current lie. Within 50 feet (15.24 meters), the app asks whether you are putting before generating a plan. Choose Yes for the putting caddy or No to keep your throwing style. You can also mark a putt at any distance; 50 feet is a prompt, not a limit.

The putting section offers putters actually in your bag, putting comfort/risk controls and your per-copy accuracy profiles. Wind, slope, trouble, hand, release, disc condition, notes and the rest of the existing profile features remain. More established, comparable putting results can modestly inform the recommendation, alongside your preferred/trusted putter and conditions. The app does not invent a make probability for a new putter or force a driver into a putting recommendation.

In What happened?, **This putt** records:

- Starting distance from the lie to the pin, with approximate/measured source.
- Trying to make it, laying up, or not recorded.
- Made, Missed, or not recorded; the existing result field stays synchronized.
- All existing actual-shot, execution, flight, weather and note fields.

Made finishes the hole. A miss lets you enter the actual next-lie distance and plan again. Each new throw clears the old mode decision and heading so a nearby next lie can ask again. Declining putting preserves a forehand/backhand choice.

## Your putter's accuracy

Each physical bag copy keeps make percentages, makes and attempts in the four bands you chose:

- 0–10 feet (positive distances through exactly 10).
- Greater than 10 through 20 feet.
- Greater than 20 through 25 feet.
- Greater than 25 feet.

Meters are available in Caddy; the underlying boundaries stay in feet. No attempts shows a dash, while confirmed misses can legitimately show 0%. Layups, unknown results, missing distances and unrecorded intent stay outside the denominator. Putter drives are not putting attempts. Execution misses still count in accuracy, rather than selectively counting only clean putts.

Starting distance to the pin, GPS carry and remaining distance are three separate values. A missed 20-foot putt that flies 24 feet and leaves 6 feet records all three independently. GPS is generally too uncertain to establish short-putt distance reliably; enter an approximate start distance or a tape/suitable-rangefinder measurement instead.

Disc room's existing feedback correction now includes putting start distance/source and intent. Correcting these recalculates the bands; the original made/missed result and hole sequence remain. Bag backups include the new data, while old backups still load. Older putting logs need a known run/layup intent for accuracy; unknown intent stays unclassified until corrected. No new database store or duplicate statistics table is introduced.

At least five confirmed attempts in the same distance band, throwing hand and comparable wind/slope/wet/temperature conditions are needed before observed accuracy changes putter ranking. The adjustment is bounded and sparse samples are pulled toward neutral. Overall profile percentages remain descriptive history, not guaranteed odds for a future putt.

## Guidance and rules

New guidance uses PDGA putting-area rules, Innova's putting/routine material, Discmania's realistic-practice advice and existing manufacturer resources. The official putting-area boundary is 10 meters (about 32.8 feet), not the app's 50-foot prompt. The app reminds you about balance inside the area and legal release/support outside it. See PUTTING-RESEARCH-1.8.0.md for sources and the limits of the recommendation rules.

## Update on your Android phone

Replace the repository-root **Fairway-Form-Source.zip** in the SAME GitHub repository and commit it. Keep that exact filename, existing workflow, APP_SIGNING_PASSWORD and .fairway-signing.enc. When Actions succeeds, download/extract Fairway-Form-APK and install Fairway-Form.apk over the existing app. App & settings should show Version 1.8.0.

This update includes GPS measurement, the phone compass and previous coaching/catalog features. Package com.fairwayform.app, the appassets origin, database version 4, signing identity and Kotlin BOM fix remain. Local versionCode is 20; CI continues to provide an increasing run-based code. No new native permission or dependency is needed.

## Verification and phone checks

364 automated tests pass, including 19 new putting tests and 11 new caddy integration tests. Tests cover a drive followed by missed/made putts, both measurement locations across later throws, no double-counting, range boundaries, meters, layups, unknown data, real-bag eligibility, matched-condition evidence, corrections and backups. Static JavaScript/import/HTML/cache/XML/shell/version/native wiring checks pass. Embedded browser-check scripts parse; CI smoke now exercises putting feedback, the shared measurement controls, actual profile editing and backup provenance with controlled test data.

Full browser/model smoke and signed APK compilation remain for GitHub Actions. Local Chromium is blocked by workspace socket restrictions; no Android SDK/Gradle setup is configured here. This is editable source, not an already compiled APK. GPS/compass and the new layout still need testing on your phone.

On the phone: start measurement at the top and finish/save in feedback; repeat on throw 2; enter 50 feet and try both answers; try meters; mark a longer putt explicitly; record a missed 20-foot putt followed by a made 8-foot putt; check each putter's bands in Disc room; exclude a layup; correct the starting distance; and export/restore your bag history. No data should move between physical bag copies or be counted twice.
