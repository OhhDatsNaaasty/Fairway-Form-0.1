# Fairway Form 1.9.0 — more discs, a simpler Caddy, My Courses

## Disc catalog

850 bundled molds across 28 brands, up from 302 across 10. All original brands remain, with expanded model coverage. Added brands include AGL, Clash, Climo, DGA, Gateway, Infinite, Kastaplast, Legacy, Lone Star, Løft, Millennium, Mint, RPM, Stokely, Streamline, Thought Space Athletics, Viking and Yikun.

312 entries use manufacturer sources; 538 additions use clearly labeled reference catalog snapshots. Original manufacturer numbers, version notes and all 302 previous IDs are preserved. This protects existing bags and learned per-copy histories. Missing flight numbers are not guessed. Catalog coverage is broader, not a claim of every mold ever manufactured. New entries without a verified photo use an explicit unavailable state. See DISC-CATALOG-EXPANSION-1.9.0.md for counts, sources and limitations.

The reviewed data snapshots and an offline catalog rebuild script are included, so future mold additions do not depend on this conversation. Run `node scripts/build-catalog.mjs`, then test and rebuild the APK.

## A clearer Caddy flow

My Courses appears at the top. Measure throw stays prominent. Once you ask for a recommendation, the plan and What happened? appear together directly below the main measurement card. The leading disc/shot is shown first; alternatives, detailed flight/range explanations and planning sources stay available in closed sections. What happened? follows the recommendation without unrelated setup cards between them.

Basic result, disc used, distance left and carry stay easy to reach. Optional release/execution/flight details remain in a drop-down. The synchronized measurement controls and all putting feedback fields remain. A large **Save throw N & next throw →** button saves the feedback and advances to that throw's next lie. A Next throw shortcut leads to the save button. After saving, Caddy returns to the distance-to-pin field, with a nearby Choose disc for this lie button. Profile defaults, old round logs and hole history are collapsed by default.

The measurement's Save throw button still saves only the distance draft. The larger feedback save button records the full shot and advances the counter. Existing GPS accuracy limits and separate putting-start/throw-carry/remaining distances are retained.

## My Courses

Save a course name and hole number, par, tee-to-basket distance, fairway direction, elevation, hazards/OB, wooded flag and notes. Distances default to feet, with a meters option. Course data is stored locally and works offline.

Choose a saved course and hole to preview the layout. **Play this hole** loads its tee details into Caddy and starts a new independent round log using your current player defaults. It preserves the previous log. Weather, wind direction and personal limits are not baked into the course template. Your current course/hole/par stays visible.

Add or edit layouts in the collapsed editor and choose **Save course & hole**. Changing the hole number lets you add the next hole without creating another course. Copy current tee setup can copy the existing Caddy fields into the editor; it refuses later lies so a 50-foot remaining putt cannot replace a 750-foot tee distance. For alternate tee/basket sets, use distinct course names for now.

After finishing a hole, **Next course hole** starts the next saved hole in numeric order. Existing practice holes and saved round logs still work separately. Throw feedback keeps its course/hole/par association, while the saved tee layout stays unchanged. This is a local course notebook, not a public course database, live map or full scorecard service.

My Courses has its own JSON export/restore. Restore validates all layouts before merging by course ID. It does not replace bag, player, video or round history. Bag/throw-history backup and the full per-hole log export remain separate.

## Phone update

1. Download the new Fairway-Form-Source.zip.
2. Replace the repository-root ZIP in the same GitHub repository and commit. Keep the exact filename, existing workflow, `.fairway-signing.enc` and `APP_SIGNING_PASSWORD`.
3. When Actions succeeds, download and extract Fairway-Form-APK. Install Fairway-Form.apk over the current app.
4. App & settings should display Version 1.9.0. Do not uninstall or clear app data. Back up your bag/throw history and player profile before installing.

The package remains `com.fairwayform.app` and the app origin remains `https://appassets.androidplatform.net`. IndexedDB upgrades from version 4 to 5 by adding only the courses store. Existing sessions, bag copies, imported catalog, player record and caddy logs remain in their stores. CI still supplies its run-number Android versionCode; the local default is 21. Kotlin runtime alignment is unchanged.

## Validation

374 automated tests pass, including new course validation, multiple-hole editing, feet/meters conversion, fresh-round recall, per-throw advancement, putting/history preservation, course tee isolation, saved-course reopening, next-hole progression, storage-failure recovery, and preservation of every original catalog ID. JavaScript/imports, HTML controls and nesting, offline shell files, Android XML/shell scripts and release versions are checked separately.

The GitHub browser smoke checks now exercise the v4-to-v5 database upgrade, all 28 brand filters/full pagination, course persistence across reload, actual course selection/play, feedback ordering and next-hole progression. Full browser/model checks and signed Android compilation must run in GitHub Actions; this workspace cannot launch the required browser/SDK. This package is editable source, not an APK built here.

## Phone checks

- Confirm your bag copies, learned ranges, putting percentages, profile and saved sessions remain.
- Browse a newly added brand and search for a previously missing mold. Confirm source labels and image fallbacks.
- Add one course with two holes and different par, distance, hazards and fairway directions. Close/reopen the app, select it and play hole 1.
- Get a recommendation. Confirm What happened? is immediately below it, with alternatives and detailed explanations collapsed.
- Measure or enter a throw, save feedback and check that the next lie uses the entered distance left while the saved tee distance is unchanged.
- Finish the hole and use Next course hole. Confirm a fresh throw-1 log and the next hole's par/layout.
- Export My Courses and restore it. Verify your bag/throw history is unaffected. Test putting and GPS on subsequent throws as before.
