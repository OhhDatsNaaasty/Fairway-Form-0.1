# Fairway Form 1.13.0

Optional Android camera measurement is added to Caddy for nearby basket distances and walked throw estimates. It supplements GPS. It does not guarantee better accuracy than GPS or replace a laser rangefinder.

## Use it on your Pixel

From Plan, choose **Camera · nearby basket (≤33 ft)**. Stand at your lie, aim at ground at the basket base and follow the scanning/steady-camera guidance. Capture freezes a result; acknowledge the estimate and tap Use estimate to fill distance to pin. This mode is limited to 10 meters. Google's best depth accuracy is roughly 0.5–5 meters, so even accepted readings need checking.

From Throw → Measure throw → Camera measurement, choose **Camera · walk this throw**. It is also accessible from the measurement section in What happened?. Select the actual disc first. After throwing, return to the release spot, scan/mark it, keep the camera uncovered while walking to the first landing spot, then scan that spot and Stop. Use estimate saves carry to this throw and disc and opens feedback. It works on later throws too. Reset/Cancel preserve the existing saved information. Camera walks are limited to 150 meters and five minutes and can drift; tracking loss or interruptions invalidate them.

The first launch may request camera permission and installation/update of Google Play Services for AR. Both Pixel 10 Pro and Pro XL are listed for Depth support, but the app checks at runtime. Unsupported devices/browser users retain GPS/manual input.

Camera estimates retain their source in the disc history and backups and stay separate from measured averages and power references. Basket distance and throw carry are separate. Your existing bag, courses, profiles and throw logs remain compatible; no package/origin/signing identity or database-schema change is required.

## GPS correction

GPS can no longer accept a 25-meter endpoint at the deadline. Each new endpoint needs reported accuracy of 8 meters or better. Save is blocked when combined reported uncertainty exceeds 20% of this throw's distance. This reduces obviously unsuitable measurements; it does not guarantee an error bound or eliminate tree-cover/multipath errors. Existing GPS history is retained.

## Update from your Android phone

Replace the private repository's root **Fairway-Form-Source.zip** with this download using the exact filename and commit it. Keep the existing workflow, encrypted signing key and APP_SIGNING_PASSWORD. After Actions succeeds, download/extract **Fairway-Form-APK** and install **Fairway-Form.apk** over the current app. Do not uninstall or clear data. Settings should show **Version 1.13.0**. Local versionCode fallback is 28; CI supplies its run number.

## Verification and limits

455 JavaScript tests and 19 compiled native measurement-rule checks pass. Java syntax, imports, control IDs, offline shell, XML and shell/version checks pass. The Android build runs the native rule checks before its browser/model and Gradle build steps. Browser CI also checks that camera measurement has a clear native-device fallback.

Full Android/ARCore compilation, the signed APK and actual camera accuracy must still be verified through GitHub Actions and field testing on your Pixel. No APK was compiled locally. Camera readings must be compared with known tape/laser distances before relying on them. See CAMERA-RANGE-RESEARCH-1.13.0.md for the sources, limitations and test checklist. The download contains editable source, not sensor-tested accuracy guarantees or sample measurement data.
