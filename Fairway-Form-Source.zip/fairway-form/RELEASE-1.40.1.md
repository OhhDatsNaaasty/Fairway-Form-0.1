# Final Form - Disc Golf 1.40.1

## Landing picker correction

The GitHub browser gate reported “Landing placement scrolled the page” after a vertical touch on the 3D landing picker. This patch addresses two code-level weaknesses: task transitions can still be smooth-scrolling when the modal opens, and the bottom-anchored sheet previously changed height when its distance label wrapped. A local real-browser reproduction remains blocked by environment permissions; the exact movement in the user's run cannot be determined from the old diagnostics alone.

Opening the scene sheet now cancels pending page scrolling and retains the background position. The open scene sheet prevents background overflow/overscroll. Landing placement uses a fixed-height flex sheet, a flexible drawing, reserved status space and visible confirmation controls. The orbit toolbar is available after choosing Rotate view; placement keeps it collapsed. Leaving or closing the picker removes its special layout and stops animation.

The mandatory browser gate retains its no-scroll assertion and now exercises vertical placement at 320×568, 480×844 and 390×844. It waits for rendered coordinates, verifies the actual touch hits the drawing, checks unchanged drawing position/height and SVG identity, and reports the before/after scroll positions of the page and each ancestor if anything moves. The existing next-lie, approximate-distance and profile checks remain required. The gesture now ends at the known route point, rather than dragging away from it while expecting its original next-lie values; unit tests verify the same serialized coordinate helper against the real terrain projection.

## Pixel 10 Pro XL

The user's phone model is recorded in the measurement research note. Google's advertised dual-band GNSS capability is registered in the searchable library with provenance. Hardware support is not proof of actual ten-foot accuracy, and no measurement thresholds or evidence weights are weakened for this model.

## Validation

All 1,079 automated tests and 58 native host-rule checks passed. Syntax, retained controls, offline paths and archive verification are recorded in the accompanying verification.json. The fresh local full-browser check is BLOCKED by workspace socket permissions before tests run. An isolated Chromium startup also failed with a socket permission error. No local real-browser, physical-phone accuracy or signed APK pass is claimed. The GitHub browser/model/native/APK gates remain required.

## Install

Replace the repository-root Fairway-Form-Source.zip, keeping that exact filename. Run the existing GitHub workflow. After every required check passes, install its signed APK over the current app. Package, signing configuration, origin, storage identities and saved data are unchanged. Version name: 1.40.1. Fallback versionCode: 68; CI keeps its increasing code policy.
