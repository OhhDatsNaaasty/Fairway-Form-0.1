# Final Form - Disc Golf 1.28.1

Fixes the hole-sign marker redraw path and hardens the browser drag check that
blocked the supplied GitHub build. The new runtime keeps each SVG handle
connected and updates its coordinates, hit circle, label and route in place.
Pointer capture and keyboard focus no longer depend on handles being recreated
for every pointer event. Adding/removing other markers remains supported.

The browser check now finishes scrolling with an instant scroll, waits for
layout, hit-tests the visible marker center and sends explicit mouse-button
state. It checks actual coordinate movement and identity of the original live
handle. A separate protocol touch gesture tests the phone interaction path.
Failures include Caddy state, sign status, marker/viewport coordinates and
recent pointer/capture events. The active-tee/basket, reanalysis-retention,
course-save, video/model, native and APK checks remain required.

The supplied 1.28.0 log proves that the first tee movement assertion failed;
it did not record the target/coordinates. The redraw pattern was confirmed by
source inspection. This patch addresses both target replacement and unsettled
input coordinates, but this exact Chrome failure was not reproduced locally.
No claim of a completed browser/phone pass is made.

## Verification

747 JavaScript tests passed; zero failures, skips or cancellations. Eight new
regressions cover retaining SVG-node identity during movement/cancellation,
resizing/removing other points, settled input coordinates, blocked targets,
no-motion diagnostics and rejecting a replacement handle. Existing Caddy/course
and hole-sign tests remain included. Syntax checks passed for 87 JS/MJS files;
all 19 serialized browser checked-step expressions parsed and all 97 offline
shell paths exist.

Local npm run test:browser was BLOCKED by socket EPERM (run
4c987d57-ec61-4e09-a99d-fb6250a25c09, 2026-11-02). A small diagnostic Chrome
launch also encountered a socket restriction. Neither is a browser pass.
The required GitHub browser/model gate must run successfully before an APK is
accepted. No local signed APK or physical-phone verification was performed.

## Update

Replace the SAME repository-root Fairway-Form-Source.zip with this ZIP and commit.
Keep the existing working workflow and signing credentials. After Actions
succeeds, extract and install the APK over the existing app without uninstalling.
App version is 1.28.1; fallback versionCode is 50 (CI supplies its increasing code).

Package com.fairwayform.app, WebView origin, IndexedDB schema 5, IDs, saved bag,
course layouts/rounds, approved intro, video analysis and signing setup remain
compatible. All 1.28.0 hole-sign detection, confirmation and searchable research
remain included. No new research claims, model weights or course-data import
are introduced by this patch.
