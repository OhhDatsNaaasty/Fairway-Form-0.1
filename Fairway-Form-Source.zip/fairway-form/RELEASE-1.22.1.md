# Final Form - Disc Golf 1.22.1

Build-workflow update. Includes the entire 1.22.0 app and 1,092-entry catalog; no form-analysis or Caddy behavior changed in this patch.

Browser checks now have a separate parent-process watchdog, fresh run IDs/logs/status, named stages and ten-second heartbeat output. A silent step times out after three minutes; the whole browser run times out after ten minutes. The watchdog can terminate the worker and Chrome descendants even if their event loops hang. Chrome startup retains its two bounded attempts. Polling assertions now honor elapsed wall time and forward their remaining deadline to the browser protocol.

The local server preflight is limited to three seconds. Socket permission denial produces a clear BLOCKED result and exit code 2, rather than queuing another automatic additional-permission launch. Passed, blocked, failed, timed-out and interrupted outcomes are distinct. Only an actual passing run exits zero. Both npm run test:browser and direct browser-smoke.mjs invocations use the supervisor.

The existing GitHub ZIP workflow receives the watchdog through scripts/build-android.sh automatically. Its mandatory browser/model gate stays enabled. Included workflow templates also upload browser-check.log and browser-check-status.json on failure or success. Existing workflows still receive live stage and heartbeat output in the build log without an edit. AGENTS.md records the local-block/fallback and communication workflow for future work. See BROWSER-CHECKS.md.

Project timers start after a command launches. They cannot time out a Codex approval queue, tool scheduling wait or client/service disconnection before launch. The earlier long-wait evidence was an interrupted tool launch with an unchanged earlier successful browser log; it does not establish a Chrome process was running. These changes reduce repeated local launch attempts and make actual running checks observable; they cannot repair the Codex service itself.

## Validation

- 631 automated JavaScript tests passed, zero failures.
- New tests cover supervised success/failure, live output/stages, explicit environment blocks, inactivity and total deadlines, cancellation, spawn errors, preflight deadlines, per-command protocol deadlines and Chrome process grouping.
- A real Node child deliberately blocks its JavaScript event loop; the parent watchdog stops it and returns a nonzero timeout result.
- The actual local npm entry point returned BLOCKED in about 0.2 seconds, with a fresh run ID, clear explanation, log and JSON status. The direct script entry point was also checked.
- JavaScript, Android XML and shell syntax checks passed. Both workflow YAML files parsed, including the always-on diagnostics upload and job timeout.
- No full local browser/model pass or signed APK build is claimed for this patch. GitHub must pass the required browser/model, Android compile and APK verification steps.

## Update

Replace repository-root Fairway-Form-Source.zip and commit in the same private repository. Keep the existing signing credentials and workflow identity. Install the resulting successful APK over the existing app without uninstalling. No workflow edit is required to receive the watchdog. The new source includes all app changes from 1.21.0 and 1.22.0.

Source 1.22.1; local default Android versionCode 41, with CI supplying its increasing code. Package/origin, IndexedDB schema 5, signing flow, startup movie, bag records and throw/course histories are unchanged.
