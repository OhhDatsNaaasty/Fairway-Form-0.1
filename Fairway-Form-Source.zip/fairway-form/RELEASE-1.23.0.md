# Final Form - Disc Golf 1.23.0

Replaces the Android APK's repeated paused-seek review path with prepared source
images for supported clips. One background native decode supplies scrubbing,
stepping, silent review playback, markers and body/hand inference. Actual
presentation timestamps stay attached to the images. Marker saving waits for
the requested image, and stale requests cannot replace a newer scrub.

Automatic release selection now requires sustained motion, respects other
marked phases and visible approach direction, and asks for an anchor when
several strong swing sequences compete. It still estimates swing timing rather
than detecting disc separation. Saved manual markers remain visible when pose
detection fails; absent evidence is not filled with an unrelated frame.

Includes the full 1.22.2 catalog, manufacturer-search assertion fix and bounded
browser-check runner. App package, origin, signing workflow, IndexedDB schema 5,
original videos, bag records and saved courses are preserved.

## Validation and limits

- 652 automated JavaScript checks passed, zero failures.
- 13 Java frame-rule checks compiled and passed; changed Java syntax parsed.
- JavaScript, XML and shell syntax checks passed.
- The local browser check promptly returned BLOCKED because localhost server
  sockets are denied. GitHub must run the full browser/model and Android build
  gates. The added browser fixture uses a test native bridge, not MediaCodec.
- No local Android API build, signed APK or target-phone codec test is claimed.
  The original problem clip is still needed for reproduction and accuracy checks.
- Review images are temporary, resized (960-pixel maximum long edge), retained
  at up to about 60 frames/s, and capped at 128 MB. The original video is kept.
  Unsupported formats explicitly fall back to the browser player. Native review
  playback has no audio. See VIDEO-PIPELINE.md for architecture and limits.

## Install and test

Replace repository-root Fairway-Form-Source.zip in the same private repository
and commit it. Keep your current workflow and signing credentials. After Actions
passes, download Fairway-Form-APK and install the extracted APK over the current
app without uninstalling. No workflow edit is required.

Open the previously failing clip and wait for “Frame review ready.” Test scrubbing
around the failure and near the end, stepping, markers, analysis, saving and
reopening. If a fallback notice appears, keep its exact message and the original
clip for diagnosis. This release introduces a different pipeline; it is not a
claim that the user's decoding failure or automatic event accuracy is verified
resolved.

Source version 1.23.0; fallback Android versionCode 43. CI still supplies its
increasing version code. Approved intro and disc catalog data are unchanged.
