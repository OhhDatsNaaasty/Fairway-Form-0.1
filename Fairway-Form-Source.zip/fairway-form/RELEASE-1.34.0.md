# Final Form - Disc Golf 1.34.0

Attack now compares a reachable shot past a known bend with a placement before it. Previously every known corner forced all candidates to stop before the bend, and wooded-line scoring could select a short putter even when a longer familiar disc could work through the corner. Attack now gives useful reachable progress more weight; Safe favors the controlled earlier landing. Both tactics remain available when they offer a meaningful comparison, including two plans for the same physical disc.

For a long straight section followed by a bend, the new attacking option uses a flat early flight and a compatible natural finish. Right-hand backhand fades left, right-hand forehand fades right, and left-hand throws reverse those directions. Learned early fades, early turnovers, blocked styles, speed limits, insufficient range, required carry and nearby long trouble can exclude that option. A suggested route does not establish a visible opening through the trees. More complex turnover and multi-corner attacking routes are not inferred by this change.

Long-hazard checks now use the actual route target after its reach and corner limits. Distant water beyond the basket no longer penalizes a first stage hundreds of feet short of it, or penalizes a disc merely because its full distance reference could reach the water. Near-basket targets still receive a controlled carry/ground-play margin. Removing water from the reported example leaves its useful attacking comparison unchanged. Fade-based scoring now consistently uses each candidate's hand and throw type.

Choosing a tactic updates the plan heading, landing artwork, target distance and exact saved recommendation key together. Planned distance remains separate from actual throw distance and distance remaining. The dogleg lesson now explains the two tactics and includes a corridor/landing-zone practice task, an outcome check and progression, linked to existing registered strategy and flight sources. No new research viewing or physics validation is claimed.

## Verification

All 916 automated tests passed, including 25 new planning/UI regressions. Tests reproduce both versions of the user's wooded 475-foot hole with a slight left bend at 250 feet, with and without water 20 feet past the basket. Longer-disc distances are hypothetical fixtures, not the user's reported distances. In a test bag with a 330-foot TeeBird reference, Attack proposes approximately 297 feet past the bend; Safe prefers a nearer placement. Coverage includes mirrored hands and styles, blocked styles, speed limits, poor reach, explicit targets, wind/elevation, nearby water, carry constraints, exact same-disc tactic selection, matching artwork, history backup, units and isolation of actual results.

Static checks retain all 409 unique controls, check syntax in 113 runtime/script files and verify all 107 offline paths. The production-renderer preview beside the ZIP compares the two targets on the same scaled sketch; it is not a phone screenshot. The archive is checked for CRC integrity, exact workspace equality and unchanged files against version 1.33.0.

Fresh local browser run 89e46d71-f335-48cb-ae41-89df110f4fe3 was BLOCKED immediately by socket EPERM before Chrome started. No browser, APK or physical-phone pass is claimed. The mandatory GitHub browser/model gate remains enabled and adds a regression for both note variants, same-disc tactic selection, heading/landing updates and untouched actual results.

## Update

Replace repository-root Fairway-Form-Source.zip and run the existing GitHub workflow. After every required check passes, install the signed APK over the current app without uninstalling. Version name is 1.34.0; fallback versionCode is 60 and CI retains its increasing code. Package/origin, signing identity, storage schema, approved intro and video-analysis pipeline are unchanged.
