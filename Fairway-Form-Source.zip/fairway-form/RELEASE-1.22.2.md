# Final Form - Disc Golf 1.22.2

Fixes the GitHub browser failure “Manufacturer-name search failed”. The 1.22.0 catalog expansion added Trash Panda Outer Core, bringing that brand to six molds. The browser test still expected the original five. The app's manufacturer search was returning the correct expanded results; removing a disc or bypassing the test was not needed. The stale assertion also existed in 1.22.1.

The browser check now compares the current catalog's exact Trash Panda mold IDs for both “trashpanda” and “Trash Panda”, rather than a fixed count. A shared assertion is also exercised against the actual catalog UI in the Node tests. Negative checks verify that missing, wrong-brand and duplicate cards still fail, even if the total happens to match. Diagnostics identify the query, expected and actual counts, missing IDs and unexpected IDs. Future catalog growth is supported without a fixed-number edit.

Includes the entire 1.22.0 catalog and 1.22.1 browser supervisor: fresh logs, named stages, ten-second heartbeats, three-minute inactivity and ten-minute total deadlines. The mandatory GitHub browser/model gate remains enabled.

## Validation

- 634 automated JavaScript tests passed, zero failures (including three new regression tests).
- JavaScript syntax, Android XML and shell syntax checks passed.
- The local browser entry point returned an explicit BLOCKED result in about 0.2 seconds because this environment denies the localhost server socket. This is not a browser pass. GitHub must run the full browser/model check, Android compilation and APK verification.
- No local signed APK build is claimed. The approved intro movie and catalog data are unchanged.

## Update

Use this ZIP in place of either 1.22.0 or 1.22.1: replace repository-root Fairway-Form-Source.zip and commit it in the same private repository. Keep the current workflow, encrypted signing key and password secret. After Actions passes, download Fairway-Form-APK and install the extracted APK over the current app without uninstalling.

Source version 1.22.2; fallback Android versionCode 42, with CI supplying its increasing code. Package com.fairwayform.app, appassets origin, IndexedDB schema 5, signing flow, saved bag copies and throw/course histories are unchanged. The app logic changed only in version labels/cache names; the functional change is to build validation.
