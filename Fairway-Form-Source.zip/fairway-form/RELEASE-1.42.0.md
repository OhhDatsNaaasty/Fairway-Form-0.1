# Final Form - Disc Golf 1.42.0

## Camera and touch controls

The course renderer now uses a true look-at camera with a 10°–90° elevation range. The default remains a low 14° view. A steep view fits the route and has a well-defined overhead projection. Camera elevation does not alter any stated hill height, route coordinate or saved lie.

In the pop-up viewer and landing picker, moving two spread fingers vertically tilts the camera. Pinch changes zoom, and sideways two-finger translation pans the crop. Gesture intent is classified after coherent motion: an arriving vertical finger cannot immediately turn a parallel tilt into a spurious pinch. Gestures are coalesced on display frames. The visible Tilt slider and up/down arrow keys provide alternative controls. Behind tee restores the default view.

The picker inverts zoom/pan and intersects the tilted camera ray with the same terrain that is drawn. Tests cover slopes, every orbit quadrant, multiple zoom levels and straight overhead. Starting a multi-touch gesture restores a pending single-finger marker drag; neither tilting nor pinching commits a landing. Saved world geometry and distance evidence remain independent of the camera.

## Trees and sky

Landing views keep the same canopy dimensions and use 62% opacity. Normal views keep opaque foliage. Trunks and canopy placement adapt to camera tilt, and the basket has an overhead ring. Tree positions/counts and planner obstacle checks are unchanged.

A lightweight SVG sky supplies day, overcast, sunrise/sunset and night colors, a lower sun near dusk, and an illustrative moon/stars for glow rounds. It refreshes with the viewer and at foreground minute ticks. The existing consented Open-Meteo request now also requests cloud cover, weather code, day/night status and two days of sunrise/sunset times in GMT. Optional sky fields are validated independently from the required wind fields. Clouds/conditions expire after 30 minutes; bounded same-day sun events can still guide the sky after wind expires. No extra location or background weather request is introduced, and geographic coordinates are not added to the returned weather object.

Without usable sun events the renderer uses an approximate device-local clock schedule. The sun path, moon position and lunar appearance are illustrative, not a compass or astronomical ephemeris. The Open-Meteo documentation source is registered in the searchable library with its review provenance. The forecast endpoint's existing distribution restrictions remain documented in CADDY-RESEARCH.md.

Each live viewer owns independent SVG gradient/clip IDs, so simultaneous low-angle and overhead views cannot borrow one another’s clips. Saved feature IDs remain unchanged. Every star, cloud, sun and moon is enclosed by an explicit horizon clip. The gradient is scaled to that sky region. The ground plane is drawn above the sky layer. At 90° overhead the sky clip has zero height; no sky is drawn over the fairway. Night terrain is gently shaded while labels and the target remain legible.

## Preview and verification

The interactive conversation preview and PNG use sample hole/weather data and the app's renderer. The bundled renderer is checked against the source modules. They are not Android/browser screenshots and do not change a saved course.

All 1,117 automated tests and 58 native host-rule checks passed. The accompanying verification.json records the test totals, the exact source diff, native host-rule checks, retained controls, offline paths and archive integrity. New tests cover the tilt camera, gesture classification/cancellation, accurate ground picking, retained nodes at changing tilt, same-size translucent canopies, sky clipping and optional weather parsing. The required GitHub browser gate adds an actual two-finger vertical gesture, overhead marker verification and the zero-height sky clip check while retaining its other model/route/scroll/profile assertions.

The fresh local browser attempt is BLOCKED by workspace socket permissions before browser tests run. No signed APK, physical-phone touch/performance result or GPS accuracy pass is claimed. GitHub's browser/model/native/APK gates remain required.

## Install

Replace repository-root Fairway-Form-Source.zip, preserving its filename. Run the existing workflow and install its signed APK over the current app only after all required checks pass. Package, signing identity, origin, storage keys and existing data are unchanged. Version name: 1.42.0. Fallback versionCode: 72; CI retains its increasing code.
