# Final Form - Disc Golf 1.40.2

## Build-check correction

The required GitHub browser gate failed with “Cannot read properties of null (reading slice)” while preparing the 320×568 landing picker. The previous test typed a practice-hole title, changed the units, then searched storage by the typed title. The units handler refreshes form controls from the round, replacing an uncommitted title. The lookup could therefore return no round; sceneForRound produced an empty layout and terrainProjection received null points.

The browser fixture now records and uses the active saved round's stable ID, enters the optional title after unit changes, waits for the persistence queue, and validates the expected 475-foot route and 250-foot bend before calculating touch coordinates. Missing or ambiguous active IDs fail clearly before projection. Diagnostics include the active ID and current setup fields. The renderer is not given fabricated fallback points.

Two regression tests exercise the actual Caddy unit-change, persistence and recommendation handlers, reproduce the title reset, verify a valid persisted scene using the same serialized identity helper, reject missing/duplicate IDs and ignore decoy titles. All existing real touch, three-viewport, scroll, ground-rectangle, retained-SVG, next-lie and weighted-distance browser assertions remain required.

## Scope and validation

This is a build-test correction plus version metadata. The 1.40.1 landing sheet and 1.40.0 approximate-distance/GNSS behavior are unchanged. Package, signing setup, origin, storage keys and existing data are preserved. No new research or phone accuracy claim is introduced.

Automated test totals, source comparisons, archive checks and the fresh browser status are recorded in verification.json. Local full-browser execution remains blocked by workspace socket permissions before any browser tests run. No local signed APK or physical-phone accuracy result is claimed. GitHub's browser/model/native/APK checks remain enabled and must pass.

## Install

Replace repository-root Fairway-Form-Source.zip, keeping that exact name. Run the existing GitHub workflow. After all required checks pass, install its signed APK over the existing app without uninstalling. Version name: 1.40.2. Fallback versionCode: 69; CI retains its increasing code.
