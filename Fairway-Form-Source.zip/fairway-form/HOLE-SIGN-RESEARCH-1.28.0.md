# Hole-sign and map reading — 1.28.0

This release separates text facts, proposed route geometry and player-confirmed
markers. It does not add a cloud image service, scrape a course database, or
retrain a general-purpose visual model. Photos and processing remain local.

## Research and examples

All seven public references below are registered in `dist/lib/hole-sign-research.js`,
with original subject-specific summaries, review dates and access provenance.
They are searchable in Technique library → Research & sources. Four new
Course planning lessons explain active layouts, tracing bends, retaining rules
and avoiding pixel-based distance or compass assumptions.

| Source | What was reviewed and used |
| --- | --- |
| [DiscGolfPark map drawing](https://www.discgolfpark.com/discgolfpark/services/map-drawing/) | Custom schematic/online maps and the separation of maps from sponsor graphics. |
| [DiscGolfPark TeeSign](https://www.discgolfpark.com/discgolfpark/products/teesign/) | Visible hole facts, restrictions and safety information; no universal symbol standard assumed. |
| [PDGA skill-level guidelines](https://www.pdga.com/course-development/skill-level-guidelines) | Multiple target positions, active-position indication and dogleg landing areas. |
| [UDisc public editing documentation](https://help.udisc.com/en/articles/10705000-editing-fairways-in-map-manager) | Movable route points, dogleg distance versus direct distance and layout notes. Documentation only; no course-data import/license inferred. |
| [Belvidere designer page](https://www.discgolfpark.com/course/belvidere-discgolfpark/) | Linked nine-hole overview visually reviewed: dashed routes, gray tees, circular targets, distance table and north arrow. Its table lists hole 1 as 255 ft/par 3. |
| [Rockford Park District](https://rockfordparkdistrict.org/discgolf) | Anna Page course names, differing layouts and terrain. No current hole geometry imported. |
| [Omaha tournament caddy book](https://omahadiscgolf.com/uploads/1/2/1/8/121804338/sff36-caddy-book-small.pdf) | PDF page 3 (hole 1) visually reviewed and text inspected: 340 ft/par 3, pale aerial route, tee rectangle, basket glyph and written OB. The whole book was not individually studied. |

The Belvidere course overview and Omaha hole-1 page were downloaded for local
research and pixel checks. Their artwork/PDFs are excluded from the source ZIP.
The audit JSON records source URLs, image hashes, bounded resolutions and the
observed proposals. Synthetic tests use original drawings generated in code.
These references inform heuristics and interface design; they do not establish
a measured real-world recognition accuracy.

## The supplied examples

Literal transcriptions test the supplied Anna Page screenshot (Hole 1, Par 3,
297 ft and parking/bathroom/shelter pavement OB) and the Belvidere sign (#1,
Par 3, 255 ft). Course Par 57 is not a hole par. A layout header such as “White
baskets” is a selectable label, not a spatial basket location. Course name and
written rules now reach the editable setup and the same saved course hole.

The embedded user images were inspected visually in the conversation, but were
not available as local original files for an end-to-end ML Kit or pixel test.
No claim that those exact photos were automatically recognized is made.

## Implementation

- Route analysis runs at at most 640 pixels on the long edge. It searches
  colored, neutral gray/white and dark strokes; connects compatible short
  dashed fragments; and uses nearby labels, tee rectangles and basket glyphs
  as endpoint clues. OCR boxes are excluded from route pixels. Border graphics
  and broad background fills are rejected. Green map panels can constrain the
  search, but are not a semantic segmentation model.
- Shapes are classified in the image's physical aspect ratio and travel order.
  Straight routes need only tee and basket. Slight/full doglegs and two opposite
  bends can populate the existing fairway options. Symbol outlines are kept
  from becoming false last-second bends. Up to two bend markers are editable.
- Unlabeled routes still need direction confirmation. Multiple unanchored routes
  or a course overview can return no route rather than picking an unrelated hole.
  Hole-number text can help prioritize a route, but does not prove its identity.
- All four markers support direct Pointer Events dragging, large hit targets,
  pointer capture, cancellation rollback and keyboard arrows. SVG aspect ratio
  keeps the circles round. A new image/hole invalidates an old drag. Reanalysis
  preserves a complete manually corrected route.
- Text parsing keeps explicit units, scopes multi-hole cards to a selected hole,
  asks about alternate distances/pars, retains rule notes and proposes course
  names. Different named courses cannot silently overwrite one another.
- Use confirmed sign details applies these facts to the existing Caddy form;
  normal autosave stores the same setup in My Courses. Notes are appended without
  duplicates. A different hole cannot replace a hole with recorded throws.
  Written route descriptions take priority over automatic image guesses; player-
  corrected markers can override them, with disagreement shown for review.

## Verification and limits

Regression tests cover both example transcriptions, multiple holes/layouts,
straight/slight/combo routes, physical aspect, pale and dashed strokes, adjacent
fairways, borders, unanchored overviews, every draggable marker, cancellation,
new-hole isolation, keyboard corrections, course save/reopen and library search.
A browser scenario adds a generated image, a clearly labeled test OCR bridge,
real pointer dragging, reanalysis retention and saved-course assertions.

The published Omaha hole-1 image produced tee/basket proposals near the visible
symbols and a slight-right line at 495×640; the Belvidere whole-course map at
640×431 correctly withheld an unanchored route. These are two development
checks, not a representative accuracy benchmark or phone performance result.

ML Kit still handles text in the APK; arbitrary icons, aerial vegetation,
overlapping lines, skewed photos, mandatories and current pin positions can
remain ambiguous. Confirm proposed markers and fields. The analyzer does not
infer a compass bearing, route scale, elevation, hazard side, safe clearance or
current rules from pixels. Printed distances and explicit written directions
are separate evidence. North-arrow recognition is not implemented. Images with
more than two important bends may need a simplified route plus written notes.

See RELEASE-1.28.0.md and the external verification.json for the exact test and
browser status. No on-device OCR, signed APK or physical-phone validation was
performed locally. GitHub's browser/model and APK gates remain required.
