# Fairway Form 1.2.0 — your course caddy

Caddy now has its own section immediately after Disc room, plus a home-page shortcut. It uses the copies in your saved bag to help plan the next throw and explains its choices.

## Included

- Distance in feet by default, with meters available. Straight lines, left/right doglegs, heavy trees, uphill/downhill, landing points, miss hazards and risk preference.
- Handed backhand/forehand advice, planned effort and bag-based range comparison. Ratings provide approximate shape context; they do not invent your throwing distance.
- Personal bag details for primary/alternate throw distance, observed stock flight, putting range, putting favorite, wind trust and wet-grip trust. Existing bag backups keep these fields.
- Manual calm/light/medium/strong wind, numeric mph/gusts, headwind, tailwind and both crosswind directions. Wet conditions and known weight also inform the comparison.
- Optional current model weather using a one-time coarse location request. Enter the direction of the current throw to convert compass wind, or select relative direction yourself. Manual input stays available offline.
- A putting caddy with a separate comfort range, familiar putter selection and run/layup options based on the miss, slope and conditions.
- Saved hole logs: tee throw, subsequent throws, actual disc, outcome, notes and remaining distance. Each next lie gets fresh line/wind-direction inputs. Holed-out throws finish a hole. Saved holes can be resumed; JSON logs can be exported.
- Sign camera/gallery support and bundled on-device Latin OCR in the Android APK. Choose among recognized distances and confirm the active tee/pin. Mark tee, bend and basket to review the route. This is assisted sign analysis; it does not automatically understand every tree, gap or schematic drawing.

The Android edition adds an image picker/camera FileProvider, optional coarse-location permission and ML Kit OCR 16.0.1. The existing form analysis, coaching and 301-mold catalog remain included. IndexedDB upgrades to version 3 while preserving previous stores. Default local Android versionCode is 10; CI still supplies its increasing versionCode.

## Install using your phone

1. Download Fairway-Form-Source.zip for 1.2.0. Keep it zipped and use that exact filename.
2. Replace the root ZIP in the same GitHub repository and commit to main.
3. Keep the working workflow, APP_SIGNING_PASSWORD secret and .fairway-signing.enc file.
4. When the newest Actions run succeeds, download and extract Fairway-Form-APK, then install Fairway-Form.apk over your current app.
5. Check App & settings shows Version 1.2.0.

This source ZIP is not an APK. The existing workflow downloads dependencies/assets, performs its checks, and compiles/signs the installable app. The native OCR dependency makes this build somewhat larger. No extra secret is needed for the current personal weather-testing endpoint.

## Try on your phone

Open Disc room → My bag and fill the throwing references for the discs you carry. Expand Personal caddy details to tag the throw style, other-throw distance and putting range/favorite. Old distances default to a backhand reference; correct that selector if yours describe forehands.

Open Caddy from the home screen or navigation. Set the actual distance and line, then get a recommendation. Test a headwind and a wooded dogleg. Record the disc/result and remaining distance; confirm the next throw asks for its new line. Try putting, record a made putt, and reopen the saved hole. Check your older sessions and bag as well.

Use Read a hole sign for a real photo. Test camera permission, gallery selection, OCR, multiple distance choices, route markers and confirmation. Check that the actual tee/basket matches. For weather, try allowing and declining location. Confirm the displayed model time, compass heading conversion and local wind before applying it. Try manual controls with internet switched off.

## Verification and limits

159 automated tests pass. Static syntax, imports, controls, offline cache paths, XML/provider wiring and versions were checked. The workspace cannot run its browser server or compile Android; actual OCR, camera, location, weather access and the new interface still need the GitHub build/phone test. This is a working implementation in source, not a claim of completed device verification.

Planning is a transparent heuristic ranking, not a validated aerodynamic or course-clearance simulation. Source research, scoring margins and limitations are in CADDY-RESEARCH.md. The current Open-Meteo endpoint permits personal/non-commercial testing; a paid, ad-supported or other commercial release needs licensed weather access and the SDK/privacy disclosures described there.
