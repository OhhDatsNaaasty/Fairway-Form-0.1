# Approved design direction — implemented in 1.31.0

On November 10, 2026, the user explicitly approved proceeding with the full redesign. Use deep forest and basket gold; discard the white-background design alternative. Keep the compact overhead hole-sign picture, independent feature placement from notes, saved sign-photo priority, clear per-hole state and a simple next-throw / putting flow. Existing app capabilities, intro, signing identity and saved data remain in scope. Do not ask for another broad redesign approval.

The implementation and feature locations are documented in FIELD-INTERFACE-1.31.0.md. The earlier design-review HTML files are prototypes, not the production source. The production runtime now includes the field interface. Local browser rendering remained blocked / interrupted; do not claim the preview images are actual redesigned-app screenshots or that the new compass is physically validated.
