# Final Form - Disc Golf 1.25.0

Repairs a confirmed analysis-preview regression: prepared-frame inference was
reading new images while leaving an old image on screen. Both body and hand
passes now show the measured source frame with its own matching landmarks.
Original phone/browser video is the default again; Prepared frames is an
optional Android compatibility mode in App & settings. Reopen the clip after
changing modes. Forward decoding remains in place, with bounded playback
recovery for paused scrubs that fail to produce an image.

The user clarified that the inaccurate “points” are suggested throw moments.
A hand-motion peak is not proof of disc separation. Automatic release is now
labeled Release check and leads to a short replay for confirmation. Default
coaching waits for a marked release before presenting corrective judgments;
marking release recalculates the other suggestions. Plant must also be marked
before brace praise/faults. This does not claim automatic event detection has
been validated or made accurate on the user's missing original clip. See
ANALYSIS-REGRESSION-1.25.0.md for the diagnosis and remaining work.

## Validation

684 JavaScript tests passed, zero failures/skips/cancellations. Changed syntax
passed, and eleven embedded checked-step expressions were parsed. The fresh
local browser check was BLOCKED by localhost socket permissions (EPERM); no
local browser/model or signed APK pass is claimed. The full GitHub browser,
real model/codec fixtures, Android compile and APK checks remain mandatory.
No physical-phone accuracy or playback verification has been performed.

## Update and phone checks

Replace repository-root Fairway-Form-Source.zip in the same private repository
and commit. Keep the existing workflow and signing credentials. After Actions
passes, download Fairway-Form-APK, extract the APK and install over the existing
app without uninstalling. Source version 1.25.0; fallback Android versionCode
46, with CI supplying its increasing code.

1. Open the same problem clip in the default Original video mode. During
   Analyze my throw, the image/time should advance with the measured frames.
   This is frame-by-frame analysis progress, not normal-speed movie playback.
2. Check the release suggestion against visible disc separation. Step to the
   correct source frame and use Mark release here. Check the other suggestions
   after they update; mark visible plant contact if its suggestion is wrong.
3. Scrub, step and play the original clip. Marker buttons must wait for a
   displayed paused frame. An unavailable frame must not silently save the
   scrub target or borrow landmarks from another frame.
4. If a particular clip still fails to open/scrub, choose Prepared frames in
   App & settings and reopen it. This remains a compatibility option, not an
   accuracy claim. Sequence-study source thumbnails are available in that mode.
5. Confirm saved sessions, bag profiles, course data and opening animation
   remain intact. Do not uninstall to update.

Please supply the original failing video for event-by-event labeling; screenshots
cannot establish which source frames should be plant, release or follow-through.
