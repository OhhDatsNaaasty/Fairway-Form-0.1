# Caddy research and implementation — 21 October 2026

## Source review

The caddy uses original explanations informed by the following public sources. Instruction is separate from the ranking policy; these articles do not validate its numerical weights or predict an individual's flight.

| Source | What was reviewed and used |
| --- | --- |
| [Innova: Understanding Flight Numbers](https://www.innovadiscs.com/tips/understanding-flight-numbers/) | Read the article. Ratings are reference tendencies; relative airspeed changes turn, and comparisons across manufacturers/speed classes are limited. |
| [Innova: Flight Ratings System](https://www.innovadiscs.com/home/disc-golf-faq/flight-ratings-system/) | Reviewed the manufacturer definitions and indexed guidance. A speed rating is not a distance for a player. |
| [Innova: Playing in Wind](https://www.innovadiscs.com/tips/tips-for-playing-disc-golf-in-the-wind/) | Read the article. Used conservative landing, local wind observation and exposed-flight-plate considerations. |
| [Innova: Master Your Approach Game](https://www.innovadiscs.com/innova-news/master-your-approach-game/) | Read the article. Reassess each lie and choose a landing zone; consider the next putt and ground play. |
| [Dynamic Discs / Robert McCall: Putting Strategy](https://blog.dynamicdiscs.com/2017/11/quick-tip-putting-strategy.html) | Read the article body. A run/layup choice should account for commitment, the miss and the next putt. No population make percentages were adopted. |
| [Ultiworld / Matt Rothstein: Uphill and Downhill Putting](https://discgolf.ultiworld.com/2017/07/18/tuesday-tips-using-straddle-stance-uphill-downhill-putts/) | Read the coach-authored text. Used slope/balance context and a practiced straddle as an option, without universal aiming offsets. The app links the current putting rule separately through its existing library rather than adopting the old rule number quoted in this article. |
| [Open-Meteo documentation](https://open-meteo.com/en/docs) and [terms](https://open-meteo.com/en/terms) | Reviewed current model-weather variables, mph selection, wind/gust semantics, attribution and the public endpoint's non-commercial restriction. |
| [Google ML Kit text recognition](https://developers.google.com/ml-kit/vision/text-recognition/v2/android) and [terms/privacy](https://developers.google.com/ml-kit/terms) | Reviewed bundled Latin OCR 16.0.1, image preparation, API level requirements, on-device processing and SDK diagnostics disclosure. |

No paid content, full article archive or video library is bundled. Manufacturer photos and catalog references keep their existing credits. These sources are references, not endorsements.

## Recommendation inputs and scope

The Caddy section follows Disc room in navigation and has a home-page shortcut. It reads the real IndexedDB bag and custom catalog. It never adds a product to a recommendation unless a copy is in that bag. Separate copies can have different weight, condition, personal flight notes, wind/wet trust and putting preference.

For each lie, the player supplies remaining distance, backhand/forehand/putt, hand, line, slope, optional landing-point distance, woods, hazard side, risk, effort, and wind. Distance defaults to feet with a meter option; canonical stored distances are in feet. A wooded dogleg can keep both conditions. A selected landing point changes the immediate target while retaining basket distance.

A logged throwing reference applies to its selected primary throw style; the alternate style has its own optional distance. Putting range is separate. An uncalibrated style stays labeled range-unverified; the model never converts speed numbers into throwing distance. Direction reverses correctly for left/right hands and forehand/backhand. Personal stock-shape observations can modify the rough shape preference without rewriting manufacturer ratings.

The shortlist compares logged reach, shape compatibility, control, wind, slope and risk. Headwinds favor less-turning reference shapes; tailwind advice considers controllable speed/glide. Crosswind advice stays conditional on bank angle and exposure. Known lighter copies get a caution in stronger non-tailwinds; weight alone does not establish stability. Wet-grip and wind-trust flags are user experience, not inferred plastic guarantees. High-speed, severely reduced-power options are treated cautiously. Exact release angle, spin, speed, canopy clearance, landing, skip and force are not simulated.

## Explicit planning policy

The scoring weights in caddy.js are editable heuristics. For example, uphill/downhill range comparisons currently use 1.12/0.92 demand margins, and a headwind adds a small ranking margin by category. These are not sourced aerodynamic equations, an asserted plays-like yardage or a carry forecast. They only help compare options; the interface explains qualitative effects rather than presenting an exact adjusted distance.

Manual wind categories are app conventions: numeric speeds/gusts below 1 mph are calm, 1–7 light, above 7 through 15 medium, and above 15 strong. Gusts can increase the caution level. These bins are not a meteorological standard. Numeric readings override categories, and contradictory positive-wind/calm directions become unconfirmed. The weather heading conversion displays along/cross components; ranking uses the dominant relative direction, not a full three-dimensional wind field.

Putting only considers bag putters/slow putt-approach molds. Preferred putters and a personal putting limit matter. A dangerous or conservative, beyond-comfort putt can favor a layup. A chosen placement target is also a layup. Explicit run preference remains available. There is no invented make percentage or expected-strokes model.

## Throws, feedback and storage

Each hole has a saved draft and numbered physical throws, beginning at the tee. The player records the actual bag copy used, result, notes and actual remaining distance. The disc's identity is snapshotted so removing it later does not erase history. The next lie resets the line, landing point, hazard, wooded flag, compass heading and non-calm wind direction. A missing remaining distance stays blank. A made putt or holed-out throw completes the hole. This is a throw log, not an automatic rules/penalty scorecard.

Feedback is conditional on the outcome reported by the user. One miss does not identify a cause, train a model or change the manufacturer's ratings. A shortlist caution may appear after at least three recent, similarly distanced throws with matching hand, style, line, effort and wind context have a repeated flight/length miss. Hole JSON export includes throw context and used-disc snapshots; sign photo bytes are excluded. The full editable image remains in the local app log. Existing bag backup includes the new calibration fields.

IndexedDB version 3 preserves sessions/bag/catalog and adds caddyHoles. The Android package, asset origin and release-signing workflow remain stable. New hole profiles remember distance units, hand and personal limits locally. No account, server log of throws or background location tracking was added.

## Sign photographs

The Android APK uses bundled ML Kit Latin text recognition. Camera capture uses a private FileProvider cache URI; gallery access uses the system document picker, not access to the whole photo library. The browser prepares an oriented JPEG up to 1,600 pixels on the long edge, and the native OCR bridge bounds image size and request IDs. Photos and recognized text stay on-device. Google states SDK performance/utilization metrics can be sent to Google; the app discloses that in sign help and privacy settings.

Recognized unit-labeled distances remain choices. Unlabeled numbers, hole/par numbers and the active tee or basket are not guessed. Literal slope/hazard/route words can become suggestions. The player can mark tee, one bend and basket on the photo; a signed turn in those markers suggests left/right/straight independently of the image's rotation. This is assisted diagram review, not automatic understanding of every obstacle or a general vision-language model. The user confirms details before they change the planning form. No map scale, real corner distance, compass north or tree clearance is inferred from the drawing.

## Weather access and publication

Manual conditions work offline. Weather is an explicit, one-time request behind an explanation and Android coarse-location permission. The request rounds coordinates to 0.01 degrees before sending them to Open-Meteo; coordinates are not saved in the app's hole record. The provider receives that rounded location and network request under its own privacy terms. Bag, throws and photos are not sent.

The app requests mph, current model wind/direction/gusts, temperature and precipitation. It rejects unexpected wind units, invalid values and badly dated responses. Saved model results expire for application after 30 minutes. The player enters a throw compass heading or confirms relative wind manually. A new lie cannot reuse the old heading. Model wind at 10 m is not a sensor reading at the basket; local shelter/gusts can differ. Attribution and CC BY 4.0 links appear beside the weather feature.

The public free Open-Meteo endpoint is configured for the current personal, non-commercial testing. Its terms exclude subscription-, advertising- and other commercial use. Before such distribution, use a licensed service through a server-side endpoint that protects its credentials; do not embed a private key in the APK. Public distribution also needs the appropriate ML Kit SDK/data disclosures. No subscription or paid account was created by this task.

## Validation limits

159 local tests pass, including existing form/frame/voice/catalog checks and 47 caddy, weather and sign cases. API/bridge tests use explicitly controlled transports and fixtures; these are not live weather observations or OCR accuracy results. The browser smoke script now covers real bag-backed recommendation flow, unit conversion, confirmed sign text, next-lie state, outcome changes and location opt-in, alongside its existing real model/video checks.

This workspace cannot open the local server required by the browser check, and has no Android SDK/Gradle/JDK. APK compilation and actual native camera/OCR/location behavior remain pending the existing GitHub build and a phone test. A live Open-Meteo request was also attempted through the web research tool, which could not access the API URL; live endpoint availability is not verified here. Manufacturer instruction and weather/SDK documentation were accessible. No claim is made that the heuristics have been validated against a labeled set of real shots.
