# Fairway Form 1.14.0

This update targets both reported problems: missed/misidentified throw moments and coaching that feels too general.

- The uploaded-video body pass uses a fresh video tracker with ordered original-frame timestamps. Its state is closed before hand-detail revisits and reset for each new analysis.
- Choose the part of the video to review lets you set Start before the approach and End after the finish. This keeps setup gestures/other throws out of this review without altering the original file. Your choice is saved with the session.
- Isolated, implausible limb jumps are excluded from coaching. Hidden frames are not generated or filled in.
- Manual phase matching no longer borrows a pose up to 0.12 seconds away. Matching follows the observed frame spacing and is capped at 0.05 seconds. If a nearby pose is unavailable, the measurement stays unavailable.
- Tapping a suggested phase now selects that same event in the marker menu. It still requires Set marker to confirm the original frame.
- Short and expanded coaching use actual event order and observed movement. Hip drift and increased knee bend receive different brace explanations, for example. Clearly marked evidence is favored over a generic estimated crossover when selecting automatic practice.

## Try it on a throw

Upload the original side-on clip. If it contains setup movements or more than one throw, open **Choose the part of the video to review**, pause just before your approach and tap **Start here**, then pause after your finish and tap **End here**. Analyze again after changing the range.

Tap the suggested release/plant phase to replay it. Check the original frames, adjust if needed, then use **Set marker** or **Mark release here**. Reanalyze after correcting release so the hand close-up reviews that part of the throw. Open the short coaching and its replay moments first; full measurements remain in the detailed section.

The release suggestion still comes from hand motion. It is not an automatic detector of the disc leaving your fingers. X-step recognition remains a conservative heuristic. This is a first engine upgrade with useful software checks, not a validated replacement for expert coaching. Real throw clips with independently marked events are needed to measure whether the upgrade improves detection and advice. See THROW-ANALYSIS-RESEARCH-1.14.0.md.

## Update from your Android phone

Replace the private repository's root **Fairway-Form-Source.zip** with this download and commit it, preserving the filename, existing workflow, encrypted signing key and APP_SIGNING_PASSWORD. After Actions succeeds, download/extract **Fairway-Form-APK**, then install **Fairway-Form.apk** over the existing app. Do not uninstall or clear data.

Settings should show **Version 1.14.0**. Local versionCode fallback is 29; CI supplies its run number. Package com.fairwayform.app, the WebView origin and database schema 5 remain compatible. Existing saved sessions without a review window default to the whole clip. Existing raw frames are retained; reopening a saved session recalculates its report under the new rules. No private IP review files are included.

## Verification

471 JavaScript tests pass, including the new pipeline/range/coaching regressions. The existing compiled native camera-measurement rules also pass 19 checks. Static JavaScript/import/control/offline-shell, XML, shell/version and serialized browser-expression checks pass.

Real MediaPipe/browser integration and signed Android compilation must still pass in GitHub Actions. The source ZIP is not a locally compiled APK. No real-player accuracy benchmark or guaranteed detection improvement is claimed.
