# Fairway Form 1.11.0

## Easier Caddy use

Plan starts with distance, line, throw/hand, par and elevation. Course creation and layout saving share one collapsed editor; wind and optional shot settings show their selected conditions in their summary. Measure a throw is accessible near the top of Plan. The Throw task names the selected physical bag copy and offers a prominent **Log this throw →** action and **Change the plan**. Measurement buttons remain available, with longer instructions collapsed. Result starts with your actual disc, supports multiple outcomes, and keeps extra learning details behind an expansion.

A saved measurement reopens directly into its unfinished Result. Completing it updates the same throw ID. Empty bags stay on Plan with a useful instruction instead of opening a blank Throw task. Repeated recommendation taps cannot submit concurrent requests. After saving a result, focus goes to the visible distance-to-basket field for the next lie. Made shots still finish the hole and advance to the next hole.

## See what is already in your bag

Catalog cards show **1 in your bag**, **2 in your bag**, and so on. The number counts physical copies of that mold, regardless of plastic. It updates after adding, removing or restoring copies, including while a search/brand filter is active. Adding preserves catalog pagination. The button becomes **Add another**; it remains possible to bag different plastics and weights. Each physical copy retains its own learned disc profile.

## Find BuzzzSaw

Search BuzzzSaw, buzzsaw, Buzzz Saw or Fuzed Buzzz. The Buzzz result includes a product-version description, manufacturer link and **Add BuzzzSaw** button. That action creates a physical Discraft Buzzz bag copy with **Fuzed Z · BuzzzSaw** pre-filled as plastic/version. Existing Buzzz copies and histories remain unchanged. Discraft identifies the underlying model as Buzzz, so this does not inflate the mold count with a duplicate.

The Buzzz baseline remains the manufacturer-published 5 / 4 / -1 / 1. The product description notes increased torque resistance for the Fuzed version; no separate numerical ratings or exact-distance claims are invented. Your actual copy learns from its Caddy feedback.

## Flight information coverage

All **850 molds across 28 brands** have speed, glide, turn and fade, a rating-based flight interpretation, role and estimated planning range. Of those, **312 rating records** cite manufacturers and **538** cite reference catalogs. **44 molds have reviewed manufacturer chart links** (including two lineup-chart references); **21** have individually written manufacturer-informed purpose summaries. Other purposes/shapes are interpretations of ratings, not individually reviewed charts or measured flight paths. A new expandable explanation in the catalog reports coverage rather than implying every mold was independently researched.

See CATALOG-FLIGHT-AUDIT-1.11.0.md for sources and limitations. The existing per-copy range/flight learning, shot-angle and handedness comparisons, weather context, putting statistics and source labeling continue to apply.

## Update using your Android phone

1. Replace the repository-root **Fairway-Form-Source.zip** in your existing GitHub repository and commit. Keep its exact filename, the workflow, .fairway-signing.enc and APP_SIGNING_PASSWORD.
2. After Actions succeeds, download and extract **Fairway-Form-APK**.
3. Install **Fairway-Form.apk** over the current app. Do not uninstall or clear its data. Settings should show **Version 1.11.0**.

Package com.fairwayform.app, WebView origin, signing identity and database schema 5 are unchanged. The local Android versionCode fallback is 24; CI supplies its run number. Existing bag copies, disc histories, sessions, profiles and courses are preserved. Back up your bag/history and courses before updating.

## Verification

408 automated tests pass, including real catalog handler tests for multiple copies, filtering, add/remove/restore, failed saves and duplicate taps; BuzzzSaw aliases/version storage; all-mold flight coverage; focused Caddy actions; pending-measurement resume and same-ID finalization; and earlier form-analysis/course/putting/GPS regressions. Static syntax/import/control/offline-shell, HTML structure, Android XML and shell/version checks also pass.

The GitHub browser smoke check now verifies live ownership, BuzzzSaw search and the Log this throw action. Full browser/model smoke checks and signed APK compilation still run in GitHub Actions. This source archive is not a locally built APK; this workspace cannot run the required browser/Android SDK build. Phone layout, GPS, native OCR and installation remain device checks.
