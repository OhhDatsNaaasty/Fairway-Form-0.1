# Fairway Form 1.1.4 — release-frame stall fix

## What changed

The earlier release-detail pass moved backward from the end of the clip, then requested a separate 60 Hz sequence around release. That is why the final part of a throw appeared to play again. The seek readiness check also required the playhead to be within 3 milliseconds of the request; a completed seek rounded to a nearby source frame could incorrectly time out. The screenshot identifies a failure during this path, but the original clip and phone decoder have not been reproduced here.

The update removes that arbitrary extra 60 Hz sequence. With hand detail enabled, it revisits each already sampled release frame once, in order, and labels the pass as a hand close-up. With hand detail disabled, there is no second pass. To examine more frames from high-frame-rate footage, choose 60 samples/s in Settings for the main pass; the app never generates replacement frames.

Completed seeks tolerate source-frame rounding within about one 24 fps frame, after observed seeking or its completion acknowledgement. They still require image readiness and a stopped seek. A nearby unchanged frame cannot approve a silently ignored request, and a distant or genuinely stalled frame still stops inference. Actual frame timestamps are retained when supplied by the compositor; approximate fallbacks remain labeled. Frame callbacks are registered before seeking so a paused decoder's only presentation is not missed, and unrelated metadata is rejected.

Hand matching re-detects the pose on the currently decoded pixels. Hand-detail requests have a three-second timeout. If one fails, the optional pass stops without retrying the rest of the window. Completed body coverage and its coaching remain available; missing hand detail is disclosed. Cancelling the close-up also preserves completed body coverage. A real failure or cancellation during the body pass still produces a labeled partial review. There is no automatic jump back into the failed close-up after a detail failure.

## Update using your Android phone

1. Download **Fairway-Form-Source.zip** for 1.1.4. If your phone adds `(1)` to the name, rename it back to that exact filename. Keep it zipped.
2. In the **same existing GitHub repository**, replace the root **Fairway-Form-Source.zip** and commit to **main**.
3. Keep the working workflow, **APP_SIGNING_PASSWORD** secret and **.fairway-signing.enc** file.
4. Open the newest Actions run and wait for it to succeed. Download its **Fairway-Form-APK** artifact, extract it, then tap **Fairway-Form.apk**.
5. Install over your current app. Keep the current installation and its data; no uninstall is needed. App & settings should show **Version 1.1.4**.

This ZIP is updated source, not an installable APK. Your existing GitHub workflow produces and signs the APK. It supplies an increasing versionCode; the default local code is 8. The Android package, storage origin and database schema remain unchanged.

## Validation

**99 local automated tests pass.** The added cases cover a 3.76-second 30 fps decoder, a 3.58-second request landing at 3.5667 seconds, missing seeked events, unchanged stale frames, out-of-window timestamps, compositor presentation before seek resolution, duplicate frames at 60 requested samples/s, optional decoder/model/inference failures, stalled optional seeks, body versus hand cancellation, and retained partial body evidence. Earlier coaching, catalog, voice, tracking and photo-import tests also pass. These are deterministic test decoders, not a reproduction of the user's particular recording or hardware codec.

JavaScript syntax, local module paths, offline cache entries, HTML controls, Android XML, shell syntax and versions were checked. The GitHub browser script now adds rounded-playhead recovery with a real generated clip and checks optional-pass failure isolation separately from real model inference. Test-only pose tokens used for that orchestration check are never shown as user findings or used as model evidence.

The local browser check was attempted but blocked at server startup by `listen EPERM` on 127.0.0.1. Android SDK/Gradle and bundled model downloads are not available in this workspace. Real-browser/model checks and Android compilation still need the GitHub run. No APK has been built or tested here.

After installation, analyze the **same clip** with your usual settings and hand detail enabled. The body pass should finish, followed by one clearly labeled close-up. A failed close-up should leave body coaching ready rather than throw away the completed review. Also try hand detail off, cancellation during each pass, stepping around release, and saving/reopening the review. Confirm old sessions and your bag remain available.
