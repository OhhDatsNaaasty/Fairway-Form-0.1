# Fairway Form 1.1.0 — coaching and disc-room update

## What you will see

A cleaner forest layout with small teal, clay and warm yellow accents. The whole-body review sits directly below the video on mobile. Phase chips jump to reachback, plant, loading, release and finish, and you can correct their markers. Review cards distinguish measurements, visible patterns to keep, review prompts and missing evidence.

Thirteen checks now cover the release, head, posture, reachback, elbow opening, upper-arm/forearm position, coil estimate, event timing, foot placement, lead-leg support, hand alignment, off-arm and follow-through. Every supported observation links to its sampled video time. Your practice plan links the findings into a short field session and can be read aloud by your phone or saved as text.

The library grows to 38 lessons and 28 linked resources. The new disc room includes 50 manufacturer-sourced molds across seven brands, an editable personal bag, actual field-distance notes, JSON backup/import and a basic comparison against a target distance.

## Precision controls

Full pose model is the default, with Lite and Heavy options. Analysis samples source video at 15, 30 or 60 requested samples/second and refines the release window. Actual decoded frame timestamps are used when available and fallback seek timestamps remain approximate. A separate hand model examines real-pixel crops near the throwing wrist, with full-frame fallback. It rejects missing, distant or ambiguous hand matches. No generated frames are used as measurement evidence.

These controls do not make one camera a validated biomechanics system. Side-on footage is strongest for the arm, posture and event order. Rear footage helps foot stagger and arm clearance. Coil remains a model depth estimate, ground forces are not measured, and grip pressure/spin/nose angle remain unmeasured. Specialty throws do not receive automatic backhand pocket/brace fault prompts.

The walkthrough uses local report-based writing. An external generative AI coach and a course-aware caddy are future work; the version does not pretend to include them.

## Install this update from your phone

1. Download the new Fairway-Form-Source.zip. Keep its filename exact.
2. In the SAME private GitHub repository, replace the existing ZIP and commit to main.
3. Keep the existing working workflow, APP_SIGNING_PASSWORD secret and encrypted signing key.
4. Open the newest Actions run. The build script now also runs browser checks against the bundled models before Gradle.
5. After the run succeeds, download Fairway-Form-APK, extract it and install Fairway-Form.apk over your existing app.

The package ID and Android asset origin stay the same. The existing workflow’s run number increases Android versionCode and its saved signing key signs the update. Do not uninstall merely to update; that would clear app-private data. Back up valuable videos/reports and your bag separately.

The source ZIP is small because neural model files download during the build. Lite, Full, Heavy and hand models will increase the built app size. They are included for offline use, rather than adding unused gigabytes.

## Checks and first phone test

36 local algorithm/data tests pass. Static checks cover JavaScript, YAML, shell, Android XML, source imports, control IDs and packaging. The local browser/model check cannot run in this workspace because localhost sockets are blocked; actual GitHub browser checks, Android compilation and phone testing are still required for this update.

The added GitHub browser check exercises camera/gallery explanations, migration of an old session into the new database, library search, bag editing, personal-distance comparison, real pose and hand initialization, no-person video rejection and report rendering. It is new and has not yet been executed here. The existing successful 1.0.2 APK remains the rollback point.

After installing, confirm that old sessions open. Try a new side-on clip in Full mode, mark plant and release, and reanalyze to refresh hand detail around the corrected release. Inspect overlays against the actual video. Then add a bag disc, enter a distance and export a backup. Test the spoken plan if your phone has a suitable voice installed. Heavy mode and higher sampling rates can take more time and memory; start with Full.
