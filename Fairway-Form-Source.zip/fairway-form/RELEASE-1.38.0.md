# Final Form - Disc Golf 1.38.0

Terrain rotation now follows display animation frames instead of an eight-updates-per-second timer. Hole and suggested-landing pictures open in 3D first, with View hole sign available in the enlarged view.

## Rotation

- Reuses the SVG, tree crowns, basket, terrain surfaces and landing target throughout a turn. Updates projection attributes and depth order without rebuilding the drawing's DOM on each frame.
- Prepares route samples, feature positions, tree art and ground heights once per open viewer. Flat ground uses one surface instead of 520 small tiles; hills retain their height mesh.
- Coalesces drag and slider changes into the next display frame, preserves fractional scale changes and uses continuous label placement to avoid jumping between label slots.
- Full circle remains a manually started, approximately 30-second turn on a constant-radius, level-horizon camera. A delayed frame is capped to a small motion step rather than catching up in a large jump. Closing, hiding, navigating away or switching to the photo cancels animation. Arrow, slider, keyboard and Behind tee / Behind lie controls remain available.

## 3D first, photo available

The Caddy home picture, selected landing picture and their enlarged views show the 3D render first, including the confirmed sign-derived route and tree symbols where available. View hole sign switches to the saved photo; View 3D hole or View 3D landing returns to the render. Photo switching stops the orbit. A registered sign still supports its landing overlay, including geometry restored from a course backup. The switch preserves the selected shot and exact landing target.

Existing photos, confirmed diagram geometry, tree corrections and course data remain stored. Caddy disc ranking, note interpretation, throw results, signing identity, package, WebView origin, storage identifiers, intro and video analysis are unchanged. No new disc-golf research was introduced.

## Verification

- Full automated suite: 1,015 passed, zero failed, cancelled or skipped. Ten new checks cover retained drawing identity and projection through the full orbit, flat/hill surfaces, fine scale precision, photo availability with a 3D landing, display-frame cadence, input coalescing, delayed-frame motion limits and pause cleanup.
- Retained projection attributes and depth order are compared against independent complete renders for flat, elevated and turning routes. The same selected landing and input objects survive the orbit without mutation.
- Syntax: 119 application/build JavaScript modules checked. All 409 existing static controls retained with unique IDs. All 113 offline shell paths resolve.
- The fresh local browser run 276ec41c-6549-4ac0-a134-a31c38acace5 started 2026-11-17T04:15:58.104Z and was BLOCKED by workspace socket permissions (EPERM) before browser tests ran. No local browser tests passed. The mandatory GitHub browser/model gate stays enabled; assertions cover actual DOM identity, 3D-first home and landing views, photo decoding and round trips, preserved trees/target, and stopping rotation on close or photo switch.
- The optional 30-second preview is a 60-fps export from the production renderer at 0.2-degree increments. It illustrates the geometry and visual direction; it is not a browser or phone performance recording. CPU-only projection timings are recorded separately and exclude browser painting and phone hardware.
- APK compilation/signing and Android phone performance verification remain pending. Display-frame scheduling does not establish a measured 60 fps on a particular phone.

## Updating

Replace repository-root Fairway-Form-Source.zip, commit, and run the existing GitHub workflow. After every required check passes, install the signed APK over the existing app without uninstalling. Version name is 1.38.0; fallback versionCode is 65, with the existing increasing CI code retained. Existing photos and sign geometry do not need to be imported again. Tap the 3D picture to enlarge it, then use Full circle or drag horizontally. View hole sign opens the saved photo.
