# Fairway Form

An editable Android/Web app for disc-golf video practice. This delivery contains source, not a compiled APK. It has not yet been run on a physical Android phone. The cloud executor blocked socket access, so Android tool downloads, model download, browser QA and publication could not be completed here.

## What is implemented

Version 1.0.2 adds a dismissible camera/gallery explanation before the first use of each input in a session. Continuing requests camera access through Android/browser controls or opens the system video picker. Cancel and Escape leave the camera/picker closed. Choosing a gallery video grants access to the selected file; broad gallery permissions are not requested. The explanatory prompt is separate from Android permissions, which must be granted on the installed device.

- Camera preview and video recording (automatic stop just under 20 seconds), plus Android/Chrome Gallery selection.
- Uploaded-video duration validation, playback, slow motion, scrubbing and approximate 1/30-second stepping.
- MediaPipe Pose Landmarker integration: actual per-frame pose detection, confidence filtering and skeleton overlay in the video's coordinate system. No demo landmarks or synthetic personal results.
- Camera-dependent elbow-angle and torso-tilt measurements, estimated release cue, manual release correction and timestamped evidence cards. These are limited observations, not a comprehensive validated biomechanics assessment.
- Assisted disc-color tracking from a user-selected disc, both live and from recorded clips. Conservative stop on loss or ambiguity, plus manual timestamped trace points. Not an automatic disc detector or reliable long-flight/3D tracker.
- IndexedDB session storage including video Blob, landmarks, trail, notes and report. Export of original video and analysis JSON. Browser/Android storage can still be cleared; keep backups.
- Eleven editable technique/practice entries with external source links.
- Installable web manifest, service-worker shell cache and offline-pose download controls.
- A native Android launcher/WebView project with camera permission, video picker, native capture fallback and file export. No subscription service or API key is required.

## Run the web app

Install Node.js 22+ and Python 3. From this folder:

```sh
npm test
npm run assets
npm start
```

Open `http://localhost:8080` on the same computer. For phone camera access, deploy `dist/` to an HTTPS static host, then open that HTTPS URL on the phone. An ordinary HTTP LAN address does not permit browser camera access. In Chrome, use menu → Add to Home screen → Install. The app can then appear in the Android launcher. Opening `index.html` directly as a file is not supported because this app uses ES modules, camera secure contexts and IndexedDB.

No npm dependency installation is necessary. `npm run assets` uses curl to fetch pinned MediaPipe 0.10.21 code, WASM and the official pose_landmarker_lite float16 model. If assets are not bundled, the browser tries the pinned CDN. First use then needs internet. Browsers must support modern WebAssembly, ES modules, MediaRecorder and IndexedDB. Camera recording needs permission. Native Android package minimum: Android 10.

## Build using only an Android phone

Use the ZIP-upload workflow in `phone-build/build-apk.yml` and follow `phone-build/PHONE-INSTALL.md`. This route builds a signed release APK on GitHub Actions, keeps the encrypted signing key in your private repository and increments Android version codes for updates. It requires one repository secret, APP_SIGNING_PASSWORD. No computer or local SDK is required. It has not been executed in this environment.

## Build the Android APK on a computer

Use JDK 21, Gradle 8.11.1 and Android SDK platform 35 / build-tools 35.0.0. Set `ANDROID_HOME` to your SDK path, then:

```sh
npm run assets
npm test
npm run android
```

The build script bundles the complete web app and downloaded pose assets. Output: `artifacts/Fairway-Form.apk`. This command builds a debug APK for personal installation. Allow installation from the app you use to open that APK on your phone. It is not a Play Store release. The included GitHub Actions workflow performs the same build and exposes the APK under the run's Artifacts if you push the source to a repository and run the workflow. The workflow has been provided but not executed here.

Android Studio alternative: run `npm run assets`, copy `dist/` into `android/app/src/main/assets/web/`, open the `android/` project, sync Gradle and build the APK.

## How to use

1. Choose throw, hand and camera view. Upload a playable clip of 20 seconds or less, or record one.
2. Choose Analyze. Inference is local; it processes real frames rather than returning a preloaded review. If the pose engine cannot load or visibility is insufficient, no personal result is invented.
3. Inspect the suggested release. Use the scrubber/frame controls and Mark release here to improve the review's anchor.
4. Jump to timestamped evidence, toggle the skeleton, choose one comfortable practice cue and add field notes.
5. To trace a disc, pause near release. Choose Select disc and tap its center. Set radius before selecting. Trace from this frame starts color-based tracking. If it loses the disc or follows a similar object, clear the trail and use Add point by tapping, stepping forward between points.
6. Live tracing: open the camera and select the visible disc. Recording saves the measured trace and pose samples from the recording interval. Live pose and tracking share the phone's processing capacity and may not keep up with fast throws.
7. Save session. Videos remain on this device. Export valuable clips and reports separately.

## Updates and editing

Read `UPDATE-GUIDE.md`. Keep your signing key to update an existing APK without uninstalling. Uninstalling clears app-private sessions. Web installations retrieve versioned service-worker updates from the same HTTPS origin.

## Validation completed here

Twelve direct unit checks passed for image-aspect-corrected geometry, occlusion handling, manual release anchoring for left-handed throws, missing-release rejection, stationary-footage behavior, pose-overlay timestamp separation, visible-color disc movement, lost-target rejection, ambiguity rejection and tracker reset. JavaScript syntax and static file references were also checked. These tests use synthetic geometry/pixels to test algorithms; no synthetic video or findings are exposed in the product.

Not verified: MediaPipe asset fetching/inference, browser/camera end-to-end behavior, Android Gradle compilation, physical device behavior or a production deployment. Physical-device testing with representative disc-golf footage remains essential. Do not interpret passing unit checks as proof of coaching accuracy.
