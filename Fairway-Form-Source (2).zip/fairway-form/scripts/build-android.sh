#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"
if [[ ! -s dist/vendor/pose_landmarker_lite.task ]]; then
 echo 'Offline model missing. Run npm run assets before packaging.' >&2
 exit 1
fi
: "${ANDROID_HOME:?Set ANDROID_HOME to an Android SDK with platform 35 and build-tools 35.0.0.}"
GRADLE_CMD="${GRADLE_CMD:-gradle}"
rm -rf android/app/src/main/assets/web
mkdir -p android/app/src/main/assets/web
cp -R dist/. android/app/src/main/assets/web/
cd android
"$GRADLE_CMD" --no-daemon "${1:-assembleDebug}"
mkdir -p ../artifacts
if [[ "${1:-assembleDebug}" == assembleDebug ]]; then
 cp app/build/outputs/apk/debug/app-debug.apk ../artifacts/Fairway-Form.apk
 echo 'APK ready: artifacts/Fairway-Form.apk'
else
 if [[ -f app/build/outputs/apk/release/app-release.apk ]]; then
  cp app/build/outputs/apk/release/app-release.apk ../artifacts/Fairway-Form.apk
  echo 'Signed APK ready: artifacts/Fairway-Form.apk'
 fi
 echo 'Release output: android/app/build/outputs/apk/release/'
fi
