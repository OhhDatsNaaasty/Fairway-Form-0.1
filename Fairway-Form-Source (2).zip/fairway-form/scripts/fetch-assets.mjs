import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {CDN,MODEL} from '../dist/lib/pose.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
for(const [url,target]of [...['vision_bundle.mjs','wasm/vision_wasm_internal.js','wasm/vision_wasm_internal.wasm','wasm/vision_wasm_nosimd_internal.js','wasm/vision_wasm_nosimd_internal.wasm'].map(p=>[`${CDN}/${p}`,p]),[MODEL,'pose_landmarker_lite.task']]){
 const dest=path.join(root,'dist/vendor',target);await fs.mkdir(path.dirname(dest),{recursive:true});
 try{const s=await fs.stat(dest);if(s.size>1000){console.log('Already available:',target);continue}}catch{}
 console.log('Downloading:',target);
 try{execFileSync('curl',['--fail','--location','--retry','2','--connect-timeout','15','--max-time','180',url,'--output',dest+'.partial'],{stdio:'inherit'});await fs.rename(dest+'.partial',dest)}catch(e){await fs.rm(dest+'.partial',{force:true});throw Error(`Asset download failed: ${target}. Check network access, then rerun npm run assets.`)}
}
// Preserve the upstream license alongside bundled files.
execFileSync('curl',['--fail','--location','--max-time','60',`${CDN}/README.md`,'--output',path.join(root,'dist/vendor/UPSTREAM-README.md')],{stdio:'inherit'});
console.log('Offline pose assets ready.');
