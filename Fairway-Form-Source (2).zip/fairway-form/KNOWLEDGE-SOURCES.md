# Coaching knowledge provenance

The app ships an editable, curated knowledge collection. It is not a trained disc-golf-specific machine-learning model, an exhaustive database of every form, or a certified biomechanics system. Pose detection is provided by the general-purpose MediaPipe model; original application rules interpret a limited set of camera-dependent measurements. Coaching cues are suggestions and the numeric rules are not validated normative cutoffs.

The following sources were located/read during development and are linked in the app where relevant:

- EDGE, Dave Dunipace: [Backhand throw chart](https://edgediscgolf.org/wp-content/uploads/2021/03/Backhand_Throw_Chart.pdf). Body turn, arm unfolding and continuing follow-through.
- PDGA, Scott Stokely: [Three Keys to a Better Sidearm](https://www.pdga.com/news/three-keys-better-sidearm). Forehand instruction.
- Innova: [6 Quick Putting Tips](https://www.innovadiscs.com/tips/6-quick-putting-tips/). Putting practice context.
- Innova: [Get Rolling: The Fundamentals of Throwing Rollers](https://www.innovadiscs.com/tips/get-rolling-the-fundamentals-of-throwing-rollers/). Roller setup and flight/landing context.
- Innova: [Glossary of Disc Golf Terms](https://www.innovadiscs.com/home/disc-golf-faq/glossary-of-terms/). Release-angle terminology.
- Scott Stokely, Disc Golf Discovery: [Thumber](https://discgolfdiscovery.com/Throws/Thumber/). Overhand grip/motion context.
- Google: [Pose landmark detection guide for Web](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker/web_js). Landmark detection and implementation, not disc-golf coaching validation.

Practice drills and explanations were authored for this app; they are not reproduced lessons or endorsements from these organizations. Some sources were available as indexed search excerpts rather than complete pages. No proprietary instructional database was licensed or included. Specialty-throw library coverage does not imply equally detailed automated analysis.

For a more capable coach, collect consented labeled examples with experienced disc-golf coaches; document observable features, necessary camera angles, failure cases and appropriate phrasing for every rule; measure false-positive rates before labeling a movement a fault. Never convert pose-estimation confidence into a form-quality score.
